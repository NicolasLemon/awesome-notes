(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["coursePlay"], {
    "0040": function (A, e, t) {
        "use strict";
        var r = function () {
        };
        A.exports = function (A) {
            return {
                filterToEnabled: function (e, t) {
                    var n = { main: [], facade: [] };
                    return e ? "string" === typeof e && (e = [e]) : e = [], A.forEach((function (A) {
                        A && ("websocket" !== A.transportName || !1 !== t.websocket ? e.length && -1 === e.indexOf(A.transportName) ? r("not in whitelist", A.transportName) : A.enabled(t) ? (r("enabled", A.transportName), n.main.push(A), A.facadeTransport && n.facade.push(A.facadeTransport)) : r("disabled", A.transportName) : r("disabled from server", "websocket"))
                    })), n
                }
            }
        }
    }, "0e88": function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("ada0").EventEmitter, i = function () {
        };

        function s(A, e, t) {
            i(e), n.call(this), this.Receiver = A, this.receiveUrl = e, this.AjaxObject = t, this._scheduleReceiver()
        }

        r(s, n), s.prototype._scheduleReceiver = function () {
            i("_scheduleReceiver");
            var A = this, e = this.poll = new this.Receiver(this.receiveUrl, this.AjaxObject);
            e.on("message", (function (e) {
                i("message", e), A.emit("message", e)
            })), e.once("close", (function (t, r) {
                i("close", t, r, A.pollIsClosing), A.poll = e = null, A.pollIsClosing || ("network" === r ? A._scheduleReceiver() : (A.emit("close", t || 1006, r), A.removeAllListeners()))
            }))
        }, s.prototype.abort = function () {
            i("abort"), this.removeAllListeners(), this.pollIsClosing = !0, this.poll && this.poll.abort()
        }, A.exports = s
    }, 1015: function (A, e) {
        A.exports = "1.4.0"
    }, "103f": function (A, e, t) {
    }, "12ef": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAACthJREFUeF7tnU/MHVUZh39vAmUBGmw0kZDoho1oAiwUFoALamADikGDKFBii0YCTdghW//sCEo0FirQoLEBBYUV2iZiuyC6ABJlxUYTgokEiMICMHnNaa7pZ22/O/e9c+/M3N8z6/OeOe/znuebb+bOnBPigAAETksgYAMBCJyeAIIwOyCwDQEEYXpAAEGYAxCoEeAKUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEECQNRc6MxvzCyVdIOnjkj4qaaekcyTtmA3nPUlvS3pD0muS/ibpFUkvR0SuecjWp0OQFZc/Mz8kaZekKyRdJukSSWcUT/tvSS9Iel7SHyQdiYg3i30R1oEAgnSAtGiTzPywpC9Lun4mx6JdLNL+sKSnJD0eEa8vEkjb+QQQZD6jzi0y8ypJeyTd2Dmo34aHJB2IiCP9duvbG4L0UPvMvEHSPkmX99BdH10clXR/RDzZR2fOfSDIEtXPzKsl3Tu7v1iip5WFPifpOxHR/g3jKBBAkAK0zDxf0vcl3VwIHyLkoKR7IqI9EeNYgACCLACrNc3Mr0u6T9IHFwwduvlbku6OiEeGHsiUzo8gHauVmWdJ2i/p1o4hY23WBPlGRLw/1gGOaVwI0qEamXmxpEclXdSh+RSavChpd0S8NIXBDjlGBJlDPzOvlfQLSWcPWagVnLv9Un9TRDyzgr43pksE2aaUmdn+nWpXjk0+2pWk3cRznIIAgpxmWmTmXkkPmsya2yPiIZNcF0oTQU6By+TKcXLmXEm4gsz/4zG753h6fsuNbHEd9yT/W1euIFt4ZGZ7SnVs9ur5RhowJ6l32usyEdGecnFIQpDZNMjMMyX9UVJ7pOt8tEe/l0bEu84Q/ps7gpwQ5GFJtzEpjhM4GBG7YcEV5PgcyMwmRhOE4wSBPRHxU3cg9leQzDyvfcoq6Vz3yXBS/v9snwZHxKvOXBAks/0QOPX3q1Y1hx+LiFtW1fkU+rUWJDPbt+K/m0KhBhzjNRHx7IDnH/TU7oL8XtJnB63A+E9+NCKuHP8wVzNCW0Ey84uSfrUarBvX65ci4pcbl1WHhJwFacvmtKV4OOYTOBYRlqwsBZmtPsJ32vPF2Npil+NqKa6CtO87hlqaZ7FpOZ7WhyLiK+MZznpGYifIbFG3f6wH78ad5SNui9M5CvItST/auKm7noTuiIgfr+dU4ziLoyDtd4/2+wfH4gQOR8TnFg+bboSVILOFpNuK6Rx1AjudFsx2E6QtEfpEfW4QKcnqNxE3QX4o6U6m+VIEHoiIu5bqYULBboK0D6I+PaH6jHGof4qIz4xxYKsYk40gs52d2s5N1c1rVsF/in22TXx2uOx05STIJyX9eYozcoRj/lRE/GWE4+p9SE6CfF7Sr3sn6NnhFyLiNw6pOwnSbs7bTTrH8gT2RYQFSydBvtf2yFh+btBD2xslIr7tQMJJkJ+0Zf8dirqGHPdHxDfXcJ7BT+EkyM8kfXVw4psxgJ9HxNc2I5Xts3AS5PH2K7BDUdeQ4xMR0ba53vgDQTa+xCtJEEFWgnXATjOTf7H648+/WP2xHEdPmclNen+l4Ca9P5bj6CkzeczbXyl4zNsfy3H0lJntDdQfjGM0kx/FXRHxwOSz6JCA0006r5p0mBAdm/CqSUdQk2mWmbys2F+1eFmxP5bj6InX3XurA6+794ZyZB1lJh9MLV8TPphanuE4e8hMPrldvjR8crs8w3H2kJntVZP2yglHnQCLNtTZjTuSZX96qQ/L/vSCcaSdZCYLx9Vrw8JxdXbTiMxMlh6tl4qlR+vsphHJ4tVL1YnFq5fCN5HgzGT7g8VrxfYHizObZgQb6JTqxgY6JWwTDcpMtmDrXju2YOvOajNasonnQnW0+u1jKxmbt3lPNR0yk22g53vCNtDzGW1mi8xsm8H8djOz6y2rayLi2d56m1hH1leQVqvMfFTSrROr27qG+1hE3LKuk43xPAiSeZ6klyWdO8YCDTimf0n6RES8OuAYBj+1vSCzq8htkh4evBrjGsDeiDgwriGtfzQIMmOemU2QJgqHdDAidgNCQpATgpwpqX1QdbH5xHhJ0qUR8a45h+PpI8iWWZCZF0k6Jukc08nxjqTLI+JF0/z/L20EOQlJZl4r6WnTCXJdRDxjmvsp00aQU2DJzPbYtz3+dTp2R8RBp4S75Iogp6GUmXslPdgF4ga0uT0iHtqAPHpPAUG2QWpyJeHKsc0cQJA5f3Nm9yTt+5Gze//zNGyHb0u6iXuO7YuAIB0maWa2R7/tnqQ95dqEoz2laleO9kiXgyvI8nMgM8+StH8D3tt6pO3VGBHvL09l83vgCrJgjTNzj6T7JH1gwdChm78l6e6IaIJwdCSAIB1BbW2Wmee3rZAl3VwIHyKkPb69JyJeG+LkUz4ngixRvcy8WtK9kq5YoptVhj4n6bsR0dYC4ygQQJACtJNDMvMGSfvaaxo9dNdHF0cl3R8RT/bRmXMfCNJj9WerpbR7lBt77HaRrg5JOhARRxYJou3pCSDICmbHbHG6to/49ZJ2reAUW7s8LOmptih3RLy+4nPZdY8gKy75bMHsqyRdKekySZdIOqN42rZ5zQuSnpfUli06EhFvFvsirAMBBOkAqc8ms52uLpR0gaSPSWqf/O6cvWK/Y3au9yS1X7rfkPR3SX+V9Er7NDgiss/x0Nf2BBCEGQKBbQggCNMDAgjCHIBAjQBXkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAv8B2wLU2F3C5UUAAAAASUVORK5CYII="
    }, "13c0": function (A, e, t) {
        "use strict";
        (function (e) {
            var t = e.WebSocket || e.MozWebSocket;
            A.exports = t ? function (A) {
                return new t(A)
            } : void 0
        }).call(this, t("c8ba"))
    }, 1548: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("ada0").EventEmitter, i = function () {
        };

        function s(A, e) {
            i(A), n.call(this);
            var t = this;
            this.bufferPosition = 0, this.xo = new e("POST", A, null), this.xo.on("chunk", this._chunkHandler.bind(this)), this.xo.once("finish", (function (A, e) {
                i("finish", A, e), t._chunkHandler(A, e), t.xo = null;
                var r = 200 === A ? "network" : "permanent";
                i("close", r), t.emit("close", null, r), t._cleanup()
            }))
        }

        r(s, n), s.prototype._chunkHandler = function (A, e) {
            if (i("_chunkHandler", A), 200 === A && e) for (var t = -1; ; this.bufferPosition += t + 1) {
                var r = e.slice(this.bufferPosition);
                if (t = r.indexOf("\n"), -1 === t) break;
                var n = r.slice(0, t);
                n && (i("message", n), this.emit("message", n))
            }
        }, s.prototype._cleanup = function () {
            i("_cleanup"), this.removeAllListeners()
        }, s.prototype.abort = function () {
            i("abort"), this.xo && (this.xo.close(), i("close"), this.emit("close", null, "user"), this.xo = null), this._cleanup()
        }, A.exports = s
    }, "15ba": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAKKADAAQAAAABAAAAKAAAAABZLkSWAAAB+UlEQVRYCe2WvUrEQBDHLyKKhSAogoUnovgJvoDvoI2tja0IlloIgoJgLZaWvoCIT2CrnahY+FWI2lkoCsbf6F7IXXK3s6uJV2RhmM3szPz/mZkNKZWKVVTgfysQ2ODDMFzEZ9rmpzh/xGcnCIIrhW/k0hLt6m/+gpxk70VWeeHh+lDJE00F903YHvoumcJqmcNjMub1yn5LW8nWWKBte0vSS5tT7TkVezG2E3QZ6UGkkiqSmhab/L9Wz2TYQER3IKp250mwRAeeXEnmShBy9UgOyVnacpnBtHgX2yhzNx8LuGYv8yjtXkKWkcTKg+CHQR1Ai6Qt+QSlrjwIHoAsn7O2FAad2MZT7JEpc4JcjHvQdiPE2IaWj/C4HjMltrlfkgQDi6EgaCmQ9bjpK+h9SRjwGV5/ylqCaodTLs1htanxkxdByEnlZxH5yLqsQWKPIPmpDfIiKAAAbQMygVh/2QyZEH3uQk7ivAhKIEAXKJFMV9NfkqYn6N1iZlBmr92lv4zFm4u/+HoTJHYNGZMk2sVLnUFyU+svfl4tNtXrcgEyvt0mVh3qVUGqAE64AkqfGunH8UFiXWK8CAoAQO+oGxcwH1+vFvsA+cYUBH0rV4lzmcGy6w2sgDTQ/Q3Ovo9cCC7YkmVxrpnB4yyAa3LmgVEDWTwWFdBV4Av/IG+Sf2qUhwAAAABJRU5ErkJggg=="
    }, 1816: function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("440d"), n = t("9c59"), i = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
                s = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\S\s]*)/i,
                o = "[\\x09\\x0A\\x0B\\x0C\\x0D\\x20\\xA0\\u1680\\u180E\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200A\\u202F\\u205F\\u3000\\u2028\\u2029\\uFEFF]",
                a = new RegExp("^" + o + "+");

            function c(A) {
                return (A || "").toString().replace(a, "")
            }

            var l = [["#", "hash"], ["?", "query"], function (A) {
                return A.replace("\\", "/")
            }, ["/", "pathname"], ["@", "auth", 1], [NaN, "host", void 0, 1, 1], [/:(\d+)$/, "port", void 0, 1], [NaN, "hostname", void 0, 1, 1]],
                u = { hash: 1, query: 1 };

            function d(A) {
                var t;
                t = "undefined" !== typeof window ? window : "undefined" !== typeof e ? e : "undefined" !== typeof self ? self : {};
                var r = t.location || {};
                A = A || r;
                var n, s = {}, o = typeof A;
                if ("blob:" === A.protocol) s = new g(unescape(A.pathname), {}); else if ("string" === o) for (n in s = new g(A, {}), u) delete s[n]; else if ("object" === o) {
                    for (n in A) n in u || (s[n] = A[n]);
                    void 0 === s.slashes && (s.slashes = i.test(A.href))
                }
                return s
            }

            function B(A) {
                A = c(A);
                var e = s.exec(A);
                return { protocol: e[1] ? e[1].toLowerCase() : "", slashes: !!e[2], rest: e[3] }
            }

            function h(A, e) {
                if ("" === A) return e;
                var t = (e || "/").split("/").slice(0, -1).concat(A.split("/")), r = t.length, n = t[r - 1], i = !1,
                    s = 0;
                while (r--) "." === t[r] ? t.splice(r, 1) : ".." === t[r] ? (t.splice(r, 1), s++) : s && (0 === r && (i = !0), t.splice(r, 1), s--);
                return i && t.unshift(""), "." !== n && ".." !== n || t.push(""), t.join("/")
            }

            function g(A, e, t) {
                if (A = c(A), !(this instanceof g)) return new g(A, e, t);
                var i, s, o, a, u, p, f = l.slice(), w = typeof e, C = this, m = 0;
                for ("object" !== w && "string" !== w && (t = e, e = null), t && "function" !== typeof t && (t = n.parse), e = d(e), s = B(A || ""), i = !s.protocol && !s.slashes, C.slashes = s.slashes || i && e.slashes, C.protocol = s.protocol || e.protocol || "", A = s.rest, s.slashes || (f[3] = [/(.*)/, "pathname"]); m < f.length; m++) a = f[m], "function" !== typeof a ? (o = a[0], p = a[1], o !== o ? C[p] = A : "string" === typeof o ? ~(u = A.indexOf(o)) && ("number" === typeof a[2] ? (C[p] = A.slice(0, u), A = A.slice(u + a[2])) : (C[p] = A.slice(u), A = A.slice(0, u))) : (u = o.exec(A)) && (C[p] = u[1], A = A.slice(0, u.index)), C[p] = C[p] || i && a[3] && e[p] || "", a[4] && (C[p] = C[p].toLowerCase())) : A = a(A);
                t && (C.query = t(C.query)), i && e.slashes && "/" !== C.pathname.charAt(0) && ("" !== C.pathname || "" !== e.pathname) && (C.pathname = h(C.pathname, e.pathname)), r(C.port, C.protocol) || (C.host = C.hostname, C.port = ""), C.username = C.password = "", C.auth && (a = C.auth.split(":"), C.username = a[0] || "", C.password = a[1] || ""), C.origin = C.protocol && C.host && "file:" !== C.protocol ? C.protocol + "//" + C.host : "null", C.href = C.toString()
            }

            function p(A, e, t) {
                var i = this;
                switch (A) {
                    case "query":
                        "string" === typeof e && e.length && (e = (t || n.parse)(e)), i[A] = e;
                        break;
                    case "port":
                        i[A] = e, r(e, i.protocol) ? e && (i.host = i.hostname + ":" + e) : (i.host = i.hostname, i[A] = "");
                        break;
                    case "hostname":
                        i[A] = e, i.port && (e += ":" + i.port), i.host = e;
                        break;
                    case "host":
                        i[A] = e, /:\d+$/.test(e) ? (e = e.split(":"), i.port = e.pop(), i.hostname = e.join(":")) : (i.hostname = e, i.port = "");
                        break;
                    case "protocol":
                        i.protocol = e.toLowerCase(), i.slashes = !t;
                        break;
                    case "pathname":
                    case "hash":
                        if (e) {
                            var s = "pathname" === A ? "/" : "#";
                            i[A] = e.charAt(0) !== s ? s + e : e
                        } else i[A] = e;
                        break;
                    default:
                        i[A] = e
                }
                for (var o = 0; o < l.length; o++) {
                    var a = l[o];
                    a[4] && (i[a[1]] = i[a[1]].toLowerCase())
                }
                return i.origin = i.protocol && i.host && "file:" !== i.protocol ? i.protocol + "//" + i.host : "null", i.href = i.toString(), i
            }

            function f(A) {
                A && "function" === typeof A || (A = n.stringify);
                var e, t = this, r = t.protocol;
                r && ":" !== r.charAt(r.length - 1) && (r += ":");
                var i = r + (t.slashes ? "//" : "");
                return t.username && (i += t.username, t.password && (i += ":" + t.password), i += "@"), i += t.host + t.pathname, e = "object" === typeof t.query ? A(t.query) : t.query, e && (i += "?" !== e.charAt(0) ? "?" + e : e), t.hash && (i += t.hash), i
            }

            g.prototype = {
                set: p,
                toString: f
            }, g.extractProtocol = B, g.location = d, g.trimLeft = c, g.qs = n, A.exports = g
        }).call(this, t("c8ba"))
    }, "1c4c": function (A, e, t) {
        "use strict";
        var r = t("9b43"), n = t("5ca1"), i = t("4bf8"), s = t("1fa8"), o = t("33a4"), a = t("9def"), c = t("f1ae"),
            l = t("27ee");
        n(n.S + n.F * !t("5cc5")((function (A) {
            Array.from(A)
        })), "Array", {
            from: function (A) {
                var e, t, n, u, d = i(A), B = "function" == typeof this ? this : Array, h = arguments.length,
                    g = h > 1 ? arguments[1] : void 0, p = void 0 !== g, f = 0, w = l(d);
                if (p && (g = r(g, h > 2 ? arguments[2] : void 0, 2)), void 0 == w || B == Array && o(w)) for (e = a(d.length), t = new B(e); e > f; f++) c(t, f, p ? g(d[f], f) : d[f]); else for (u = w.call(d), t = new B; !(n = u.next()).done; f++) c(t, f, p ? s(u, g, [n.value, f], !0) : n.value);
                return t.length = f, t
            }
        })
    }, 2582: function (A, e, t) {
        "use strict";
        var r = t("cfe6"), n = "abcdefghijklmnopqrstuvwxyz012345";
        A.exports = {
            string: function (A) {
                for (var e = n.length, t = r.randomBytes(A), i = [], s = 0; s < A; s++) i.push(n.substr(t[s] % e, 1));
                return i.join("")
            }, number: function (A) {
                return Math.floor(Math.random() * A)
            }, numberString: function (A) {
                var e = ("" + (A - 1)).length, t = new Array(e + 1).join("0");
                return (t + this.number(A)).slice(-e)
            }
        }
    }, "26a0": function (A, e, t) {
        "use strict";
        (function (e) {
            A.exports = {
                isOpera: function () {
                    return e.navigator && /opera/i.test(e.navigator.userAgent)
                }, isKonqueror: function () {
                    return e.navigator && /konqueror/i.test(e.navigator.userAgent)
                }, hasDomain: function () {
                    if (!e.document) return !0;
                    try {
                        return !!e.document.domain
                    } catch (A) {
                        return !1
                    }
                }
            }
        }).call(this, t("c8ba"))
    }, "26e3": function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("3fb5"), n = t("9f3a"), i = t("d5e5");
            A.exports = function (A) {
                function t(e, t) {
                    n.call(this, A.transportName, e, t)
                }

                return r(t, n), t.enabled = function (t, r) {
                    if (!e.document) return !1;
                    var s = i.extend({}, r);
                    return s.sameOrigin = !0, A.enabled(s) && n.enabled()
                }, t.transportName = "iframe-" + A.transportName, t.needBody = !0, t.roundTrips = n.roundTrips + A.roundTrips - 1, t.facadeTransport = A, t
            }
        }).call(this, t("c8ba"))
    }, "2d5a": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAAEiUlEQVRoBe2Z3WsVRxjGn2M+jEkTm5ho4hcVsSBeVArmxt6L+AdoL6zohWiroSoIQQrthaKFCvUqYMCPk96IoqipiOmFWgN6EaP0pihSiCClfiV+NG2Ss77PoZOz8Zw9O7M7exbKDExm8p7deX7z7Dtz9uzC87wFUquQUpkluh9IXSIQ9WkwEICFDnQIRJtUFct/kPSf98WaRHCxQNQlLazGfx+A8RqpiwSiRWpGHZhUWwpAaTVLh27UqkASbTkA6lGcCfphUm6EAahJz5POQoHg5bFadAEoysSkG0xUa8UEgKJMSi5VLtlqGxSmAEqTmxbdaFCBqG1UAOrx3HaBmC818jiRT/TNuFH6dGOOL6bdtQFAMeYDV0mrqRu2ANSM50qHm9dsFQhrbQNQj3sFIZqlhm7lSQCoSbdIh98pZbfyJAEIwktBN3hpSpakASjKy8DkZJIWbV6VAFAz5zLlcuUd2HSpJABFqcd7UH7V50ulAZQub3a4geWJVLDSLfOiKi0H1OQb0wQgREPaADVpA6SaA/mkT9uBVJehc8A54BxwDjgHnAPOAeeAc8Dcgf1XsSJ/lsU/2jelnT3oyt7D5fWnsMGivt5NKcVHRtEFD1XDf+KoTYhQB2j7yBi+mp61ZYhQgO/X4cGnHdgrzzmmkoAIBaBo/2b0B0FsyMbLCS0ABbF6QbETQ09wNA6ENgAhrmxBv20II4AkIIwBbENEArAJERnAFkQsABsQsQEIUVeDcdmmPfZVyXiYaqjBmPo/qI0NsPEMPrv9GMdEwP8ceLJzKbrObMLNIGEVjwXwxXms+fUP9Hhe/qm4GjO3uh37LnyOARUo1/qpyx1X9NmOi/hk4AGOi3jhRXcG3qo2dHPDKjohIBDJga9/xspLv+OEiM948v1xK74b2IpzAVolw8YOdF/D8rO/4WTOw4w3qMuacfj6NvSVVCkTNHLg0HUszQ4jO+WB75Kny5K5ODa4Hb3TAYOONsAPt9DRcwd9UznM94/f3ojjd3bkV4E/rN3XAugdQtuPg8hO5LDQP3JbA/rufokj/phpXwvgyA0cFPGP/IO31OPs/V341h+L0tcC2LMW39RW45ESaKrD5aHd6Fb/x2kz8tZiuc4APw2j5cAvOF1bhZHBndjVOtt3j6gzQMAx2gA8/+JDNK1sxviKefg3YDzjsBGA8egaJ2jlgMY4kQ9xAM4B54BzwDngHHAOOAecA86BtB3IpQ0wmTbA27QBxtIEeJnJZCbSAngrP6We8+eU8TOiyL/BCie+lO5zmX3+wWYlASZE+C8R/rvAUhkHONMXUnnNZzzOJUjSDnC2T0U48HlCUgC5/4RfcZblShIAFH0msy685itDYBOASUa7ucS0iy0AlWS03qjEBRgXNS6twCQLo4kKwJk+k/pKxIuWVpio//MoAG9kAF7rSf9AUfsmABSkMAGsFV2AUVHk/m2cZGGkYQD/yABMMraJlCAAJha/LkdFPFaShVGXAuBGwllbSTITAG6dTLLXYSfZ/Fw5wDec3L+tJ1korLwvKLz3Cz36f3jAO1LnaxkaiWUtAAAAAElFTkSuQmCC"
    }, "397f": function (A, e, t) {
        "use strict";
        var r = t("c282"), n = t("621f"), i = t("3fb5"), s = t("ada0").EventEmitter, o = t("13c0"), a = function () {
        };

        function c(A, e, t) {
            if (!c.enabled()) throw new Error("Transport created when disabled");
            s.call(this), a("constructor", A);
            var i = this, l = n.addPath(A, "/websocket");
            l = "https" === l.slice(0, 5) ? "wss" + l.slice(5) : "ws" + l.slice(4), this.url = l, this.ws = new o(this.url, [], t), this.ws.onmessage = function (A) {
                a("message event", A.data), i.emit("message", A.data)
            }, this.unloadRef = r.unloadAdd((function () {
                a("unload"), i.ws.close()
            })), this.ws.onclose = function (A) {
                a("close event", A.code, A.reason), i.emit("close", A.code, A.reason), i._cleanup()
            }, this.ws.onerror = function (A) {
                a("error event", A), i.emit("close", 1006, "WebSocket connection broken"), i._cleanup()
            }
        }

        i(c, s), c.prototype.send = function (A) {
            var e = "[" + A + "]";
            a("send", e), this.ws.send(e)
        }, c.prototype.close = function () {
            a("close");
            var A = this.ws;
            this._cleanup(), A && A.close()
        }, c.prototype._cleanup = function () {
            a("_cleanup");
            var A = this.ws;
            A && (A.onmessage = A.onclose = A.onerror = null), r.unloadDel(this.unloadRef), this.unloadRef = this.ws = null, this.removeAllListeners()
        }, c.enabled = function () {
            return a("enabled"), !!o
        }, c.transportName = "websocket", c.roundTrips = 2, A.exports = c
    }, "3e1e": function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("3fb5"), n = t("7577"), i = t("1548"), s = t("df09"), o = t("73aa"), a = t("26a0");

            function c(A) {
                if (!o.enabled && !s.enabled) throw new Error("Transport created when disabled");
                n.call(this, A, "/xhr_streaming", i, s)
            }

            r(c, n), c.enabled = function (A) {
                return !A.nullOrigin && (!a.isOpera() && s.enabled)
            }, c.transportName = "xhr-streaming", c.roundTrips = 2, c.needBody = !!e.document, A.exports = c
        }).call(this, t("c8ba"))
    }, "3fb5": function (A, e) {
        "function" === typeof Object.create ? A.exports = function (A, e) {
            e && (A.super_ = e, A.prototype = Object.create(e.prototype, {
                constructor: {
                    value: A,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }))
        } : A.exports = function (A, e) {
            if (e) {
                A.super_ = e;
                var t = function () {
                };
                t.prototype = e.prototype, A.prototype = new t, A.prototype.constructor = A
            }
        }
    }, "40b2": function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("54d6"), i = t("73aa"), s = t("7577");

        function o(A) {
            if (!n.enabled) throw new Error("Transport created when disabled");
            s.call(this, A, "/htmlfile", n, i)
        }

        r(o, s), o.enabled = function (A) {
            return n.enabled && A.sameOrigin
        }, o.transportName = "htmlfile", o.roundTrips = 2, A.exports = o
    }, 4127: function (A, e, t) {
        "use strict";
        var r = t("d233"), n = t("b313"), i = {
            brackets: function (A) {
                return A + "[]"
            }, indices: function (A, e) {
                return A + "[" + e + "]"
            }, repeat: function (A) {
                return A
            }
        }, s = Date.prototype.toISOString, o = {
            delimiter: "&", encode: !0, encoder: r.encode, encodeValuesOnly: !1, serializeDate: function (A) {
                return s.call(A)
            }, skipNulls: !1, strictNullHandling: !1
        }, a = function A(e, t, n, i, s, a, c, l, u, d, B, h) {
            var g = e;
            if ("function" === typeof c) g = c(t, g); else if (g instanceof Date) g = d(g); else if (null === g) {
                if (i) return a && !h ? a(t, o.encoder) : t;
                g = ""
            }
            if ("string" === typeof g || "number" === typeof g || "boolean" === typeof g || r.isBuffer(g)) {
                if (a) {
                    var p = h ? t : a(t, o.encoder);
                    return [B(p) + "=" + B(a(g, o.encoder))]
                }
                return [B(t) + "=" + B(String(g))]
            }
            var f, w = [];
            if ("undefined" === typeof g) return w;
            if (Array.isArray(c)) f = c; else {
                var C = Object.keys(g);
                f = l ? C.sort(l) : C
            }
            for (var m = 0; m < f.length; ++m) {
                var Q = f[m];
                s && null === g[Q] || (w = Array.isArray(g) ? w.concat(A(g[Q], n(t, Q), n, i, s, a, c, l, u, d, B, h)) : w.concat(A(g[Q], t + (u ? "." + Q : "[" + Q + "]"), n, i, s, a, c, l, u, d, B, h)))
            }
            return w
        };
        A.exports = function (A, e) {
            var t = A, s = e ? r.assign({}, e) : {};
            if (null !== s.encoder && void 0 !== s.encoder && "function" !== typeof s.encoder) throw new TypeError("Encoder has to be a function.");
            var c = "undefined" === typeof s.delimiter ? o.delimiter : s.delimiter,
                l = "boolean" === typeof s.strictNullHandling ? s.strictNullHandling : o.strictNullHandling,
                u = "boolean" === typeof s.skipNulls ? s.skipNulls : o.skipNulls,
                d = "boolean" === typeof s.encode ? s.encode : o.encode,
                B = "function" === typeof s.encoder ? s.encoder : o.encoder,
                h = "function" === typeof s.sort ? s.sort : null, g = "undefined" !== typeof s.allowDots && s.allowDots,
                p = "function" === typeof s.serializeDate ? s.serializeDate : o.serializeDate,
                f = "boolean" === typeof s.encodeValuesOnly ? s.encodeValuesOnly : o.encodeValuesOnly;
            if ("undefined" === typeof s.format) s.format = n["default"]; else if (!Object.prototype.hasOwnProperty.call(n.formatters, s.format)) throw new TypeError("Unknown format option provided.");
            var w, C, m = n.formatters[s.format];
            "function" === typeof s.filter ? (C = s.filter, t = C("", t)) : Array.isArray(s.filter) && (C = s.filter, w = C);
            var Q, y = [];
            if ("object" !== typeof t || null === t) return "";
            Q = s.arrayFormat in i ? s.arrayFormat : "indices" in s ? s.indices ? "indices" : "repeat" : "indices";
            var U = i[Q];
            w || (w = Object.keys(t)), h && w.sort(h);
            for (var v = 0; v < w.length; ++v) {
                var F = w[v];
                u && null === t[F] || (y = y.concat(a(t[F], F, U, l, u, d ? B : null, C, h, g, p, m, f)))
            }
            var I = y.join(c), E = !0 === s.addQueryPrefix ? "?" : "";
            return I.length > 0 ? E + I : ""
        }
    }, 4328: function (A, e, t) {
        "use strict";
        var r = t("4127"), n = t("9e6a"), i = t("b313");
        A.exports = { formats: i, parse: n, stringify: r }
    }, "440d": function (A, e, t) {
        "use strict";
        A.exports = function (A, e) {
            if (e = e.split(":")[0], A = +A, !A) return !1;
            switch (e) {
                case "http":
                case "ws":
                    return 80 !== A;
                case "https":
                case "wss":
                    return 443 !== A;
                case "ftp":
                    return 21 !== A;
                case "gopher":
                    return 70 !== A;
                case "file":
                    return !1
            }
            return 0 !== A
        }
    }, "47e4": function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("9a833");

        function i(A) {
            n.call(this), this.initEvent("message", !1, !1), this.data = A
        }

        r(i, n), A.exports = i
    }, 4812: function (A, e, t) {
        "use strict";
        var r = t("8a92"), n = t.n(r);
        n.a
    }, "486c": function (A, e, t) {
        "use strict";
        (function (e) {
            t("7725");
            var r, n = t("1816"), i = t("3fb5"), s = t("930c"), o = t("2582"), a = t("84fc"), c = t("621f"),
                l = t("c282"), u = t("0040"), d = t("d5e5"), B = t("26a0"), h = t("48cd"), g = t("9a833"),
                p = t("97a2"), f = t("a0e2"), w = t("e362"), C = t("47e4"), m = t("b9a8"), Q = function () {
                };

            function y(A, e, t) {
                if (!(this instanceof y)) return new y(A, e, t);
                if (arguments.length < 1) throw new TypeError("Failed to construct 'SockJS: 1 argument required, but only 0 present");
                p.call(this), this.readyState = y.CONNECTING, this.extensions = "", this.protocol = "", t = t || {}, t.protocols_whitelist && h.warn("'protocols_whitelist' is DEPRECATED. Use 'transports' instead."), this._transportsWhitelist = t.transports, this._transportOptions = t.transportOptions || {}, this._timeout = t.timeout || 0;
                var r = t.sessionId || 8;
                if ("function" === typeof r) this._generateSessionId = r; else {
                    if ("number" !== typeof r) throw new TypeError("If sessionId is used in the options, it needs to be a number or a function.");
                    this._generateSessionId = function () {
                        return o.string(r)
                    }
                }
                this._server = t.server || o.numberString(1e3);
                var i = new n(A);
                if (!i.host || !i.protocol) throw new SyntaxError("The URL '" + A + "' is invalid");
                if (i.hash) throw new SyntaxError("The URL must not contain a fragment");
                if ("http:" !== i.protocol && "https:" !== i.protocol) throw new SyntaxError("The URL's scheme must be either 'http:' or 'https:'. '" + i.protocol + "' is not allowed.");
                var s = "https:" === i.protocol;
                if ("https:" === f.protocol && !s) throw new Error("SecurityError: An insecure SockJS connection may not be initiated from a page loaded over HTTPS");
                e ? Array.isArray(e) || (e = [e]) : e = [];
                var a = e.sort();
                a.forEach((function (A, e) {
                    if (!A) throw new SyntaxError("The protocols entry '" + A + "' is invalid.");
                    if (e < a.length - 1 && A === a[e + 1]) throw new SyntaxError("The protocols entry '" + A + "' is duplicated.")
                }));
                var l = c.getOrigin(f.href);
                this._origin = l ? l.toLowerCase() : null, i.set("pathname", i.pathname.replace(/\/+$/, "")), this.url = i.href, Q("using url", this.url), this._urlInfo = {
                    nullOrigin: !B.hasDomain(),
                    sameOrigin: c.isOriginEqual(this.url, f.href),
                    sameScheme: c.isSchemeEqual(this.url, f.href)
                }, this._ir = new m(this.url, this._urlInfo), this._ir.once("finish", this._receiveInfo.bind(this))
            }

            function U(A) {
                return 1e3 === A || A >= 3e3 && A <= 4999
            }

            i(y, p), y.prototype.close = function (A, e) {
                if (A && !U(A)) throw new Error("InvalidAccessError: Invalid code");
                if (e && e.length > 123) throw new SyntaxError("reason argument has an invalid length");
                if (this.readyState !== y.CLOSING && this.readyState !== y.CLOSED) {
                    var t = !0;
                    this._close(A || 1e3, e || "Normal closure", t)
                }
            }, y.prototype.send = function (A) {
                if ("string" !== typeof A && (A = "" + A), this.readyState === y.CONNECTING) throw new Error("InvalidStateError: The connection has not been established yet");
                this.readyState === y.OPEN && this._transport.send(a.quote(A))
            }, y.version = t("1015"), y.CONNECTING = 0, y.OPEN = 1, y.CLOSING = 2, y.CLOSED = 3, y.prototype._receiveInfo = function (A, e) {
                if (Q("_receiveInfo", e), this._ir = null, A) {
                    this._rto = this.countRTO(e), this._transUrl = A.base_url ? A.base_url : this.url, A = d.extend(A, this._urlInfo), Q("info", A);
                    var t = r.filterToEnabled(this._transportsWhitelist, A);
                    this._transports = t.main, Q(this._transports.length + " enabled transports"), this._connect()
                } else this._close(1002, "Cannot connect to server")
            }, y.prototype._connect = function () {
                for (var A = this._transports.shift(); A; A = this._transports.shift()) {
                    if (Q("attempt", A.transportName), A.needBody && (!e.document.body || "undefined" !== typeof e.document.readyState && "complete" !== e.document.readyState && "interactive" !== e.document.readyState)) return Q("waiting for body"), this._transports.unshift(A), void l.attachEvent("load", this._connect.bind(this));
                    var t = Math.max(this._timeout, this._rto * A.roundTrips || 5e3);
                    this._transportTimeoutId = setTimeout(this._transportTimeout.bind(this), t), Q("using timeout", t);
                    var r = c.addPath(this._transUrl, "/" + this._server + "/" + this._generateSessionId()),
                        n = this._transportOptions[A.transportName];
                    Q("transport url", r);
                    var i = new A(r, this._transUrl, n);
                    return i.on("message", this._transportMessage.bind(this)), i.once("close", this._transportClose.bind(this)), i.transportName = A.transportName, void (this._transport = i)
                }
                this._close(2e3, "All transports failed", !1)
            }, y.prototype._transportTimeout = function () {
                Q("_transportTimeout"), this.readyState === y.CONNECTING && (this._transport && this._transport.close(), this._transportClose(2007, "Transport timed out"))
            }, y.prototype._transportMessage = function (A) {
                Q("_transportMessage", A);
                var e, t = this, r = A.slice(0, 1), n = A.slice(1);
                switch (r) {
                    case "o":
                        return void this._open();
                    case "h":
                        return this.dispatchEvent(new g("heartbeat")), void Q("heartbeat", this.transport)
                }
                if (n) try {
                    e = s.parse(n)
                } catch (i) {
                    Q("bad json", n)
                }
                if ("undefined" !== typeof e) switch (r) {
                    case "a":
                        Array.isArray(e) && e.forEach((function (A) {
                            Q("message", t.transport, A), t.dispatchEvent(new C(A))
                        }));
                        break;
                    case "m":
                        Q("message", this.transport, e), this.dispatchEvent(new C(e));
                        break;
                    case "c":
                        Array.isArray(e) && 2 === e.length && this._close(e[0], e[1], !0);
                        break
                } else Q("empty payload", n)
            }, y.prototype._transportClose = function (A, e) {
                Q("_transportClose", this.transport, A, e), this._transport && (this._transport.removeAllListeners(), this._transport = null, this.transport = null), U(A) || 2e3 === A || this.readyState !== y.CONNECTING ? this._close(A, e) : this._connect()
            }, y.prototype._open = function () {
                Q("_open", this._transport && this._transport.transportName, this.readyState), this.readyState === y.CONNECTING ? (this._transportTimeoutId && (clearTimeout(this._transportTimeoutId), this._transportTimeoutId = null), this.readyState = y.OPEN, this.transport = this._transport.transportName, this.dispatchEvent(new g("open")), Q("connected", this.transport)) : this._close(1006, "Server lost session")
            }, y.prototype._close = function (A, e, t) {
                Q("_close", this.transport, A, e, t, this.readyState);
                var r = !1;
                if (this._ir && (r = !0, this._ir.close(), this._ir = null), this._transport && (this._transport.close(), this._transport = null, this.transport = null), this.readyState === y.CLOSED) throw new Error("InvalidStateError: SockJS has already been closed");
                this.readyState = y.CLOSING, setTimeout(function () {
                    this.readyState = y.CLOSED, r && this.dispatchEvent(new g("error"));
                    var n = new w("close");
                    n.wasClean = t || !1, n.code = A || 1e3, n.reason = e, this.dispatchEvent(n), this.onmessage = this.onclose = this.onerror = null, Q("disconnected")
                }.bind(this), 0)
            }, y.prototype.countRTO = function (A) {
                return A > 100 ? 4 * A : 300 + A
            }, A.exports = function (A) {
                return r = u(A), t("9fa7")(y, A), y
            }
        }).call(this, t("c8ba"))
    }, "48cd": function (A, e, t) {
        "use strict";
        (function (e) {
            var t = {};
            ["log", "debug", "warn"].forEach((function (A) {
                var r;
                try {
                    r = e.console && e.console[A] && e.console[A].apply
                } catch (n) {
                }
                t[A] = r ? function () {
                    return e.console[A].apply(e.console, arguments)
                } : "log" === A ? function () {
                } : t.log
            })), A.exports = t
        }).call(this, t("c8ba"))
    }, "49fb": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAHKADAAQAAAABAAAAHAAAAABHddaYAAAB00lEQVRIDe1WPUsDQRB9ezEYvyAWgjEoIoqFgoK9nZVWgj/AJo0oKIqWllGDgiKICFpba59CsFXQRiUERJEUaqGQcObG2SMre64hl5A0koUws2/fm3fMXdgRKGN1xmmZ6UsFyfbLmkiUIXepwq8gGqfJPHCm8wPA1NOaONexUrlViqDOHWBC5Sr+hamzYtG3IQSajCJ/YQbJC/g39Ooq3v1/wwbZm5lTClym0dfQgcf0rMhW3C8fQiu6SaMXKaS+HNxlM8hENmjah65iipV3cEBAj1uB0Mb5Se8xhSquWEIoP5oxD4dN7VcMerAqbuQ7dN+jXtMhE9PP/eTdG9RlCwyEgrhOL4p3panJ3yKySTEbSMNBMpdDKpKg8ZoZDu1TKwi7/AtKE/4m2imPvZoZvn+inwiNysCNhGG1r3pLHQt8iRjrx+cnMSg1AuqGVW9svaX/o6U8fHmX5YAnQmMZPGYYWCmtxdPYjV5aCOTCLXjQMZkz7uEVw6RW1vDoNa0lApjnafjNJQjY/AALt3PiwyPgTXMIRxySGp4sYBoEuFquwXX4wuAH5drSQ5Hcybt3h8JZGyNBwv3jqnhWh7/jOpF1uIVRicdWcLUuhNFSpSl2H34DBDR9yphIIqoAAAAASUVORK5CYII="
    }, "4b11": function (A, e, t) {
    }, "52db": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjE5RTQ2QzZCRjNEMzExRTBCNzM0RkZBNEEwMDU0Njk0IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjE5RTQ2QzZDRjNEMzExRTBCNzM0RkZBNEEwMDU0Njk0Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MTlFNDZDNjlGM0QzMTFFMEI3MzRGRkE0QTAwNTQ2OTQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MTlFNDZDNkFGM0QzMTFFMEI3MzRGRkE0QTAwNTQ2OTQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz76PDNBAAAGuUlEQVR42oyZ209TWxDGadkqihcusUGimMrtkPAgIdH4/7/6AGosFqxNjSAE5Y7cjj2/dsp0mFl7c9ZDsy9rz5rLNzPfWi19+/ZtYGCg3W4P5A95WyqV9DZ5nZycnOPmO2mMrN0dyVWdrjqNIXPsTLmVmXqtF+62QL78ZqqNflMul90C0dbS9bBmWFFWmsyJVjmZui6vytEZVqe4mLMhRl9eJZ+7aFhpLvqZs9jBwinqdE0a7VZNQs2JcnI62MozRcffv3/dx+onlWs/kfm6dsSfA5bKt3Myp7L7TSJGPxkcHOQXuf92R8/QLOM503hujRTo6PKCueizXhCdTgWBE8TINUK5ODw83NnZOTg4OD09vby85PmdO3fu3bv3+PHjSqUyMjKCfldXV842u3wy6zvvWq2Wg6fTKeYB/tjf3280GuiENq5kSFyYMz4+Xq1Wnz59iiOtQHVVXrHoiPv+/XteLXU4E3GMZrNZr9fPz88Hu8NJ10xEG96+fPlybm6OC4lyMqtizmWx9OVVZBRCeq1WW19fxxl37961H0YhBJTrjY2NP3/+vH79mk8UfwWtogcSG2k7z9bMXkPIso3uYD2JgsvqZPKj/ebm5qdPnxyM0rHTImzrtRZlq6jMQxWQROxQTpPISZQ80AsViGZAhdCLPdGYUhhl1UBw4xbQ2JFQxA4VpSjYOVYPFaLZKhcYAyc4Pj6Wz8vXIy7XV8vGUR1mjUDoz58/yT7MTdrnPO28LhUOhOEzUcu5ObbasprlyrH1Fk+2trZcbcvjP67K63ooBAwuLi5cfU72Rx8IuXDqYyiVE58VpEXyWmdK9E9OTqi9gs64yg0dnL4RfYijiGOlYiUufAOtBnPuIcphXsFMFZUVN3N5eHZ2ZjGXRzTiw+gSirDtCnmo6LXVPI4loqXp2oIZJeYRTjdN+UJB9e55K5Jmt4ygKjb1pMTYsux8vCB2FrOpzFVO29s1Cvfv31fNlJ8kuX/kxNb9aPPgwQNHHyIH7Kml/TzSYrl9+PAhlVpz2/b/JLdO+k86PWzHTbMUvk+cYgmJcMFExNFoI/HKq17xFlcNDw9DxRyrLqVGuXTbEIOeP39uIRIl5tUwfYJVz549Aw+2XMcW3Cc2BWRGLUbi2NjY3t6e0JWC3WxsKeIqFIJ7JRMi5k05EoEYVoSCrYWFBYAvEImlUoFie7AOXAUZJIKISrZn91t2M6L/5S1yJycn5+fnoRJ2g5AMgbOeXJmampqZmbFFq+eV6y7k+EjZQcG+7ru0+yWa/dMdaJZXeOJ5BDqBy6WlpSSzUB/7dKZJuWLtCqC9EOO+fv26trZGRxJalzwZQG+0p3hOT08TfaZFLp93ZlGSTVUBhU/2LLQB+7DC7e1tKWa2QsoOESyOjo7Ozs5OTEzInixuaPMqamfdo6Oj2N1upVa4gV9Mgh7+/v0b5iOYIyfYJ1LkyFzUwkmiU4x1dNWNbXpSrYKNpX0lfJrosLbESPixKM0TybuC05e8kVnIR46Qd+oiQ/alsr2xJUpUFCxaDfTWta8IzSz2sgIiJYKEBWjtxlXsrYX8SE6IwxT7yY1rHpRvVPl4CpLc9QJ2rlHioDvAFjxYgaX7IuBFG3306NGT7hgaGpJMlLJy68llJ0wQ4oJDEXvugNxfv36x12CnIDQ6tkUFr6AKbdCJrkUGVCoV+o91nvPIDRBja0xRPlZeJaBmZ8xGj6TDMRJBjWNMDhUlkRUnQR+o9bRFvKgFOfdwj6qYpJSCIR7ini9fvuAnfVKcRPGYUzdqmIfDXr16RY3Fi+rvWI86nD8pHRiBm8+fP7daLSTKxjV5KOcOiRzVtCqK83AVJW1xcZHICigTk0Vll64kPHVyZWVFtof2IC/S81trb7SHpMHxNH46rPAA14L6aulnfNBoNFZXV5mt7Op/hiwZvuRXeA7lXrx4sby8zCo2DzpqyOGi3ZLThj9+/GiP1GIztgVFz7finxHxvwg3gBBN8+3bt0BNDhb73rJHtKD7w4cP7rQobgFu7R55cVQaqBJQgNrx7t07kNP3GaCTSejUbDbfv38vfkoeqcdykMyAW7uesw2fwcnevHnT706qEyUAPKlO8Yw/trDkljDJv5NdVeswXeHHjx+1Wq1/JCaNE33JOyFu7euRp5ACLvk3U/w/IelyJwTYQOBQrlerRV8gBbOTHUQBZchbuG1GnBCfR6skRKQaXafH5Xd3d6kIup1PNqxkKjnGHA+3Cv5ai/9DocDx8XG9Xu84j3u4uavjMc+L/9CKFMjVsGRlidGXw99qtfqfAAMAVXB5lHUIUuQAAAAASUVORK5CYII="
    }, "54d6": function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("3fb5"), n = t("f1f8"), i = t("621f"), s = t("ada0").EventEmitter, o = t("2582"),
                a = function () {
                };

            function c(A) {
                a(A), s.call(this);
                var t = this;
                n.polluteGlobalNamespace(), this.id = "a" + o.string(6), A = i.addQuery(A, "c=" + decodeURIComponent(n.WPrefix + "." + this.id)), a("using htmlfile", c.htmlfileEnabled);
                var r = c.htmlfileEnabled ? n.createHtmlfile : n.createIframe;
                e[n.WPrefix][this.id] = {
                    start: function () {
                        a("start"), t.iframeObj.loaded()
                    }, message: function (A) {
                        a("message", A), t.emit("message", A)
                    }, stop: function () {
                        a("stop"), t._cleanup(), t._close("network")
                    }
                }, this.iframeObj = r(A, (function () {
                    a("callback"), t._cleanup(), t._close("permanent")
                }))
            }

            r(c, s), c.prototype.abort = function () {
                a("abort"), this._cleanup(), this._close("user")
            }, c.prototype._cleanup = function () {
                a("_cleanup"), this.iframeObj && (this.iframeObj.cleanup(), this.iframeObj = null), delete e[n.WPrefix][this.id]
            }, c.prototype._close = function (A) {
                a("_close", A), this.emit("close", null, A), this.removeAllListeners()
            }, c.htmlfileEnabled = !1;
            var l = ["Active"].concat("Object").join("X");
            if (l in e) try {
                c.htmlfileEnabled = !!new e[l]("htmlfile")
            } catch (u) {
            }
            c.enabled = c.htmlfileEnabled || n.iframeEnabled, A.exports = c
        }).call(this, t("c8ba"))
    }, "5df3": function (A, e, t) {
        "use strict";
        var r = t("02f4")(!0);
        t("01f9")(String, "String", (function (A) {
            this._t = String(A), this._i = 0
        }), (function () {
            var A, e = this._t, t = this._i;
            return t >= e.length ? { value: void 0, done: !0 } : (A = r(e, t), this._i += A.length, { value: A, done: !1 })
        }))
    }, "621f": function (A, e, t) {
        "use strict";
        var r = t("1816"), n = function () {
        };
        A.exports = {
            getOrigin: function (A) {
                if (!A) return null;
                var e = new r(A);
                if ("file:" === e.protocol) return null;
                var t = e.port;
                return t || (t = "https:" === e.protocol ? "443" : "80"), e.protocol + "//" + e.hostname + ":" + t
            }, isOriginEqual: function (A, e) {
                var t = this.getOrigin(A) === this.getOrigin(e);
                return n("same", A, e, t), t
            }, isSchemeEqual: function (A, e) {
                return A.split(":")[0] === e.split(":")[0]
            }, addPath: function (A, e) {
                var t = A.split("?");
                return t[0] + e + (t[1] ? "?" + t[1] : "")
            }, addQuery: function (A, e) {
                return A + (-1 === A.indexOf("?") ? "?" + e : "&" + e)
            }
        }
    }, 6846: function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAHKADAAQAAAABAAAAHAAAAABHddaYAAABk0lEQVRIDe3UP0vDUBAA8LtXxKG7k7VgimN3qYPQOjiqq4N/Ojn5CSRfwkWsHSx+AsdEHOwqCC5iVdqKWBG6SIUgOXMpfU1rkyZpAg590NC83Ltf7rXvAKZjugP/fQcw7hdc0JYKBD8bgqBaX3u+iBVM65miSeYJENiOELiZiKvCYcx2CF5iqXAUhoAGClwWUVfohgGKrXq+dhtphV5Yo/B4ycVFBvrBGJRbmr3LJpWqMseTQYdfjPPaYFpX1tsfXy3jm95T2uKxSqp8kXF4EEyCpglH1k3SPi8EB2f6eckPGhSTICK0nJUQ0U5Jq5x6oWEwCYrEzCEgvjpRAHPXDQ2LcX75L03pGQWIrq3P/CAsyvuF7aKKqsnzk2C8XoJ8Mw4tX1X2nL2xmwANPtS9c8ZzXmMA5EA31Aq8IYRcrxFzLLerIFh3DV+HhhvqDAuD8fo/FfaSeqFhMU+QH45CJ8E4p2dHaeZrT9ZxWbXiGhxsjU7Q36y7rH913dJ+CAD32fZnJwezifvmysOb89n0+/AO/AKJBfgZykzlOgAAAABJRU5ErkJggg=="
    }, 6945: function (A, e, t) {
        "use strict";
        A.exports = [t("397f"), t("3e1e"), t("b185"), t("7b4d"), t("26e3")(t("7b4d")), t("40b2"), t("26e3")(t("40b2")), t("e2b3"), t("e556"), t("26e3")(t("e2b3")), t("f84c")]
    }, "6e46": function (A, e, t) {
        "use strict";
        var r = t("4b11"), n = t.n(r);
        n.a
    }, "704d": function (A, e, t) {
        "use strict";
        var r = function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", {
                staticStyle: {
                    width: "100%",
                    height: "100%",
                    position: "relative"
                }
            }, [t("div", {
                directives: [{ name: "show", rawName: "v-show", value: A.isPlay, expression: "isPlay" }],
                staticClass: "prism-player",
                attrs: { id: "J_prismPlayer" }
            }, [t("div", { ref: "waterMarker", staticClass: "waterMarker" })])])
        }, n = [], i = (t("8e6e"), t("456d"), t("28a5"), t("5df3"), t("1c4c"), t("6762"), t("2fdb"), t("bd86")),
            s = (t("a481"), t("ac6a"), t("96cf"), t("3b8d")), o = (t("c5f6"), t("8e44")), a = t("ccf6"), c = t.n(a),
            l = t("fa7d"), u = t("9ff8");

        function d(A, e) {
            var t = Object.keys(A);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(A);
                e && (r = r.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(A, e).enumerable
                }))), t.push.apply(t, r)
            }
            return t
        }

        function B(A) {
            for (var e = 1; e < arguments.length; e++) {
                var t = null != arguments[e] ? arguments[e] : {};
                e % 2 ? d(Object(t), !0).forEach((function (e) {
                    Object(i["a"])(A, e, t[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(A, Object.getOwnPropertyDescriptors(t)) : d(Object(t)).forEach((function (e) {
                    Object.defineProperty(A, e, Object.getOwnPropertyDescriptor(t, e))
                }))
            }
            return A
        }

        var h = {
            props: {
                resetHandoutAndVideoProps: { default: !1, type: Boolean },
                isTitle: { default: "", type: String },
                autoPlay: { default: !0, type: Boolean },
                videoId: { default: "", type: String },
                noteId: { default: "", type: String },
                resourceRelId: { default: "", type: String },
                curTime: {
                    default: function () {
                        return {}
                    }, type: Object
                },
                recordTime: { default: 0, type: Number },
                seek: { default: 0, type: Number },
                setting: {
                    default: function () {
                        return {}
                    }, type: Object
                },
                allowHighSpeed: { default: !0, type: Boolean },
                allowMinStudyTime: { default: !0, type: Boolean },
                type: { default: "", type: String },
                settingBtn: { default: !1, type: Boolean },
                heartBeatFlag: { default: !1, type: Boolean },
                courseId: { default: "", type: String },
                isNewPlay: {
                    type: Boolean, default: function () {
                        return !1
                    }
                },
                allowDrag: { default: !1, type: Boolean }
            }, data: function () {
                return {
                    player: null,
                    eventList: ["ready", "play", "pause", "canplay", "playing", "ended", "liveStreamStop", "m3u8Retry", "hideBar", "showBar", "waiting", "timeupdate", "snapshoted", "requestFullScreen", "cancelFullScreen", "error", "startSeek", "completeSeek", "seeking"],
                    playAuth: null,
                    isPlay: !0,
                    TimeId: null,
                    sourceUrl: null,
                    playerBuild: 0,
                    seeked: 0,
                    videoAddressUrl: "",
                    updateToken: "",
                    base64Url: "",
                    playWay: "source",
                    heartbeatTime: 0,
                    heartbeatTimer: null,
                    hangUpCheckFlag: !1,
                    yinpinBG: c.a,
                    recordTimeIdTemp: null,
                    recordTimeTemp: 0,
                    urlObj: null,
                    cookieValue: "HD"
                }
            }, components: { AliyunPreview: u["a"] }, computed: {
                components: function () {
                    return this.allowHighSpeed ? [{ name: "RateComponent", type: AliPlayerComponent.RateComponent }] : []
                }
            }, watch: {
                resetHandoutAndVideoProps: function (A) {
                    A && (document.pictureInPictureElement && document.exitPictureInPicture(), this.$emit("openAndCloseVideoParent", {
                        flag: 0,
                        noteId: this.noteId
                    }))
                }, videoId: function (A, e) {
                    var t = this;
                    "videoId" !== this.playWay && ("" === A || "video" !== this.type && "audio" !== this.type || (clearTimeout(this.TimeId), this.isPlay = !1, this.TimeId = setTimeout((function () {
                        t.$nextTick((function () {
                            t.isPlay = !0, t.playerBuild, t.aliPlayer(), t.playerBuild++
                        }))
                    }), 1e3)))
                }
            }, methods: {
                openAndCloseVideo: function (A) {
                    var e = document.getElementsByTagName("video")[0];
                    if (A) {
                        try {
                            document.pictureInPictureEnabled && e.requestPictureInPicture()
                        } catch (r) {
                        }
                        this.$emit("openAndCloseVideoParent", { flag: 1, noteId: this.noteId })
                    } else document.pictureInPictureElement && document.exitPictureInPicture(), this.$emit("openAndCloseVideoParent", {
                        flag: 0,
                        noteId: this.noteId
                    });
                    var t = this;
                    e.addEventListener("leavepictureinpicture", (function () {
                        var A = document.getElementById("handoutOperate");
                        A.innerText = t.$t("v4.js.pc.ocmt.viewHandout"), t.$emit("openAndCloseVideoParent", {
                            flag: 0,
                            noteId: this.noteId
                        })
                    }))
                }, openHandout: function () {
                    var A = "/courseSetting/preview/document?id=".concat(this.noteId);
                    window.open(A)
                }, getVideoAddress: function (A) {
                    var e = this;
                    return Object(s["a"])(regeneratorRuntime.mark((function t() {
                        var r, n, i, s, a;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1) switch (t.prev = t.next) {
                                case 0:
                                    return r = A || e.videoId, t.next = 3, o["a"].getVideoPlayAuthForPC({ resourceRelId: r });
                                case 3:
                                    return n = t.sent, t.next = 6, o["a"].APIgetTokenForHls();
                                case 6:
                                    i = t.sent, i = i.msg, n.bizResult.playInfoResponse || null === n.bizResult.playInfoResponse && null === n.bizResult.videoId ? (e.playWay = "source", n.bizResult.playInfoResponse ? ("", s = {}, a = n.bizResult.playInfoResponse.playInfoList, e.urlObj = {}, a.forEach((function (A, t) {
                                        0 === t ? (s["LD"] = A.playURL + "?MtsHlsUriToken=" + i, e.urlObj["超清"] = A.playURL + "?MtsHlsUriToken=" + i) : 1 === t && (s["HD"] = A.playURL + "?MtsHlsUriToken=" + i, e.urlObj["高清"] = A.playURL + "?MtsHlsUriToken=" + i)
                                    })), a.length > 0 ? (e.sourceUrl = JSON.stringify(s), e.player && e.player.loadByUrl(s.LD, e.seeked)) : (e.sourceUrl = a[0].playURL, e.player && e.player.loadByUrl(e.sourceUrl, e.seeked)), console.log(e.sourceUrl), e.player && (e.player.loadByUrl(e.sourceUrl, e.seeked), e.player.loadByUrl(s.LD, e.seeked)), e.videoAddressUrl = a[0].playURL) : (e.sourceUrl = n.bizResult.playUrl, e.player && e.player.loadByUrl(e.sourceUrl, e.seeked))) : (e.playWay = "videoId", e.videoId = n.bizResult.videoId, e.playAuth = n.bizResult.playAuth);
                                case 9:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })))()
                }, getPlayAuth: function () {
                    var A = this;
                    return Object(s["a"])(regeneratorRuntime.mark((function e() {
                        var t, r, n;
                        return regeneratorRuntime.wrap((function (e) {
                            while (1) switch (e.prev = e.next) {
                                case 0:
                                    return t = A.videoId, e.next = 3, o["a"].APIgetVideoPlayAuth({ resourceRelId: t });
                                case 3:
                                    r = e.sent, n = r.bizResult, A.playAuth = n.playAuth;
                                case 6:
                                case "end":
                                    return e.stop()
                            }
                        }), e)
                    })))()
                }, replayByVidAndPlayAuth: function () {
                    var A = this;
                    this.getPlayAuth().then((function () {
                        A.player.replayByVidAndPlayAuth(A.videoId, A.playAuth)
                    }))
                }, aliPlayer: function (A, e) {
                    var t = this;
                    e ? this.$store.dispatch("home/updateJumpFlag", !0) : this.$store.dispatch("home/updateJumpFlag", !1);
                    var r = !1;
                    this.isNewPlay && (r = this.getIsScreenStatus()), this.isPlay = !0, this.getVideoAddress(A).then((function () {
                        var n = t, i = {
                            id: "J_prismPlayer",
                            width: "100%",
                            height: "100%",
                            source: t.sourceUrl.replace("https://testvod.21tb.com", "https://testvod-xinyi.21tb.com"),
                            encryptType: 1,
                            autoplay: t.autoPlay,
                            isLive: !1,
                            rePlay: !1,
                            playsinline: !0,
                            preload: t.autoPlay,
                            waitingTimeout: 10,
                            language: "zh-cn",
                            controlBarVisibility: "always",
                            videoHeight: "calc(100% - 44px)",
                            useH5Prism: !0,
                            cover: t.autoPlay ? "@/assets/img/cover.png" : "",
                            components: t.components,
                            PlayConfig: { PlayDomain: "testvod-xinyi.21tb.com" },
                            skinLayout: [{ name: "bigPlayButton", align: "blabs", x: 30, y: 80 }, {
                                name: "H5Loading",
                                align: "cc"
                            }, {
                                name: "errorDisplay",
                                align: "tlabs",
                                x: 0,
                                y: 0
                            }, { name: "infoDisplay" }, {
                                name: "tooltip",
                                align: "blabs",
                                x: 0,
                                y: 56
                            }, { name: "thumbnail" }, {
                                name: "controlBar",
                                align: "blabs",
                                x: 0,
                                y: 0,
                                children: [{ name: "progress", align: "blabs", x: 0, y: 44 }, {
                                    name: "playButton",
                                    align: "tl",
                                    x: 15,
                                    y: 12
                                }, { name: "timeDisplay", align: "tl", x: 10, y: 7 }, {
                                    name: "fullScreenButton",
                                    align: "tr",
                                    x: 10,
                                    y: 12
                                }, { name: "setting", align: "tr", x: 15, y: 12 }, {
                                    name: "volume",
                                    align: "tr",
                                    x: 5,
                                    y: 10
                                }]
                            }]
                        }, s = {
                            id: "J_prismPlayer",
                            width: "100%",
                            height: "100%",
                            vid: t.videoId,
                            playauth: t.playAuth,
                            encryptType: 1,
                            autoplay: t.autoPlay,
                            isLive: !1,
                            rePlay: !1,
                            playsinline: !0,
                            preload: t.autoPlay,
                            waitingTimeout: 10,
                            language: "zh-cn",
                            controlBarVisibility: "always",
                            videoHeight: "calc(100% - 44px)",
                            useH5Prism: !0,
                            cover: t.autoPlay ? "@/assets/img/cover.png" : "",
                            components: t.components,
                            PlayConfig: { PlayDomain: "testvod-xinyi.21tb.com" },
                            skinLayout: [{ name: "bigPlayButton", align: "blabs", x: 30, y: 80 }, {
                                name: "H5Loading",
                                align: "cc"
                            }, {
                                name: "errorDisplay",
                                align: "tlabs",
                                x: 0,
                                y: 0
                            }, { name: "infoDisplay" }, {
                                name: "tooltip",
                                align: "blabs",
                                x: 0,
                                y: 56
                            }, { name: "thumbnail" }, {
                                name: "controlBar",
                                align: "blabs",
                                x: 0,
                                y: 0,
                                children: [{ name: "progress", align: "blabs", x: 0, y: 44 }, {
                                    name: "playButton",
                                    align: "tl",
                                    x: 15,
                                    y: 12
                                }, { name: "timeDisplay", align: "tl", x: 10, y: 7 }, {
                                    name: "fullScreenButton",
                                    align: "tr",
                                    x: 10,
                                    y: 12
                                }, { name: "setting", align: "tr", x: 15, y: 12 }, {
                                    name: "volume",
                                    align: "tr",
                                    x: 5,
                                    y: 10
                                }]
                            }]
                        }, a = t, u = "videoId" === t.playWay ? s : i;
                        if (i = B(B({}, u), t.setting), a.player) {
                            if (a.player.dispose(), !document.querySelector(".waterMarker")) {
                                var d = document.getElementById("J_prismPlayer"), h = document.createElement("div");
                                d.appendChild(h), h.className = "waterMarker", h.setAttribute("ref", "waterMarker"), h.style.position = "absolute", h.style.left = "0", h.style.top = "0", h.style.width = "100%", h.style.height = "100%", h.style.opacity = "0.3", h.style.pointerEvents = "none", h.style.backgroundImage = "url(".concat(t.base64Url, ")");
                                var g = document.createElement("div");
                                g.style.position = "absolute", g.style.left = "0", g.style.top = "0", g.style.width = "100%", g.style.height = "100%", g.style.pointerEvents = "none", "audio" === a.type && d.appendChild(g);
                                var p = document.createElement("img");
                                p.setAttribute("src", c.a), p.style.position = "absolute", p.style.left = "50%", p.style.top = "50%", p.style.width = "300px", p.style.height = "300px", p.style.pointerEvents = "none", p.style.marginLeft = "-150px", p.style.marginTop = "-150px", "audio" === a.type && g.appendChild(p);
                                var f = document.createElement("div");
                                f.style.position = "absolute", f.style.bottom = "0", f.style.left = "150px", f.style.width = "calc(100% - 240px)", f.style.height = "38px", f.style.zIndex = "20";
                                var w = document.createElement("span"), C = document.createElement("span");
                                if (C.setAttribute("id", "handoutOperate"), C.innerText = "讲义", w.style.lineHeight = "38px", w.style.color = "#fff", w.style.fontSize = "14px", w.style.float = "left", C.style.cursor = "pointer", C.style.lineHeight = "38px", C.style.color = "#fff", C.style.fontSize = "14px", C.style.float = "right", t.isNewPlay && (C.style.minWidth = "60px", C.style.height = "28px", C.style.lineHeight = "28px", C.style.textAlign = "center", C.style.background = "rgba(0,0,0,0.45)", C.style.borderRadius = "14px", C.style.marginTop = "5px", C.style.marginRight = "8px", C.style.padding = "0 10px"), d.appendChild(f), a.allowMinStudyTime && "preview" !== t.$route.query.from && (t.recordTimeTemp = t.recordTime, t.recordTimeIdTemp && clearInterval(t.recordTimeIdTemp), t.recordTimeIdTemp = setInterval((function () {
                                    t.recordTimeTemp++, "setting" !== t.isTitle && (w.innerText = "(观看时长不少于".concat(Object(l["TimeToString"])(a.curTime.minStudyTime), "，您已学习").concat(Object(l["TimeToString"])(a.recordTime > a.curTime.minStudyTime ? a.curTime.minStudyTime : a.recordTime), ")"), a.recordTime > a.curTime.minStudyTime && (clearInterval(t.recordTimeIdTemp), t.$emit("updateAndClear", "", "clear")))
                                }), 1e3), f.appendChild(w)), a.isNewPlay) {
                                    var m = a.setPowerAndSpeed(), Q = m.ultraClearOperate, y = m.doubleSpeedOperate;
                                    "video" === t.type && f.appendChild(Q), "video" !== t.type && "audio" !== t.type || !t.allowHighSpeed || f.appendChild(y)
                                }
                                a.noteId && (console.log("sourceUrl", A), f.appendChild(C), C.onclick = function () {
                                    if (C.innerText === a.$t("v4.js.pc.ocmt.viewHandout")) if (document.pictureInPictureEnabled) a.openAndCloseVideo(1), C.innerText = a.$t("v4.js.pc.ocmt.closeHandout"); else {
                                        var A = "/courseSetting/preview/handout?id=".concat(a.noteId);
                                        window.open(A)
                                    } else a.openAndCloseVideo(0), C.innerText = a.$t("v4.js.pc.ocmt.viewHandout")
                                }, C.addEventListener("mouseenter", (function (A) {
                                    C.style.background = "#1888FF"
                                })), C.addEventListener("mouseleave", (function (A) {
                                    C.style.background = "rgba(0, 0, 0, 0.45)"
                                })))
                            }
                        } else {
                            var U = document.getElementById("J_prismPlayer"), v = document.createElement("div");
                            v.style.position = "absolute", v.style.left = "0", v.style.top = "0", v.style.width = "100%", v.style.height = "100%", v.style.pointerEvents = "none", "audio" === a.type && U.appendChild(v);
                            var F = document.createElement("img");
                            F.setAttribute("src", c.a), F.style.position = "absolute", F.style.left = "50%", F.style.top = "50%", F.style.width = "300px", F.style.height = "300px", F.style.marginLeft = "-150px", F.style.pointerEvents = "none", F.style.marginTop = "-150px", "audio" === a.type && v.appendChild(F);
                            var I = document.createElement("div");
                            I.style.position = "absolute", I.style.bottom = "0", I.style.left = "150px", I.style.width = "calc(100% - 240px)", I.style.height = "38px", I.style.zIndex = "20";
                            var E = document.createElement("span"), b = document.createElement("span");
                            if (b.setAttribute("id", "handoutOperate"), b.innerText = a.$t("v4.js.pc.ocmt.viewHandout"), E.style.lineHeight = "38px", E.style.color = "#fff", E.style.fontSize = "14px", E.style.float = "left", b.style.cursor = "pointer", b.style.lineHeight = "38px", b.style.color = "#fff", b.style.fontSize = "14px", b.style.float = "right", t.isNewPlay && (b.style.minWidth = "60px", b.style.height = "28px", b.style.lineHeight = "28px", b.style.textAlign = "center", b.style.background = "rgba(0,0,0,0.45)", b.style.borderRadius = "14px", b.style.marginTop = "5px", b.style.marginRight = "8px", b.style.padding = "0 10px"), U.appendChild(I), a.allowMinStudyTime && "preview" !== t.$route.query.from && (t.recordTimeTemp = t.recordTime, t.recordTimeIdTemp && clearInterval(t.recordTimeIdTemp), t.recordTimeIdTemp = setInterval((function () {
                                t.recordTimeTemp++, "setting" !== t.isTitle && (E.innerText = "(观看时长不少于".concat(Object(l["TimeToString"])(a.curTime.minStudyTime), "，您已学习").concat(Object(l["TimeToString"])(a.recordTime > a.curTime.minStudyTime ? a.curTime.minStudyTime : a.recordTime), ")"), a.recordTime > a.curTime.minStudyTime && (clearInterval(t.recordTimeIdTemp), t.$emit("updateAndClear", "", "clear")))
                            }), 1e3), I.appendChild(E)), a.isNewPlay) {
                                var H = a.setPowerAndSpeed(), T = H.ultraClearOperate, x = H.doubleSpeedOperate;
                                "video" === t.type && I.appendChild(T), "video" !== t.type && "audio" !== t.type || !t.allowHighSpeed || I.appendChild(x)
                            }
                            a.noteId && (I.appendChild(b), b.onclick = function () {
                                if (b.innerText === a.$t("v4.js.pc.ocmt.viewHandout")) if (document.pictureInPictureEnabled) a.openAndCloseVideo(1), b.innerText = a.$t("v4.js.pc.ocmt.closeHandout"); else {
                                    var A = "/courseSetting/preview/handout?id=".concat(a.noteId);
                                    window.open(A)
                                } else a.openAndCloseVideo(0), b.innerText = a.$t("v4.js.pc.ocmt.viewHandout")
                            }, b.addEventListener("mouseenter", (function (A) {
                                b.style.background = "#1888FF"
                            })), b.addEventListener("mouseleave", (function (A) {
                                b.style.background = "rgba(0, 0, 0, 0.45)"
                            })))
                        }
                        t.player = new Aliplayer(i, (function (A) {
                            var t = this;
                            a.settingBtn || (document.querySelector(".prism-setting-btn").style.display = "none"), A.on("ready", (function () {
                                if (n.playerBuild = 1, n.isNewPlay) {
                                    document.querySelector(".prism-progress-cursor");
                                    var e = document.querySelector(".prism-progress-cursor > img");
                                    e.src = "", e.style = "width:14px;\n                height:14px;\n                background:#1888FF;\n                border-radius:50%;\n                display:block;", n.$nextTick((function () {
                                        if (r) {
                                            var A = document.querySelector(".prism-fullscreen-btn");
                                            A && (A.classList.add("fullscreen"), A.addEventListener("click", (function () {
                                                A.click()
                                            })))
                                        }
                                    }))
                                }
                                /** NicolasLemon修改1 */
                                // console.log('@@@', n);
                                // 将对象e的seek时间设置为当前课程需要学习的最少时间
                                n.seek = n.curTime.minStudyTime + 10;
                                // 更新当前学习时间
                                n.curTime.currentStudyTime = n.seek;
                                A.seek(n.seek)
                            })), A.on("canplay", (function () {
                                A.play(), e && A.pause()
                            })), A.on("play", (function () {
                                clearInterval(t.updateToken), t.updateToken = setInterval((function () {
                                    var A = o["a"].APIgetTokenForHls();
                                    A = A.msg, n.sourceUrl = n.videoAddressUrl + "?MtsHlsUriToken=" + A
                                }), 6e4)
                            })), A.on("error", (function () {
                                console.log("出错了，播放器重新播放了"), console.log(document.querySelector(".prism-button-refresh")), document.querySelector(".prism-button-refresh").click()
                            })), setTimeout((function () {
                                n.registerEvent()
                            }), 0), a.$emit("isReady", !0), a.heartBeatFlag && document.getElementsByTagName("video")[0] && a.addVideoClick()
                        }))
                    }))
                }, getIsScreenStatus: function () {
                    var A = document.querySelector(".prism-fullscreen-btn");
                    return !(!A || !Array.from(A.classList).includes("fullscreen"))
                }, setPowerAndSpeed: function (A) {
                    var e = document.createElement("span");
                    e.setAttribute("id", "ultraClearOperate"), e.innerText = this.$t("v4.js.pc.ocmt.ultraClear"), e.style.cursor = "pointer", e.style.lineHeight = "38px", e.style.color = "#fff", e.style.fontSize = "14px", e.style.float = "right", e.style.minWidth = "60px", e.style.height = "28px", e.style.lineHeight = "28px", e.style.textAlign = "center", e.style.background = "rgba(0,0,0,0.45)", e.style.borderRadius = "14px", e.style.marginTop = "5px", e.style.marginRight = "8px", e.style.padding = "0 10px", e.innerHTML = '<span id="ul_label">'.concat("HD" === this.cookieValue ? "高清" : "超清", '</span>\n                      <div id="ultraClearOperate_main" style="display: none;">\n                      <div id="ultraClearOperate_list">\n                           <div class="ul-item">高清</div>\n                           <div class="ul-item">超清</div>\n                      </div>\n                      </div>\n                  '), console.log("innerHtml", e.innerHTML, this.cookieValue), this.setResolvingPower(e), e.addEventListener("click", (function (A) {
                    })), e.addEventListener("mouseenter", (function (A) {
                        var t = document.getElementById("ultraClearOperate_main");
                        e.style.background = "#1888FF", t.style.display = "block"
                    })), e.addEventListener("mouseleave", (function (A) {
                        var t = document.getElementById("ultraClearOperate_main");
                        e.style.background = "rgba(0, 0, 0, 0.45)", t.style.display = "none "
                    }));
                    var t = document.createElement("span");
                    return t.setAttribute("id", "doubleSpeedOperate"), t.innerText = this.$t("v4.js.pc.ocmt.doubleSpeed"), t.style.cursor = "pointer", t.style.lineHeight = "38px", t.style.color = "#fff", t.style.fontSize = "14px", t.style.float = "right", t.style.minWidth = "60px", t.style.height = "28px", t.style.lineHeight = "28px", t.style.textAlign = "center", t.style.background = "rgba(0,0,0,0.45)", t.style.borderRadius = "14px", t.style.marginTop = "5px", t.style.marginRight = "8px", t.style.padding = "0 10px", t.innerHTML = '<span id="dso_label">倍速</span>\n                      <div id="doubleSpeedOperate_main" style="display: none;">\n                      <div id="doubleSpeedOperate_list">\n                           <div class="dso-item">0.5x</div>\n                           <div class="dso-item">1.0x</div>\n                           <div class="dso-item">1.25x</div>\n                           <div class="dso-item">1.5x</div>\n                           <div class="dso-item">2.0x</div>\n                      </div>\n                      </div>\n                  ', this.setDoubleSpeedOperate(t), t.addEventListener("click", (function (A) {
                    })), t.addEventListener("mouseenter", (function (A) {
                        var e = document.getElementById("doubleSpeedOperate_main");
                        t.style.background = "#1888FF", e.style.display = "block"
                    })), t.addEventListener("mouseleave", (function (A) {
                        var e = document.getElementById("doubleSpeedOperate_main");
                        t.style.background = "rgba(0, 0, 0, 0.45)", e.style.display = "none "
                    })), { ultraClearOperate: e, doubleSpeedOperate: t }
                }, setResolvingPower: function (A) {
                    var e = this, t = this.urlObj;
                    A.style.display = "block", A.style.position = "relative";
                    var r = A.querySelector("#ul_label"), n = A.querySelector("#ultraClearOperate_list"),
                        i = A.querySelector("#ultraClearOperate_main");
                    i.style.width = "116px", i.style.height = "122px", i.style.position = "absolute", i.style.top = "-107px", i.style.left = "-28px", i.style.margin = "auto", i.style.background = "transparent", n.style.width = "116px", n.style.height = "92px", n.style.background = "rgba(0,0,0,0.75)", n.style.borderRadius = "4px";
                    var s = n.querySelectorAll(".ul-item"), o = Array.from(s);
                    o.forEach((function (A) {
                        A.style.height = "46px", A.style.lineHeight = "46px", A.addEventListener("click", (function (A) {
                            if (A.target.innerText) {
                                var n = "HD";
                                "高清" === A.target.innerText ? n = "HD" : "超清" === A.target.innerText && (n = "LD"), e.cookieValue = n;
                                var s = document.cookie.replace(/(selectedStreamLevel=)\w{2}/, "$1" + n);
                                document.cookie = s, r.innerText = A.target.innerText, i.style.display = "none", e.sourceUrl = t[A.target.innerText], e.player && e.aliPlayer()
                            }
                        })), A.addEventListener("mouseenter", (function (A) {
                            A.target.style.color = "#1888FF"
                        })), A.addEventListener("mouseleave", (function (A) {
                            A.target.style.color = "inherit"
                        }))
                    }))
                }, setDoubleSpeedOperate: function (A) {
                    A.style.display = "block", A.style.position = "relative";
                    var e = A.querySelector("#dso_label"), t = A.querySelector("#doubleSpeedOperate_list"),
                        r = A.querySelector("#doubleSpeedOperate_main");
                    r.style.width = "116px", r.style.height = "246px", r.style.position = "absolute", r.style.top = "-244px", r.style.left = "-28px", r.style.margin = "auto", r.style.background = "transparent", t.style.width = "116px", t.style.height = "235px", t.style.background = "rgba(0,0,0,0.75)", t.style.borderRadius = "4px";
                    var n = t.querySelectorAll(".dso-item"), i = Array.from(n);
                    i.forEach((function (A) {
                        A.style.height = "46px", A.style.lineHeight = "46px", A.addEventListener("click", (function (A) {
                            e.innerText = A.target.innerText;
                            var t = document.querySelector("#J_prismPlayer>video");
                            t.playbackRate = parseFloat(A.target.innerText.split("x")[0]), t.play(), r.style.display = "none"
                        })), A.addEventListener("mouseenter", (function (A) {
                            A.target.style.color = "#1888FF"
                        })), A.addEventListener("mouseleave", (function (A) {
                            A.target.style.color = "inherit"
                        }))
                    }))
                }, registerEvent: function () {
                    var A = this;
                    this.eventList.map((function (e) {
                        A.player.on(e, (function (t) {
                            A.$emit(e, t)
                        }))
                    }))
                }, rePlay: function () {
                    var A = this;
                    "" !== this.videoId && (this.isPlay = !1, this.$nextTick((function () {
                        A.isPlay = !0, A.aliPlayer()
                    })))
                }, addVideoClick: function () {
                    if ("preview" !== this.$route.query.from) {
                        var A = this;
                        setTimeout((function () {
                            document.getElementsByTagName("video")[0].addEventListener("play", (function () {
                                clearInterval(A.heartbeatTimer), A.heartbeatTimer = setInterval((function () {
                                    console.log(A.heartbeatTime), A.heartbeatTime % 60 === 0 && document.getElementsByTagName("video")[0] && o["c"].heartBeatSetData(A.courseId), A.heartbeatTime++
                                }), 1e3)
                            })), document.getElementsByTagName("video")[0].addEventListener("pause", (function () {
                                console.log("clear"), clearInterval(A.heartbeatTimer)
                            })), document.getElementsByTagName("video")[0].pause(), document.getElementsByTagName("video")[0].play(), A.$store.state.home.jumpFlag && document.getElementsByTagName("video")[0].pause()
                        }), 1500)
                    }
                }, resetPlayer: function () {
                    this.isPlay = !1
                }, initWater: function () {
                    var A = this;
                    o["a"].APIconfirmWatermark().then((function (e) {
                        var t = e.bizResult, r = "true" === t.enableWatermark,
                            n = t.waterMarkShowObject ? t.waterMarkShowObject.split(",") : [], i = [];
                        n.forEach((function (A) {
                            "EMPLOYEE_CODE" === A ? i.push(t.employeeCode) : "USER_NAME" === A ? i.push(t.userName) : "LOGIN_NAME" === A && i.push(t.loginName)
                        })), i = i.join(" "), console.log(i), r && A.setWater(t, i)
                    }))
                }, setWater: function (A, e) {
                    var t, r, n = e.length, i = "middle", s = 1.1 - A.waterMarkDensity / 100,
                        o = A.waterMarkTransparency / 100,
                        a = 40 * n * s + 200 > document.documentElement.offsetWidth ? document.documentElement.offsetWidth - 150 : 40 * n * s + 200,
                        c = .8 * a;
                    t = (a - 100) / 1.7, r = (a - 100) / 1.5, 40 * n * s + 150 > document.documentElement.offsetWidth && (i = "end");
                    var l = '<svg xmlns="http://www.w3.org/2000/svg"  width="'.concat(a, 'px" height="').concat(c, "px\">\n                            <text \n                              x='").concat(t, "px'\n                              y='").concat(r, "px'\n                              text-anchor=\"").concat(i, '"\n                              stroke="#999"\n                              dominant-baseline="middle"\n                              stroke-opacity="0.25"\n                              fill="#999"\n                              transform="rotate(-45, 120 120)"\n                              style="font-size: 18px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:').concat(o, '">\n                              ').concat(e, "\n                            </text>\n                          </svg>"),
                        u = "data:image/svg+xml;base64,".concat(window.btoa(unescape(encodeURIComponent(l))));
                    this.base64Url = u, this.$refs.waterMarker.style.backgroundImage = "url(".concat(u, ")")
                }
            }, beforeDestroy: function () {
                clearInterval(this.heartbeatTimer)
            }, mounted: function () {
                this.initWater(), this.aliPlayer()
            }, destroyed: function () {
            }
        }, g = h, p = (t("da3d"), t("2877")), f = Object(p["a"])(g, r, n, !1, null, "c1fcee6a", null);
        e["a"] = f.exports
    }, "73aa": function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("d8d69");

        function i(A, e, t) {
            n.call(this, A, e, t, { noCredentials: !0 })
        }

        r(i, n), i.enabled = n.enabled, A.exports = i
    }, "74e3": function (A, e, t) {
    }, 7577: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("621f"), i = t("f7a9"), s = function () {
        };

        function o(A) {
            return function (e, t, r) {
                s("create ajax sender", e, t);
                var i = {};
                "string" === typeof t && (i.headers = { "Content-type": "text/plain" });
                var o = n.addPath(e, "/xhr_send"), a = new A("POST", o, t, i);
                return a.once("finish", (function (A) {
                    if (s("finish", A), a = null, 200 !== A && 204 !== A) return r(new Error("http status " + A));
                    r()
                })), function () {
                    s("abort"), a.close(), a = null;
                    var A = new Error("Aborted");
                    A.code = 1e3, r(A)
                }
            }
        }

        function a(A, e, t, r) {
            i.call(this, A, e, o(r), t, r)
        }

        r(a, i), A.exports = a
    }, 7725: function (A, e, t) {
        "use strict";
        var r, n = Array.prototype, i = Object.prototype, s = Function.prototype, o = String.prototype, a = n.slice,
            c = i.toString, l = function (A) {
                return "[object Function]" === i.toString.call(A)
            }, u = function (A) {
                return "[object Array]" === c.call(A)
            }, d = function (A) {
                return "[object String]" === c.call(A)
            }, B = Object.defineProperty && function () {
                try {
                    return Object.defineProperty({}, "x", {}), !0
                } catch (A) {
                    return !1
                }
            }();
        r = B ? function (A, e, t, r) {
            !r && e in A || Object.defineProperty(A, e, { configurable: !0, enumerable: !1, writable: !0, value: t })
        } : function (A, e, t, r) {
            !r && e in A || (A[e] = t)
        };
        var h = function (A, e, t) {
            for (var n in e) i.hasOwnProperty.call(e, n) && r(A, n, e[n], t)
        }, g = function (A) {
            if (null == A) throw new TypeError("can't convert " + A + " to object");
            return Object(A)
        };

        function p(A) {
            var e = +A;
            return e !== e ? e = 0 : 0 !== e && e !== 1 / 0 && e !== -1 / 0 && (e = (e > 0 || -1) * Math.floor(Math.abs(e))), e
        }

        function f(A) {
            return A >>> 0
        }

        function w() {
        }

        h(s, {
            bind: function (A) {
                var e = this;
                if (!l(e)) throw new TypeError("Function.prototype.bind called on incompatible " + e);
                for (var t = a.call(arguments, 1), r = function () {
                    if (this instanceof o) {
                        var r = e.apply(this, t.concat(a.call(arguments)));
                        return Object(r) === r ? r : this
                    }
                    return e.apply(A, t.concat(a.call(arguments)))
                }, n = Math.max(0, e.length - t.length), i = [], s = 0; s < n; s++) i.push("$" + s);
                var o = Function("binder", "return function (" + i.join(",") + "){ return binder.apply(this, arguments); }")(r);
                return e.prototype && (w.prototype = e.prototype, o.prototype = new w, w.prototype = null), o
            }
        }), h(Array, { isArray: u });
        var C = Object("a"), m = "a" !== C[0] || !(0 in C), Q = function (A) {
            var e = !0, t = !0;
            return A && (A.call("foo", (function (A, t, r) {
                "object" !== typeof r && (e = !1)
            })), A.call([1], (function () {
                t = "string" === typeof this
            }), "x")), !!A && e && t
        };
        h(n, {
            forEach: function (A) {
                var e = g(this), t = m && d(this) ? this.split("") : e, r = arguments[1], n = -1, i = t.length >>> 0;
                if (!l(A)) throw new TypeError;
                while (++n < i) n in t && A.call(r, t[n], n, e)
            }
        }, !Q(n.forEach));
        var y = Array.prototype.indexOf && -1 !== [0, 1].indexOf(1, 2);
        h(n, {
            indexOf: function (A) {
                var e = m && d(this) ? this.split("") : g(this), t = e.length >>> 0;
                if (!t) return -1;
                var r = 0;
                for (arguments.length > 1 && (r = p(arguments[1])), r = r >= 0 ? r : Math.max(0, t + r); r < t; r++) if (r in e && e[r] === A) return r;
                return -1
            }
        }, y);
        var U = o.split;
        2 !== "ab".split(/(?:ab)*/).length || 4 !== ".".split(/(.?)(.?)/).length || "t" === "tesst".split(/(s)*/)[1] || 4 !== "test".split(/(?:)/, -1).length || "".split(/.?/).length || ".".split(/()()/).length > 1 ? function () {
            var A = void 0 === /()??/.exec("")[1];
            o.split = function (e, t) {
                var r = this;
                if (void 0 === e && 0 === t) return [];
                if ("[object RegExp]" !== c.call(e)) return U.call(this, e, t);
                var i, s, o, a, l = [],
                    u = (e.ignoreCase ? "i" : "") + (e.multiline ? "m" : "") + (e.extended ? "x" : "") + (e.sticky ? "y" : ""),
                    d = 0;
                e = new RegExp(e.source, u + "g"), r += "", A || (i = new RegExp("^" + e.source + "$(?!\\s)", u)), t = void 0 === t ? -1 >>> 0 : f(t);
                while (s = e.exec(r)) {
                    if (o = s.index + s[0].length, o > d && (l.push(r.slice(d, s.index)), !A && s.length > 1 && s[0].replace(i, (function () {
                        for (var A = 1; A < arguments.length - 2; A++) void 0 === arguments[A] && (s[A] = void 0)
                    })), s.length > 1 && s.index < r.length && n.push.apply(l, s.slice(1)), a = s[0].length, d = o, l.length >= t)) break;
                    e.lastIndex === s.index && e.lastIndex++
                }
                return d === r.length ? !a && e.test("") || l.push("") : l.push(r.slice(d)), l.length > t ? l.slice(0, t) : l
            }
        }() : "0".split(void 0, 0).length && (o.split = function (A, e) {
            return void 0 === A && 0 === e ? [] : U.call(this, A, e)
        });
        var v = o.substr, F = "".substr && "b" !== "0b".substr(-1);
        h(o, {
            substr: function (A, e) {
                return v.call(this, A < 0 && (A = this.length + A) < 0 ? 0 : A, e)
            }
        }, F)
    }, "7b4d": function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("7577"), i = t("f91e"), s = t("df09"), o = t("ca34");

        function a(A) {
            if (!a.enabled()) throw new Error("Transport created when disabled");
            n.call(this, A, "/eventsource", i, s)
        }

        r(a, n), a.enabled = function () {
            return !!o
        }, a.transportName = "eventsource", a.roundTrips = 2, A.exports = a
    }, "7c20": function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("ada0").EventEmitter, n = t("3fb5"), i = t("930c"), s = t("c282"), o = t("9f3a"), a = t("c529"),
                c = function () {
                };

            function l(A, t) {
                var n = this;
                r.call(this);
                var l = function () {
                    var e = n.ifr = new o(a.transportName, t, A);
                    e.once("message", (function (A) {
                        if (A) {
                            var e;
                            try {
                                e = i.parse(A)
                            } catch (s) {
                                return c("bad json", A), n.emit("finish"), void n.close()
                            }
                            var t = e[0], r = e[1];
                            n.emit("finish", t, r)
                        }
                        n.close()
                    })), e.once("close", (function () {
                        n.emit("finish"), n.close()
                    }))
                };
                e.document.body ? l() : s.attachEvent("load", l)
            }

            n(l, r), l.enabled = function () {
                return o.enabled()
            }, l.prototype.close = function () {
                this.ifr && this.ifr.close(), this.removeAllListeners(), this.ifr = null
            }, A.exports = l
        }).call(this, t("c8ba"))
    }, "7ff9": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAIAAAAACPTkDJAAAFWUlEQVRYCeWXe2zURRDHZ67XFkuRChHpAaWIiEoQExVRUIHgo1DBRzRiwEhMQCBRVNrDqAl/aNKKBCSRh8QQAmoUhCBBSEhFkRiswQQSRbHSUui1aigPa/H6uPUzv95d78q12mD9x01/ndnZeXx3Z3d2T+T/3rSzBRhZ6vr8rlIYcfKgOhnhRAKiko1+Jd+ujAx5p/p5Pd6Z/cASV4D+q9jmiU/W1hbra6l0LwIQWO6GRJolyMDTBO2Vyigqa1GVjRk+ef1EkRoor+Wtdlc0n5dV2M6KyYz602TcqSL9OlFmfBKAQKmb7px82CFwBUrlTuUYAVslIrfATxUn6VFnLXjZw0yPQK/D9h7G+nhjKiFoLn2Ls6Buia6J2sSJP87BRERMwWbdwrfZr7LmVFDL4ZNa7ptuKFBeJthTHhAnhfCF8O1NZUtab5nf2iB1CP3qk4z2wXYuvgI3r3PpNWclbGh9Ii+FlmhJu1pqzoC4iCzAZhrfYOZZj+1+nK6tCepBs2IvNEMMwCL2wVsdPcVX4NA8bc4tcUeYxBiW+G4U/xZA7WI9gV4w+nX0/Y/6AG5v5PiTaG/SqLed7fgeb0kAmL0HgI2YWf+H3Nfj0QmQBCBULIfIo+1c25HTPdrD/5IAqKojDTujMac9+pFL6+H4yStgwdjVOzwq0v9AtYz/zwFkZ8lnBG3wArfKjEsGoF4R6tRNUgpMq+JZDZOGPcazKR8yai1/hcsZvswN6E5ahq5wVgW9NBLoXJun5P/xQpQoDpS4J6iK75kMMJ9C7uBk5Hh9kSbqxLc43OZLl/dPvaA1Jk9s16xymRcaZUaryCvIR7MGzp8u16JbkahnfEoANts/w/Ib4/FC1dEw2o8AcC9e9vNVa6sEAHcTYwUxwKbnU1kdCurCqE0SSQnANCihZZDJOG5GaSPfV6wKf5LHxTOF9EyAvyiFyBJbBSV4WahI1tsJSxyI8Z0CyH3DPceJWAkAx7U3+GRQ2+pD1JI05UVU5uB2GqJReM+Kgq2iX4bjbXOLpWypqoHufiMN+ayCs487Yl5XHpY65xu20l1ltCu9VGOdroApDyx1h9nFN5Ln3bVBnZrKwaXKukTM8sYup8k9dTl1CYCctlXFHrycukyBc04DpXKSDTaINGwiDU/aklsx+rJS9rJCtzMWRtTI+Hnoab5fSdsJzkclzo/6s+Wb6gV6BnnKFgcwuMSNbvHJLJw+gGa2psm9ocX6Q26pW8OZfoYA9ROGyYAtj2mrbbgLYamJVbmUnmNCThFBjtHdis/N5jM2ZFQD61yWOyPr0ZqJwzgglB+uLdLtHMf7OY67PSOfTKwr1i+M5zl2F+/C8dilc9AyAZjDeeuHg1xWJQ+VvFQA0fugX7bM/W6heveNP3JW3kX5cZSt7F6A3wXdGiI4vPTuJfsaGr3LKZsydCsiDwDPsf3w9qVs+Rtcr6Z6ud61yG34noJSASGyWM2Z9Q2SSf8RM1TO+VloX+ZeSb2+M1Vt57luvxFmozeffXDUDLvbhpS6AK/TA4AZhm0DT3Tv6a6c9R0IY6+f88x+J8tYRsCDI8fKT59PUnuid7tN3Of8P5bLCHyNY9ZWugtxcrnniLdnXVC9q16vLnF9WfcNKMSv3lg0jJtYmZ8BaCchBLh6cn7O5yQMbTI9Nm0GJTkT2pdAtgfsJ9wQbIZjc9FvAca3XyYy5/gS9a5n+m1t0HI3hnzN5reg5SY/Kv63SBU34sfql001L+rhRKdxAIlCO2bhZhnLpruBWeQzls+MroTvj4Htl6zY7Og3MdZI/xz8acbsGq+Cr6IWfJ+ZLuWVi/SXRP+J/F+XK9H/d2hQCQAAAABJRU5ErkJggg=="
    }, 8170: function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAADtklEQVRoBe2aW08UMRiGWRE8ICooHlCvjN4aY4x647/30niMJiYajcZoEOSgeABZ32egZCy728O028S0ybftdqZ9n37ztbPT2Yl+v39eNjlRKB2S7gnZFUEcL8EAAAkPXBTEgszUNQdyf9hiJyV4WRBHcwub/m0A6qdklwQxL+uZE3PlgwCM1pwKeGPaVOTIRwGghzgBejqXN1wAZtBnVFgUBJcnafIFQJTAxBsEarIUAoAoQclUZcoeTkERCmA0WbTwxoypiM1jAdCj7QVBnJNF9xPdsDXiWZXxxrFWnXcxBQBixAOz5GyoN1IBmBGfUoHF64ipcOWpAdBjrQBiTuZcynMAmEHPq8A9ZeRSnhMAEC4F3uDSDEy5ARDlMhCcBOmBxWscAGbkTFOmK7/A9tM4ARBFj9+g3OqbNG4Ao8uPHRawhshUjjsnLiZLecAMfrYkABAzpQGmSgMUjYEm6Et7oOg0rB6oHqgeqB6oHqgeqB6oHqgeiPJA8zjVtEz0EfKj9Lo078sWE2k33Rx4Xh/SOeIY6eZuNvFxL++U+XgAt19rqbDhAEQST/gAbEjskawvMykZhA8Aorg7C4QvQDaIEIAsEKEAySFiAJJCxAIkg+gCkASiK0BniBQAQOzwMSBtDaj7pyoFwIJ6vCVrb82zaj6ULclGpq4AbMnflrXFEWTV/ETBlboAsN97R2b38UR13ndKu7EL2Bzn5SXi9h8fnqvuvTnJJ48BYLv9rsz+LfFSdW9lQSkUgBeV92TTlsorfX9t1Xl9DQHghQPi9huxN6oDICr5AiCKuP3PineqexGlvNfIF+CGzrf/5PJBdc+6iNPWF+Cpzv3eEmOaPW59jy76AvyUwgPZuuyzjIUmSerptcnVgJ54K/pHNmztD+hq91R7Lrs6cN5cXB3Yx30vgd0u2fcKUD1QPVA9UD1QPVA9UD1QPVA9UNoDO6UBtksDbJYGWC8JsNrr9bZKAWzq0WqFx6vQZ8MUj2SriGv0zRuYcQLwYLsk4R/tUYwDgJF+lXHN2++dGo7cAIz2i4R/N2oDPnIBsIGBMG/cRqYcAIguS5ydFGdKCUCQMWqmmHdKBWCCLHjvqCsAu2dMraFB5nJFLAAjXZZtSPzA1HKJto/HALBhybXebncUWw4BQBDh9o5prO5+O1+ANbVg/Q4Osn2lIQUXwC+1I8jIs6RhAAQWt8s1iXcKMhf1IAAWEkadJMhCAFg6CbJvrkYpjxsPsA3P+p08yJyw2q63X8M42/xXJ/wFwHnm7/JFNS4AAAAASUVORK5CYII="
    }, "84fc": function (A, e, t) {
        "use strict";
        var r, n = t("930c"),
            i = /[\x00-\x1f\ud800-\udfff\ufffe\uffff\u0300-\u0333\u033d-\u0346\u034a-\u034c\u0350-\u0352\u0357-\u0358\u035c-\u0362\u0374\u037e\u0387\u0591-\u05af\u05c4\u0610-\u0617\u0653-\u0654\u0657-\u065b\u065d-\u065e\u06df-\u06e2\u06eb-\u06ec\u0730\u0732-\u0733\u0735-\u0736\u073a\u073d\u073f-\u0741\u0743\u0745\u0747\u07eb-\u07f1\u0951\u0958-\u095f\u09dc-\u09dd\u09df\u0a33\u0a36\u0a59-\u0a5b\u0a5e\u0b5c-\u0b5d\u0e38-\u0e39\u0f43\u0f4d\u0f52\u0f57\u0f5c\u0f69\u0f72-\u0f76\u0f78\u0f80-\u0f83\u0f93\u0f9d\u0fa2\u0fa7\u0fac\u0fb9\u1939-\u193a\u1a17\u1b6b\u1cda-\u1cdb\u1dc0-\u1dcf\u1dfc\u1dfe\u1f71\u1f73\u1f75\u1f77\u1f79\u1f7b\u1f7d\u1fbb\u1fbe\u1fc9\u1fcb\u1fd3\u1fdb\u1fe3\u1feb\u1fee-\u1fef\u1ff9\u1ffb\u1ffd\u2000-\u2001\u20d0-\u20d1\u20d4-\u20d7\u20e7-\u20e9\u2126\u212a-\u212b\u2329-\u232a\u2adc\u302b-\u302c\uaab2-\uaab3\uf900-\ufa0d\ufa10\ufa12\ufa15-\ufa1e\ufa20\ufa22\ufa25-\ufa26\ufa2a-\ufa2d\ufa30-\ufa6d\ufa70-\ufad9\ufb1d\ufb1f\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufb4e\ufff0-\uffff]/g,
            s = function (A) {
                var e, t = {}, r = [];
                for (e = 0; e < 65536; e++) r.push(String.fromCharCode(e));
                return A.lastIndex = 0, r.join("").replace(A, (function (A) {
                    return t[A] = "\\u" + ("0000" + A.charCodeAt(0).toString(16)).slice(-4), ""
                })), A.lastIndex = 0, t
            };
        A.exports = {
            quote: function (A) {
                var e = n.stringify(A);
                return i.lastIndex = 0, i.test(e) ? (r || (r = s(i)), e.replace(i, (function (A) {
                    return r[A]
                }))) : e
            }
        }
    }, "89bc": function (A, e, t) {
        "use strict";
        var r = t("ada0").EventEmitter, n = t("3fb5"), i = t("930c"), s = t("d5e5"), o = function () {
        };

        function a(A, e) {
            r.call(this);
            var t = this, n = +new Date;
            this.xo = new e("GET", A), this.xo.once("finish", (function (A, e) {
                var r, a;
                if (200 === A) {
                    if (a = +new Date - n, e) try {
                        r = i.parse(e)
                    } catch (c) {
                        o("bad json", e)
                    }
                    s.isObject(r) || (r = {})
                }
                t.emit("finish", r, a), t.removeAllListeners()
            }))
        }

        n(a, r), a.prototype.close = function () {
            this.removeAllListeners(), this.xo.close()
        }, A.exports = a
    }, "8a92": function (A, e, t) {
    }, "930c": function (A, e, t) {
        (function (A, r) {
            var n;/*! JSON v3.3.2 | https://bestiejs.github.io/json3 | Copyright 2012-2015, Kit Cambridge, Benjamin Tan | http://kit.mit-license.org */
            (function () {
                var i = t("3c35"), s = { function: !0, object: !0 }, o = s[typeof e] && e && !e.nodeType && e,
                    a = s[typeof window] && window || this,
                    c = o && s[typeof A] && A && !A.nodeType && "object" == typeof r && r;

                function l(A, e) {
                    A || (A = a.Object()), e || (e = a.Object());
                    var t = A.Number || a.Number, r = A.String || a.String, n = A.Object || a.Object,
                        i = A.Date || a.Date, o = A.SyntaxError || a.SyntaxError, c = A.TypeError || a.TypeError,
                        u = A.Math || a.Math, d = A.JSON || a.JSON;
                    "object" == typeof d && d && (e.stringify = d.stringify, e.parse = d.parse);
                    var B, h = n.prototype, g = h.toString, p = h.hasOwnProperty;

                    function f(A, e) {
                        try {
                            A()
                        } catch (t) {
                            e && e()
                        }
                    }

                    var w = new i(-0xc782b5b800cec);

                    function C(A) {
                        if (null != C[A]) return C[A];
                        var n;
                        if ("bug-string-char-index" == A) n = "a" != "a"[0]; else if ("json" == A) n = C("json-stringify") && C("date-serialization") && C("json-parse"); else if ("date-serialization" == A) {
                            if (n = C("json-stringify") && w, n) {
                                var s = e.stringify;
                                f((function () {
                                    n = '"-271821-04-20T00:00:00.000Z"' == s(new i(-864e13)) && '"+275760-09-13T00:00:00.000Z"' == s(new i(864e13)) && '"-000001-01-01T00:00:00.000Z"' == s(new i(-621987552e5)) && '"1969-12-31T23:59:59.999Z"' == s(new i(-1))
                                }))
                            }
                        } else {
                            var o, a = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
                            if ("json-stringify" == A) {
                                s = e.stringify;
                                var c = "function" == typeof s;
                                c && ((o = function () {
                                    return 1
                                }).toJSON = o, f((function () {
                                    c = "0" === s(0) && "0" === s(new t) && '""' == s(new r) && s(g) === B && s(B) === B && s() === B && "1" === s(o) && "[1]" == s([o]) && "[null]" == s([B]) && "null" == s(null) && "[null,null,null]" == s([B, g, null]) && s({ a: [o, !0, !1, null, "\0\b\n\f\r\t"] }) == a && "1" === s(null, o) && "[\n 1,\n 2\n]" == s([1, 2], null, 1)
                                }), (function () {
                                    c = !1
                                }))), n = c
                            }
                            if ("json-parse" == A) {
                                var l, u = e.parse;
                                "function" == typeof u && f((function () {
                                    0 !== u("0") || u(!1) || (o = u(a), l = 5 == o["a"].length && 1 === o["a"][0], l && (f((function () {
                                        l = !u('"\t"')
                                    })), l && f((function () {
                                        l = 1 !== u("01")
                                    })), l && f((function () {
                                        l = 1 !== u("1.")
                                    }))))
                                }), (function () {
                                    l = !1
                                })), n = l
                            }
                        }
                        return C[A] = !!n
                    }

                    if (f((function () {
                        w = -109252 == w.getUTCFullYear() && 0 === w.getUTCMonth() && 1 === w.getUTCDate() && 10 == w.getUTCHours() && 37 == w.getUTCMinutes() && 6 == w.getUTCSeconds() && 708 == w.getUTCMilliseconds()
                    })), C["bug-string-char-index"] = C["date-serialization"] = C["json"] = C["json-stringify"] = C["json-parse"] = null, !C("json")) {
                        var m = "[object Function]", Q = "[object Date]", y = "[object Number]", U = "[object String]",
                            v = "[object Array]", F = "[object Boolean]", I = C("bug-string-char-index"),
                            E = function (A, e) {
                                var t, r, n, i = 0;
                                for (n in (t = function () {
                                    this.valueOf = 0
                                }).prototype.valueOf = 0, r = new t, r) p.call(r, n) && i++;
                                return t = r = null, i ? E = function (A, e) {
                                    var t, r, n = g.call(A) == m;
                                    for (t in A) n && "prototype" == t || !p.call(A, t) || (r = "constructor" === t) || e(t);
                                    (r || p.call(A, t = "constructor")) && e(t)
                                } : (r = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"], E = function (A, e) {
                                    var t, n, i = g.call(A) == m,
                                        o = !i && "function" != typeof A.constructor && s[typeof A.hasOwnProperty] && A.hasOwnProperty || p;
                                    for (t in A) i && "prototype" == t || !o.call(A, t) || e(t);
                                    for (n = r.length; t = r[--n];) o.call(A, t) && e(t)
                                }), E(A, e)
                            };
                        if (!C("json-stringify") && !C("date-serialization")) {
                            var b = { 92: "\\\\", 34: '\\"', 8: "\\b", 12: "\\f", 10: "\\n", 13: "\\r", 9: "\\t" },
                                H = "000000", T = function (A, e) {
                                    return (H + (e || 0)).slice(-A)
                                }, x = function (A) {
                                    var e, t, r, n, i, s, o, a, c;
                                    if (w) e = function (A) {
                                        t = A.getUTCFullYear(), r = A.getUTCMonth(), n = A.getUTCDate(), s = A.getUTCHours(), o = A.getUTCMinutes(), a = A.getUTCSeconds(), c = A.getUTCMilliseconds()
                                    }; else {
                                        var l = u.floor, d = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
                                            B = function (A, e) {
                                                return d[e] + 365 * (A - 1970) + l((A - 1969 + (e = +(e > 1))) / 4) - l((A - 1901 + e) / 100) + l((A - 1601 + e) / 400)
                                            };
                                        e = function (A) {
                                            for (n = l(A / 864e5), t = l(n / 365.2425) + 1970 - 1; B(t + 1, 0) <= n; t++);
                                            for (r = l((n - B(t, 0)) / 30.42); B(t, r + 1) <= n; r++);
                                            n = 1 + n - B(t, r), i = (A % 864e5 + 864e5) % 864e5, s = l(i / 36e5) % 24, o = l(i / 6e4) % 60, a = l(i / 1e3) % 60, c = i % 1e3
                                        }
                                    }
                                    return x = function (A) {
                                        return A > -1 / 0 && A < 1 / 0 ? (e(A), A = (t <= 0 || t >= 1e4 ? (t < 0 ? "-" : "+") + T(6, t < 0 ? -t : t) : T(4, t)) + "-" + T(2, r + 1) + "-" + T(2, n) + "T" + T(2, s) + ":" + T(2, o) + ":" + T(2, a) + "." + T(3, c) + "Z", t = r = n = s = o = a = c = null) : A = null, A
                                    }, x(A)
                                };
                            if (C("json-stringify") && !C("date-serialization")) {
                                function S(A) {
                                    return x(this)
                                }

                                var D = e.stringify;
                                e.stringify = function (A, e, t) {
                                    var r = i.prototype.toJSON;
                                    i.prototype.toJSON = S;
                                    var n = D(A, e, t);
                                    return i.prototype.toJSON = r, n
                                }
                            } else {
                                var L = "\\u00", K = function (A) {
                                    var e = A.charCodeAt(0), t = b[e];
                                    return t || L + T(2, e.toString(16))
                                }, k = /[\x00-\x1f\x22\x5c]/g, O = function (A) {
                                    return k.lastIndex = 0, '"' + (k.test(A) ? A.replace(k, K) : A) + '"'
                                }, P = function (A, e, t, r, n, s, o) {
                                    var a, l, u, d, h, p, w, C, m;
                                    if (f((function () {
                                        a = e[A]
                                    })), "object" == typeof a && a && (a.getUTCFullYear && g.call(a) == Q && a.toJSON === i.prototype.toJSON ? a = x(a) : "function" == typeof a.toJSON && (a = a.toJSON(A))), t && (a = t.call(e, A, a)), a == B) return a === B ? a : "null";
                                    switch (l = typeof a, "object" == l && (u = g.call(a)), u || l) {
                                        case "boolean":
                                        case F:
                                            return "" + a;
                                        case "number":
                                        case y:
                                            return a > -1 / 0 && a < 1 / 0 ? "" + a : "null";
                                        case "string":
                                        case U:
                                            return O("" + a)
                                    }
                                    if ("object" == typeof a) {
                                        for (w = o.length; w--;) if (o[w] === a) throw c();
                                        if (o.push(a), d = [], C = s, s += n, u == v) {
                                            for (p = 0, w = a.length; p < w; p++) h = P(p, a, t, r, n, s, o), d.push(h === B ? "null" : h);
                                            m = d.length ? n ? "[\n" + s + d.join(",\n" + s) + "\n" + C + "]" : "[" + d.join(",") + "]" : "[]"
                                        } else E(r || a, (function (A) {
                                            var e = P(A, a, t, r, n, s, o);
                                            e !== B && d.push(O(A) + ":" + (n ? " " : "") + e)
                                        })), m = d.length ? n ? "{\n" + s + d.join(",\n" + s) + "\n" + C + "}" : "{" + d.join(",") + "}" : "{}";
                                        return o.pop(), m
                                    }
                                };
                                e.stringify = function (A, e, t) {
                                    var r, n, i, o;
                                    if (s[typeof e] && e) if (o = g.call(e), o == m) n = e; else if (o == v) {
                                        i = {};
                                        for (var a, c = 0, l = e.length; c < l;) a = e[c++], o = g.call(a), "[object String]" != o && "[object Number]" != o || (i[a] = 1)
                                    }
                                    if (t) if (o = g.call(t), o == y) {
                                        if ((t -= t % 1) > 0) for (t > 10 && (t = 10), r = ""; r.length < t;) r += " "
                                    } else o == U && (r = t.length <= 10 ? t : t.slice(0, 10));
                                    return P("", (a = {}, a[""] = A, a), n, i, r, "", [])
                                }
                            }
                        }
                        if (!C("json-parse")) {
                            var N, R, M = r.fromCharCode,
                                _ = { 92: "\\", 34: '"', 47: "/", 98: "\b", 116: "\t", 110: "\n", 102: "\f", 114: "\r" },
                                V = function () {
                                    throw N = R = null, o()
                                }, G = function () {
                                    var A, e, t, r, n, i = R, s = i.length;
                                    while (N < s) switch (n = i.charCodeAt(N), n) {
                                        case 9:
                                        case 10:
                                        case 13:
                                        case 32:
                                            N++;
                                            break;
                                        case 123:
                                        case 125:
                                        case 91:
                                        case 93:
                                        case 58:
                                        case 44:
                                            return A = I ? i.charAt(N) : i[N], N++, A;
                                        case 34:
                                            for (A = "@", N++; N < s;) if (n = i.charCodeAt(N), n < 32) V(); else if (92 == n) switch (n = i.charCodeAt(++N), n) {
                                                case 92:
                                                case 34:
                                                case 47:
                                                case 98:
                                                case 116:
                                                case 110:
                                                case 102:
                                                case 114:
                                                    A += _[n], N++;
                                                    break;
                                                case 117:
                                                    for (e = ++N, t = N + 4; N < t; N++) n = i.charCodeAt(N), n >= 48 && n <= 57 || n >= 97 && n <= 102 || n >= 65 && n <= 70 || V();
                                                    A += M("0x" + i.slice(e, N));
                                                    break;
                                                default:
                                                    V()
                                            } else {
                                                if (34 == n) break;
                                                n = i.charCodeAt(N), e = N;
                                                while (n >= 32 && 92 != n && 34 != n) n = i.charCodeAt(++N);
                                                A += i.slice(e, N)
                                            }
                                            if (34 == i.charCodeAt(N)) return N++, A;
                                            V();
                                        default:
                                            if (e = N, 45 == n && (r = !0, n = i.charCodeAt(++N)), n >= 48 && n <= 57) {
                                                for (48 == n && (n = i.charCodeAt(N + 1), n >= 48 && n <= 57) && V(), r = !1; N < s && (n = i.charCodeAt(N), n >= 48 && n <= 57); N++);
                                                if (46 == i.charCodeAt(N)) {
                                                    for (t = ++N; t < s; t++) if (n = i.charCodeAt(t), n < 48 || n > 57) break;
                                                    t == N && V(), N = t
                                                }
                                                if (n = i.charCodeAt(N), 101 == n || 69 == n) {
                                                    for (n = i.charCodeAt(++N), 43 != n && 45 != n || N++, t = N; t < s; t++) if (n = i.charCodeAt(t), n < 48 || n > 57) break;
                                                    t == N && V(), N = t
                                                }
                                                return +i.slice(e, N)
                                            }
                                            r && V();
                                            var o = i.slice(N, N + 4);
                                            if ("true" == o) return N += 4, !0;
                                            if ("fals" == o && 101 == i.charCodeAt(N + 4)) return N += 5, !1;
                                            if ("null" == o) return N += 4, null;
                                            V()
                                    }
                                    return "$"
                                }, J = function (A) {
                                    var e, t;
                                    if ("$" == A && V(), "string" == typeof A) {
                                        if ("@" == (I ? A.charAt(0) : A[0])) return A.slice(1);
                                        if ("[" == A) {
                                            for (e = []; ;) {
                                                if (A = G(), "]" == A) break;
                                                t ? "," == A ? (A = G(), "]" == A && V()) : V() : t = !0, "," == A && V(), e.push(J(A))
                                            }
                                            return e
                                        }
                                        if ("{" == A) {
                                            for (e = {}; ;) {
                                                if (A = G(), "}" == A) break;
                                                t ? "," == A ? (A = G(), "}" == A && V()) : V() : t = !0, "," != A && "string" == typeof A && "@" == (I ? A.charAt(0) : A[0]) && ":" == G() || V(), e[A.slice(1)] = J(G())
                                            }
                                            return e
                                        }
                                        V()
                                    }
                                    return A
                                }, j = function (A, e, t) {
                                    var r = X(A, e, t);
                                    r === B ? delete A[e] : A[e] = r
                                }, X = function (A, e, t) {
                                    var r, n = A[e];
                                    if ("object" == typeof n && n) if (g.call(n) == v) for (r = n.length; r--;) j(g, E, n, r, t); else E(n, (function (A) {
                                        j(n, A, t)
                                    }));
                                    return t.call(A, e, n)
                                };
                            e.parse = function (A, e) {
                                var t, r;
                                return N = 0, R = "" + A, t = J(G()), "$" != G() && V(), N = R = null, e && g.call(e) == m ? X((r = {}, r[""] = t, r), "", e) : t
                            }
                        }
                    }
                    return e.runInContext = l, e
                }

                if (!c || c.global !== c && c.window !== c && c.self !== c || (a = c), o && !i) l(a, o); else {
                    var u = a.JSON, d = a.JSON3, B = !1, h = l(a, a.JSON3 = {
                        noConflict: function () {
                            return B || (B = !0, a.JSON = u, a.JSON3 = d, u = d = null), h
                        }
                    });
                    a.JSON = { parse: h.parse, stringify: h.stringify }
                }
                i && (n = function () {
                    return h
                }.call(e, t, e, A), void 0 === n || (A.exports = n))
            }).call(this)
        }).call(this, t("62e4")(A), t("c8ba"))
    }, "948c": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAANxJREFUOBHdky0OwkAQhTsbDArFCXoEDEGQIEkQBIVA4MpFOEQvQRAkBIUjNT1CT4BCIZfvkQkJblsck7zuT9836XZnLCNijCOGFRpqic5mdmT8BJ4Ni6lv3BkPeOrgcMnG2F+mDPKWYo3H3uEFGZ8pNEwf3wlVgYc+u0mF8WbubcQqwU/Rg751zHDpyP0dpjqY6VRczbXN6eDm8usW1g62SgCzFKcEpkmHeHMqJDVG7uWZlMe9uVj9A3WimumBVJ7qRnXaV6Hg27I/QQrBA1QEjDWTHapQashbiH0BjwFD/NVolbwAAAAASUVORK5CYII="
    }, "97a2": function (A, e, t) {
        "use strict";

        function r() {
            this._listeners = {}
        }

        r.prototype.addEventListener = function (A, e) {
            A in this._listeners || (this._listeners[A] = []);
            var t = this._listeners[A];
            -1 === t.indexOf(e) && (t = t.concat([e])), this._listeners[A] = t
        }, r.prototype.removeEventListener = function (A, e) {
            var t = this._listeners[A];
            if (t) {
                var r = t.indexOf(e);
                -1 === r || (t.length > 1 ? this._listeners[A] = t.slice(0, r).concat(t.slice(r + 1)) : delete this._listeners[A])
            }
        }, r.prototype.dispatchEvent = function () {
            var A = arguments[0], e = A.type, t = 1 === arguments.length ? [A] : Array.apply(null, arguments);
            if (this["on" + e] && this["on" + e].apply(this, t), e in this._listeners) for (var r = this._listeners[e], n = 0; n < r.length; n++) r[n].apply(this, t)
        }, A.exports = r
    }, "9a48": function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAADvdJREFUeF7tnXnIblUVxp+HqCgLymzULJs0lKJMNBrIqIzU1MxCK1PMKBxKqUg0HDJRLDQNyww1J8zMTJts1CIzqRC1HBqUSMsGMtEGK1YsOfd6u937feecd631neE54F/uvdbZv71/d73f++6zD6FLBERgvQQoNiIgAusnIEG0OkRgCQISRMtDBCSI1oAI9COgCtKPm3rNhIAEmclEa5j9CEiQftzUayYEJMhMJlrD7EdAgvTjpl4zISBBZjLRGmY/AhKkHzf1mgkBCTKTidYw+xGQIP24qddMCEiQmUy0htmPgATpx029ZkJAgsxkojXMfgQkSD9u6jUTAhJkBSbazHYCsAOArQBsDeAPAK4H8AsAnyR5+wrcllKug4AEKV4WZnYZgJ2XSHsfgANJnl18a0onQVZ2DZjZjQC2bHkX25O8smVbNUsioAqSBHbtsGa2F4DzO6bbhOQdHfuoeSABCRIIc32hzGwDADcA2KxjuktI7t6xj5oHEpAggTCXEGQbANf2SHUXySf16KcuQQQkSBDIpcKY2T4AzuqZajN9q9WTXEA3CRIAcbkQZnYUgCOXa7ee/68/1nuCi+gmQSIoLhNDghRATkohQZLArhlWghRATkohQZLASpACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBLYtSrIkQCO6plqe5JX9uyrbgsSkCALAmzT3cwkSBtQA2wjQQomRYIUQE5KIUGSwOojVgHYghQSpACyKkgB5KQUEiQJrCpIAdiCFBKkALIqSAHkpBQSJAmsKkgB2IIUEqQAsipIAeSkFBIkCawqSAHYghQSpACyKkgB5KQUEiQJrCpIAdiCFBKkALI2KxZATkohQZLAqoIUgC1IIUEKIOtvkALISSkkSBLYtSqIb3X3Hb19Lm1370MtqM/kBDGznQC8BsDmAJ4P4K8AvgLghyQ/H8StU5gxVhAz2wPAiwHsCOBRAH4C4CYA55G8oROAETeelCBmdhmAnZeYj0tJ7lY9X2MSxMyeA+BYAC7I+q7jSR5WzXEl8k1GEDO7DcDTW0C8m+RjW7QLazKWb7HMbHcAJwPYpMXgTyZ5SIt2o24yCUHM7AMATugwE38huWGH9gs1HUMFMbNXAfgygId3GOzrSH6tQ/vRNR29IGb2WgB9Julmks+tmLGhC2Jm2zRyPKEjj18C2Ibk3R37jab5FAQ5EcD7ehK/iuQrevZt3W3IH7HMzL/MuBzAs1sP6H8b7kby0p59B99tCoL4tysvXID0RSTfvED/ZbsOtYKY2RObb/i2XnYQ628w6b9FpiDIPQAevcAEe9dTSR68YIz1dh+iIGb2sOaj6SsXHPflJF+/YIzBdp+CIN8FEPEx6QiSH8mYqSF+xDKzLwLYNWC8R5Pse+ZXQPrcEFMQ5FQABwZh2p/kZ4JirQ4ztApiZmcDeHvQOPckeWFQrMGFmYIgrwbwjUCyu5D0HxzDriEJYmYfBxD1cfIWAC8l+acwWAMLNHpBnKeZRVYRD+mT/oOouRrKRywz+zCAI6LGBWA/kmcGxhtcqKkI8tSmimwRSPh5UXuOhlBBzMy/CvevxKOui0kutR0lKs+KxpmEIE0V2RaA/+H55ECiTyP5m0XjrbQgZvZOAKcvOo41+n8LgP/+cW9gzEGGmowgjSS+i/cSABsE0f4PgI0W/aV4JT9imdmbAHwuiIeH+XEjx28DYw421KQEaSR5I4DIbe13+uY9ktZ3FleqgpiZf4Hh23Ae0vfe1+rnW0t2JfmzoHiDDzM5QRpJ9gMQ+XXtdSRf0Hc2V0IQM3sRgCsARG3K/GNTOcK+vOjLs7LfJAVpJDkUwMcCYV5B0jdGdr6qP2KZ2TMB+N8Jbbb/txnPvxo5/MGzWV2TFaSRZJFHXde1EM4h2fkHtsoKYmZeMb7TPE0ZtZjfSvL8qGBjijNpQRpJTgLw3sBJOZGkP3/S+qoSxMx8Pq8C8LLWN7d8wwNInrZ8s2m2mLwgjST+Y9a+gVPYad9W1UcsM/Nt6/5MftR1OMnjooKNMc4sBGkk+QKANwRO0kEkP9EmXkUFMbPzALylzf20bNO5UraMO6pmcxLEfxvxB3v80dKoa2+S5y4XLFsQM3NRD1juPjr8/zNI+o+Ls79mI0hTRZ7SSOKPmEZd/rvAl5YKlvkRK2F/VfoDZFHgK+LMSpBGEn8O3SuJH28TdS15uFtWBTGz6K+yfVe072b+RxSYsceZnSCNJNs1kvgjp1HX1iR/uq5gGYKYmX/pELmT9tpGjt9HAZlCnFkK0kiyQ7O58RFBE3mf//ZA8ldrx4v+iGVm/iSgb8yMum5t5Lg5KuBU4sxWkEaS6I18vwawHUnflrH6iqwgZuaPF/tjxlHXXc3+qmuiAk4pzqwFaSTZH8CnAyf1RwBeTvL+VTGjBDEzP2v4+wGHVKy6tX82cnw9cPyTClUiiJk9A8D9JAe5RTrhYaJvkvSt9w9cEYKY2aYAfKNgm2NB2y7SUT5PbmaPAbApyevbDrRvuzRBzMz/EPbv0n3bw7OaG/QzrL4H4BSSt/e96Yx+ZnYMgA8Fxl79xN2igjQnq18NYKvA+3s3yU8FxksP1fwt58cUrdpK4x8P/ePmtzMO2/ABpQhiZu8AcMYSxPwP2gNJ+ukag7mCDzTwcZ1Jcr8AQVzeyP1Vh5E8fjDgl7mRZuu+r5Utl2jqkkT+CPxAqnBBzOyiZY7OX3OMO5P0A5MHcwUfiePj8s2S/o6SvmdH+QkrkQeznUDyg4MBvrwc+wA4q+X93kly45ZtWzULFcTM/HwqP2Gky7UtSf8OfjBX4KFqq8Z09AJvmIrkcjrJd0UGzIxlZv48y40dH6E+iaT/gBpyhQliZo8E4N+j+wkjXa6rSb6kS4fstmbm+7b8X+5Fj+XMvtUu8S8kuWeXDivd1sz8lRadHi1o7jnsQO1IQfyR1HX+krwM6PIX2rSZeDPzfVsuySIHO7dJVdHGv8b1j7P/rkgWlcPM/ACOPm8EC9umHymI/+t0QU84zyTpP7IN6jIz37flkqz6Fm5Q99fyZvwHQJdjdKcfmpkfEuGPD3e9ziW5d9dO62ofKcgij7cO9k2uzdfVLsnjI4AXx/CPvC6HL7TRXWbW9ySZK0luHzFgCdKCopn5vi3f0t7l9WQtIqc2+Z1/+0XSz7Ea5SVBHpy2wVaQVbeYcABb5qL9eyOHn2wy2kuCjEgQv1Uzi963lbV49yB5cVbwqrgSZGSCNJJEHwIdvd5S3nESfZNt4kmQEQrSSBL9GoE266VNm/eT/GibhmNoI0FGKkgjySkADhrQQjuO5OEDup+Fb0WCjFiQRpLPAgj5vn3B1XQaychTTRa8nZjuEmTkgjSS+AEQu8QsiV5RLiAZeR5Wr5vI6CRBpiGI79vyHckRb9rtus6+SnLHrp3G0l6CTECQpor4vi2XpPcrEnosWn+AasdFX+7TI29ZFwkyEUEaSXzflkvijxdnXz9v5BjUU5nRg5YgExKkkcQfM3ZJHhe9WNaId4cfUE3yusQcgwgtQSYmSCOJ79vyU9YfmrDK/FFll+PKhNiDCylBJihII0n0eVurSIU9CDQ4G9ZxQxJkooI0kkTv29p3aIdcZEsmQSYsSCNJ1L6tQ0ienL0ghxZfgkxckEaSRfdtHUPyyKEt3or7kSAzEKSRpO++LT9g7z0Vi3GIOSTITARpJOm6b6vXG3WHuND73pMEmZEgHSvJqSQP7ruwptJPgsxMkEaSvQAcC2CzdSzk2wD4G3T7ng4zFTceGIcEmaEgzcT7IXubN/9t0Ry4dwuAW0j+bVKrfIHBSJCZCrLAmplVVwkiQWa14LsOVoJIkK5rZlbtJYgEmdWC7zpYCSJBuq6ZWbWXIBJkVgu+62AliATpumZm1V6CSJBZLfiug5UgEqTrmplVewkiQWa14LsOVoJIkK5rZlbtJYgEmdWC7zpYCSJBuq6ZWbWXIBJkVgu+62AlyIPEZnHOU9cFova9zzue3Es8tRZEIJKABImkqViTIyBBJjelGlAkAQkSSVOxJkdAgkxuSjWgSAISJJKmYk2OgASZ3JRqQJEEBinI2wCcEzlKxRKBngTOJRny9mH2vIH/62Zm2wK4Jiqe4ojAAgQOJ3ncAv1Xd40UZEMAf464KcUQgQUJhL1oKEwQH5CZHQVglkf1Lzih6h5H4CSSh0aFCxWkkcRfYjnZd3dHgVecFAJ3ktw4MnK4IKokkdOjWB0IXEcy/D31KYI0kvi3Wl7qtkx642sHdmo6YQI3AbiC5CEZY0wTZNXNmpm/DtlPMt8oYwCKOVsC9wK4leQ9mQTSBcm8ecUWgWwCEiSbsOKPmoAEGfX06eazCUiQbMKKP2oCEmTU06ebzyYgQbIJK/6oCUiQUU+fbj6bgATJJqz4oyYgQUY9fbr5bAISJJuw4o+agAQZ9fTp5rMJSJBswoo/agISZNTTp5vPJiBBsgkr/qgJSJBRT59uPpuABMkmrPijJiBBRj19uvlsAhIkm7Dij5rAfwFHMhojAvdxjgAAAABJRU5ErkJggg=="
    }, "9a833": function (A, e, t) {
        "use strict";

        function r(A) {
            this.type = A
        }

        r.prototype.initEvent = function (A, e, t) {
            return this.type = A, this.bubbles = e, this.cancelable = t, this.timeStamp = +new Date, this
        }, r.prototype.stopPropagation = function () {
        }, r.prototype.preventDefault = function () {
        }, r.CAPTURING_PHASE = 1, r.AT_TARGET = 2, r.BUBBLING_PHASE = 3, A.exports = r
    }, "9c59": function (A, e, t) {
        "use strict";
        var r, n = Object.prototype.hasOwnProperty;

        function i(A) {
            try {
                return decodeURIComponent(A.replace(/\+/g, " "))
            } catch (e) {
                return null
            }
        }

        function s(A) {
            var e, t = /([^=?&]+)=?([^&]*)/g, r = {};
            while (e = t.exec(A)) {
                var n = i(e[1]), s = i(e[2]);
                null === n || null === s || n in r || (r[n] = s)
            }
            return r
        }

        function o(A, e) {
            e = e || "";
            var t, i, s = [];
            for (i in "string" !== typeof e && (e = "?"), A) if (n.call(A, i)) {
                if (t = A[i], t || null !== t && t !== r && !isNaN(t) || (t = ""), i = encodeURIComponent(i), t = encodeURIComponent(t), null === i || null === t) continue;
                s.push(i + "=" + t)
            }
            return s.length ? e + s.join("&") : ""
        }

        e.stringify = o, e.parse = s
    }, "9d7d": function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("ada0").EventEmitter, n = t("3fb5"), i = t("c282"), s = t("26a0"), o = t("621f"),
                a = function () {
                };

            function c(A, e, t) {
                a(A, e);
                var n = this;
                r.call(this), setTimeout((function () {
                    n._start(A, e, t)
                }), 0)
            }

            n(c, r), c.prototype._start = function (A, t, r) {
                a("_start");
                var n = this, s = new e.XDomainRequest;
                t = o.addQuery(t, "t=" + +new Date), s.onerror = function () {
                    a("onerror"), n._error()
                }, s.ontimeout = function () {
                    a("ontimeout"), n._error()
                }, s.onprogress = function () {
                    a("progress", s.responseText), n.emit("chunk", 200, s.responseText)
                }, s.onload = function () {
                    a("load"), n.emit("finish", 200, s.responseText), n._cleanup(!1)
                }, this.xdr = s, this.unloadRef = i.unloadAdd((function () {
                    n._cleanup(!0)
                }));
                try {
                    this.xdr.open(A, t), this.timeout && (this.xdr.timeout = this.timeout), this.xdr.send(r)
                } catch (c) {
                    this._error()
                }
            }, c.prototype._error = function () {
                this.emit("finish", 0, ""), this._cleanup(!1)
            }, c.prototype._cleanup = function (A) {
                if (a("cleanup", A), this.xdr) {
                    if (this.removeAllListeners(), i.unloadDel(this.unloadRef), this.xdr.ontimeout = this.xdr.onerror = this.xdr.onprogress = this.xdr.onload = null, A) try {
                        this.xdr.abort()
                    } catch (e) {
                    }
                    this.unloadRef = this.xdr = null
                }
            }, c.prototype.close = function () {
                a("close"), this._cleanup(!0)
            }, c.enabled = !(!e.XDomainRequest || !s.hasDomain()), A.exports = c
        }).call(this, t("c8ba"))
    }, "9e6a": function (A, e, t) {
        "use strict";
        var r = t("d233"), n = Object.prototype.hasOwnProperty, i = {
            allowDots: !1,
            allowPrototypes: !1,
            arrayLimit: 20,
            decoder: r.decode,
            delimiter: "&",
            depth: 5,
            parameterLimit: 1e3,
            plainObjects: !1,
            strictNullHandling: !1
        }, s = function (A, e) {
            for (var t = {}, r = e.ignoreQueryPrefix ? A.replace(/^\?/, "") : A, s = e.parameterLimit === 1 / 0 ? void 0 : e.parameterLimit, o = r.split(e.delimiter, s), a = 0; a < o.length; ++a) {
                var c, l, u = o[a], d = u.indexOf("]="), B = -1 === d ? u.indexOf("=") : d + 1;
                -1 === B ? (c = e.decoder(u, i.decoder), l = e.strictNullHandling ? null : "") : (c = e.decoder(u.slice(0, B), i.decoder), l = e.decoder(u.slice(B + 1), i.decoder)), n.call(t, c) ? t[c] = [].concat(t[c]).concat(l) : t[c] = l
            }
            return t
        }, o = function (A, e, t) {
            for (var r = e, n = A.length - 1; n >= 0; --n) {
                var i, s = A[n];
                if ("[]" === s) i = [], i = i.concat(r); else {
                    i = t.plainObjects ? Object.create(null) : {};
                    var o = "[" === s.charAt(0) && "]" === s.charAt(s.length - 1) ? s.slice(1, -1) : s,
                        a = parseInt(o, 10);
                    !isNaN(a) && s !== o && String(a) === o && a >= 0 && t.parseArrays && a <= t.arrayLimit ? (i = [], i[a] = r) : i[o] = r
                }
                r = i
            }
            return r
        }, a = function (A, e, t) {
            if (A) {
                var r = t.allowDots ? A.replace(/\.([^.[]+)/g, "[$1]") : A, i = /(\[[^[\]]*])/, s = /(\[[^[\]]*])/g,
                    a = i.exec(r), c = a ? r.slice(0, a.index) : r, l = [];
                if (c) {
                    if (!t.plainObjects && n.call(Object.prototype, c) && !t.allowPrototypes) return;
                    l.push(c)
                }
                var u = 0;
                while (null !== (a = s.exec(r)) && u < t.depth) {
                    if (u += 1, !t.plainObjects && n.call(Object.prototype, a[1].slice(1, -1)) && !t.allowPrototypes) return;
                    l.push(a[1])
                }
                return a && l.push("[" + r.slice(a.index) + "]"), o(l, e, t)
            }
        };
        A.exports = function (A, e) {
            var t = e ? r.assign({}, e) : {};
            if (null !== t.decoder && void 0 !== t.decoder && "function" !== typeof t.decoder) throw new TypeError("Decoder has to be a function.");
            if (t.ignoreQueryPrefix = !0 === t.ignoreQueryPrefix, t.delimiter = "string" === typeof t.delimiter || r.isRegExp(t.delimiter) ? t.delimiter : i.delimiter, t.depth = "number" === typeof t.depth ? t.depth : i.depth, t.arrayLimit = "number" === typeof t.arrayLimit ? t.arrayLimit : i.arrayLimit, t.parseArrays = !1 !== t.parseArrays, t.decoder = "function" === typeof t.decoder ? t.decoder : i.decoder, t.allowDots = "boolean" === typeof t.allowDots ? t.allowDots : i.allowDots, t.plainObjects = "boolean" === typeof t.plainObjects ? t.plainObjects : i.plainObjects, t.allowPrototypes = "boolean" === typeof t.allowPrototypes ? t.allowPrototypes : i.allowPrototypes, t.parameterLimit = "number" === typeof t.parameterLimit ? t.parameterLimit : i.parameterLimit, t.strictNullHandling = "boolean" === typeof t.strictNullHandling ? t.strictNullHandling : i.strictNullHandling, "" === A || null === A || "undefined" === typeof A) return t.plainObjects ? Object.create(null) : {};
            for (var n = "string" === typeof A ? s(A, t) : A, o = t.plainObjects ? Object.create(null) : {}, c = Object.keys(n), l = 0; l < c.length; ++l) {
                var u = c[l], d = a(u, n[u], t);
                o = r.merge(o, d, t)
            }
            return r.compact(o)
        }
    }, "9f3a": function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("930c"), i = t("ada0").EventEmitter, s = t("1015"), o = t("621f"), a = t("f1f8"),
            c = t("c282"), l = t("2582"), u = function () {
            };

        function d(A, e, t) {
            if (!d.enabled()) throw new Error("Transport created when disabled");
            i.call(this);
            var r = this;
            this.origin = o.getOrigin(t), this.baseUrl = t, this.transUrl = e, this.transport = A, this.windowId = l.string(8);
            var n = o.addPath(t, "/iframe.html") + "#" + this.windowId;
            u(A, e, n), this.iframeObj = a.createIframe(n, (function (A) {
                u("err callback"), r.emit("close", 1006, "Unable to load an iframe (" + A + ")"), r.close()
            })), this.onmessageCallback = this._message.bind(this), c.attachEvent("message", this.onmessageCallback)
        }

        r(d, i), d.prototype.close = function () {
            if (u("close"), this.removeAllListeners(), this.iframeObj) {
                c.detachEvent("message", this.onmessageCallback);
                try {
                    this.postMessage("c")
                } catch (A) {
                }
                this.iframeObj.cleanup(), this.iframeObj = null, this.onmessageCallback = this.iframeObj = null
            }
        }, d.prototype._message = function (A) {
            if (u("message", A.data), o.isOriginEqual(A.origin, this.origin)) {
                var e;
                try {
                    e = n.parse(A.data)
                } catch (r) {
                    return void u("bad json", A.data)
                }
                if (e.windowId === this.windowId) switch (e.type) {
                    case "s":
                        this.iframeObj.loaded(), this.postMessage("s", n.stringify([s, this.transport, this.transUrl, this.baseUrl]));
                        break;
                    case "t":
                        this.emit("message", e.data);
                        break;
                    case "c":
                        var t;
                        try {
                            t = n.parse(e.data)
                        } catch (r) {
                            return void u("bad json", e.data)
                        }
                        this.emit("close", t[0], t[1]), this.close();
                        break
                } else u("mismatched window id", e.windowId, this.windowId)
            } else u("not same origin", A.origin, this.origin)
        }, d.prototype.postMessage = function (A, e) {
            u("postMessage", A, e), this.iframeObj.post(n.stringify({
                windowId: this.windowId,
                type: A,
                data: e || ""
            }), this.origin)
        }, d.prototype.send = function (A) {
            u("send", A), this.postMessage("m", A)
        }, d.enabled = function () {
            return a.iframeEnabled
        }, d.transportName = "iframe", d.roundTrips = 2, A.exports = d
    }, "9fa7": function (A, e, t) {
        "use strict";
        var r = t("621f"), n = t("c282"), i = t("930c"), s = t("bb31"), o = t("c529"), a = t("f1f8"), c = t("a0e2"),
            l = function () {
            };
        A.exports = function (A, e) {
            var t, u = {};
            e.forEach((function (A) {
                A.facadeTransport && (u[A.facadeTransport.transportName] = A.facadeTransport)
            })), u[o.transportName] = o, A.bootstrap_iframe = function () {
                var e;
                a.currentWindowId = c.hash.slice(1);
                var o = function (n) {
                    if (n.source === parent && ("undefined" === typeof t && (t = n.origin), n.origin === t)) {
                        var o;
                        try {
                            o = i.parse(n.data)
                        } catch (f) {
                            return void l("bad json", n.data)
                        }
                        if (o.windowId === a.currentWindowId) switch (o.type) {
                            case "s":
                                var d;
                                try {
                                    d = i.parse(o.data)
                                } catch (f) {
                                    l("bad json", o.data);
                                    break
                                }
                                var B = d[0], h = d[1], g = d[2], p = d[3];
                                if (l(B, h, g, p), B !== A.version) throw new Error('Incompatible SockJS! Main site uses: "' + B + '", the iframe: "' + A.version + '".');
                                if (!r.isOriginEqual(g, c.href) || !r.isOriginEqual(p, c.href)) throw new Error("Can't connect to different domain from within an iframe. (" + c.href + ", " + g + ", " + p + ")");
                                e = new s(new u[h](g, p));
                                break;
                            case "m":
                                e._send(o.data);
                                break;
                            case "c":
                                e && e._close(), e = null;
                                break
                        }
                    }
                };
                n.attachEvent("message", o), a.postMessage("s")
            }
        }
    }, "9fee": function (A, e, t) {
    }, "9ff8": function (A, e, t) {
        "use strict";
        var r = function () {
            var A = this, e = A.$createElement, r = A._self._c || e;
            return r("div", {
                ref: "aliyunPreview",
                staticClass: "aliyunPreview-box"
            }, [A.isShow ? r("iframe", {
                ref: "aliyunPreviewIframe",
                attrs: { allowfullscreen: "", id: "aliyunPreview", frameborder: "0", src: A.baseUrl }
            }) : A._e(), A.isControl ? r("div", { staticClass: "control-bar" }, [A._t("default", [r("span", { staticClass: "tips-text" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.completedLearning")))])]), r("div", { staticClass: "is-handout-span" }, [A.noteId ? A._t("handoutSpan") : A._e(), A.fullscreen ? r("img", {
                staticClass: "fullScreen",
                attrs: { src: t("dfcd"), alt: "" },
                on: { click: A.exitFullscreen }
            }) : r("img", {
                staticClass: "fullScreen", attrs: { src: t("948c"), alt: "" }, on: {
                    click: function (e) {
                        return A.toFullVideo(A.$refs.aliyunPreview)
                    }
                }
            })], 2)], 2) : A._e()])
        }, n = [], i = (t("ac6a"), t("28a5"), t("0fb7"), t("450d"), t("f529")), s = t.n(i),
            o = (t("6b54"), t("c5f6"), t("8e44")), a = {
                data: function () {
                    return {
                        type: "",
                        totalCount: 0,
                        currentCount: this.pageIndex,
                        fullscreen: !1,
                        wmType: 0,
                        wmValue: "",
                        wmDensity: .7,
                        wmOpcity: .6,
                        baseUrl: 0 === this.pageIndex ? "https://preview.imm.aliyun.com/index.html" : "https://preview.imm.aliyun.com/index.html?pageIndex=".concat(this.pageIndex),
                        docUrl: "https://tbcossdocument.oss-cn-shanghai.aliyuncs.com/docs/output/".concat(this.resourceRelId),
                        isShow: !0,
                        tryTimer: null,
                        tryCount: 0,
                        heartTimer: null
                    }
                },
                props: {
                    resourceRelId: { type: String, default: "" },
                    pageIndex: { type: Number, default: 0 },
                    isControl: { type: Boolean, default: !0 },
                    isFinish: { type: Boolean, default: !1 },
                    noteId: { default: "", type: String }
                },
                watch: {
                    resourceRelId: function () {
                        var A = this;
                        this.isShow = !1, this.docUrl = "https://tbcossdocument.oss-cn-shanghai.aliyuncs.com/docs/output/".concat(this.resourceRelId), this.baseUrl = 0 === this.pageIndex ? "https://preview.imm.aliyun.com/index.html" : "https://preview.imm.aliyun.com/index.html?pageIndex=".concat(this.pageIndex), this.currentCount = this.pageIndex, this.$nextTick((function () {
                            A.isShow = !0, A.initAliyunPreview()
                        }))
                    }
                },
                methods: {
                    json2str: function (A) {
                        return JSON.stringify(A, (function (A, e) {
                            return "function" === typeof e && (e = e.toString()), e
                        }))
                    }, initAliyunPreview: function () {
                        var A = this, e = this;
                        window.sendMessage = function (A, t) {
                            var r = document.getElementById("aliyunPreview");
                            r.contentWindow.postMessage(e.json2str({ action: A, data: t }), "*")
                        }, window.addEventListener("message", (function (A) {
                            var t = Math.floor(800 * (1.1 - e.wmDensity));
                            try {
                                var r = JSON.parse(A.data)
                            } catch (n) {
                                return
                            }
                            switch (r.action) {
                                case "preview.ready":
                                    window.sendMessage("preview.init", {
                                        url: e.docUrl,
                                        wmType: e.wmType,
                                        wmValue: e.wmValue,
                                        wmHeight: t,
                                        wmWidth: t,
                                        wmColor: "rgba(192, 192, 192, ".concat(e.wmOpcity, ")")
                                    }), window.sendMessage("setConfig", {
                                        writerCustomStyle: function (A) {
                                            return A ? { pageBorder: "1px solid #d2d5d8" } : {
                                                containerMarginTop: 30,
                                                containerMarginBottom: 30,
                                                pageSpacing: 20,
                                                pageShadow: "0px 0px 6px 0px rgba(0, 0, 0, 0.3)",
                                                pageBorder: "none",
                                                scale: {},
                                                scaleBtn: {},
                                                scaleShrink: {},
                                                scaleShrinkText: "",
                                                scaleShrinkDisable: {},
                                                scaleMagnify: {},
                                                scaleMagnifyText: "",
                                                scaleMagnifyDisable: {},
                                                scaleText: {},
                                                scaleSort: ["shrink", "text", "magnify"]
                                            }
                                        }, powerpointCustomStyle: function (A) {
                                            return A ? {} : {
                                                paginationDisplay: !0,
                                                fullScreenButtonDisplay: !1,
                                                containerMarginTop: 30,
                                                containerMarginBottom: 30,
                                                containerBackground: "#000000"
                                            }
                                        }, couldRetry: function (A) {
                                            return console.log("重试的次数", A), new Promise((function (e) {
                                                if (A > 35) e(!1); else {
                                                    var t = 0;
                                                    t = A < 2 ? 250 : A <= 11 ? 500 : 1e3, setTimeout((function () {
                                                        e(!0)
                                                    }), t)
                                                }
                                            }))
                                        }
                                    });
                                    break;
                                case "page.readPage":
                                    e.currentCount = r.data.pageIndex;
                                    break;
                                case "preview.meta":
                                    e.type = r.data.ext, "xlsx" === e.type || "xls" === e.type ? e.totalCount = r.data.asc : e.totalCount = r.data.pc;
                                    break;
                                case "message.error":
                                    "aliyunRequestTimeout" === r.result && s()({
                                        message: e.$t("v4.js.pc.ocmt.Resourceloadingtimeout"),
                                        type: "error"
                                    });
                                    break;
                                case "page.renderDone":
                                    clearInterval(e.tryTimer);
                                    break
                            }
                        }), !1), document.addEventListener("gesturestart", (function (A) {
                            A.preventDefault()
                        })), window.addEventListener("resize", (function (e) {
                            A.fullscreen = document.fullscreen || document.msFullscreenElement || document.mozFullScreen || document.webkitIsFullScreen
                        }))
                    }, init: function () {
                        var A = this;
                        "km" !== this.$route.query.from ? o["a"].APIconfirmWatermark().then((function (e) {
                            var t = e.bizResult;
                            A.wmType = "true" === t.enableWatermark ? 1 : 0, A.wmDensity = t.waterMarkDensity / 100, A.wmOpcity = t.waterMarkTransparency / 100, A.wmValue = "";
                            var r = t.waterMarkShowObject ? t.waterMarkShowObject.split(",") : [], n = [];
                            r.forEach((function (A) {
                                "EMPLOYEE_CODE" === A ? n.push(t.employeeCode) : "USER_NAME" === A ? n.push(t.userName) : "LOGIN_NAME" === A && n.push(t.loginName)
                            })), A.wmValue = n.join(" "), A.initAliyunPreview()
                        })) : o["a"].APIconfirmWatermarkKM().then((function (e) {
                            var t = e.bizResult;
                            A.wmType = "true" === t.enableWatermark ? 1 : 0, A.wmDensity = t.waterMarkDensity / 100, A.wmOpcity = t.waterMarkTransparency / 100, A.wmValue = "";
                            var r = t.waterMarkShowObject ? t.waterMarkShowObject.split(",") : [], n = [];
                            r.forEach((function (A) {
                                "EMPLOYEE_CODE" === A ? n.push(t.employeeCode) : "USER_NAME" === A ? n.push(t.userName) : "LOGIN_NAME" === A && n.push(t.loginName)
                            })), A.wmValue = n.join(" "), A.initAliyunPreview()
                        }))
                    }, toFullVideo: function (A) {
                        A.requestFullscreen ? A.requestFullscreen() : A.webkitRequestFullScreen ? A.webkitRequestFullScreen() : A.mozRequestFullScreen ? A.mozRequestFullScreen() : A.msRequestFullscreen()
                    }, exitFullscreen: function () {
                        document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen()
                    }, initHeart: function () {
                        var A = this, e = decodeURIComponent(this.$route.params.courseInfo).split("&")[0],
                            t = { courseId: e };
                        o["c"].loadCourseSystemSeting(t).then((function (t) {
                            "1001" == t.code && (!t.bizResult.heartBeat || A.isFinish && !t.bizResult.continueHeartBeat || (A.heartTimer = setInterval((function () {
                                o["c"].heartBeatSetData(e)
                            }), 6e4)))
                        }))
                    }
                },
                beforeDestroy: function () {
                    clearInterval(this.heartTimer)
                },
                mounted: function () {
                    var A = this;
                    this.initHeart(), this.init(), this.tryTimer = setInterval((function () {
                        A.isShow = !1, A.$nextTick((function () {
                            A.isShow = !0, A.initAliyunPreview()
                        })), A.tryCount++, A.tryCount >= 10 && clearInterval(A.tryTimer)
                    }), 3e3), this.$emit("isReady")
                }
            }, c = a, l = (t("ff5b"), t("2877")), u = Object(l["a"])(c, r, n, !1, null, "e07ef2b6", null);
        e["a"] = u.exports
    }, a0e2: function (A, e, t) {
        "use strict";
        (function (e) {
            A.exports = e.location || {
                origin: "http://localhost:80",
                protocol: "http:",
                host: "localhost",
                port: 80,
                href: "http://localhost/",
                hash: ""
            }
        }).call(this, t("c8ba"))
    }, ada0: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("97a2");

        function i() {
            n.call(this)
        }

        r(i, n), i.prototype.removeAllListeners = function (A) {
            A ? delete this._listeners[A] : this._listeners = {}
        }, i.prototype.once = function (A, e) {
            var t = this, r = !1;

            function n() {
                t.removeListener(A, n), r || (r = !0, e.apply(this, arguments))
            }

            this.on(A, n)
        }, i.prototype.emit = function () {
            var A = arguments[0], e = this._listeners[A];
            if (e) {
                for (var t = arguments.length, r = new Array(t - 1), n = 1; n < t; n++) r[n - 1] = arguments[n];
                for (var i = 0; i < e.length; i++) e[i].apply(this, r)
            }
        }, i.prototype.on = i.prototype.addListener = n.prototype.addEventListener, i.prototype.removeListener = n.prototype.removeEventListener, A.exports.EventEmitter = i
    }, aef4: function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAAEw0lEQVRoBe2bW2gVRxjH/3uOGm/xEqPxjlTBhxYjhrZUoUKliAqKUBBvqbUBbX1QrL4IpSgtSPFFpILaUrT6Kqigrb604kNRVIT2xaqgVIuXxGjSJJo0x++/ZY5zTvac2d0ze/ZlBvbM7Lc78//Nt9/M7s4myOVyDbJlkVLKiO5I2aYJxPA0GAjARA9MEojxsimbfyDpn2KxUSI4VSCGJi2s2i8GoH2wbFMEok42T52YVB4EoLTGSoHeGKIMSeTlAKhHcQbomKS8YQJQnR4nhckCwctjNYUFoCgDk95goFpLUQAoyqDkUOWQHWSDIiqA0uSkRW+MUIa4eVwA6rHuRIGYIFvsdmJX1HpcK2V6Y5hmC120AUAxxgNHSX1Ub9gCUD0eLQVOXjXKYMptA1CPcwUhxspmnMqTAFCdrpMC7yllp/IkAQjCS0Fv8NIEpqQBKMrLwOBkkA6YvKoBoHrOYcrhyiewfKomAEWpx2dQ3ur9VG0ApcuHHU5gPpEyVjtnXGTT8oDqfG2aAIQYkTbA4LQBUo0BP+jT9kCqw9B5wHnAecB5wHnAecB5wHnAeSAZDxy6jAmnbyH0WuKA12UfK+bPwSto2PsbTgzKoBMr0Lx8Fp6bmrL2VOyL/4oTvf2Y0d2Ht7adwrEwnrACoIurHhNi93m0qP1SecUAQeIUGz0UP//yKfaXElb2igDKiV/ajK31NfhPCZXKYwPYECdULABb4rEAbIpHBrAtHgkgCfHQAEmJE8A4FXNu5/TKGY4VVOI4DzvUVJ2g3DgKJtWhJ5NBT3FlWX99WVuD/mJ71H0jAG8o3yxC85AsbuuNt/dgedMBfK3b4pSNAGx07Vy07Xof6+Uud08Xae3Cqsbv8KVui1oOBcBGN72DR9sW+BAPdJFHnfh43kHs0G1RyqEB2OgX83G/pQnrZW3tsS7yTwc2v30In+u2sOVIAGz0qw9wd80cNGc9PNVF/m7H9gWHsVG3hSlHBmCj3y7GXyvfxIaMhw5d5M5T7Fr4A1brNlM5FgAbPbAMfy6djY2eh391kZut2PPhUazUbeXKsQHY6JEVuL7oDWwST7zIi+Tg/fEQe5cex5K8rUyhIgC2+9NH+P3dafiME1NeJ4fsjQfY9/01jM/bShQqBmC7J1fjYtNUbJVin6/jobdxMna0zCscLf6xoh8rAGzzzFpcaGzATrkc3e9Nx5az63CuSCtw15PPJjMDj8Q0/ngV9Z804UnY6tYBwgqr86xdAtVg1NwBOA84DzgPOA84DzgPOA84DzgPpO2B/rQB+tIG6Eob4HmaAO2e5/WmBdAlb1BtfIsyrpRGfdUKcX67nNMmvc/x3GoC9IreYxHuprBK1QBgT7mixmvu91qJM08agL19IsKvl2909QQBuIhN4YJlvCJtfzcJD1C0VcSNX8xIYBOAQcZec4iFTrYAVJBF/n5QKQA/ZHBolQwykyviArCnrbJ1iPiAoWUS1Y/HAeDaMK/1/4uSemsxylEAKEjhgsXpGJoFVcICPJNanL8jB1mBWsCOCYCr4Ayy16vhAY1UYioFwMDi7fKZiFcUZCa4IABOJOy1lSCLAsCpk0HWaapk87jyAP/ahfO39SAzwspyfdX+wdUIk8YJrwDREG917sSAdgAAAABJRU5ErkJggg=="
    }, b185: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("7577"), i = t("1548"), s = t("9d7d");

        function o(A) {
            if (!s.enabled) throw new Error("Transport created when disabled");
            n.call(this, A, "/xhr_streaming", i, s)
        }

        r(o, n), o.enabled = function (A) {
            return !A.cookie_needed && !A.nullOrigin && (s.enabled && A.sameScheme)
        }, o.transportName = "xdr-streaming", o.roundTrips = 2, A.exports = o
    }, b313: function (A, e, t) {
        "use strict";
        var r = String.prototype.replace, n = /%20/g;
        A.exports = {
            default: "RFC3986", formatters: {
                RFC1738: function (A) {
                    return r.call(A, n, "+")
                }, RFC3986: function (A) {
                    return A
                }
            }, RFC1738: "RFC1738", RFC3986: "RFC3986"
        }
    }, b9a8: function (A, e, t) {
        "use strict";
        var r = t("ada0").EventEmitter, n = t("3fb5"), i = t("621f"), s = t("9d7d"), o = t("df09"), a = t("73aa"),
            c = t("f701"), l = t("7c20"), u = t("89bc"), d = function () {
            };

        function B(A, e) {
            d(A);
            var t = this;
            r.call(this), setTimeout((function () {
                t.doXhr(A, e)
            }), 0)
        }

        n(B, r), B._getReceiver = function (A, e, t) {
            return t.sameOrigin ? new u(e, a) : o.enabled ? new u(e, o) : s.enabled && t.sameScheme ? new u(e, s) : l.enabled() ? new l(A, e) : new u(e, c)
        }, B.prototype.doXhr = function (A, e) {
            var t = this, r = i.addPath(A, "/info");
            d("doXhr", r), this.xo = B._getReceiver(A, r, e), this.timeoutRef = setTimeout((function () {
                d("timeout"), t._cleanup(!1), t.emit("finish")
            }), B.timeout), this.xo.once("finish", (function (A, e) {
                d("finish", A, e), t._cleanup(!0), t.emit("finish", A, e)
            }))
        }, B.prototype._cleanup = function (A) {
            d("_cleanup"), clearTimeout(this.timeoutRef), this.timeoutRef = null, !A && this.xo && this.xo.close(), this.xo = null
        }, B.prototype.close = function () {
            d("close"), this.removeAllListeners(), this._cleanup(!1)
        }, B.timeout = 8e3, A.exports = B
    }, bb31: function (A, e, t) {
        "use strict";
        var r = t("930c"), n = t("f1f8");

        function i(A) {
            this._transport = A, A.on("message", this._transportMessage.bind(this)), A.on("close", this._transportClose.bind(this))
        }

        i.prototype._transportClose = function (A, e) {
            n.postMessage("c", r.stringify([A, e]))
        }, i.prototype._transportMessage = function (A) {
            n.postMessage("t", A)
        }, i.prototype._send = function (A) {
            this._transport.send(A)
        }, i.prototype._close = function () {
            this._transport.close(), this._transport.removeAllListeners()
        }, A.exports = i
    }, bf4a: function (A, e, t) {
        "use strict";
        (function (e) {
            var r, n, i = t("2582"), s = t("621f"), o = function () {
            };

            function a(A) {
                o("createIframe", A);
                try {
                    return e.document.createElement('<iframe name="' + A + '">')
                } catch (r) {
                    var t = e.document.createElement("iframe");
                    return t.name = A, t
                }
            }

            function c() {
                o("createForm"), r = e.document.createElement("form"), r.style.display = "none", r.style.position = "absolute", r.method = "POST", r.enctype = "application/x-www-form-urlencoded", r.acceptCharset = "UTF-8", n = e.document.createElement("textarea"), n.name = "d", r.appendChild(n), e.document.body.appendChild(r)
            }

            A.exports = function (A, e, t) {
                o(A, e), r || c();
                var l = "a" + i.string(8);
                r.target = l, r.action = s.addQuery(s.addPath(A, "/jsonp_send"), "i=" + l);
                var u = a(l);
                u.id = l, u.style.display = "none", r.appendChild(u);
                try {
                    n.value = e
                } catch (B) {
                }
                r.submit();
                var d = function (A) {
                    o("completed", l, A), u.onerror && (u.onreadystatechange = u.onerror = u.onload = null, setTimeout((function () {
                        o("cleaning up", l), u.parentNode.removeChild(u), u = null
                    }), 500), n.value = "", t(A))
                };
                return u.onerror = function () {
                    o("onerror", l), d()
                }, u.onload = function () {
                    o("onload", l), d()
                }, u.onreadystatechange = function (A) {
                    o("onreadystatechange", l, u.readyState, A), "complete" === u.readyState && d()
                }, function () {
                    o("aborted", l), d(new Error("Aborted"))
                }
            }
        }).call(this, t("c8ba"))
    }, c0e9: function (A, e, t) {
        /*!
 * html2canvas 1.3.3 <https://html2canvas.hertzen.com>
 * Copyright (c) 2021 Niklas von Hertzen <https://hertzen.com>
 * Released under MIT License
 */
        (function (e, t) {
            A.exports = t()
        })(0, (function () {
            "use strict";
            /*! *****************************************************************************
    Copyright (c) Microsoft Corporation.

    Permission to use, copy, modify, and/or distribute this software for any
    purpose with or without fee is hereby granted.

    THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
    REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
    AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
    INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
    LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
    OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
    PERFORMANCE OF THIS SOFTWARE.
    ***************************************************************************** */
            var A = function (e, t) {
                return A = Object.setPrototypeOf || { __proto__: [] } instanceof Array && function (A, e) {
                    A.__proto__ = e
                } || function (A, e) {
                    for (var t in e) Object.prototype.hasOwnProperty.call(e, t) && (A[t] = e[t])
                }, A(e, t)
            };

            function e(e, t) {
                if ("function" !== typeof t && null !== t) throw new TypeError("Class extends value " + String(t) + " is not a constructor or null");

                function r() {
                    this.constructor = e
                }

                A(e, t), e.prototype = null === t ? Object.create(t) : (r.prototype = t.prototype, new r)
            }

            var t = function () {
                return t = Object.assign || function (A) {
                    for (var e, t = 1, r = arguments.length; t < r; t++) for (var n in e = arguments[t], e) Object.prototype.hasOwnProperty.call(e, n) && (A[n] = e[n]);
                    return A
                }, t.apply(this, arguments)
            };

            function r(A, e, t, r) {
                function n(A) {
                    return A instanceof t ? A : new t((function (e) {
                        e(A)
                    }))
                }

                return new (t || (t = Promise))((function (t, i) {
                    function s(A) {
                        try {
                            a(r.next(A))
                        } catch (Ne) {
                            i(Ne)
                        }
                    }

                    function o(A) {
                        try {
                            a(r["throw"](A))
                        } catch (Ne) {
                            i(Ne)
                        }
                    }

                    function a(A) {
                        A.done ? t(A.value) : n(A.value).then(s, o)
                    }

                    a((r = r.apply(A, e || [])).next())
                }))
            }

            function n(A, e) {
                var t, r, n, i, s = {
                    label: 0, sent: function () {
                        if (1 & n[0]) throw n[1];
                        return n[1]
                    }, trys: [], ops: []
                };
                return i = {
                    next: o(0),
                    throw: o(1),
                    return: o(2)
                }, "function" === typeof Symbol && (i[Symbol.iterator] = function () {
                    return this
                }), i;

                function o(A) {
                    return function (e) {
                        return a([A, e])
                    }
                }

                function a(i) {
                    if (t) throw new TypeError("Generator is already executing.");
                    while (s) try {
                        if (t = 1, r && (n = 2 & i[0] ? r["return"] : i[0] ? r["throw"] || ((n = r["return"]) && n.call(r), 0) : r.next) && !(n = n.call(r, i[1])).done) return n;
                        switch (r = 0, n && (i = [2 & i[0], n.value]), i[0]) {
                            case 0:
                            case 1:
                                n = i;
                                break;
                            case 4:
                                return s.label++, { value: i[1], done: !1 };
                            case 5:
                                s.label++, r = i[1], i = [0];
                                continue;
                            case 7:
                                i = s.ops.pop(), s.trys.pop();
                                continue;
                            default:
                                if (n = s.trys, !(n = n.length > 0 && n[n.length - 1]) && (6 === i[0] || 2 === i[0])) {
                                    s = 0;
                                    continue
                                }
                                if (3 === i[0] && (!n || i[1] > n[0] && i[1] < n[3])) {
                                    s.label = i[1];
                                    break
                                }
                                if (6 === i[0] && s.label < n[1]) {
                                    s.label = n[1], n = i;
                                    break
                                }
                                if (n && s.label < n[2]) {
                                    s.label = n[2], s.ops.push(i);
                                    break
                                }
                                n[2] && s.ops.pop(), s.trys.pop();
                                continue
                        }
                        i = e.call(A, s)
                    } catch (Ne) {
                        i = [6, Ne], r = 0
                    } finally {
                            t = n = 0
                        }
                    if (5 & i[0]) throw i[1];
                    return { value: i[0] ? i[1] : void 0, done: !0 }
                }
            }

            function i(A, e, t) {
                if (t || 2 === arguments.length) for (var r, n = 0, i = e.length; n < i; n++) !r && n in e || (r || (r = Array.prototype.slice.call(e, 0, n)), r[n] = e[n]);
                return A.concat(r || e)
            }

            for (var s = function () {
                function A(A, e, t, r) {
                    this.left = A, this.top = e, this.width = t, this.height = r
                }

                return A.prototype.add = function (e, t, r, n) {
                    return new A(this.left + e, this.top + t, this.width + r, this.height + n)
                }, A.fromClientRect = function (e, t) {
                    return new A(t.left + e.windowBounds.left, t.top + e.windowBounds.top, t.width, t.height)
                }, A.fromDOMRectList = function (e, t) {
                    var r = t[0];
                    return r ? new A(r.x + e.windowBounds.left, r.y + e.windowBounds.top, r.width, r.height) : A.EMPTY
                }, A.EMPTY = new A(0, 0, 0, 0), A
            }(), o = function (A, e) {
                return s.fromClientRect(A, e.getBoundingClientRect())
            }, a = function (A) {
                var e = A.body, t = A.documentElement;
                if (!e || !t) throw new Error("Unable to get document size");
                var r = Math.max(Math.max(e.scrollWidth, t.scrollWidth), Math.max(e.offsetWidth, t.offsetWidth), Math.max(e.clientWidth, t.clientWidth)),
                    n = Math.max(Math.max(e.scrollHeight, t.scrollHeight), Math.max(e.offsetHeight, t.offsetHeight), Math.max(e.clientHeight, t.clientHeight));
                return new s(0, 0, r, n)
            }, c = function (A) {
                var e = [], t = 0, r = A.length;
                while (t < r) {
                    var n = A.charCodeAt(t++);
                    if (n >= 55296 && n <= 56319 && t < r) {
                        var i = A.charCodeAt(t++);
                        56320 === (64512 & i) ? e.push(((1023 & n) << 10) + (1023 & i) + 65536) : (e.push(n), t--)
                    } else e.push(n)
                }
                return e
            }, l = function () {
                for (var A = [], e = 0; e < arguments.length; e++) A[e] = arguments[e];
                if (String.fromCodePoint) return String.fromCodePoint.apply(String, A);
                var t = A.length;
                if (!t) return "";
                var r = [], n = -1, i = "";
                while (++n < t) {
                    var s = A[n];
                    s <= 65535 ? r.push(s) : (s -= 65536, r.push(55296 + (s >> 10), s % 1024 + 56320)), (n + 1 === t || r.length > 16384) && (i += String.fromCharCode.apply(String, r), r.length = 0)
                }
                return i
            }, u = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", d = "undefined" === typeof Uint8Array ? [] : new Uint8Array(256), B = 0; B < u.length; B++) d[u.charCodeAt(B)] = B;
            var h = function (A) {
                var e, t, r, n, i, s = .75 * A.length, o = A.length, a = 0;
                "=" === A[A.length - 1] && (s--, "=" === A[A.length - 2] && s--);
                var c = "undefined" !== typeof ArrayBuffer && "undefined" !== typeof Uint8Array && "undefined" !== typeof Uint8Array.prototype.slice ? new ArrayBuffer(s) : new Array(s),
                    l = Array.isArray(c) ? c : new Uint8Array(c);
                for (e = 0; e < o; e += 4) t = d[A.charCodeAt(e)], r = d[A.charCodeAt(e + 1)], n = d[A.charCodeAt(e + 2)], i = d[A.charCodeAt(e + 3)], l[a++] = t << 2 | r >> 4, l[a++] = (15 & r) << 4 | n >> 2, l[a++] = (3 & n) << 6 | 63 & i;
                return c
            }, g = function (A) {
                for (var e = A.length, t = [], r = 0; r < e; r += 2) t.push(A[r + 1] << 8 | A[r]);
                return t
            }, p = function (A) {
                for (var e = A.length, t = [], r = 0; r < e; r += 4) t.push(A[r + 3] << 24 | A[r + 2] << 16 | A[r + 1] << 8 | A[r]);
                return t
            }, f = 5, w = 11, C = 2, m = w - f, Q = 65536 >> f, y = 1 << f, U = y - 1, v = 1024 >> f, F = Q + v, I = F,
                E = 32, b = I + E, H = 65536 >> w, T = 1 << m, x = T - 1, S = function (A, e, t) {
                    return A.slice ? A.slice(e, t) : new Uint16Array(Array.prototype.slice.call(A, e, t))
                }, D = function (A, e, t) {
                    return A.slice ? A.slice(e, t) : new Uint32Array(Array.prototype.slice.call(A, e, t))
                }, L = function (A) {
                    var e = h(A), t = Array.isArray(e) ? p(e) : new Uint32Array(e),
                        r = Array.isArray(e) ? g(e) : new Uint16Array(e), n = 24, i = S(r, n / 2, t[4] / 2),
                        s = 2 === t[5] ? S(r, (n + t[4]) / 2) : D(t, Math.ceil((n + t[4]) / 4));
                    return new K(t[0], t[1], t[2], t[3], i, s)
                }, K = function () {
                    function A(A, e, t, r, n, i) {
                        this.initialValue = A, this.errorValue = e, this.highStart = t, this.highValueIndex = r, this.index = n, this.data = i
                    }

                    return A.prototype.get = function (A) {
                        var e;
                        if (A >= 0) {
                            if (A < 55296 || A > 56319 && A <= 65535) return e = this.index[A >> f], e = (e << C) + (A & U), this.data[e];
                            if (A <= 65535) return e = this.index[Q + (A - 55296 >> f)], e = (e << C) + (A & U), this.data[e];
                            if (A < this.highStart) return e = b - H + (A >> w), e = this.index[e], e += A >> f & x, e = this.index[e], e = (e << C) + (A & U), this.data[e];
                            if (A <= 1114111) return this.data[this.highValueIndex]
                        }
                        return this.errorValue
                    }, A
                }(),
                k = "KwAAAAAAAAAACA4AUD0AADAgAAACAAAAAAAIABAAGABAAEgAUABYAGAAaABgAGgAYgBqAF8AZwBgAGgAcQB5AHUAfQCFAI0AlQCdAKIAqgCyALoAYABoAGAAaABgAGgAwgDKAGAAaADGAM4A0wDbAOEA6QDxAPkAAQEJAQ8BFwF1AH0AHAEkASwBNAE6AUIBQQFJAVEBWQFhAWgBcAF4ATAAgAGGAY4BlQGXAZ8BpwGvAbUBvQHFAc0B0wHbAeMB6wHxAfkBAQIJAvEBEQIZAiECKQIxAjgCQAJGAk4CVgJeAmQCbAJ0AnwCgQKJApECmQKgAqgCsAK4ArwCxAIwAMwC0wLbAjAA4wLrAvMC+AIAAwcDDwMwABcDHQMlAy0DNQN1AD0DQQNJA0kDSQNRA1EDVwNZA1kDdQB1AGEDdQBpA20DdQN1AHsDdQCBA4kDkQN1AHUAmQOhA3UAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AKYDrgN1AHUAtgO+A8YDzgPWAxcD3gPjA+sD8wN1AHUA+wMDBAkEdQANBBUEHQQlBCoEFwMyBDgEYABABBcDSARQBFgEYARoBDAAcAQzAXgEgASIBJAEdQCXBHUAnwSnBK4EtgS6BMIEyAR1AHUAdQB1AHUAdQCVANAEYABgAGAAYABgAGAAYABgANgEYADcBOQEYADsBPQE/AQEBQwFFAUcBSQFLAU0BWQEPAVEBUsFUwVbBWAAYgVgAGoFcgV6BYIFigWRBWAAmQWfBaYFYABgAGAAYABgAKoFYACxBbAFuQW6BcEFwQXHBcEFwQXPBdMF2wXjBeoF8gX6BQIGCgYSBhoGIgYqBjIGOgZgAD4GRgZMBmAAUwZaBmAAYABgAGAAYABgAGAAYABgAGAAYABgAGIGYABpBnAGYABgAGAAYABgAGAAYABgAGAAYAB4Bn8GhQZgAGAAYAB1AHcDFQSLBmAAYABgAJMGdQA9A3UAmwajBqsGqwaVALMGuwbDBjAAywbSBtIG1QbSBtIG0gbSBtIG0gbdBuMG6wbzBvsGAwcLBxMHAwcbByMHJwcsBywHMQcsB9IGOAdAB0gHTgfSBkgHVgfSBtIG0gbSBtIG0gbSBtIG0gbSBiwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdgAGAALAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAdbB2MHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB2kH0gZwB64EdQB1AHUAdQB1AHUAdQB1AHUHfQdgAIUHjQd1AHUAlQedB2AAYAClB6sHYACzB7YHvgfGB3UAzgfWBzMB3gfmB1EB7gf1B/0HlQENAQUIDQh1ABUIHQglCBcDLQg1CD0IRQhNCEEDUwh1AHUAdQBbCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIaQhjCGQIZQhmCGcIaAhpCGMIZAhlCGYIZwhoCGkIYwhkCGUIZghnCGgIcAh3CHoIMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIgggwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAALAcsBywHLAcsBywHLAcsBywHLAcsB4oILAcsB44I0gaWCJ4Ipgh1AHUAqgiyCHUAdQB1AHUAdQB1AHUAdQB1AHUAtwh8AXUAvwh1AMUIyQjRCNkI4AjoCHUAdQB1AO4I9gj+CAYJDgkTCS0HGwkjCYIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiCCIIIggiAAIAAAAFAAYABgAGIAXwBgAHEAdQBFAJUAogCyAKAAYABgAEIA4ABGANMA4QDxAMEBDwE1AFwBLAE6AQEBUQF4QkhCmEKoQrhCgAHIQsAB0MLAAcABwAHAAeDC6ABoAHDCwMMAAcABwAHAAdDDGMMAAcAB6MM4wwjDWMNow3jDaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAGgAaABoAEjDqABWw6bDqABpg6gAaABoAHcDvwOPA+gAaABfA/8DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DvwO/A78DpcPAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcAB9cPKwkyCToJMAB1AHUAdQBCCUoJTQl1AFUJXAljCWcJawkwADAAMAAwAHMJdQB2CX4JdQCECYoJjgmWCXUAngkwAGAAYABxAHUApgn3A64JtAl1ALkJdQDACTAAMAAwADAAdQB1AHUAdQB1AHUAdQB1AHUAowYNBMUIMAAwADAAMADICcsJ0wnZCRUE4QkwAOkJ8An4CTAAMAB1AAAKvwh1AAgKDwoXCh8KdQAwACcKLgp1ADYKqAmICT4KRgowADAAdQB1AE4KMAB1AFYKdQBeCnUAZQowADAAMAAwADAAMAAwADAAMAAVBHUAbQowADAAdQC5CXUKMAAwAHwBxAijBogEMgF9CoQKiASMCpQKmgqIBKIKqgquCogEDQG2Cr4KxgrLCjAAMADTCtsKCgHjCusK8Qr5CgELMAAwADAAMAB1AIsECQsRC3UANAEZCzAAMAAwADAAMAB1ACELKQswAHUANAExCzkLdQBBC0kLMABRC1kLMAAwADAAMAAwADAAdQBhCzAAMAAwAGAAYABpC3ELdwt/CzAAMACHC4sLkwubC58Lpwt1AK4Ltgt1APsDMAAwADAAMAAwADAAMAAwAL4LwwvLC9IL1wvdCzAAMADlC+kL8Qv5C/8LSQswADAAMAAwADAAMAAwADAAMAAHDDAAMAAwADAAMAAODBYMHgx1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1ACYMMAAwADAAdQB1AHUALgx1AHUAdQB1AHUAdQA2DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AD4MdQBGDHUAdQB1AHUAdQB1AEkMdQB1AHUAdQB1AFAMMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQBYDHUAdQB1AF8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUA+wMVBGcMMAAwAHwBbwx1AHcMfwyHDI8MMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAYABgAJcMMAAwADAAdQB1AJ8MlQClDDAAMACtDCwHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsB7UMLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHdQB1AHUAdQB1AHUAdQB1AHUAdQB1AHUAdQB1AA0EMAC9DDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAsBywHLAcsBywHLAcsBywHLQcwAMEMyAwsBywHLAcsBywHLAcsBywHLAcsBywHzAwwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwAHUAdQB1ANQM2QzhDDAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMABgAGAAYABgAGAAYABgAOkMYADxDGAA+AwADQYNYABhCWAAYAAODTAAMAAwADAAFg1gAGAAHg37AzAAMAAwADAAYABgACYNYAAsDTQNPA1gAEMNPg1LDWAAYABgAGAAYABgAGAAYABgAGAAUg1aDYsGVglhDV0NcQBnDW0NdQ15DWAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAlQCBDZUAiA2PDZcNMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAnw2nDTAAMAAwADAAMAAwAHUArw23DTAAMAAwADAAMAAwADAAMAAwADAAMAB1AL8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAB1AHUAdQB1AHUAdQDHDTAAYABgAM8NMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA1w11ANwNMAAwAD0B5A0wADAAMAAwADAAMADsDfQN/A0EDgwOFA4wABsOMAAwADAAMAAwADAAMAAwANIG0gbSBtIG0gbSBtIG0gYjDigOwQUuDsEFMw7SBjoO0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGQg5KDlIOVg7SBtIGXg5lDm0OdQ7SBtIGfQ6EDooOjQ6UDtIGmg6hDtIG0gaoDqwO0ga0DrwO0gZgAGAAYADEDmAAYAAkBtIGzA5gANIOYADaDokO0gbSBt8O5w7SBu8O0gb1DvwO0gZgAGAAxA7SBtIG0gbSBtIGYABgAGAAYAAED2AAsAUMD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHJA8sBywHLAcsBywHLAccDywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywPLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAc0D9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAccD9IG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIGFA8sBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHLAcsBywHPA/SBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gbSBtIG0gYUD0QPlQCVAJUAMAAwADAAMACVAJUAlQCVAJUAlQCVAEwPMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAA//8EAAQABAAEAAQABAAEAAQABAANAAMAAQABAAIABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQACgATABcAHgAbABoAHgAXABYAEgAeABsAGAAPABgAHABLAEsASwBLAEsASwBLAEsASwBLABgAGAAeAB4AHgATAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABYAGwASAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWAA0AEQAeAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAFAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJABYAGgAbABsAGwAeAB0AHQAeAE8AFwAeAA0AHgAeABoAGwBPAE8ADgBQAB0AHQAdAE8ATwAXAE8ATwBPABYAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AHgAeAFAATwBAAE8ATwBPAEAATwBQAFAATwBQAB4AHgAeAB4AHgAeAB0AHQAdAB0AHgAdAB4ADgBQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgBQAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAJAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAkACQAJAAkACQAJAAkABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAFAAHgAeAB4AKwArAFAAUABQAFAAGABQACsAKwArACsAHgAeAFAAHgBQAFAAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUAAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAYAA0AKwArAB4AHgAbACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAB4ABAAEAB4ABAAEABMABAArACsAKwArACsAKwArACsAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAKwArACsAKwBWAFYAVgBWAB4AHgArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AGgAaABoAGAAYAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQAEwAEACsAEwATAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABLAEsASwBLAEsASwBLAEsASwBLABoAGQAZAB4AUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQABMAUAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABABQAFAABAAEAB4ABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUAAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAFAABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQAUABQAB4AHgAYABMAUAArACsABAAbABsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAFAABAAEAAQABAAEAFAABAAEAAQAUAAEAAQABAAEAAQAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArACsAHgArAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAUAAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEAA0ADQBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUAArACsAKwBQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABABQACsAKwArACsAKwArACsAKwAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUAAaABoAUABQAFAAUABQAEwAHgAbAFAAHgAEACsAKwAEAAQABAArAFAAUABQAFAAUABQACsAKwArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQACsAUABQACsAKwAEACsABAAEAAQABAAEACsAKwArACsABAAEACsAKwAEAAQABAArACsAKwAEACsAKwArACsAKwArACsAUABQAFAAUAArAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLAAQABABQAFAAUAAEAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsAKwAEAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAArACsAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AGwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAKwArACsAKwArAAQABAAEACsAKwArACsAUABQACsAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAAQAUAArAFAAUABQAFAAUABQACsAKwArAFAAUABQACsAUABQAFAAUAArACsAKwBQAFAAKwBQACsAUABQACsAKwArAFAAUAArACsAKwBQAFAAUAArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArAAQABAAEAAQABAArACsAKwAEAAQABAArAAQABAAEAAQAKwArAFAAKwArACsAKwArACsABAArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAHgAeAB4AHgAeAB4AGwAeACsAKwArACsAKwAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAUABQAFAAKwArACsAKwArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwAOAFAAUABQAFAAUABQAFAAHgBQAAQABAAEAA4AUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAKwArAAQAUAAEAAQABAAEAAQABAAEACsABAAEAAQAKwAEAAQABAAEACsAKwArACsAKwArACsABAAEACsAKwArACsAKwArACsAUAArAFAAUAAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAFAABAAEAAQABAAEAAQABAArAAQABAAEACsABAAEAAQABABQAB4AKwArACsAKwBQAFAAUAAEAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQABoAUABQAFAAUABQAFAAKwAEAAQABAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQACsAUAArACsAUABQAFAAUABQAFAAUAArACsAKwAEACsAKwArACsABAAEAAQABAAEAAQAKwAEACsABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArAAQABAAeACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAXAAqACoAKgAqACoAKgAqACsAKwArACsAGwBcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAeAEsASwBLAEsASwBLAEsASwBLAEsADQANACsAKwArACsAKwBcAFwAKwBcACsAXABcAFwAXABcACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAXAArAFwAXABcAFwAXABcAFwAXABcAFwAKgBcAFwAKgAqACoAKgAqACoAKgAqACoAXAArACsAXABcAFwAXABcACsAXAArACoAKgAqACoAKgAqACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwBcAFwAXABcAFAADgAOAA4ADgAeAA4ADgAJAA4ADgANAAkAEwATABMAEwATAAkAHgATAB4AHgAeAAQABAAeAB4AHgAeAB4AHgBLAEsASwBLAEsASwBLAEsASwBLAFAAUABQAFAAUABQAFAAUABQAFAADQAEAB4ABAAeAAQAFgARABYAEQAEAAQAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQADQAEAAQABAAEAAQADQAEAAQAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAA0ADQAeAB4AHgAeAB4AHgAEAB4AHgAeAB4AHgAeACsAHgAeAA4ADgANAA4AHgAeAB4AHgAeAAkACQArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgBcAEsASwBLAEsASwBLAEsASwBLAEsADQANAB4AHgAeAB4AXABcAFwAXABcAFwAKgAqACoAKgBcAFwAXABcACoAKgAqAFwAKgAqACoAXABcACoAKgAqACoAKgAqACoAXABcAFwAKgAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKgAqAFwAKgBLAEsASwBLAEsASwBLAEsASwBLACoAKgAqACoAKgAqAFAAUABQAFAAUABQACsAUAArACsAKwArACsAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAKwBQACsAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsABAAEAAQAHgANAB4AHgAeAB4AHgAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUAArACsADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAWABEAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQANAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAANAA0AKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUAArAAQABAArACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqAA0ADQAVAFwADQAeAA0AGwBcACoAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwAeAB4AEwATAA0ADQAOAB4AEwATAB4ABAAEAAQACQArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAHgArACsAKwATABMASwBLAEsASwBLAEsASwBLAEsASwBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAXABcAFwAXABcACsAKwArACsAKwArACsAKwArACsAKwBcAFwAXABcAFwAXABcAFwAXABcAFwAXAArACsAKwArAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAXAArACsAKwAqACoAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAArACsAHgAeAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcACoAKgAqACoAKgAqACoAKgAqACoAKwAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKwArAAQASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACoAKgAqACoAKgAqACoAXAAqACoAKgAqACoAKgArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABABQAFAAUABQAFAAUABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwANAA0AHgANAA0ADQANAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAEAAQABAAEAAQAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwAeAB4AHgAeAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArAA0ADQANAA0ADQBLAEsASwBLAEsASwBLAEsASwBLACsAKwArAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAA0ADQBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUAAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArAAQABAAEAB4ABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAAQAUABQAFAAUABQAFAABABQAFAABAAEAAQAUAArACsAKwArACsABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQACsAUAArAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAFAAUABQACsAHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQACsAKwAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQACsAHgAeAB4AHgAeAB4AHgAOAB4AKwANAA0ADQANAA0ADQANAAkADQANAA0ACAAEAAsABAAEAA0ACQANAA0ADAAdAB0AHgAXABcAFgAXABcAFwAWABcAHQAdAB4AHgAUABQAFAANAAEAAQAEAAQABAAEAAQACQAaABoAGgAaABoAGgAaABoAHgAXABcAHQAVABUAHgAeAB4AHgAeAB4AGAAWABEAFQAVABUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ADQAeAA0ADQANAA0AHgANAA0ADQAHAB4AHgAeAB4AKwAEAAQABAAEAAQABAAEAAQABAAEAFAAUAArACsATwBQAFAAUABQAFAAHgAeAB4AFgARAE8AUABPAE8ATwBPAFAAUABQAFAAUAAeAB4AHgAWABEAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArABsAGwAbABsAGwAbABsAGgAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGgAbABsAGwAbABoAGwAbABoAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbABsAGwAbAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAHgAeAFAAGgAeAB0AHgBQAB4AGgAeAB4AHgAeAB4AHgAeAB4AHgBPAB4AUAAbAB4AHgBQAFAAUABQAFAAHgAeAB4AHQAdAB4AUAAeAFAAHgBQAB4AUABPAFAAUAAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAHgBQAFAAUABQAE8ATwBQAFAAUABQAFAATwBQAFAATwBQAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAUABQAFAATwBPAE8ATwBPAE8ATwBPAE8ATwBQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABPAB4AHgArACsAKwArAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHQAdAB4AHgAeAB0AHQAeAB4AHQAeAB4AHgAdAB4AHQAbABsAHgAdAB4AHgAeAB4AHQAeAB4AHQAdAB0AHQAeAB4AHQAeAB0AHgAdAB0AHQAdAB0AHQAeAB0AHgAeAB4AHgAeAB0AHQAdAB0AHgAeAB4AHgAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB4AHgAeAB0AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAeAB0AHQAdAB0AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAdAB4AHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAWABEAHgAeAB4AHgAeAB4AHQAeAB4AHgAeAB4AHgAeACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAWABEAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAFAAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAeAB4AHQAdAB0AHQAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB0AHQAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB0AHQAeAB4AHQAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AHQAdAB0AHgAeAB0AHgAeAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlAB4AHQAdAB4AHgAdAB4AHgAeAB4AHQAdAB4AHgAeAB4AJQAlAB0AHQAlAB4AJQAlACUAIAAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAeAB4AHgAeAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHgAdAB0AHQAeAB0AJQAdAB0AHgAdAB0AHgAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHQAdAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAdAB0AHQAdACUAHgAlACUAJQAdACUAJQAdAB0AHQAlACUAHQAdACUAHQAdACUAJQAlAB4AHQAeAB4AHgAeAB0AHQAlAB0AHQAdAB0AHQAdACUAJQAlACUAJQAdACUAJQAgACUAHQAdACUAJQAlACUAJQAlACUAJQAeAB4AHgAlACUAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB0AHgAeAB4AFwAXABcAFwAXABcAHgATABMAJQAeAB4AHgAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARABYAEQAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAWABEAFgARABYAEQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAWABEAFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AFgARAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAdAB0AHQAdAB0AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAFAAUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAEAAQABAAeAB4AKwArACsAKwArABMADQANAA0AUAATAA0AUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUAANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAA0ADQANAA0ADQANAA0ADQAeAA0AFgANAB4AHgAXABcAHgAeABcAFwAWABEAFgARABYAEQAWABEADQANAA0ADQATAFAADQANAB4ADQANAB4AHgAeAB4AHgAMAAwADQANAA0AHgANAA0AFgANAA0ADQANAA0ADQANAA0AHgANAB4ADQANAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArACsAKwArACsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArAA0AEQARACUAJQBHAFcAVwAWABEAFgARABYAEQAWABEAFgARACUAJQAWABEAFgARABYAEQAWABEAFQAWABEAEQAlAFcAVwBXAFcAVwBXAFcAVwBXAAQABAAEAAQABAAEACUAVwBXAFcAVwA2ACUAJQBXAFcAVwBHAEcAJQAlACUAKwBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBRAFcAUQBXAFEAVwBXAFcAVwBXAFcAUQBXAFcAVwBXAFcAVwBRAFEAKwArAAQABAAVABUARwBHAFcAFQBRAFcAUQBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFEAVwBRAFcAUQBXAFcAVwBXAFcAVwBRAFcAVwBXAFcAVwBXAFEAUQBXAFcAVwBXABUAUQBHAEcAVwArACsAKwArACsAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwAlACUAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACsAKwArACsAKwArACsAKwArACsAKwArAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAUQBRAFEAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBPAE8ATwBPAE8ATwBPAE8AJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADQATAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABLAEsASwBLAEsASwBLAEsASwBLAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAABAAEAAQABAAeAAQABAAEAAQABAAEAAQABAAEAAQAHgBQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUABQAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAeAA0ADQANAA0ADQArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AUAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAB4AHgAeAB4AHgAeAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AUABQAFAAUABQAFAAUABQAFAAUABQAAQAUABQAFAABABQAFAAUABQAAQAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAeAB4AHgAeAAQAKwArACsAUABQAFAAUABQAFAAHgAeABoAHgArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAADgAOABMAEwArACsAKwArACsAKwArACsABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwANAA0ASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUAAeAB4AHgBQAA4AUABQAAQAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArAB4AWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYAFgAWABYACsAKwArAAQAHgAeAB4AHgAeAB4ADQANAA0AHgAeAB4AHgArAFAASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArAB4AHgBcAFwAXABcAFwAKgBcAFwAXABcAFwAXABcAFwAXABcAEsASwBLAEsASwBLAEsASwBLAEsAXABcAFwAXABcACsAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAFAAUABQAAQAUABQAFAAUABQAFAAUABQAAQABAArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAHgANAA0ADQBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKgAqACoAXAAqACoAKgBcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXAAqAFwAKgAqACoAXABcACoAKgBcAFwAXABcAFwAKgAqAFwAKgBcACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFwAXABcACoAKgBQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAA0ADQBQAFAAUAAEAAQAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQADQAEAAQAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAVABVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBUAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVAFUAVQBVACsAKwArACsAKwArACsAKwArACsAKwArAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAWQBZAFkAKwArACsAKwBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAWgBaAFoAKwArACsAKwAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYABgAGAAYAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAKwArACsAKwArAFYABABWAFYAVgBWAFYAVgBWAFYAVgBWAB4AVgBWAFYAVgBWAFYAVgBWAFYAVgBWAFYAVgArAFYAVgBWAFYAVgArAFYAKwBWAFYAKwBWAFYAKwBWAFYAVgBWAFYAVgBWAFYAVgBWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAEQAWAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAaAB4AKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAGAARABEAGAAYABMAEwAWABEAFAArACsAKwArACsAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACUAJQAlACUAJQAWABEAFgARABYAEQAWABEAFgARABYAEQAlACUAFgARACUAJQAlACUAJQAlACUAEQAlABEAKwAVABUAEwATACUAFgARABYAEQAWABEAJQAlACUAJQAlACUAJQAlACsAJQAbABoAJQArACsAKwArAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAcAKwATACUAJQAbABoAJQAlABYAEQAlACUAEQAlABEAJQBXAFcAVwBXAFcAVwBXAFcAVwBXABUAFQAlACUAJQATACUAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXABYAJQARACUAJQAlAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAWACUAEQAlABYAEQARABYAEQARABUAVwBRAFEAUQBRAFEAUQBRAFEAUQBRAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAEcARwArACsAVwBXAFcAVwBXAFcAKwArAFcAVwBXAFcAVwBXACsAKwBXAFcAVwBXAFcAVwArACsAVwBXAFcAKwArACsAGgAbACUAJQAlABsAGwArAB4AHgAeAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwAEAAQABAAQAB0AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsADQANAA0AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAA0AUABQAFAAUAArACsAKwArAFAAUABQAFAAUABQAFAAUAANAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwArAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwBQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwANAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAB4AUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAUABQAFAAUABQAAQABAAEACsABAAEACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAKwBQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAA0ADQANAA0ADQANAA0ADQAeACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAArACsAKwArAFAAUABQAFAAUAANAA0ADQANAA0ADQAUACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsADQANAA0ADQANAA0ADQBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAB4AHgAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArAAQABAANACsAKwBQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAB4AHgAeAB4AHgArACsAKwArACsAKwAEAAQABAAEAAQABAAEAA0ADQAeAB4AHgAeAB4AKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwAeACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEACsASwBLAEsASwBLAEsASwBLAEsASwANAA0ADQANAFAABAAEAFAAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAeAA4AUAArACsAKwArACsAKwArACsAKwAEAFAAUABQAFAADQANAB4ADQAEAAQABAAEAB4ABAAEAEsASwBLAEsASwBLAEsASwBLAEsAUAAOAFAADQANAA0AKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAANAA0AHgANAA0AHgAEACsAUABQAFAAUABQAFAAUAArAFAAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAA0AKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsABAAEAAQABAArAFAAUABQAFAAUABQAFAAUAArACsAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQACsABAAEAFAABAAEAAQABAAEAAQABAArACsABAAEACsAKwAEAAQABAArACsAUAArACsAKwArACsAKwAEACsAKwArACsAKwBQAFAAUABQAFAABAAEACsAKwAEAAQABAAEAAQABAAEACsAKwArAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsABAAEAAQABAAEAAQABABQAFAAUABQAA0ADQANAA0AHgBLAEsASwBLAEsASwBLAEsASwBLAA0ADQArAB4ABABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAFAAUAAeAFAAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABAAEAAQADgANAA0AEwATAB4AHgAeAA0ADQANAA0ADQANAA0ADQANAA0ADQANAA0ADQANAFAAUABQAFAABAAEACsAKwAEAA0ADQAeAFAAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAFAAKwArACsAKwArACsAKwBLAEsASwBLAEsASwBLAEsASwBLACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAXABcAFwAKwArACoAKgAqACoAKgAqACoAKgAqACoAKgAqACoAKgAqACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBcAFwADQANAA0AKgBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAKwArAFAAKwArAFAAUABQAFAAUABQAFAAUAArAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQAKwAEAAQAKwArAAQABAAEAAQAUAAEAFAABAAEAA0ADQANACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAArACsABAAEAAQABAAEAAQABABQAA4AUAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAABAAEAAQABAAEAAQABAAEAAQABABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAFAABAAEAAQABAAOAB4ADQANAA0ADQAOAB4ABAArACsAKwArACsAKwArACsAUAAEAAQABAAEAAQABAAEAAQABAAEAAQAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAA0ADQANAFAADgAOAA4ADQANACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAEAAQABAAEACsABAAEAAQABAAEAAQABAAEAFAADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAOABMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQACsAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAArACsAKwAEACsABAAEACsABAAEAAQABAAEAAQABABQAAQAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAUABQAFAAUABQAFAAKwBQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAUAArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAABAAEAAQABAAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAaABoAGgAaAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArAA0AUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsADQANAA0ADQANACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABIAEgAQwBDAEMAUABQAFAAUABDAFAAUABQAEgAQwBIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAASABDAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwAJAAkACQAJAAkACQAJABYAEQArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABIAEMAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwANAA0AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArAAQABAAEAAQABAANACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEAA0ADQANAB4AHgAeAB4AHgAeAFAAUABQAFAADQAeACsAKwArACsAKwArACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAANAA0AHgAeACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwAEAFAABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwAEAAQABAAEAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAARwBHABUARwAJACsAKwArACsAKwArACsAKwArACsAKwAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUQBRAFEAKwArACsAKwArACsAKwArACsAKwArACsAKwBRAFEAUQBRACsAKwArACsAKwArACsAKwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUAArACsAHgAEAAQADQAEAAQABAAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAAQABAAEAAQABAAeAB4AHgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAB4AHgAEAAQABAAEAAQABAAEAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4ABAAEAAQAHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwArACsAKwArACsAKwArACsAKwArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAKwArAFAAKwArAFAAUAArACsAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACsAUAArAFAAUABQAFAAUABQAFAAKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwBQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAHgAeAFAAUABQAFAAUAArAFAAKwArACsAUABQAFAAUABQAFAAUAArAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAB4AHgAeAB4AHgAeAB4AHgAeACsAKwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAEsASwBLAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAeAB4AHgAeAB4AHgAeAB4ABAAeAB4AHgAeAB4AHgAeAB4AHgAeAAQAHgAeAA0ADQANAA0AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQAKwAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArAAQABAAEAAQABAAEAAQAKwAEAAQAKwAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwAEAAQABAAEAAQABAAEAFAAUABQAFAAUABQAFAAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwBQAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArABsAUABQAFAAUABQACsAKwBQAFAAUABQAFAAUABQAFAAUAAEAAQABAAEAAQABAAEACsAKwArACsAKwArACsAKwArAB4AHgAeAB4ABAAEAAQABAAEAAQABABQACsAKwArACsASwBLAEsASwBLAEsASwBLAEsASwArACsAKwArABYAFgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAGgBQAFAAUAAaAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAeAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQACsAKwBQAFAAUABQACsAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUAArACsAKwArACsAKwBQACsAKwArACsAUAArAFAAKwBQACsAUABQAFAAKwBQAFAAKwBQACsAKwBQACsAUAArAFAAKwBQACsAUAArAFAAUAArAFAAKwArAFAAUABQAFAAKwBQAFAAUABQAFAAUABQACsAUABQAFAAUAArAFAAUABQAFAAKwBQACsAUABQAFAAUABQAFAAUABQAFAAUAArAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAArACsAKwArACsAUABQAFAAKwBQAFAAUABQAFAAKwBQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwAeAB4AKwArACsAKwArACsAKwArACsAKwArACsAKwArAE8ATwBPAE8ATwBPAE8ATwBPAE8ATwBPAE8AJQAlACUAHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHgAeAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB4AHgAeACUAJQAlAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAdAB0AHQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAKQApACkAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAlACUAJQAlACUAHgAlACUAJQAlACUAIAAgACAAJQAlACAAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACEAIQAhACEAIQAlACUAIAAgACUAJQAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlACUAIAAlACUAJQAlACAAIAAgACUAIAAgACAAJQAlACUAJQAlACUAJQAgACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAlAB4AJQAeACUAJQAlACUAJQAgACUAJQAlACUAHgAlAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAgACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACAAIAAgACAAIAAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeABcAFwAXABUAFQAVAB4AHgAeAB4AJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAgACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlACUAJQAeAB4AHgAeAB4AHgAeAB4AHgAeACUAJQAlACUAJQAlAB4AHgAeAB4AHgAeAB4AHgAlACUAJQAlACUAJQAlACUAHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAgACUAJQAgACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAJQAlACUAJQAlACUAIAAlACUAJQAlACUAJQAlACUAJQAgACAAIAAgACAAIAAgACAAIAAgACUAJQAgACAAIAAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACAAIAAlACAAIAAlACAAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAgACAAIAAlACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAJQAlAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AKwAeAB4AHgAeAB4AHgAeAB4AHgAeAB4AHgArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAEsASwBLAEsASwBLAEsASwBLAEsAKwArACsAKwArACsAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwArAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwAlACUAJQAlACUAJQAlACUAJQAlACUAVwBXACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQBXAFcAVwBXAFcAVwBXAFcAVwBXAFcAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAJQAlACUAKwAEACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArACsAKwArAA==",
                O = 50, P = 1, N = 2, R = 3, M = 4, _ = 5, V = 7, G = 8, J = 9, j = 10, X = 11, W = 12, Y = 13, Z = 14,
                q = 15, z = 16, $ = 17, AA = 18, eA = 19, tA = 20, rA = 21, nA = 22, iA = 23, sA = 24, oA = 25, aA = 26,
                cA = 27, lA = 28, uA = 29, dA = 30, BA = 31, hA = 32, gA = 33, pA = 34, fA = 35, wA = 36, CA = 37,
                mA = 38, QA = 39, yA = 40, UA = 41, vA = 42, FA = 43, IA = [9001, 65288], EA = "!", bA = "×", HA = "÷",
                TA = L(k), xA = [dA, wA], SA = [P, N, R, _], DA = [j, G], LA = [cA, aA], KA = SA.concat(DA),
                kA = [mA, QA, yA, pA, fA], OA = [q, Y], PA = function (A, e) {
                    void 0 === e && (e = "strict");
                    var t = [], r = [], n = [];
                    return A.forEach((function (A, i) {
                        var s = TA.get(A);
                        if (s > O ? (n.push(!0), s -= O) : n.push(!1), -1 !== ["normal", "auto", "loose"].indexOf(e) && -1 !== [8208, 8211, 12316, 12448].indexOf(A)) return r.push(i), t.push(z);
                        if (s === M || s === X) {
                            if (0 === i) return r.push(i), t.push(dA);
                            var o = t[i - 1];
                            return -1 === KA.indexOf(o) ? (r.push(r[i - 1]), t.push(o)) : (r.push(i), t.push(dA))
                        }
                        return r.push(i), s === BA ? t.push("strict" === e ? rA : CA) : s === vA || s === uA ? t.push(dA) : s === FA ? A >= 131072 && A <= 196605 || A >= 196608 && A <= 262141 ? t.push(CA) : t.push(dA) : void t.push(s)
                    })), [r, t, n]
                }, NA = function (A, e, t, r) {
                    var n = r[t];
                    if (Array.isArray(A) ? -1 !== A.indexOf(n) : A === n) {
                        var i = t;
                        while (i <= r.length) {
                            i++;
                            var s = r[i];
                            if (s === e) return !0;
                            if (s !== j) break
                        }
                    }
                    if (n === j) {
                        i = t;
                        while (i > 0) {
                            i--;
                            var o = r[i];
                            if (Array.isArray(A) ? -1 !== A.indexOf(o) : A === o) {
                                var a = t;
                                while (a <= r.length) {
                                    a++;
                                    s = r[a];
                                    if (s === e) return !0;
                                    if (s !== j) break
                                }
                            }
                            if (o !== j) break
                        }
                    }
                    return !1
                }, RA = function (A, e) {
                    var t = A;
                    while (t >= 0) {
                        var r = e[t];
                        if (r !== j) return r;
                        t--
                    }
                    return 0
                }, MA = function (A, e, t, r, n) {
                    if (0 === t[r]) return bA;
                    var i = r - 1;
                    if (Array.isArray(n) && !0 === n[i]) return bA;
                    var s = i - 1, o = i + 1, a = e[i], c = s >= 0 ? e[s] : 0, l = e[o];
                    if (a === N && l === R) return bA;
                    if (-1 !== SA.indexOf(a)) return EA;
                    if (-1 !== SA.indexOf(l)) return bA;
                    if (-1 !== DA.indexOf(l)) return bA;
                    if (RA(i, e) === G) return HA;
                    if (TA.get(A[i]) === X) return bA;
                    if ((a === hA || a === gA) && TA.get(A[o]) === X) return bA;
                    if (a === V || l === V) return bA;
                    if (a === J) return bA;
                    if (-1 === [j, Y, q].indexOf(a) && l === J) return bA;
                    if (-1 !== [$, AA, eA, sA, lA].indexOf(l)) return bA;
                    if (RA(i, e) === nA) return bA;
                    if (NA(iA, nA, i, e)) return bA;
                    if (NA([$, AA], rA, i, e)) return bA;
                    if (NA(W, W, i, e)) return bA;
                    if (a === j) return HA;
                    if (a === iA || l === iA) return bA;
                    if (l === z || a === z) return HA;
                    if (-1 !== [Y, q, rA].indexOf(l) || a === Z) return bA;
                    if (c === wA && -1 !== OA.indexOf(a)) return bA;
                    if (a === lA && l === wA) return bA;
                    if (l === tA) return bA;
                    if (-1 !== xA.indexOf(l) && a === oA || -1 !== xA.indexOf(a) && l === oA) return bA;
                    if (a === cA && -1 !== [CA, hA, gA].indexOf(l) || -1 !== [CA, hA, gA].indexOf(a) && l === aA) return bA;
                    if (-1 !== xA.indexOf(a) && -1 !== LA.indexOf(l) || -1 !== LA.indexOf(a) && -1 !== xA.indexOf(l)) return bA;
                    if (-1 !== [cA, aA].indexOf(a) && (l === oA || -1 !== [nA, q].indexOf(l) && e[o + 1] === oA) || -1 !== [nA, q].indexOf(a) && l === oA || a === oA && -1 !== [oA, lA, sA].indexOf(l)) return bA;
                    if (-1 !== [oA, lA, sA, $, AA].indexOf(l)) {
                        var u = i;
                        while (u >= 0) {
                            var d = e[u];
                            if (d === oA) return bA;
                            if (-1 === [lA, sA].indexOf(d)) break;
                            u--
                        }
                    }
                    if (-1 !== [cA, aA].indexOf(l)) {
                        u = -1 !== [$, AA].indexOf(a) ? s : i;
                        while (u >= 0) {
                            d = e[u];
                            if (d === oA) return bA;
                            if (-1 === [lA, sA].indexOf(d)) break;
                            u--
                        }
                    }
                    if (mA === a && -1 !== [mA, QA, pA, fA].indexOf(l) || -1 !== [QA, pA].indexOf(a) && -1 !== [QA, yA].indexOf(l) || -1 !== [yA, fA].indexOf(a) && l === yA) return bA;
                    if (-1 !== kA.indexOf(a) && -1 !== [tA, aA].indexOf(l) || -1 !== kA.indexOf(l) && a === cA) return bA;
                    if (-1 !== xA.indexOf(a) && -1 !== xA.indexOf(l)) return bA;
                    if (a === sA && -1 !== xA.indexOf(l)) return bA;
                    if (-1 !== xA.concat(oA).indexOf(a) && l === nA && -1 === IA.indexOf(A[o]) || -1 !== xA.concat(oA).indexOf(l) && a === AA) return bA;
                    if (a === UA && l === UA) {
                        var B = t[i], h = 1;
                        while (B > 0) {
                            if (B--, e[B] !== UA) break;
                            h++
                        }
                        if (h % 2 !== 0) return bA
                    }
                    return a === hA && l === gA ? bA : HA
                }, _A = function (A, e) {
                    e || (e = { lineBreak: "normal", wordBreak: "normal" });
                    var t = PA(A, e.lineBreak), r = t[0], n = t[1], i = t[2];
                    "break-all" !== e.wordBreak && "break-word" !== e.wordBreak || (n = n.map((function (A) {
                        return -1 !== [oA, dA, vA].indexOf(A) ? CA : A
                    })));
                    var s = "keep-all" === e.wordBreak ? i.map((function (e, t) {
                        return e && A[t] >= 19968 && A[t] <= 40959
                    })) : void 0;
                    return [r, n, s]
                }, VA = function () {
                    function A(A, e, t, r) {
                        this.codePoints = A, this.required = e === EA, this.start = t, this.end = r
                    }

                    return A.prototype.slice = function () {
                        return l.apply(void 0, this.codePoints.slice(this.start, this.end))
                    }, A
                }(), GA = function (A, e) {
                    var t = c(A), r = _A(t, e), n = r[0], i = r[1], s = r[2], o = t.length, a = 0, l = 0;
                    return {
                        next: function () {
                            if (l >= o) return { done: !0, value: null };
                            var A = bA;
                            while (l < o && (A = MA(t, i, n, ++l, s)) === bA);
                            if (A !== bA || l === o) {
                                var e = new VA(t, A, a, l);
                                return a = l, { value: e, done: !1 }
                            }
                            return { done: !0, value: null }
                        }
                    }
                }, JA = 1, jA = 2, XA = 4, WA = 8, YA = 10, ZA = 47, qA = 92, zA = 9, $A = 32, Ae = 34, ee = 61, te = 35,
                re = 36, ne = 37, ie = 39, se = 40, oe = 41, ae = 95, ce = 45, le = 33, ue = 60, de = 62, Be = 64,
                he = 91, ge = 93, pe = 61, fe = 123, we = 63, Ce = 125, me = 124, Qe = 126, ye = 128, Ue = 65533,
                ve = 42, Fe = 43, Ie = 44, Ee = 58, be = 59, He = 46, Te = 0, xe = 8, Se = 11, De = 14, Le = 31,
                Ke = 127, ke = -1, Oe = 48, Pe = 97, Ne = 101, Re = 102, Me = 117, _e = 122, Ve = 65, Ge = 69, Je = 70,
                je = 85, Xe = 90, We = function (A) {
                    return A >= Oe && A <= 57
                }, Ye = function (A) {
                    return A >= 55296 && A <= 57343
                }, Ze = function (A) {
                    return We(A) || A >= Ve && A <= Je || A >= Pe && A <= Re
                }, qe = function (A) {
                    return A >= Pe && A <= _e
                }, ze = function (A) {
                    return A >= Ve && A <= Xe
                }, $e = function (A) {
                    return qe(A) || ze(A)
                }, At = function (A) {
                    return A >= ye
                }, et = function (A) {
                    return A === YA || A === zA || A === $A
                }, tt = function (A) {
                    return $e(A) || At(A) || A === ae
                }, rt = function (A) {
                    return tt(A) || We(A) || A === ce
                }, nt = function (A) {
                    return A >= Te && A <= xe || A === Se || A >= De && A <= Le || A === Ke
                }, it = function (A, e) {
                    return A === qA && e !== YA
                }, st = function (A, e, t) {
                    return A === ce ? tt(e) || it(e, t) : !!tt(A) || !(A !== qA || !it(A, e))
                }, ot = function (A, e, t) {
                    return A === Fe || A === ce ? !!We(e) || e === He && We(t) : We(A === He ? e : A)
                }, at = function (A) {
                    var e = 0, t = 1;
                    A[e] !== Fe && A[e] !== ce || (A[e] === ce && (t = -1), e++);
                    var r = [];
                    while (We(A[e])) r.push(A[e++]);
                    var n = r.length ? parseInt(l.apply(void 0, r), 10) : 0;
                    A[e] === He && e++;
                    var i = [];
                    while (We(A[e])) i.push(A[e++]);
                    var s = i.length, o = s ? parseInt(l.apply(void 0, i), 10) : 0;
                    A[e] !== Ge && A[e] !== Ne || e++;
                    var a = 1;
                    A[e] !== Fe && A[e] !== ce || (A[e] === ce && (a = -1), e++);
                    var c = [];
                    while (We(A[e])) c.push(A[e++]);
                    var u = c.length ? parseInt(l.apply(void 0, c), 10) : 0;
                    return t * (n + o * Math.pow(10, -s)) * Math.pow(10, a * u)
                }, ct = { type: 2 }, lt = { type: 3 }, ut = { type: 4 }, dt = { type: 13 }, Bt = { type: 8 }, ht = { type: 21 },
                gt = { type: 9 }, pt = { type: 10 }, ft = { type: 11 }, wt = { type: 12 }, Ct = { type: 14 }, mt = { type: 23 },
                Qt = { type: 1 }, yt = { type: 25 }, Ut = { type: 24 }, vt = { type: 26 }, Ft = { type: 27 }, It = { type: 28 },
                Et = { type: 29 }, bt = { type: 31 }, Ht = { type: 32 }, Tt = function () {
                    function A() {
                        this._value = []
                    }

                    return A.prototype.write = function (A) {
                        this._value = this._value.concat(c(A))
                    }, A.prototype.read = function () {
                        var A = [], e = this.consumeToken();
                        while (e !== Ht) A.push(e), e = this.consumeToken();
                        return A
                    }, A.prototype.consumeToken = function () {
                        var A = this.consumeCodePoint();
                        switch (A) {
                            case Ae:
                                return this.consumeStringToken(Ae);
                            case te:
                                var e = this.peekCodePoint(0), t = this.peekCodePoint(1), r = this.peekCodePoint(2);
                                if (rt(e) || it(t, r)) {
                                    var n = st(e, t, r) ? jA : JA, i = this.consumeName();
                                    return { type: 5, value: i, flags: n }
                                }
                                break;
                            case re:
                                if (this.peekCodePoint(0) === ee) return this.consumeCodePoint(), dt;
                                break;
                            case ie:
                                return this.consumeStringToken(ie);
                            case se:
                                return ct;
                            case oe:
                                return lt;
                            case ve:
                                if (this.peekCodePoint(0) === ee) return this.consumeCodePoint(), Ct;
                                break;
                            case Fe:
                                if (ot(A, this.peekCodePoint(0), this.peekCodePoint(1))) return this.reconsumeCodePoint(A), this.consumeNumericToken();
                                break;
                            case Ie:
                                return ut;
                            case ce:
                                var s = A, o = this.peekCodePoint(0), a = this.peekCodePoint(1);
                                if (ot(s, o, a)) return this.reconsumeCodePoint(A), this.consumeNumericToken();
                                if (st(s, o, a)) return this.reconsumeCodePoint(A), this.consumeIdentLikeToken();
                                if (o === ce && a === de) return this.consumeCodePoint(), this.consumeCodePoint(), Ut;
                                break;
                            case He:
                                if (ot(A, this.peekCodePoint(0), this.peekCodePoint(1))) return this.reconsumeCodePoint(A), this.consumeNumericToken();
                                break;
                            case ZA:
                                if (this.peekCodePoint(0) === ve) {
                                    this.consumeCodePoint();
                                    while (1) {
                                        var c = this.consumeCodePoint();
                                        if (c === ve && (c = this.consumeCodePoint(), c === ZA)) return this.consumeToken();
                                        if (c === ke) return this.consumeToken()
                                    }
                                }
                                break;
                            case Ee:
                                return vt;
                            case be:
                                return Ft;
                            case ue:
                                if (this.peekCodePoint(0) === le && this.peekCodePoint(1) === ce && this.peekCodePoint(2) === ce) return this.consumeCodePoint(), this.consumeCodePoint(), yt;
                                break;
                            case Be:
                                var u = this.peekCodePoint(0), d = this.peekCodePoint(1), B = this.peekCodePoint(2);
                                if (st(u, d, B)) {
                                    i = this.consumeName();
                                    return { type: 7, value: i }
                                }
                                break;
                            case he:
                                return It;
                            case qA:
                                if (it(A, this.peekCodePoint(0))) return this.reconsumeCodePoint(A), this.consumeIdentLikeToken();
                                break;
                            case ge:
                                return Et;
                            case pe:
                                if (this.peekCodePoint(0) === ee) return this.consumeCodePoint(), Bt;
                                break;
                            case fe:
                                return ft;
                            case Ce:
                                return wt;
                            case Me:
                            case je:
                                var h = this.peekCodePoint(0), g = this.peekCodePoint(1);
                                return h !== Fe || !Ze(g) && g !== we || (this.consumeCodePoint(), this.consumeUnicodeRangeToken()), this.reconsumeCodePoint(A), this.consumeIdentLikeToken();
                            case me:
                                if (this.peekCodePoint(0) === ee) return this.consumeCodePoint(), gt;
                                if (this.peekCodePoint(0) === me) return this.consumeCodePoint(), ht;
                                break;
                            case Qe:
                                if (this.peekCodePoint(0) === ee) return this.consumeCodePoint(), pt;
                                break;
                            case ke:
                                return Ht
                        }
                        return et(A) ? (this.consumeWhiteSpace(), bt) : We(A) ? (this.reconsumeCodePoint(A), this.consumeNumericToken()) : tt(A) ? (this.reconsumeCodePoint(A), this.consumeIdentLikeToken()) : {
                            type: 6,
                            value: l(A)
                        }
                    }, A.prototype.consumeCodePoint = function () {
                        var A = this._value.shift();
                        return "undefined" === typeof A ? -1 : A
                    }, A.prototype.reconsumeCodePoint = function (A) {
                        this._value.unshift(A)
                    }, A.prototype.peekCodePoint = function (A) {
                        return A >= this._value.length ? -1 : this._value[A]
                    }, A.prototype.consumeUnicodeRangeToken = function () {
                        var A = [], e = this.consumeCodePoint();
                        while (Ze(e) && A.length < 6) A.push(e), e = this.consumeCodePoint();
                        var t = !1;
                        while (e === we && A.length < 6) A.push(e), e = this.consumeCodePoint(), t = !0;
                        if (t) {
                            var r = parseInt(l.apply(void 0, A.map((function (A) {
                                return A === we ? Oe : A
                            }))), 16), n = parseInt(l.apply(void 0, A.map((function (A) {
                                return A === we ? Je : A
                            }))), 16);
                            return { type: 30, start: r, end: n }
                        }
                        var i = parseInt(l.apply(void 0, A), 16);
                        if (this.peekCodePoint(0) === ce && Ze(this.peekCodePoint(1))) {
                            this.consumeCodePoint(), e = this.consumeCodePoint();
                            var s = [];
                            while (Ze(e) && s.length < 6) s.push(e), e = this.consumeCodePoint();
                            n = parseInt(l.apply(void 0, s), 16);
                            return { type: 30, start: i, end: n }
                        }
                        return { type: 30, start: i, end: i }
                    }, A.prototype.consumeIdentLikeToken = function () {
                        var A = this.consumeName();
                        return "url" === A.toLowerCase() && this.peekCodePoint(0) === se ? (this.consumeCodePoint(), this.consumeUrlToken()) : this.peekCodePoint(0) === se ? (this.consumeCodePoint(), {
                            type: 19,
                            value: A
                        }) : { type: 20, value: A }
                    }, A.prototype.consumeUrlToken = function () {
                        var A = [];
                        if (this.consumeWhiteSpace(), this.peekCodePoint(0) === ke) return { type: 22, value: "" };
                        var e = this.peekCodePoint(0);
                        if (e === ie || e === Ae) {
                            var t = this.consumeStringToken(this.consumeCodePoint());
                            return 0 === t.type && (this.consumeWhiteSpace(), this.peekCodePoint(0) === ke || this.peekCodePoint(0) === oe) ? (this.consumeCodePoint(), {
                                type: 22,
                                value: t.value
                            }) : (this.consumeBadUrlRemnants(), mt)
                        }
                        while (1) {
                            var r = this.consumeCodePoint();
                            if (r === ke || r === oe) return { type: 22, value: l.apply(void 0, A) };
                            if (et(r)) return this.consumeWhiteSpace(), this.peekCodePoint(0) === ke || this.peekCodePoint(0) === oe ? (this.consumeCodePoint(), {
                                type: 22,
                                value: l.apply(void 0, A)
                            }) : (this.consumeBadUrlRemnants(), mt);
                            if (r === Ae || r === ie || r === se || nt(r)) return this.consumeBadUrlRemnants(), mt;
                            if (r === qA) {
                                if (!it(r, this.peekCodePoint(0))) return this.consumeBadUrlRemnants(), mt;
                                A.push(this.consumeEscapedCodePoint())
                            } else A.push(r)
                        }
                    }, A.prototype.consumeWhiteSpace = function () {
                        while (et(this.peekCodePoint(0))) this.consumeCodePoint()
                    }, A.prototype.consumeBadUrlRemnants = function () {
                        while (1) {
                            var A = this.consumeCodePoint();
                            if (A === oe || A === ke) return;
                            it(A, this.peekCodePoint(0)) && this.consumeEscapedCodePoint()
                        }
                    }, A.prototype.consumeStringSlice = function (A) {
                        var e = 6e4, t = "";
                        while (A > 0) {
                            var r = Math.min(e, A);
                            t += l.apply(void 0, this._value.splice(0, r)), A -= r
                        }
                        return this._value.shift(), t
                    }, A.prototype.consumeStringToken = function (A) {
                        var e = "", t = 0;
                        do {
                            var r = this._value[t];
                            if (r === ke || void 0 === r || r === A) return e += this.consumeStringSlice(t), {
                                type: 0,
                                value: e
                            };
                            if (r === YA) return this._value.splice(0, t), Qt;
                            if (r === qA) {
                                var n = this._value[t + 1];
                                n !== ke && void 0 !== n && (n === YA ? (e += this.consumeStringSlice(t), t = -1, this._value.shift()) : it(r, n) && (e += this.consumeStringSlice(t), e += l(this.consumeEscapedCodePoint()), t = -1))
                            }
                            t++
                        } while (1)
                    }, A.prototype.consumeNumber = function () {
                        var A = [], e = XA, t = this.peekCodePoint(0);
                        t !== Fe && t !== ce || A.push(this.consumeCodePoint());
                        while (We(this.peekCodePoint(0))) A.push(this.consumeCodePoint());
                        t = this.peekCodePoint(0);
                        var r = this.peekCodePoint(1);
                        if (t === He && We(r)) {
                            A.push(this.consumeCodePoint(), this.consumeCodePoint()), e = WA;
                            while (We(this.peekCodePoint(0))) A.push(this.consumeCodePoint())
                        }
                        t = this.peekCodePoint(0), r = this.peekCodePoint(1);
                        var n = this.peekCodePoint(2);
                        if ((t === Ge || t === Ne) && ((r === Fe || r === ce) && We(n) || We(r))) {
                            A.push(this.consumeCodePoint(), this.consumeCodePoint()), e = WA;
                            while (We(this.peekCodePoint(0))) A.push(this.consumeCodePoint())
                        }
                        return [at(A), e]
                    }, A.prototype.consumeNumericToken = function () {
                        var A = this.consumeNumber(), e = A[0], t = A[1], r = this.peekCodePoint(0),
                            n = this.peekCodePoint(1), i = this.peekCodePoint(2);
                        if (st(r, n, i)) {
                            var s = this.consumeName();
                            return { type: 15, number: e, flags: t, unit: s }
                        }
                        return r === ne ? (this.consumeCodePoint(), { type: 16, number: e, flags: t }) : {
                            type: 17,
                            number: e,
                            flags: t
                        }
                    }, A.prototype.consumeEscapedCodePoint = function () {
                        var A = this.consumeCodePoint();
                        if (Ze(A)) {
                            var e = l(A);
                            while (Ze(this.peekCodePoint(0)) && e.length < 6) e += l(this.consumeCodePoint());
                            et(this.peekCodePoint(0)) && this.consumeCodePoint();
                            var t = parseInt(e, 16);
                            return 0 === t || Ye(t) || t > 1114111 ? Ue : t
                        }
                        return A === ke ? Ue : A
                    }, A.prototype.consumeName = function () {
                        var A = "";
                        while (1) {
                            var e = this.consumeCodePoint();
                            if (rt(e)) A += l(e); else {
                                if (!it(e, this.peekCodePoint(0))) return this.reconsumeCodePoint(e), A;
                                A += l(this.consumeEscapedCodePoint())
                            }
                        }
                    }, A
                }(), xt = function () {
                    function A(A) {
                        this._tokens = A
                    }

                    return A.create = function (e) {
                        var t = new Tt;
                        return t.write(e), new A(t.read())
                    }, A.parseValue = function (e) {
                        return A.create(e).parseComponentValue()
                    }, A.parseValues = function (e) {
                        return A.create(e).parseComponentValues()
                    }, A.prototype.parseComponentValue = function () {
                        var A = this.consumeToken();
                        while (31 === A.type) A = this.consumeToken();
                        if (32 === A.type) throw new SyntaxError("Error parsing CSS component value, unexpected EOF");
                        this.reconsumeToken(A);
                        var e = this.consumeComponentValue();
                        do {
                            A = this.consumeToken()
                        } while (31 === A.type);
                        if (32 === A.type) return e;
                        throw new SyntaxError("Error parsing CSS component value, multiple values found when expecting only one")
                    }, A.prototype.parseComponentValues = function () {
                        var A = [];
                        while (1) {
                            var e = this.consumeComponentValue();
                            if (32 === e.type) return A;
                            A.push(e), A.push()
                        }
                    }, A.prototype.consumeComponentValue = function () {
                        var A = this.consumeToken();
                        switch (A.type) {
                            case 11:
                            case 28:
                            case 2:
                                return this.consumeSimpleBlock(A.type);
                            case 19:
                                return this.consumeFunction(A)
                        }
                        return A
                    }, A.prototype.consumeSimpleBlock = function (A) {
                        var e = { type: A, values: [] }, t = this.consumeToken();
                        while (1) {
                            if (32 === t.type || Rt(t, A)) return e;
                            this.reconsumeToken(t), e.values.push(this.consumeComponentValue()), t = this.consumeToken()
                        }
                    }, A.prototype.consumeFunction = function (A) {
                        var e = { name: A.value, values: [], type: 18 };
                        while (1) {
                            var t = this.consumeToken();
                            if (32 === t.type || 3 === t.type) return e;
                            this.reconsumeToken(t), e.values.push(this.consumeComponentValue())
                        }
                    }, A.prototype.consumeToken = function () {
                        var A = this._tokens.shift();
                        return "undefined" === typeof A ? Ht : A
                    }, A.prototype.reconsumeToken = function (A) {
                        this._tokens.unshift(A)
                    }, A
                }(), St = function (A) {
                    return 15 === A.type
                }, Dt = function (A) {
                    return 17 === A.type
                }, Lt = function (A) {
                    return 20 === A.type
                }, Kt = function (A) {
                    return 0 === A.type
                }, kt = function (A, e) {
                    return Lt(A) && A.value === e
                }, Ot = function (A) {
                    return 31 !== A.type
                }, Pt = function (A) {
                    return 31 !== A.type && 4 !== A.type
                }, Nt = function (A) {
                    var e = [], t = [];
                    return A.forEach((function (A) {
                        if (4 === A.type) {
                            if (0 === t.length) throw new Error("Error parsing function args, zero tokens for arg");
                            return e.push(t), void (t = [])
                        }
                        31 !== A.type && t.push(A)
                    })), t.length && e.push(t), e
                }, Rt = function (A, e) {
                    return 11 === e && 12 === A.type || (28 === e && 29 === A.type || 2 === e && 3 === A.type)
                }, Mt = function (A) {
                    return 17 === A.type || 15 === A.type
                }, _t = function (A) {
                    return 16 === A.type || Mt(A)
                }, Vt = function (A) {
                    return A.length > 1 ? [A[0], A[1]] : [A[0]]
                }, Gt = { type: 17, number: 0, flags: XA }, Jt = { type: 16, number: 50, flags: XA },
                jt = { type: 16, number: 100, flags: XA }, Xt = function (A, e, t) {
                    var r = A[0], n = A[1];
                    return [Wt(r, e), Wt("undefined" !== typeof n ? n : r, t)]
                }, Wt = function (A, e) {
                    if (16 === A.type) return A.number / 100 * e;
                    if (St(A)) switch (A.unit) {
                        case "rem":
                        case "em":
                            return 16 * A.number;
                        case "px":
                        default:
                            return A.number
                    }
                    return A.number
                }, Yt = "deg", Zt = "grad", qt = "rad", zt = "turn", $t = {
                    name: "angle", parse: function (A, e) {
                        if (15 === e.type) switch (e.unit) {
                            case Yt:
                                return Math.PI * e.number / 180;
                            case Zt:
                                return Math.PI / 200 * e.number;
                            case qt:
                                return e.number;
                            case zt:
                                return 2 * Math.PI * e.number
                        }
                        throw new Error("Unsupported angle type")
                    }
                }, Ar = function (A) {
                    return 15 === A.type && (A.unit === Yt || A.unit === Zt || A.unit === qt || A.unit === zt)
                }, er = function (A) {
                    var e = A.filter(Lt).map((function (A) {
                        return A.value
                    })).join(" ");
                    switch (e) {
                        case "to bottom right":
                        case "to right bottom":
                        case "left top":
                        case "top left":
                            return [Gt, Gt];
                        case "to top":
                        case "bottom":
                            return tr(0);
                        case "to bottom left":
                        case "to left bottom":
                        case "right top":
                        case "top right":
                            return [Gt, jt];
                        case "to right":
                        case "left":
                            return tr(90);
                        case "to top left":
                        case "to left top":
                        case "right bottom":
                        case "bottom right":
                            return [jt, jt];
                        case "to bottom":
                        case "top":
                            return tr(180);
                        case "to top right":
                        case "to right top":
                        case "left bottom":
                        case "bottom left":
                            return [jt, Gt];
                        case "to left":
                        case "right":
                            return tr(270)
                    }
                    return 0
                }, tr = function (A) {
                    return Math.PI * A / 180
                }, rr = {
                    name: "color", parse: function (A, e) {
                        if (18 === e.type) {
                            var t = ur[e.name];
                            if ("undefined" === typeof t) throw new Error('Attempting to parse an unsupported color function "' + e.name + '"');
                            return t(A, e.values)
                        }
                        if (5 === e.type) {
                            if (3 === e.value.length) {
                                var r = e.value.substring(0, 1), n = e.value.substring(1, 2), i = e.value.substring(2, 3);
                                return sr(parseInt(r + r, 16), parseInt(n + n, 16), parseInt(i + i, 16), 1)
                            }
                            if (4 === e.value.length) {
                                r = e.value.substring(0, 1), n = e.value.substring(1, 2), i = e.value.substring(2, 3);
                                var s = e.value.substring(3, 4);
                                return sr(parseInt(r + r, 16), parseInt(n + n, 16), parseInt(i + i, 16), parseInt(s + s, 16) / 255)
                            }
                            if (6 === e.value.length) {
                                r = e.value.substring(0, 2), n = e.value.substring(2, 4), i = e.value.substring(4, 6);
                                return sr(parseInt(r, 16), parseInt(n, 16), parseInt(i, 16), 1)
                            }
                            if (8 === e.value.length) {
                                r = e.value.substring(0, 2), n = e.value.substring(2, 4), i = e.value.substring(4, 6), s = e.value.substring(6, 8);
                                return sr(parseInt(r, 16), parseInt(n, 16), parseInt(i, 16), parseInt(s, 16) / 255)
                            }
                        }
                        if (20 === e.type) {
                            var o = Br[e.value.toUpperCase()];
                            if ("undefined" !== typeof o) return o
                        }
                        return Br.TRANSPARENT
                    }
                }, nr = function (A) {
                    return 0 === (255 & A)
                }, ir = function (A) {
                    var e = 255 & A, t = 255 & A >> 8, r = 255 & A >> 16, n = 255 & A >> 24;
                    return e < 255 ? "rgba(" + n + "," + r + "," + t + "," + e / 255 + ")" : "rgb(" + n + "," + r + "," + t + ")"
                }, sr = function (A, e, t, r) {
                    return (A << 24 | e << 16 | t << 8 | Math.round(255 * r) << 0) >>> 0
                }, or = function (A, e) {
                    if (17 === A.type) return A.number;
                    if (16 === A.type) {
                        var t = 3 === e ? 1 : 255;
                        return 3 === e ? A.number / 100 * t : Math.round(A.number / 100 * t)
                    }
                    return 0
                }, ar = function (A, e) {
                    var t = e.filter(Pt);
                    if (3 === t.length) {
                        var r = t.map(or), n = r[0], i = r[1], s = r[2];
                        return sr(n, i, s, 1)
                    }
                    if (4 === t.length) {
                        var o = t.map(or), a = (n = o[0], i = o[1], s = o[2], o[3]);
                        return sr(n, i, s, a)
                    }
                    return 0
                };

            function cr(A, e, t) {
                return t < 0 && (t += 1), t >= 1 && (t -= 1), t < 1 / 6 ? (e - A) * t * 6 + A : t < .5 ? e : t < 2 / 3 ? 6 * (e - A) * (2 / 3 - t) + A : A
            }

            var lr = function (A, e) {
                var t = e.filter(Pt), r = t[0], n = t[1], i = t[2], s = t[3],
                    o = (17 === r.type ? tr(r.number) : $t.parse(A, r)) / (2 * Math.PI), a = _t(n) ? n.number / 100 : 0,
                    c = _t(i) ? i.number / 100 : 0, l = "undefined" !== typeof s && _t(s) ? Wt(s, 1) : 1;
                if (0 === a) return sr(255 * c, 255 * c, 255 * c, 1);
                var u = c <= .5 ? c * (a + 1) : c + a - c * a, d = 2 * c - u, B = cr(d, u, o + 1 / 3), h = cr(d, u, o),
                    g = cr(d, u, o - 1 / 3);
                return sr(255 * B, 255 * h, 255 * g, l)
            }, ur = { hsl: lr, hsla: lr, rgb: ar, rgba: ar }, dr = function (A, e) {
                return rr.parse(A, xt.create(e).parseComponentValue())
            }, Br = {
                ALICEBLUE: 4042850303,
                ANTIQUEWHITE: 4209760255,
                AQUA: 16777215,
                AQUAMARINE: 2147472639,
                AZURE: 4043309055,
                BEIGE: 4126530815,
                BISQUE: 4293182719,
                BLACK: 255,
                BLANCHEDALMOND: 4293643775,
                BLUE: 65535,
                BLUEVIOLET: 2318131967,
                BROWN: 2771004159,
                BURLYWOOD: 3736635391,
                CADETBLUE: 1604231423,
                CHARTREUSE: 2147418367,
                CHOCOLATE: 3530104575,
                CORAL: 4286533887,
                CORNFLOWERBLUE: 1687547391,
                CORNSILK: 4294499583,
                CRIMSON: 3692313855,
                CYAN: 16777215,
                DARKBLUE: 35839,
                DARKCYAN: 9145343,
                DARKGOLDENROD: 3095837695,
                DARKGRAY: 2846468607,
                DARKGREEN: 6553855,
                DARKGREY: 2846468607,
                DARKKHAKI: 3182914559,
                DARKMAGENTA: 2332068863,
                DARKOLIVEGREEN: 1433087999,
                DARKORANGE: 4287365375,
                DARKORCHID: 2570243327,
                DARKRED: 2332033279,
                DARKSALMON: 3918953215,
                DARKSEAGREEN: 2411499519,
                DARKSLATEBLUE: 1211993087,
                DARKSLATEGRAY: 793726975,
                DARKSLATEGREY: 793726975,
                DARKTURQUOISE: 13554175,
                DARKVIOLET: 2483082239,
                DEEPPINK: 4279538687,
                DEEPSKYBLUE: 12582911,
                DIMGRAY: 1768516095,
                DIMGREY: 1768516095,
                DODGERBLUE: 512819199,
                FIREBRICK: 2988581631,
                FLORALWHITE: 4294635775,
                FORESTGREEN: 579543807,
                FUCHSIA: 4278255615,
                GAINSBORO: 3705462015,
                GHOSTWHITE: 4177068031,
                GOLD: 4292280575,
                GOLDENROD: 3668254975,
                GRAY: 2155905279,
                GREEN: 8388863,
                GREENYELLOW: 2919182335,
                GREY: 2155905279,
                HONEYDEW: 4043305215,
                HOTPINK: 4285117695,
                INDIANRED: 3445382399,
                INDIGO: 1258324735,
                IVORY: 4294963455,
                KHAKI: 4041641215,
                LAVENDER: 3873897215,
                LAVENDERBLUSH: 4293981695,
                LAWNGREEN: 2096890111,
                LEMONCHIFFON: 4294626815,
                LIGHTBLUE: 2916673279,
                LIGHTCORAL: 4034953471,
                LIGHTCYAN: 3774873599,
                LIGHTGOLDENRODYELLOW: 4210742015,
                LIGHTGRAY: 3553874943,
                LIGHTGREEN: 2431553791,
                LIGHTGREY: 3553874943,
                LIGHTPINK: 4290167295,
                LIGHTSALMON: 4288707327,
                LIGHTSEAGREEN: 548580095,
                LIGHTSKYBLUE: 2278488831,
                LIGHTSLATEGRAY: 2005441023,
                LIGHTSLATEGREY: 2005441023,
                LIGHTSTEELBLUE: 2965692159,
                LIGHTYELLOW: 4294959359,
                LIME: 16711935,
                LIMEGREEN: 852308735,
                LINEN: 4210091775,
                MAGENTA: 4278255615,
                MAROON: 2147483903,
                MEDIUMAQUAMARINE: 1724754687,
                MEDIUMBLUE: 52735,
                MEDIUMORCHID: 3126187007,
                MEDIUMPURPLE: 2473647103,
                MEDIUMSEAGREEN: 1018393087,
                MEDIUMSLATEBLUE: 2070474495,
                MEDIUMSPRINGGREEN: 16423679,
                MEDIUMTURQUOISE: 1221709055,
                MEDIUMVIOLETRED: 3340076543,
                MIDNIGHTBLUE: 421097727,
                MINTCREAM: 4127193855,
                MISTYROSE: 4293190143,
                MOCCASIN: 4293178879,
                NAVAJOWHITE: 4292783615,
                NAVY: 33023,
                OLDLACE: 4260751103,
                OLIVE: 2155872511,
                OLIVEDRAB: 1804477439,
                ORANGE: 4289003775,
                ORANGERED: 4282712319,
                ORCHID: 3664828159,
                PALEGOLDENROD: 4008225535,
                PALEGREEN: 2566625535,
                PALETURQUOISE: 2951671551,
                PALEVIOLETRED: 3681588223,
                PAPAYAWHIP: 4293907967,
                PEACHPUFF: 4292524543,
                PERU: 3448061951,
                PINK: 4290825215,
                PLUM: 3718307327,
                POWDERBLUE: 2967529215,
                PURPLE: 2147516671,
                REBECCAPURPLE: 1714657791,
                RED: 4278190335,
                ROSYBROWN: 3163525119,
                ROYALBLUE: 1097458175,
                SADDLEBROWN: 2336560127,
                SALMON: 4202722047,
                SANDYBROWN: 4104413439,
                SEAGREEN: 780883967,
                SEASHELL: 4294307583,
                SIENNA: 2689740287,
                SILVER: 3233857791,
                SKYBLUE: 2278484991,
                SLATEBLUE: 1784335871,
                SLATEGRAY: 1887473919,
                SLATEGREY: 1887473919,
                SNOW: 4294638335,
                SPRINGGREEN: 16744447,
                STEELBLUE: 1182971135,
                TAN: 3535047935,
                TEAL: 8421631,
                THISTLE: 3636451583,
                TOMATO: 4284696575,
                TRANSPARENT: 0,
                TURQUOISE: 1088475391,
                VIOLET: 4001558271,
                WHEAT: 4125012991,
                WHITE: 4294967295,
                WHITESMOKE: 4126537215,
                YELLOW: 4294902015,
                YELLOWGREEN: 2597139199
            }, hr = {
                name: "background-clip", initialValue: "border-box", prefix: !1, type: 1, parse: function (A, e) {
                    return e.map((function (A) {
                        if (Lt(A)) switch (A.value) {
                            case "padding-box":
                                return 1;
                            case "content-box":
                                return 2
                        }
                        return 0
                    }))
                }
            }, gr = { name: "background-color", initialValue: "transparent", prefix: !1, type: 3, format: "color" },
                pr = function (A, e) {
                    var t = rr.parse(A, e[0]), r = e[1];
                    return r && _t(r) ? { color: t, stop: r } : { color: t, stop: null }
                }, fr = function (A, e) {
                    var t = A[0], r = A[A.length - 1];
                    null === t.stop && (t.stop = Gt), null === r.stop && (r.stop = jt);
                    for (var n = [], i = 0, s = 0; s < A.length; s++) {
                        var o = A[s].stop;
                        if (null !== o) {
                            var a = Wt(o, e);
                            a > i ? n.push(a) : n.push(i), i = a
                        } else n.push(null)
                    }
                    var c = null;
                    for (s = 0; s < n.length; s++) {
                        var l = n[s];
                        if (null === l) null === c && (c = s); else if (null !== c) {
                            for (var u = s - c, d = n[c - 1], B = (l - d) / (u + 1), h = 1; h <= u; h++) n[c + h - 1] = B * h;
                            c = null
                        }
                    }
                    return A.map((function (A, t) {
                        var r = A.color;
                        return { color: r, stop: Math.max(Math.min(1, n[t] / e), 0) }
                    }))
                }, wr = function (A, e, t) {
                    var r = e / 2, n = t / 2, i = Wt(A[0], e) - r, s = n - Wt(A[1], t);
                    return (Math.atan2(s, i) + 2 * Math.PI) % (2 * Math.PI)
                }, Cr = function (A, e, t) {
                    var r = "number" === typeof A ? A : wr(A, e, t),
                        n = Math.abs(e * Math.sin(r)) + Math.abs(t * Math.cos(r)), i = e / 2, s = t / 2, o = n / 2,
                        a = Math.sin(r - Math.PI / 2) * o, c = Math.cos(r - Math.PI / 2) * o;
                    return [n, i - c, i + c, s - a, s + a]
                }, mr = function (A, e) {
                    return Math.sqrt(A * A + e * e)
                }, Qr = function (A, e, t, r, n) {
                    var i = [[0, 0], [0, e], [A, 0], [A, e]];
                    return i.reduce((function (A, e) {
                        var i = e[0], s = e[1], o = mr(t - i, r - s);
                        return (n ? o < A.optimumDistance : o > A.optimumDistance) ? {
                            optimumCorner: e,
                            optimumDistance: o
                        } : A
                    }), { optimumDistance: n ? 1 / 0 : -1 / 0, optimumCorner: null }).optimumCorner
                }, yr = function (A, e, t, r, n) {
                    var i = 0, s = 0;
                    switch (A.size) {
                        case 0:
                            0 === A.shape ? i = s = Math.min(Math.abs(e), Math.abs(e - r), Math.abs(t), Math.abs(t - n)) : 1 === A.shape && (i = Math.min(Math.abs(e), Math.abs(e - r)), s = Math.min(Math.abs(t), Math.abs(t - n)));
                            break;
                        case 2:
                            if (0 === A.shape) i = s = Math.min(mr(e, t), mr(e, t - n), mr(e - r, t), mr(e - r, t - n)); else if (1 === A.shape) {
                                var o = Math.min(Math.abs(t), Math.abs(t - n)) / Math.min(Math.abs(e), Math.abs(e - r)),
                                    a = Qr(r, n, e, t, !0), c = a[0], l = a[1];
                                i = mr(c - e, (l - t) / o), s = o * i
                            }
                            break;
                        case 1:
                            0 === A.shape ? i = s = Math.max(Math.abs(e), Math.abs(e - r), Math.abs(t), Math.abs(t - n)) : 1 === A.shape && (i = Math.max(Math.abs(e), Math.abs(e - r)), s = Math.max(Math.abs(t), Math.abs(t - n)));
                            break;
                        case 3:
                            if (0 === A.shape) i = s = Math.max(mr(e, t), mr(e, t - n), mr(e - r, t), mr(e - r, t - n)); else if (1 === A.shape) {
                                o = Math.max(Math.abs(t), Math.abs(t - n)) / Math.max(Math.abs(e), Math.abs(e - r));
                                var u = Qr(r, n, e, t, !1);
                                c = u[0], l = u[1];
                                i = mr(c - e, (l - t) / o), s = o * i
                            }
                            break
                    }
                    return Array.isArray(A.size) && (i = Wt(A.size[0], r), s = 2 === A.size.length ? Wt(A.size[1], n) : i), [i, s]
                }, Ur = function (A, e) {
                    var t = tr(180), r = [];
                    return Nt(e).forEach((function (e, n) {
                        if (0 === n) {
                            var i = e[0];
                            if (20 === i.type && "to" === i.value) return void (t = er(e));
                            if (Ar(i)) return void (t = $t.parse(A, i))
                        }
                        var s = pr(A, e);
                        r.push(s)
                    })), { angle: t, stops: r, type: 1 }
                }, vr = function (A, e) {
                    var t = tr(180), r = [];
                    return Nt(e).forEach((function (e, n) {
                        if (0 === n) {
                            var i = e[0];
                            if (20 === i.type && -1 !== ["top", "left", "right", "bottom"].indexOf(i.value)) return void (t = er(e));
                            if (Ar(i)) return void (t = ($t.parse(A, i) + tr(270)) % tr(360))
                        }
                        var s = pr(A, e);
                        r.push(s)
                    })), { angle: t, stops: r, type: 1 }
                }, Fr = function (A, e) {
                    var t = tr(180), r = [], n = 1, i = 0, s = 3, o = [];
                    return Nt(e).forEach((function (e, t) {
                        var i = e[0];
                        if (0 === t) {
                            if (Lt(i) && "linear" === i.value) return void (n = 1);
                            if (Lt(i) && "radial" === i.value) return void (n = 2)
                        }
                        if (18 === i.type) if ("from" === i.name) {
                            var s = rr.parse(A, i.values[0]);
                            r.push({ stop: Gt, color: s })
                        } else if ("to" === i.name) {
                            s = rr.parse(A, i.values[0]);
                            r.push({ stop: jt, color: s })
                        } else if ("color-stop" === i.name) {
                            var o = i.values.filter(Pt);
                            if (2 === o.length) {
                                s = rr.parse(A, o[1]);
                                var a = o[0];
                                Dt(a) && r.push({ stop: { type: 16, number: 100 * a.number, flags: a.flags }, color: s })
                            }
                        }
                    })), 1 === n ? { angle: (t + tr(180)) % tr(360), stops: r, type: n } : {
                        size: s,
                        shape: i,
                        stops: r,
                        position: o,
                        type: n
                    }
                }, Ir = "closest-side", Er = "farthest-side", br = "closest-corner", Hr = "farthest-corner", Tr = "circle",
                xr = "ellipse", Sr = "cover", Dr = "contain", Lr = function (A, e) {
                    var t = 0, r = 3, n = [], i = [];
                    return Nt(e).forEach((function (e, s) {
                        var o = !0;
                        if (0 === s) {
                            var a = !1;
                            o = e.reduce((function (A, e) {
                                if (a) if (Lt(e)) switch (e.value) {
                                    case "center":
                                        return i.push(Jt), A;
                                    case "top":
                                    case "left":
                                        return i.push(Gt), A;
                                    case "right":
                                    case "bottom":
                                        return i.push(jt), A
                                } else (_t(e) || Mt(e)) && i.push(e); else if (Lt(e)) switch (e.value) {
                                    case Tr:
                                        return t = 0, !1;
                                    case xr:
                                        return t = 1, !1;
                                    case "at":
                                        return a = !0, !1;
                                    case Ir:
                                        return r = 0, !1;
                                    case Sr:
                                    case Er:
                                        return r = 1, !1;
                                    case Dr:
                                    case br:
                                        return r = 2, !1;
                                    case Hr:
                                        return r = 3, !1
                                } else if (Mt(e) || _t(e)) return Array.isArray(r) || (r = []), r.push(e), !1;
                                return A
                            }), o)
                        }
                        if (o) {
                            var c = pr(A, e);
                            n.push(c)
                        }
                    })), { size: r, shape: t, stops: n, position: i, type: 2 }
                }, Kr = function (A, e) {
                    var t = 0, r = 3, n = [], i = [];
                    return Nt(e).forEach((function (e, s) {
                        var o = !0;
                        if (0 === s ? o = e.reduce((function (A, e) {
                            if (Lt(e)) switch (e.value) {
                                case "center":
                                    return i.push(Jt), !1;
                                case "top":
                                case "left":
                                    return i.push(Gt), !1;
                                case "right":
                                case "bottom":
                                    return i.push(jt), !1
                            } else if (_t(e) || Mt(e)) return i.push(e), !1;
                            return A
                        }), o) : 1 === s && (o = e.reduce((function (A, e) {
                            if (Lt(e)) switch (e.value) {
                                case Tr:
                                    return t = 0, !1;
                                case xr:
                                    return t = 1, !1;
                                case Dr:
                                case Ir:
                                    return r = 0, !1;
                                case Er:
                                    return r = 1, !1;
                                case br:
                                    return r = 2, !1;
                                case Sr:
                                case Hr:
                                    return r = 3, !1
                            } else if (Mt(e) || _t(e)) return Array.isArray(r) || (r = []), r.push(e), !1;
                            return A
                        }), o)), o) {
                            var a = pr(A, e);
                            n.push(a)
                        }
                    })), { size: r, shape: t, stops: n, position: i, type: 2 }
                }, kr = function (A) {
                    return 1 === A.type
                }, Or = function (A) {
                    return 2 === A.type
                }, Pr = {
                    name: "image", parse: function (A, e) {
                        if (22 === e.type) {
                            var t = { url: e.value, type: 0 };
                            return A.cache.addImage(e.value), t
                        }
                        if (18 === e.type) {
                            var r = Mr[e.name];
                            if ("undefined" === typeof r) throw new Error('Attempting to parse an unsupported image function "' + e.name + '"');
                            return r(A, e.values)
                        }
                        throw new Error("Unsupported image type " + e.type)
                    }
                };

            function Nr(A) {
                return !(20 === A.type && "none" === A.value) && (18 !== A.type || !!Mr[A.name])
            }

            var Rr, Mr = {
                "linear-gradient": Ur,
                "-moz-linear-gradient": vr,
                "-ms-linear-gradient": vr,
                "-o-linear-gradient": vr,
                "-webkit-linear-gradient": vr,
                "radial-gradient": Lr,
                "-moz-radial-gradient": Kr,
                "-ms-radial-gradient": Kr,
                "-o-radial-gradient": Kr,
                "-webkit-radial-gradient": Kr,
                "-webkit-gradient": Fr
            }, _r = {
                name: "background-image", initialValue: "none", type: 1, prefix: !1, parse: function (A, e) {
                    if (0 === e.length) return [];
                    var t = e[0];
                    return 20 === t.type && "none" === t.value ? [] : e.filter((function (A) {
                        return Pt(A) && Nr(A)
                    })).map((function (e) {
                        return Pr.parse(A, e)
                    }))
                }
            }, Vr = {
                name: "background-origin",
                initialValue: "border-box",
                prefix: !1,
                type: 1,
                parse: function (A, e) {
                    return e.map((function (A) {
                        if (Lt(A)) switch (A.value) {
                            case "padding-box":
                                return 1;
                            case "content-box":
                                return 2
                        }
                        return 0
                    }))
                }
            }, Gr = {
                name: "background-position", initialValue: "0% 0%", type: 1, prefix: !1, parse: function (A, e) {
                    return Nt(e).map((function (A) {
                        return A.filter(_t)
                    })).map(Vt)
                }
            }, Jr = {
                name: "background-repeat", initialValue: "repeat", prefix: !1, type: 1, parse: function (A, e) {
                    return Nt(e).map((function (A) {
                        return A.filter(Lt).map((function (A) {
                            return A.value
                        })).join(" ")
                    })).map(jr)
                }
            }, jr = function (A) {
                switch (A) {
                    case "no-repeat":
                        return 1;
                    case "repeat-x":
                    case "repeat no-repeat":
                        return 2;
                    case "repeat-y":
                    case "no-repeat repeat":
                        return 3;
                    case "repeat":
                    default:
                        return 0
                }
            };
            (function (A) {
                A["AUTO"] = "auto", A["CONTAIN"] = "contain", A["COVER"] = "cover"
            })(Rr || (Rr = {}));
            var Xr, Wr = {
                name: "background-size", initialValue: "0", prefix: !1, type: 1, parse: function (A, e) {
                    return Nt(e).map((function (A) {
                        return A.filter(Yr)
                    }))
                }
            }, Yr = function (A) {
                return Lt(A) || _t(A)
            }, Zr = function (A) {
                return {
                    name: "border-" + A + "-color",
                    initialValue: "transparent",
                    prefix: !1,
                    type: 3,
                    format: "color"
                }
            }, qr = Zr("top"), zr = Zr("right"), $r = Zr("bottom"), An = Zr("left"), en = function (A) {
                return {
                    name: "border-radius-" + A, initialValue: "0 0", prefix: !1, type: 1, parse: function (A, e) {
                        return Vt(e.filter(_t))
                    }
                }
            }, tn = en("top-left"), rn = en("top-right"), nn = en("bottom-right"), sn = en("bottom-left"),
                on = function (A) {
                    return {
                        name: "border-" + A + "-style",
                        initialValue: "solid",
                        prefix: !1,
                        type: 2,
                        parse: function (A, e) {
                            switch (e) {
                                case "none":
                                    return 0;
                                case "dashed":
                                    return 2;
                                case "dotted":
                                    return 3;
                                case "double":
                                    return 4
                            }
                            return 1
                        }
                    }
                }, an = on("top"), cn = on("right"), ln = on("bottom"), un = on("left"), dn = function (A) {
                    return {
                        name: "border-" + A + "-width", initialValue: "0", type: 0, prefix: !1, parse: function (A, e) {
                            return St(e) ? e.number : 0
                        }
                    }
                }, Bn = dn("top"), hn = dn("right"), gn = dn("bottom"), pn = dn("left"),
                fn = { name: "color", initialValue: "transparent", prefix: !1, type: 3, format: "color" }, wn = {
                    name: "direction", initialValue: "ltr", prefix: !1, type: 2, parse: function (A, e) {
                        switch (e) {
                            case "rtl":
                                return 1;
                            case "ltr":
                            default:
                                return 0
                        }
                    }
                }, Cn = {
                    name: "display", initialValue: "inline-block", prefix: !1, type: 1, parse: function (A, e) {
                        return e.filter(Lt).reduce((function (A, e) {
                            return A | mn(e.value)
                        }), 0)
                    }
                }, mn = function (A) {
                    switch (A) {
                        case "block":
                        case "-webkit-box":
                            return 2;
                        case "inline":
                            return 4;
                        case "run-in":
                            return 8;
                        case "flow":
                            return 16;
                        case "flow-root":
                            return 32;
                        case "table":
                            return 64;
                        case "flex":
                        case "-webkit-flex":
                            return 128;
                        case "grid":
                        case "-ms-grid":
                            return 256;
                        case "ruby":
                            return 512;
                        case "subgrid":
                            return 1024;
                        case "list-item":
                            return 2048;
                        case "table-row-group":
                            return 4096;
                        case "table-header-group":
                            return 8192;
                        case "table-footer-group":
                            return 16384;
                        case "table-row":
                            return 32768;
                        case "table-cell":
                            return 65536;
                        case "table-column-group":
                            return 131072;
                        case "table-column":
                            return 262144;
                        case "table-caption":
                            return 524288;
                        case "ruby-base":
                            return 1048576;
                        case "ruby-text":
                            return 2097152;
                        case "ruby-base-container":
                            return 4194304;
                        case "ruby-text-container":
                            return 8388608;
                        case "contents":
                            return 16777216;
                        case "inline-block":
                            return 33554432;
                        case "inline-list-item":
                            return 67108864;
                        case "inline-table":
                            return 134217728;
                        case "inline-flex":
                            return 268435456;
                        case "inline-grid":
                            return 536870912
                    }
                    return 0
                }, Qn = {
                    name: "float", initialValue: "none", prefix: !1, type: 2, parse: function (A, e) {
                        switch (e) {
                            case "left":
                                return 1;
                            case "right":
                                return 2;
                            case "inline-start":
                                return 3;
                            case "inline-end":
                                return 4
                        }
                        return 0
                    }
                }, yn = {
                    name: "letter-spacing", initialValue: "0", prefix: !1, type: 0, parse: function (A, e) {
                        return 20 === e.type && "normal" === e.value ? 0 : 17 === e.type || 15 === e.type ? e.number : 0
                    }
                };
            (function (A) {
                A["NORMAL"] = "normal", A["STRICT"] = "strict"
            })(Xr || (Xr = {}));
            var Un, vn = {
                name: "line-break", initialValue: "normal", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "strict":
                            return Xr.STRICT;
                        case "normal":
                        default:
                            return Xr.NORMAL
                    }
                }
            }, Fn = { name: "line-height", initialValue: "normal", prefix: !1, type: 4 }, In = function (A, e) {
                return Lt(A) && "normal" === A.value ? 1.2 * e : 17 === A.type ? e * A.number : _t(A) ? Wt(A, e) : e
            }, En = {
                name: "list-style-image", initialValue: "none", type: 0, prefix: !1, parse: function (A, e) {
                    return 20 === e.type && "none" === e.value ? null : Pr.parse(A, e)
                }
            }, bn = {
                name: "list-style-position", initialValue: "outside", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "inside":
                            return 0;
                        case "outside":
                        default:
                            return 1
                    }
                }
            }, Hn = {
                name: "list-style-type", initialValue: "none", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "disc":
                            return 0;
                        case "circle":
                            return 1;
                        case "square":
                            return 2;
                        case "decimal":
                            return 3;
                        case "cjk-decimal":
                            return 4;
                        case "decimal-leading-zero":
                            return 5;
                        case "lower-roman":
                            return 6;
                        case "upper-roman":
                            return 7;
                        case "lower-greek":
                            return 8;
                        case "lower-alpha":
                            return 9;
                        case "upper-alpha":
                            return 10;
                        case "arabic-indic":
                            return 11;
                        case "armenian":
                            return 12;
                        case "bengali":
                            return 13;
                        case "cambodian":
                            return 14;
                        case "cjk-earthly-branch":
                            return 15;
                        case "cjk-heavenly-stem":
                            return 16;
                        case "cjk-ideographic":
                            return 17;
                        case "devanagari":
                            return 18;
                        case "ethiopic-numeric":
                            return 19;
                        case "georgian":
                            return 20;
                        case "gujarati":
                            return 21;
                        case "gurmukhi":
                            return 22;
                        case "hebrew":
                            return 22;
                        case "hiragana":
                            return 23;
                        case "hiragana-iroha":
                            return 24;
                        case "japanese-formal":
                            return 25;
                        case "japanese-informal":
                            return 26;
                        case "kannada":
                            return 27;
                        case "katakana":
                            return 28;
                        case "katakana-iroha":
                            return 29;
                        case "khmer":
                            return 30;
                        case "korean-hangul-formal":
                            return 31;
                        case "korean-hanja-formal":
                            return 32;
                        case "korean-hanja-informal":
                            return 33;
                        case "lao":
                            return 34;
                        case "lower-armenian":
                            return 35;
                        case "malayalam":
                            return 36;
                        case "mongolian":
                            return 37;
                        case "myanmar":
                            return 38;
                        case "oriya":
                            return 39;
                        case "persian":
                            return 40;
                        case "simp-chinese-formal":
                            return 41;
                        case "simp-chinese-informal":
                            return 42;
                        case "tamil":
                            return 43;
                        case "telugu":
                            return 44;
                        case "thai":
                            return 45;
                        case "tibetan":
                            return 46;
                        case "trad-chinese-formal":
                            return 47;
                        case "trad-chinese-informal":
                            return 48;
                        case "upper-armenian":
                            return 49;
                        case "disclosure-open":
                            return 50;
                        case "disclosure-closed":
                            return 51;
                        case "none":
                        default:
                            return -1
                    }
                }
            }, Tn = function (A) {
                return { name: "margin-" + A, initialValue: "0", prefix: !1, type: 4 }
            }, xn = Tn("top"), Sn = Tn("right"), Dn = Tn("bottom"), Ln = Tn("left"), Kn = {
                name: "overflow", initialValue: "visible", prefix: !1, type: 1, parse: function (A, e) {
                    return e.filter(Lt).map((function (A) {
                        switch (A.value) {
                            case "hidden":
                                return 1;
                            case "scroll":
                                return 2;
                            case "clip":
                                return 3;
                            case "auto":
                                return 4;
                            case "visible":
                            default:
                                return 0
                        }
                    }))
                }
            }, kn = {
                name: "overflow-wrap", initialValue: "normal", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "break-word":
                            return "break-word";
                        case "normal":
                        default:
                            return "normal"
                    }
                }
            }, On = function (A) {
                return { name: "padding-" + A, initialValue: "0", prefix: !1, type: 3, format: "length-percentage" }
            }, Pn = On("top"), Nn = On("right"), Rn = On("bottom"), Mn = On("left"), _n = {
                name: "text-align", initialValue: "left", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "right":
                            return 2;
                        case "center":
                        case "justify":
                            return 1;
                        case "left":
                        default:
                            return 0
                    }
                }
            }, Vn = {
                name: "position", initialValue: "static", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "relative":
                            return 1;
                        case "absolute":
                            return 2;
                        case "fixed":
                            return 3;
                        case "sticky":
                            return 4
                    }
                    return 0
                }
            }, Gn = {
                name: "text-shadow", initialValue: "none", type: 1, prefix: !1, parse: function (A, e) {
                    return 1 === e.length && kt(e[0], "none") ? [] : Nt(e).map((function (e) {
                        for (var t = {
                            color: Br.TRANSPARENT,
                            offsetX: Gt,
                            offsetY: Gt,
                            blur: Gt
                        }, r = 0, n = 0; n < e.length; n++) {
                            var i = e[n];
                            Mt(i) ? (0 === r ? t.offsetX = i : 1 === r ? t.offsetY = i : t.blur = i, r++) : t.color = rr.parse(A, i)
                        }
                        return t
                    }))
                }
            }, Jn = {
                name: "text-transform", initialValue: "none", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "uppercase":
                            return 2;
                        case "lowercase":
                            return 1;
                        case "capitalize":
                            return 3
                    }
                    return 0
                }
            }, jn = {
                name: "transform", initialValue: "none", prefix: !0, type: 0, parse: function (A, e) {
                    if (20 === e.type && "none" === e.value) return null;
                    if (18 === e.type) {
                        var t = Yn[e.name];
                        if ("undefined" === typeof t) throw new Error('Attempting to parse an unsupported transform function "' + e.name + '"');
                        return t(e.values)
                    }
                    return null
                }
            }, Xn = function (A) {
                var e = A.filter((function (A) {
                    return 17 === A.type
                })).map((function (A) {
                    return A.number
                }));
                return 6 === e.length ? e : null
            }, Wn = function (A) {
                var e = A.filter((function (A) {
                    return 17 === A.type
                })).map((function (A) {
                    return A.number
                })), t = e[0], r = e[1];
                e[2], e[3];
                var n = e[4], i = e[5];
                e[6], e[7], e[8], e[9], e[10], e[11];
                var s = e[12], o = e[13];
                return e[14], e[15], 16 === e.length ? [t, r, n, i, s, o] : null
            }, Yn = { matrix: Xn, matrix3d: Wn }, Zn = { type: 16, number: 50, flags: XA }, qn = [Zn, Zn], zn = {
                name: "transform-origin", initialValue: "50% 50%", prefix: !0, type: 1, parse: function (A, e) {
                    var t = e.filter(_t);
                    return 2 !== t.length ? qn : [t[0], t[1]]
                }
            }, $n = {
                name: "visible", initialValue: "none", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "hidden":
                            return 1;
                        case "collapse":
                            return 2;
                        case "visible":
                        default:
                            return 0
                    }
                }
            };
            (function (A) {
                A["NORMAL"] = "normal", A["BREAK_ALL"] = "break-all", A["KEEP_ALL"] = "keep-all"
            })(Un || (Un = {}));
            for (var Ai = {
                name: "word-break", initialValue: "normal", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "break-all":
                            return Un.BREAK_ALL;
                        case "keep-all":
                            return Un.KEEP_ALL;
                        case "normal":
                        default:
                            return Un.NORMAL
                    }
                }
            }, ei = {
                name: "z-index", initialValue: "auto", prefix: !1, type: 0, parse: function (A, e) {
                    if (20 === e.type) return { auto: !0, order: 0 };
                    if (Dt(e)) return { auto: !1, order: e.number };
                    throw new Error("Invalid z-index number parsed")
                }
            }, ti = {
                name: "time", parse: function (A, e) {
                    if (15 === e.type) switch (e.unit.toLowerCase()) {
                        case "s":
                            return 1e3 * e.number;
                        case "ms":
                            return e.number
                    }
                    throw new Error("Unsupported time type")
                }
            }, ri = {
                name: "opacity", initialValue: "1", type: 0, prefix: !1, parse: function (A, e) {
                    return Dt(e) ? e.number : 1
                }
            }, ni = {
                name: "text-decoration-color",
                initialValue: "transparent",
                prefix: !1,
                type: 3,
                format: "color"
            }, ii = {
                name: "text-decoration-line", initialValue: "none", prefix: !1, type: 1, parse: function (A, e) {
                    return e.filter(Lt).map((function (A) {
                        switch (A.value) {
                            case "underline":
                                return 1;
                            case "overline":
                                return 2;
                            case "line-through":
                                return 3;
                            case "none":
                                return 4
                        }
                        return 0
                    })).filter((function (A) {
                        return 0 !== A
                    }))
                }
            }, si = {
                name: "font-family", initialValue: "", prefix: !1, type: 1, parse: function (A, e) {
                    var t = [], r = [];
                    return e.forEach((function (A) {
                        switch (A.type) {
                            case 20:
                            case 0:
                                t.push(A.value);
                                break;
                            case 17:
                                t.push(A.number.toString());
                                break;
                            case 4:
                                r.push(t.join(" ")), t.length = 0;
                                break
                        }
                    })), t.length && r.push(t.join(" ")), r.map((function (A) {
                        return -1 === A.indexOf(" ") ? A : "'" + A + "'"
                    }))
                }
            }, oi = {
                name: "font-size",
                initialValue: "0",
                prefix: !1,
                type: 3,
                format: "length"
            }, ai = {
                name: "font-weight", initialValue: "normal", type: 0, prefix: !1, parse: function (A, e) {
                    if (Dt(e)) return e.number;
                    if (Lt(e)) switch (e.value) {
                        case "bold":
                            return 700;
                        case "normal":
                        default:
                            return 400
                    }
                    return 400
                }
            }, ci = {
                name: "font-variant", initialValue: "none", type: 1, prefix: !1, parse: function (A, e) {
                    return e.filter(Lt).map((function (A) {
                        return A.value
                    }))
                }
            }, li = {
                name: "font-style", initialValue: "normal", prefix: !1, type: 2, parse: function (A, e) {
                    switch (e) {
                        case "oblique":
                            return "oblique";
                        case "italic":
                            return "italic";
                        case "normal":
                        default:
                            return "normal"
                    }
                }
            }, ui = function (A, e) {
                return 0 !== (A & e)
            }, di = {
                name: "content", initialValue: "none", type: 1, prefix: !1, parse: function (A, e) {
                    if (0 === e.length) return [];
                    var t = e[0];
                    return 20 === t.type && "none" === t.value ? [] : e
                }
            }, Bi = {
                name: "counter-increment", initialValue: "none", prefix: !0, type: 1, parse: function (A, e) {
                    if (0 === e.length) return null;
                    var t = e[0];
                    if (20 === t.type && "none" === t.value) return null;
                    for (var r = [], n = e.filter(Ot), i = 0; i < n.length; i++) {
                        var s = n[i], o = n[i + 1];
                        if (20 === s.type) {
                            var a = o && Dt(o) ? o.number : 1;
                            r.push({ counter: s.value, increment: a })
                        }
                    }
                    return r
                }
            }, hi = {
                name: "counter-reset", initialValue: "none", prefix: !0, type: 1, parse: function (A, e) {
                    if (0 === e.length) return [];
                    for (var t = [], r = e.filter(Ot), n = 0; n < r.length; n++) {
                        var i = r[n], s = r[n + 1];
                        if (Lt(i) && "none" !== i.value) {
                            var o = s && Dt(s) ? s.number : 0;
                            t.push({ counter: i.value, reset: o })
                        }
                    }
                    return t
                }
            }, gi = {
                name: "duration", initialValue: "0s", prefix: !1, type: 1, parse: function (A, e) {
                    return e.filter(St).map((function (e) {
                        return ti.parse(A, e)
                    }))
                }
            }, pi = {
                name: "quotes", initialValue: "none", prefix: !0, type: 1, parse: function (A, e) {
                    if (0 === e.length) return null;
                    var t = e[0];
                    if (20 === t.type && "none" === t.value) return null;
                    var r = [], n = e.filter(Kt);
                    if (n.length % 2 !== 0) return null;
                    for (var i = 0; i < n.length; i += 2) {
                        var s = n[i].value, o = n[i + 1].value;
                        r.push({ open: s, close: o })
                    }
                    return r
                }
            }, fi = function (A, e, t) {
                if (!A) return "";
                var r = A[Math.min(e, A.length - 1)];
                return r ? t ? r.open : r.close : ""
            }, wi = {
                name: "box-shadow", initialValue: "none", type: 1, prefix: !1, parse: function (A, e) {
                    return 1 === e.length && kt(e[0], "none") ? [] : Nt(e).map((function (e) {
                        for (var t = {
                            color: 255,
                            offsetX: Gt,
                            offsetY: Gt,
                            blur: Gt,
                            spread: Gt,
                            inset: !1
                        }, r = 0, n = 0; n < e.length; n++) {
                            var i = e[n];
                            kt(i, "inset") ? t.inset = !0 : Mt(i) ? (0 === r ? t.offsetX = i : 1 === r ? t.offsetY = i : 2 === r ? t.blur = i : t.spread = i, r++) : t.color = rr.parse(A, i)
                        }
                        return t
                    }))
                }
            }, Ci = {
                name: "paint-order", initialValue: "normal", prefix: !1, type: 1, parse: function (A, e) {
                    var t = [0, 1, 2], r = [];
                    return e.filter(Lt).forEach((function (A) {
                        switch (A.value) {
                            case "stroke":
                                r.push(1);
                                break;
                            case "fill":
                                r.push(0);
                                break;
                            case "markers":
                                r.push(2);
                                break
                        }
                    })), t.forEach((function (A) {
                        -1 === r.indexOf(A) && r.push(A)
                    })), r
                }
            }, mi = {
                name: "-webkit-text-stroke-color",
                initialValue: "currentcolor",
                prefix: !1,
                type: 3,
                format: "color"
            }, Qi = {
                name: "-webkit-text-stroke-width", initialValue: "0", type: 0, prefix: !1, parse: function (A, e) {
                    return St(e) ? e.number : 0
                }
            }, yi = function () {
                function A(A, e) {
                    var t, r;
                    this.animationDuration = Fi(A, gi, e.animationDuration), this.backgroundClip = Fi(A, hr, e.backgroundClip), this.backgroundColor = Fi(A, gr, e.backgroundColor), this.backgroundImage = Fi(A, _r, e.backgroundImage), this.backgroundOrigin = Fi(A, Vr, e.backgroundOrigin), this.backgroundPosition = Fi(A, Gr, e.backgroundPosition), this.backgroundRepeat = Fi(A, Jr, e.backgroundRepeat), this.backgroundSize = Fi(A, Wr, e.backgroundSize), this.borderTopColor = Fi(A, qr, e.borderTopColor), this.borderRightColor = Fi(A, zr, e.borderRightColor), this.borderBottomColor = Fi(A, $r, e.borderBottomColor), this.borderLeftColor = Fi(A, An, e.borderLeftColor), this.borderTopLeftRadius = Fi(A, tn, e.borderTopLeftRadius), this.borderTopRightRadius = Fi(A, rn, e.borderTopRightRadius), this.borderBottomRightRadius = Fi(A, nn, e.borderBottomRightRadius), this.borderBottomLeftRadius = Fi(A, sn, e.borderBottomLeftRadius), this.borderTopStyle = Fi(A, an, e.borderTopStyle), this.borderRightStyle = Fi(A, cn, e.borderRightStyle), this.borderBottomStyle = Fi(A, ln, e.borderBottomStyle), this.borderLeftStyle = Fi(A, un, e.borderLeftStyle), this.borderTopWidth = Fi(A, Bn, e.borderTopWidth), this.borderRightWidth = Fi(A, hn, e.borderRightWidth), this.borderBottomWidth = Fi(A, gn, e.borderBottomWidth), this.borderLeftWidth = Fi(A, pn, e.borderLeftWidth), this.boxShadow = Fi(A, wi, e.boxShadow), this.color = Fi(A, fn, e.color), this.direction = Fi(A, wn, e.direction), this.display = Fi(A, Cn, e.display), this.float = Fi(A, Qn, e.cssFloat), this.fontFamily = Fi(A, si, e.fontFamily), this.fontSize = Fi(A, oi, e.fontSize), this.fontStyle = Fi(A, li, e.fontStyle), this.fontVariant = Fi(A, ci, e.fontVariant), this.fontWeight = Fi(A, ai, e.fontWeight), this.letterSpacing = Fi(A, yn, e.letterSpacing), this.lineBreak = Fi(A, vn, e.lineBreak), this.lineHeight = Fi(A, Fn, e.lineHeight), this.listStyleImage = Fi(A, En, e.listStyleImage), this.listStylePosition = Fi(A, bn, e.listStylePosition), this.listStyleType = Fi(A, Hn, e.listStyleType), this.marginTop = Fi(A, xn, e.marginTop), this.marginRight = Fi(A, Sn, e.marginRight), this.marginBottom = Fi(A, Dn, e.marginBottom), this.marginLeft = Fi(A, Ln, e.marginLeft), this.opacity = Fi(A, ri, e.opacity);
                    var n = Fi(A, Kn, e.overflow);
                    this.overflowX = n[0], this.overflowY = n[n.length > 1 ? 1 : 0], this.overflowWrap = Fi(A, kn, e.overflowWrap), this.paddingTop = Fi(A, Pn, e.paddingTop), this.paddingRight = Fi(A, Nn, e.paddingRight), this.paddingBottom = Fi(A, Rn, e.paddingBottom), this.paddingLeft = Fi(A, Mn, e.paddingLeft), this.paintOrder = Fi(A, Ci, e.paintOrder), this.position = Fi(A, Vn, e.position), this.textAlign = Fi(A, _n, e.textAlign), this.textDecorationColor = Fi(A, ni, null !== (t = e.textDecorationColor) && void 0 !== t ? t : e.color), this.textDecorationLine = Fi(A, ii, null !== (r = e.textDecorationLine) && void 0 !== r ? r : e.textDecoration), this.textShadow = Fi(A, Gn, e.textShadow), this.textTransform = Fi(A, Jn, e.textTransform), this.transform = Fi(A, jn, e.transform), this.transformOrigin = Fi(A, zn, e.transformOrigin), this.visibility = Fi(A, $n, e.visibility), this.webkitTextStrokeColor = Fi(A, mi, e.webkitTextStrokeColor), this.webkitTextStrokeWidth = Fi(A, Qi, e.webkitTextStrokeWidth), this.wordBreak = Fi(A, Ai, e.wordBreak), this.zIndex = Fi(A, ei, e.zIndex)
                }

                return A.prototype.isVisible = function () {
                    return this.display > 0 && this.opacity > 0 && 0 === this.visibility
                }, A.prototype.isTransparent = function () {
                    return nr(this.backgroundColor)
                }, A.prototype.isTransformed = function () {
                    return null !== this.transform
                }, A.prototype.isPositioned = function () {
                    return 0 !== this.position
                }, A.prototype.isPositionedWithZIndex = function () {
                    return this.isPositioned() && !this.zIndex.auto
                }, A.prototype.isFloating = function () {
                    return 0 !== this.float
                }, A.prototype.isInlineLevel = function () {
                    return ui(this.display, 4) || ui(this.display, 33554432) || ui(this.display, 268435456) || ui(this.display, 536870912) || ui(this.display, 67108864) || ui(this.display, 134217728)
                }, A
            }(), Ui = function () {
                function A(A, e) {
                    this.content = Fi(A, di, e.content), this.quotes = Fi(A, pi, e.quotes)
                }

                return A
            }(), vi = function () {
                function A(A, e) {
                    this.counterIncrement = Fi(A, Bi, e.counterIncrement), this.counterReset = Fi(A, hi, e.counterReset)
                }

                return A
            }(), Fi = function (A, e, t) {
                var r = new Tt, n = null !== t && "undefined" !== typeof t ? t.toString() : e.initialValue;
                r.write(n);
                var i = new xt(r.read());
                switch (e.type) {
                    case 2:
                        var s = i.parseComponentValue();
                        return e.parse(A, Lt(s) ? s.value : e.initialValue);
                    case 0:
                        return e.parse(A, i.parseComponentValue());
                    case 1:
                        return e.parse(A, i.parseComponentValues());
                    case 4:
                        return i.parseComponentValue();
                    case 3:
                        switch (e.format) {
                            case "angle":
                                return $t.parse(A, i.parseComponentValue());
                            case "color":
                                return rr.parse(A, i.parseComponentValue());
                            case "image":
                                return Pr.parse(A, i.parseComponentValue());
                            case "length":
                                var o = i.parseComponentValue();
                                return Mt(o) ? o : Gt;
                            case "length-percentage":
                                var a = i.parseComponentValue();
                                return _t(a) ? a : Gt;
                            case "time":
                                return ti.parse(A, i.parseComponentValue())
                        }
                        break
                }
            }, Ii = "data-html2canvas-debug", Ei = function (A) {
                var e = A.getAttribute(Ii);
                switch (e) {
                    case "all":
                        return 1;
                    case "clone":
                        return 2;
                    case "parse":
                        return 3;
                    case "render":
                        return 4;
                    default:
                        return 0
                }
            }, bi = function (A, e) {
                var t = Ei(A);
                return 1 === t || e === t
            }, Hi = function () {
                function A(A, e) {
                    this.context = A, this.textNodes = [], this.elements = [], this.flags = 0, bi(e, 3), this.styles = new yi(A, window.getComputedStyle(e, null)), Uo(e) && (this.styles.animationDuration.some((function (A) {
                        return A > 0
                    })) && (e.style.animationDuration = "0s"), null !== this.styles.transform && (e.style.transform = "none")), this.bounds = o(this.context, e), bi(e, 4) && (this.flags |= 16)
                }

                return A
            }(), Ti = "AAAAAAAAAAAAEA4AGBkAAFAaAAACAAAAAAAIABAAGAAwADgACAAQAAgAEAAIABAACAAQAAgAEAAIABAACAAQAAgAEAAIABAAQABIAEQATAAIABAACAAQAAgAEAAIABAAVABcAAgAEAAIABAACAAQAGAAaABwAHgAgACIAI4AlgAIABAAmwCjAKgAsAC2AL4AvQDFAMoA0gBPAVYBWgEIAAgACACMANoAYgFkAWwBdAF8AX0BhQGNAZUBlgGeAaMBlQGWAasBswF8AbsBwwF0AcsBYwHTAQgA2wG/AOMBdAF8AekB8QF0AfkB+wHiAHQBfAEIAAMC5gQIAAsCEgIIAAgAFgIeAggAIgIpAggAMQI5AkACygEIAAgASAJQAlgCYAIIAAgACAAKBQoFCgUTBRMFGQUrBSsFCAAIAAgACAAIAAgACAAIAAgACABdAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABoAmgCrwGvAQgAbgJ2AggAHgEIAAgACADnAXsCCAAIAAgAgwIIAAgACAAIAAgACACKAggAkQKZAggAPADJAAgAoQKkAqwCsgK6AsICCADJAggA0AIIAAgACAAIANYC3gIIAAgACAAIAAgACABAAOYCCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAkASoB+QIEAAgACAA8AEMCCABCBQgACABJBVAFCAAIAAgACAAIAAgACAAIAAgACABTBVoFCAAIAFoFCABfBWUFCAAIAAgACAAIAAgAbQUIAAgACAAIAAgACABzBXsFfQWFBYoFigWKBZEFigWKBYoFmAWfBaYFrgWxBbkFCAAIAAgACAAIAAgACAAIAAgACAAIAMEFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAMgFCADQBQgACAAIAAgACAAIAAgACAAIAAgACAAIAO4CCAAIAAgAiQAIAAgACABAAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAD0AggACAD8AggACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIANYFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAMDvwAIAAgAJAIIAAgACAAIAAgACAAIAAgACwMTAwgACAB9BOsEGwMjAwgAKwMyAwsFYgE3A/MEPwMIAEUDTQNRAwgAWQOsAGEDCAAIAAgACAAIAAgACABpAzQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFOgU0BTUFNgU3BTgFOQU6BTQFNQU2BTcFOAU5BToFNAU1BTYFNwU4BTkFIQUoBSwFCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABtAwgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABMAEwACAAIAAgACAAIABgACAAIAAgACAC/AAgACAAyAQgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACAAIAAwAAgACAAIAAgACAAIAAgACAAIAAAARABIAAgACAAIABQASAAIAAgAIABwAEAAjgCIABsAqAC2AL0AigDQAtwC+IJIQqVAZUBWQqVAZUBlQGVAZUBlQGrC5UBlQGVAZUBlQGVAZUBlQGVAXsKlQGVAbAK6wsrDGUMpQzlDJUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAZUBlQGVAfAKAAuZA64AtwCJALoC6ADwAAgAuACgA/oEpgO6AqsD+AAIAAgAswMIAAgACAAIAIkAuwP5AfsBwwPLAwgACAAIAAgACADRA9kDCAAIAOED6QMIAAgACAAIAAgACADuA/YDCAAIAP4DyQAIAAgABgQIAAgAXQAOBAgACAAIAAgACAAIABMECAAIAAgACAAIAAgACAD8AAQBCAAIAAgAGgQiBCoECAExBAgAEAEIAAgACAAIAAgACAAIAAgACAAIAAgACAA4BAgACABABEYECAAIAAgATAQYAQgAVAQIAAgACAAIAAgACAAIAAgACAAIAFoECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAOQEIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAB+BAcACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAEABhgSMBAgACAAIAAgAlAQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAwAEAAQABAADAAMAAwADAAQABAAEAAQABAAEAAQABHATAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAdQMIAAgACAAIAAgACAAIAMkACAAIAAgAfQMIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACACFA4kDCAAIAAgACAAIAOcBCAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAIcDCAAIAAgACAAIAAgACAAIAAgACAAIAJEDCAAIAAgACADFAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABgBAgAZgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAbAQCBXIECAAIAHkECAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACABAAJwEQACjBKoEsgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAC6BMIECAAIAAgACAAIAAgACABmBAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAxwQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAGYECAAIAAgAzgQIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBd0FXwUIAOIF6gXxBYoF3gT5BQAGCAaKBYoFigWKBYoFigWKBYoFigWKBYoFigXWBIoFigWKBYoFigWKBYoFigWKBYsFEAaKBYoFigWKBYoFigWKBRQGCACKBYoFigWKBQgACAAIANEECAAIABgGigUgBggAJgYIAC4GMwaKBYoF0wQ3Bj4GigWKBYoFigWKBYoFigWKBYoFigWKBYoFigUIAAgACAAIAAgACAAIAAgAigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWKBYoFigWLBf///////wQABAAEAAQABAAEAAQABAAEAAQAAwAEAAQAAgAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAQADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUAAAAFAAUAAAAFAAUAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUAAQAAAAUABQAFAAUABQAFAAAAAAAFAAUAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAFAAUAAQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAAABwAHAAcAAAAHAAcABwAFAAEAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAcABwAFAAUAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAAAAQABAAAAAAAAAAAAAAAFAAUABQAFAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAHAAcAAAAHAAcAAAAAAAUABQAHAAUAAQAHAAEABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwABAAUABQAFAAUAAAAAAAAAAAAAAAEAAQABAAEAAQABAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABQANAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABAAEAAQABAAEAAQABAAEAAQABAAEAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAABQAHAAUABQAFAAAAAAAAAAcABQAFAAUABQAFAAQABAAEAAQABAAEAAQABAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAEAAQABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUAAAAFAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAUAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAcABwAFAAcABwAAAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUABwAHAAUABQAFAAUAAAAAAAcABwAAAAAABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAABQAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAAAAAAAAAAABQAFAAAAAAAFAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAFAAUABQAFAAUAAAAFAAUABwAAAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABwAFAAUABQAFAAAAAAAHAAcAAAAAAAcABwAFAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAAAAAAAAAHAAcABwAAAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAABQAHAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAUABQAFAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAHAAcABQAHAAcAAAAFAAcABwAAAAcABwAFAAUAAAAAAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAFAAcABwAFAAUABQAAAAUAAAAHAAcABwAHAAcABwAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAHAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAABwAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAUAAAAFAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABwAFAAUABQAFAAUAAAAFAAUAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABwAFAAUABQAFAAUABQAAAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABQAFAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABQAFAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAHAAUABQAFAAUABQAFAAUABwAHAAcABwAHAAcABwAHAAUABwAHAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABwAHAAcABwAFAAUABwAHAAcAAAAAAAAAAAAHAAcABQAHAAcABwAHAAcABwAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAcABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAUABQAFAAUABQAFAAUAAAAFAAAABQAAAAAABQAFAAUABQAFAAUABQAFAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAFAAUAAAAAAAUABQAFAAUABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABwAFAAcABwAHAAcABwAFAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAUABQAFAAUABwAHAAUABQAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABQAFAAcABwAHAAUABwAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAcABQAFAAUABQAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAAAAAABwAFAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAAAAAAAAAFAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAUABQAHAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAUABQAFAAUABQAHAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAcABwAFAAUABQAFAAcABwAFAAUABwAHAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAFAAcABwAFAAUABwAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAFAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAFAAUABQAAAAAABQAFAAAAAAAAAAAAAAAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAcABwAAAAAAAAAAAAAABwAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAcABwAFAAcABwAAAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAFAAUABQAAAAUABQAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABwAFAAUABQAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAUABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAHAAcABQAHAAUABQAAAAAAAAAAAAAAAAAFAAAABwAHAAcABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAHAAcABwAAAAAABwAHAAAAAAAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABwAHAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAFAAUABwAFAAcABwAFAAcABQAFAAcABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAHAAcABQAFAAUABQAAAAAABwAHAAcABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAHAAUABQAFAAUABQAFAAUABQAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABwAFAAcABwAFAAUABQAFAAUABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAcABwAFAAUABQAFAAcABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAUABQAFAAUABQAHAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAFAAUABQAFAAAAAAAFAAUABwAHAAcABwAFAAAAAAAAAAcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABwAHAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAcABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUAAAAHAAUABQAFAAUABQAFAAUABwAFAAUABwAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUAAAAAAAAABQAAAAUABQAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAHAAcABwAHAAcAAAAFAAUAAAAHAAcABQAHAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAAAAUABQAFAAAAAAAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAFAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAFAAUABQAAAAAABQAFAAUABQAFAAUABQAAAAUABQAAAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFAAUABQAFAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABQAFAAUABQAFAAUABQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAFAAUABQAFAAUADgAOAA4ADgAOAA4ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAA8ADwAPAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAcABwAHAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAgACAAIAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAMAAwADAAMAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkACQAJAAkAAAAAAAAAAAAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAKAAoACgAAAAAAAAAAAAsADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwACwAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAMAAwADAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAADgAOAA4AAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAAAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4AAAAOAAAAAAAAAAAAAAAAAA4AAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAAAAAAAAAAAA4AAAAOAAAAAAAAAAAADgAOAA4AAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAA4AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4AAAAAAA4ADgAOAA4ADgAOAA4ADgAOAAAADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4ADgAOAAAAAAAAAAAAAAAAAAAAAAAAAAAADgAOAA4ADgAOAA4AAAAAAAAAAAAAAAAAAAAAAA4ADgAOAA4ADgAOAA4ADgAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAOAA4ADgAOAA4ADgAAAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4ADgAOAA4AAAAAAAAAAAA=", xi = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", Si = "undefined" === typeof Uint8Array ? [] : new Uint8Array(256), Di = 0; Di < xi.length; Di++) Si[xi.charCodeAt(Di)] = Di;
            for (var Li = function (A) {
                var e, t, r, n, i, s = .75 * A.length, o = A.length, a = 0;
                "=" === A[A.length - 1] && (s--, "=" === A[A.length - 2] && s--);
                var c = "undefined" !== typeof ArrayBuffer && "undefined" !== typeof Uint8Array && "undefined" !== typeof Uint8Array.prototype.slice ? new ArrayBuffer(s) : new Array(s),
                    l = Array.isArray(c) ? c : new Uint8Array(c);
                for (e = 0; e < o; e += 4) t = Si[A.charCodeAt(e)], r = Si[A.charCodeAt(e + 1)], n = Si[A.charCodeAt(e + 2)], i = Si[A.charCodeAt(e + 3)], l[a++] = t << 2 | r >> 4, l[a++] = (15 & r) << 4 | n >> 2, l[a++] = (3 & n) << 6 | 63 & i;
                return c
            }, Ki = function (A) {
                for (var e = A.length, t = [], r = 0; r < e; r += 2) t.push(A[r + 1] << 8 | A[r]);
                return t
            }, ki = function (A) {
                for (var e = A.length, t = [], r = 0; r < e; r += 4) t.push(A[r + 3] << 24 | A[r + 2] << 16 | A[r + 1] << 8 | A[r]);
                return t
            }, Oi = 5, Pi = 11, Ni = 2, Ri = Pi - Oi, Mi = 65536 >> Oi, _i = 1 << Oi, Vi = _i - 1, Gi = 1024 >> Oi, Ji = Mi + Gi, ji = Ji, Xi = 32, Wi = ji + Xi, Yi = 65536 >> Pi, Zi = 1 << Ri, qi = Zi - 1, zi = function (A, e, t) {
                return A.slice ? A.slice(e, t) : new Uint16Array(Array.prototype.slice.call(A, e, t))
            }, $i = function (A, e, t) {
                return A.slice ? A.slice(e, t) : new Uint32Array(Array.prototype.slice.call(A, e, t))
            }, As = function (A, e) {
                var t = Li(A), r = Array.isArray(t) ? ki(t) : new Uint32Array(t),
                    n = Array.isArray(t) ? Ki(t) : new Uint16Array(t), i = 24, s = zi(n, i / 2, r[4] / 2),
                    o = 2 === r[5] ? zi(n, (i + r[4]) / 2) : $i(r, Math.ceil((i + r[4]) / 4));
                return new es(r[0], r[1], r[2], r[3], s, o)
            }, es = function () {
                function A(A, e, t, r, n, i) {
                    this.initialValue = A, this.errorValue = e, this.highStart = t, this.highValueIndex = r, this.index = n, this.data = i
                }

                return A.prototype.get = function (A) {
                    var e;
                    if (A >= 0) {
                        if (A < 55296 || A > 56319 && A <= 65535) return e = this.index[A >> Oi], e = (e << Ni) + (A & Vi), this.data[e];
                        if (A <= 65535) return e = this.index[Mi + (A - 55296 >> Oi)], e = (e << Ni) + (A & Vi), this.data[e];
                        if (A < this.highStart) return e = Wi - Yi + (A >> Pi), e = this.index[e], e += A >> Oi & qi, e = this.index[e], e = (e << Ni) + (A & Vi), this.data[e];
                        if (A <= 1114111) return this.data[this.highValueIndex]
                    }
                    return this.errorValue
                }, A
            }(), ts = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", rs = "undefined" === typeof Uint8Array ? [] : new Uint8Array(256), ns = 0; ns < ts.length; ns++) rs[ts.charCodeAt(ns)] = ns;
            var is, ss = 1, os = 2, as = 3, cs = 4, ls = 5, us = 7, ds = 8, Bs = 9, hs = 10, gs = 11, ps = 12, fs = 13,
                ws = 14, Cs = 15, ms = function (A) {
                    var e = [], t = 0, r = A.length;
                    while (t < r) {
                        var n = A.charCodeAt(t++);
                        if (n >= 55296 && n <= 56319 && t < r) {
                            var i = A.charCodeAt(t++);
                            56320 === (64512 & i) ? e.push(((1023 & n) << 10) + (1023 & i) + 65536) : (e.push(n), t--)
                        } else e.push(n)
                    }
                    return e
                }, Qs = function () {
                    for (var A = [], e = 0; e < arguments.length; e++) A[e] = arguments[e];
                    if (String.fromCodePoint) return String.fromCodePoint.apply(String, A);
                    var t = A.length;
                    if (!t) return "";
                    var r = [], n = -1, i = "";
                    while (++n < t) {
                        var s = A[n];
                        s <= 65535 ? r.push(s) : (s -= 65536, r.push(55296 + (s >> 10), s % 1024 + 56320)), (n + 1 === t || r.length > 16384) && (i += String.fromCharCode.apply(String, r), r.length = 0)
                    }
                    return i
                }, ys = As(Ti), Us = "×", vs = "÷", Fs = function (A) {
                    return ys.get(A)
                }, Is = function (A, e, t) {
                    var r = t - 2, n = e[r], i = e[t - 1], s = e[t];
                    if (i === os && s === as) return Us;
                    if (i === os || i === as || i === cs) return vs;
                    if (s === os || s === as || s === cs) return vs;
                    if (i === ds && -1 !== [ds, Bs, gs, ps].indexOf(s)) return Us;
                    if ((i === gs || i === Bs) && (s === Bs || s === hs)) return Us;
                    if ((i === ps || i === hs) && s === hs) return Us;
                    if (s === fs || s === ls) return Us;
                    if (s === us) return Us;
                    if (i === ss) return Us;
                    if (i === fs && s === ws) {
                        while (n === ls) n = e[--r];
                        if (n === ws) return Us
                    }
                    if (i === Cs && s === Cs) {
                        var o = 0;
                        while (n === Cs) o++, n = e[--r];
                        if (o % 2 === 0) return Us
                    }
                    return vs
                }, Es = function (A) {
                    var e = ms(A), t = e.length, r = 0, n = 0, i = e.map(Fs);
                    return {
                        next: function () {
                            if (r >= t) return { done: !0, value: null };
                            var A = Us;
                            while (r < t && (A = Is(e, i, ++r)) === Us);
                            if (A !== Us || r === t) {
                                var s = Qs.apply(null, e.slice(n, r));
                                return n = r, { value: s, done: !1 }
                            }
                            return { done: !0, value: null }
                        }
                    }
                }, bs = function (A) {
                    var e, t = Es(A), r = [];
                    while (!(e = t.next()).done) e.value && r.push(e.value.slice());
                    return r
                }, Hs = function (A) {
                    var e = 123;
                    if (A.createRange) {
                        var t = A.createRange();
                        if (t.getBoundingClientRect) {
                            var r = A.createElement("boundtest");
                            r.style.height = e + "px", r.style.display = "block", A.body.appendChild(r), t.selectNode(r);
                            var n = t.getBoundingClientRect(), i = Math.round(n.height);
                            if (A.body.removeChild(r), i === e) return !0
                        }
                    }
                    return !1
                }, Ts = function (A) {
                    var e = A.createElement("boundtest");
                    e.style.width = "50px", e.style.display = "block", e.style.fontSize = "12px", e.style.letterSpacing = "0px", e.style.wordSpacing = "0px", A.body.appendChild(e);
                    var t = A.createRange();
                    e.innerHTML = "function" === typeof "".repeat ? "&#128104;".repeat(10) : "";
                    var r = e.firstChild, n = c(r.data).map((function (A) {
                        return l(A)
                    })), i = 0, s = {}, o = n.every((function (A, e) {
                        t.setStart(r, i), t.setEnd(r, i + A.length);
                        var n = t.getBoundingClientRect();
                        i += A.length;
                        var o = n.x > s.x || n.y > s.y;
                        return s = n, 0 === e || o
                    }));
                    return A.body.removeChild(e), o
                }, xs = function () {
                    return "undefined" !== typeof (new Image).crossOrigin
                }, Ss = function () {
                    return "string" === typeof (new XMLHttpRequest).responseType
                }, Ds = function (A) {
                    var e = new Image, t = A.createElement("canvas"), r = t.getContext("2d");
                    if (!r) return !1;
                    e.src = "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg'></svg>";
                    try {
                        r.drawImage(e, 0, 0), t.toDataURL()
                    } catch (Ne) {
                        return !1
                    }
                    return !0
                }, Ls = function (A) {
                    return 0 === A[0] && 255 === A[1] && 0 === A[2] && 255 === A[3]
                }, Ks = function (A) {
                    var e = A.createElement("canvas"), t = 100;
                    e.width = t, e.height = t;
                    var r = e.getContext("2d");
                    if (!r) return Promise.reject(!1);
                    r.fillStyle = "rgb(0, 255, 0)", r.fillRect(0, 0, t, t);
                    var n = new Image, i = e.toDataURL();
                    n.src = i;
                    var s = ks(t, t, 0, 0, n);
                    return r.fillStyle = "red", r.fillRect(0, 0, t, t), Os(s).then((function (e) {
                        r.drawImage(e, 0, 0);
                        var n = r.getImageData(0, 0, t, t).data;
                        r.fillStyle = "red", r.fillRect(0, 0, t, t);
                        var s = A.createElement("div");
                        return s.style.backgroundImage = "url(" + i + ")", s.style.height = t + "px", Ls(n) ? Os(ks(t, t, 0, 0, s)) : Promise.reject(!1)
                    })).then((function (A) {
                        return r.drawImage(A, 0, 0), Ls(r.getImageData(0, 0, t, t).data)
                    })).catch((function () {
                        return !1
                    }))
                }, ks = function (A, e, t, r, n) {
                    var i = "http://www.w3.org/2000/svg", s = document.createElementNS(i, "svg"),
                        o = document.createElementNS(i, "foreignObject");
                    return s.setAttributeNS(null, "width", A.toString()), s.setAttributeNS(null, "height", e.toString()), o.setAttributeNS(null, "width", "100%"), o.setAttributeNS(null, "height", "100%"), o.setAttributeNS(null, "x", t.toString()), o.setAttributeNS(null, "y", r.toString()), o.setAttributeNS(null, "externalResourcesRequired", "true"), s.appendChild(o), o.appendChild(n), s
                }, Os = function (A) {
                    return new Promise((function (e, t) {
                        var r = new Image;
                        r.onload = function () {
                            return e(r)
                        }, r.onerror = t, r.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent((new XMLSerializer).serializeToString(A))
                    }))
                }, Ps = {
                    get SUPPORT_RANGE_BOUNDS() {
                        var A = Hs(document);
                        return Object.defineProperty(Ps, "SUPPORT_RANGE_BOUNDS", { value: A }), A
                    }, get SUPPORT_WORD_BREAKING() {
                        var A = Ps.SUPPORT_RANGE_BOUNDS && Ts(document);
                        return Object.defineProperty(Ps, "SUPPORT_WORD_BREAKING", { value: A }), A
                    }, get SUPPORT_SVG_DRAWING() {
                        var A = Ds(document);
                        return Object.defineProperty(Ps, "SUPPORT_SVG_DRAWING", { value: A }), A
                    }, get SUPPORT_FOREIGNOBJECT_DRAWING() {
                        var A = "function" === typeof Array.from && "function" === typeof window.fetch ? Ks(document) : Promise.resolve(!1);
                        return Object.defineProperty(Ps, "SUPPORT_FOREIGNOBJECT_DRAWING", { value: A }), A
                    }, get SUPPORT_CORS_IMAGES() {
                        var A = xs();
                        return Object.defineProperty(Ps, "SUPPORT_CORS_IMAGES", { value: A }), A
                    }, get SUPPORT_RESPONSE_TYPE() {
                        var A = Ss();
                        return Object.defineProperty(Ps, "SUPPORT_RESPONSE_TYPE", { value: A }), A
                    }, get SUPPORT_CORS_XHR() {
                        var A = "withCredentials" in new XMLHttpRequest;
                        return Object.defineProperty(Ps, "SUPPORT_CORS_XHR", { value: A }), A
                    }
                }, Ns = function () {
                    function A(A, e) {
                        this.text = A, this.bounds = e
                    }

                    return A
                }(), Rs = function (A, e, t, r) {
                    var n = Gs(e, t), i = [], o = 0;
                    return n.forEach((function (e) {
                        if (t.textDecorationLine.length || e.trim().length > 0) if (Ps.SUPPORT_RANGE_BOUNDS) Ps.SUPPORT_WORD_BREAKING ? i.push(new Ns(e, Vs(A, r, o, e.length))) : i.push(new Ns(e, s.fromDOMRectList(A, _s(r, o, e.length).getClientRects()))); else {
                            var n = r.splitText(e.length);
                            i.push(new Ns(e, Ms(A, r))), r = n
                        } else Ps.SUPPORT_RANGE_BOUNDS || (r = r.splitText(e.length));
                        o += e.length
                    })), i
                }, Ms = function (A, e) {
                    var t = e.ownerDocument;
                    if (t) {
                        var r = t.createElement("html2canvaswrapper");
                        r.appendChild(e.cloneNode(!0));
                        var n = e.parentNode;
                        if (n) {
                            n.replaceChild(r, e);
                            var i = o(A, r);
                            return r.firstChild && n.replaceChild(r.firstChild, r), i
                        }
                    }
                    return s.EMPTY
                }, _s = function (A, e, t) {
                    var r = A.ownerDocument;
                    if (!r) throw new Error("Node has no owner document");
                    var n = r.createRange();
                    return n.setStart(A, e), n.setEnd(A, e + t), n
                }, Vs = function (A, e, t, r) {
                    return s.fromClientRect(A, _s(e, t, r).getBoundingClientRect())
                }, Gs = function (A, e) {
                    return 0 !== e.letterSpacing ? bs(A) : js(A, e)
                }, Js = [32, 160, 4961, 65792, 65793, 4153, 4241], js = function (A, e) {
                    var t, r = GA(A, {
                        lineBreak: e.lineBreak,
                        wordBreak: "break-word" === e.overflowWrap ? "break-word" : e.wordBreak
                    }), n = [], i = function () {
                        if (t.value) {
                            var A = t.value.slice(), e = c(A), r = "";
                            e.forEach((function (A) {
                                -1 === Js.indexOf(A) ? r += l(A) : (r.length && n.push(r), n.push(l(A)), r = "")
                            })), r.length && n.push(r)
                        }
                    };
                    while (!(t = r.next()).done) i();
                    return n
                }, Xs = function () {
                    function A(A, e, t) {
                        this.text = Ws(e.data, t.textTransform), this.textBounds = Rs(A, this.text, t, e)
                    }

                    return A
                }(), Ws = function (A, e) {
                    switch (e) {
                        case 1:
                            return A.toLowerCase();
                        case 3:
                            return A.replace(Ys, Zs);
                        case 2:
                            return A.toUpperCase();
                        default:
                            return A
                    }
                }, Ys = /(^|\s|:|-|\(|\))([a-z])/g, Zs = function (A, e, t) {
                    return A.length > 0 ? e + t.toUpperCase() : A
                }, qs = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        return r.src = t.currentSrc || t.src, r.intrinsicWidth = t.naturalWidth, r.intrinsicHeight = t.naturalHeight, r.context.cache.addImage(r.src), r
                    }

                    return e(t, A), t
                }(Hi), zs = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        return r.canvas = t, r.intrinsicWidth = t.width, r.intrinsicHeight = t.height, r
                    }

                    return e(t, A), t
                }(Hi), $s = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this, n = new XMLSerializer, i = o(e, t);
                        return t.setAttribute("width", i.width + "px"), t.setAttribute("height", i.height + "px"), r.svg = "data:image/svg+xml," + encodeURIComponent(n.serializeToString(t)), r.intrinsicWidth = t.width.baseVal.value, r.intrinsicHeight = t.height.baseVal.value, r.context.cache.addImage(r.svg), r
                    }

                    return e(t, A), t
                }(Hi), Ao = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        return r.value = t.value, r
                    }

                    return e(t, A), t
                }(Hi), eo = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        return r.start = t.start, r.reversed = "boolean" === typeof t.reversed && !0 === t.reversed, r
                    }

                    return e(t, A), t
                }(Hi), to = [{ type: 15, flags: 0, unit: "px", number: 3 }], ro = [{ type: 16, flags: 0, number: 50 }],
                no = function (A) {
                    return A.width > A.height ? new s(A.left + (A.width - A.height) / 2, A.top, A.height, A.height) : A.width < A.height ? new s(A.left, A.top + (A.height - A.width) / 2, A.width, A.width) : A
                }, io = function (A) {
                    var e = A.type === ao ? new Array(A.value.length + 1).join("•") : A.value;
                    return 0 === e.length ? A.placeholder || "" : e
                }, so = "checkbox", oo = "radio", ao = "password", co = 707406591, lo = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        switch (r.type = t.type.toLowerCase(), r.checked = t.checked, r.value = io(t), r.type !== so && r.type !== oo || (r.styles.backgroundColor = 3739148031, r.styles.borderTopColor = r.styles.borderRightColor = r.styles.borderBottomColor = r.styles.borderLeftColor = 2779096575, r.styles.borderTopWidth = r.styles.borderRightWidth = r.styles.borderBottomWidth = r.styles.borderLeftWidth = 1, r.styles.borderTopStyle = r.styles.borderRightStyle = r.styles.borderBottomStyle = r.styles.borderLeftStyle = 1, r.styles.backgroundClip = [0], r.styles.backgroundOrigin = [0], r.bounds = no(r.bounds)), r.type) {
                            case so:
                                r.styles.borderTopRightRadius = r.styles.borderTopLeftRadius = r.styles.borderBottomRightRadius = r.styles.borderBottomLeftRadius = to;
                                break;
                            case oo:
                                r.styles.borderTopRightRadius = r.styles.borderTopLeftRadius = r.styles.borderBottomRightRadius = r.styles.borderBottomLeftRadius = ro;
                                break
                        }
                        return r
                    }

                    return e(t, A), t
                }(Hi), uo = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this, n = t.options[t.selectedIndex || 0];
                        return r.value = n && n.text || "", r
                    }

                    return e(t, A), t
                }(Hi), Bo = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        return r.value = t.value, r
                    }

                    return e(t, A), t
                }(Hi), ho = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        r.src = t.src, r.width = parseInt(t.width, 10) || 0, r.height = parseInt(t.height, 10) || 0, r.backgroundColor = r.styles.backgroundColor;
                        try {
                            if (t.contentWindow && t.contentWindow.document && t.contentWindow.document.documentElement) {
                                r.tree = wo(e, t.contentWindow.document.documentElement);
                                var n = t.contentWindow.document.documentElement ? dr(e, getComputedStyle(t.contentWindow.document.documentElement).backgroundColor) : Br.TRANSPARENT,
                                    i = t.contentWindow.document.body ? dr(e, getComputedStyle(t.contentWindow.document.body).backgroundColor) : Br.TRANSPARENT;
                                r.backgroundColor = nr(n) ? nr(i) ? r.styles.backgroundColor : i : n
                            }
                        } catch (Ne) {
                        }
                        return r
                    }

                    return e(t, A), t
                }(Hi), go = ["OL", "UL", "MENU"], po = function (A, e, t, r) {
                    for (var n = e.firstChild, i = void 0; n; n = i) if (i = n.nextSibling, Qo(n) && n.data.trim().length > 0) t.textNodes.push(new Xs(A, n, t.styles)); else if (yo(n)) if (Po(n) && n.assignedNodes) n.assignedNodes().forEach((function (e) {
                        return po(A, e, t, r)
                    })); else {
                        var s = fo(A, n);
                        s.styles.isVisible() && (Co(n, s, r) ? s.flags |= 4 : mo(s.styles) && (s.flags |= 2), -1 !== go.indexOf(n.tagName) && (s.flags |= 8), t.elements.push(s), n.slot, n.shadowRoot ? po(A, n.shadowRoot, s, r) : ko(n) || Ho(n) || Oo(n) || po(A, n, s, r))
                    }
                }, fo = function (A, e) {
                    return So(e) ? new qs(A, e) : xo(e) ? new zs(A, e) : Ho(e) ? new $s(A, e) : Fo(e) ? new Ao(A, e) : Io(e) ? new eo(A, e) : Eo(e) ? new lo(A, e) : Oo(e) ? new uo(A, e) : ko(e) ? new Bo(A, e) : Do(e) ? new ho(A, e) : new Hi(A, e)
                }, wo = function (A, e) {
                    var t = fo(A, e);
                    return t.flags |= 4, po(A, e, t, t), t
                }, Co = function (A, e, t) {
                    return e.styles.isPositionedWithZIndex() || e.styles.opacity < 1 || e.styles.isTransformed() || To(A) && t.styles.isTransparent()
                }, mo = function (A) {
                    return A.isPositioned() || A.isFloating()
                }, Qo = function (A) {
                    return A.nodeType === Node.TEXT_NODE
                }, yo = function (A) {
                    return A.nodeType === Node.ELEMENT_NODE
                }, Uo = function (A) {
                    return yo(A) && "undefined" !== typeof A.style && !vo(A)
                }, vo = function (A) {
                    return "object" === typeof A.className
                }, Fo = function (A) {
                    return "LI" === A.tagName
                }, Io = function (A) {
                    return "OL" === A.tagName
                }, Eo = function (A) {
                    return "INPUT" === A.tagName
                }, bo = function (A) {
                    return "HTML" === A.tagName
                }, Ho = function (A) {
                    return "svg" === A.tagName
                }, To = function (A) {
                    return "BODY" === A.tagName
                }, xo = function (A) {
                    return "CANVAS" === A.tagName
                }, So = function (A) {
                    return "IMG" === A.tagName
                }, Do = function (A) {
                    return "IFRAME" === A.tagName
                }, Lo = function (A) {
                    return "STYLE" === A.tagName
                }, Ko = function (A) {
                    return "SCRIPT" === A.tagName
                }, ko = function (A) {
                    return "TEXTAREA" === A.tagName
                }, Oo = function (A) {
                    return "SELECT" === A.tagName
                }, Po = function (A) {
                    return "SLOT" === A.tagName
                }, No = function () {
                    function A() {
                        this.counters = {}
                    }

                    return A.prototype.getCounterValue = function (A) {
                        var e = this.counters[A];
                        return e && e.length ? e[e.length - 1] : 1
                    }, A.prototype.getCounterValues = function (A) {
                        var e = this.counters[A];
                        return e || []
                    }, A.prototype.pop = function (A) {
                        var e = this;
                        A.forEach((function (A) {
                            return e.counters[A].pop()
                        }))
                    }, A.prototype.parse = function (A) {
                        var e = this, t = A.counterIncrement, r = A.counterReset, n = !0;
                        null !== t && t.forEach((function (A) {
                            var t = e.counters[A.counter];
                            t && 0 !== A.increment && (n = !1, t.length || t.push(1), t[Math.max(0, t.length - 1)] += A.increment)
                        }));
                        var i = [];
                        return n && r.forEach((function (A) {
                            var t = e.counters[A.counter];
                            i.push(A.counter), t || (t = e.counters[A.counter] = []), t.push(A.reset)
                        })), i
                    }, A
                }(), Ro = {
                    integers: [1e3, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1],
                    values: ["M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"]
                }, Mo = {
                    integers: [9e3, 8e3, 7e3, 6e3, 5e3, 4e3, 3e3, 2e3, 1e3, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
                    values: ["Ք", "Փ", "Ւ", "Ց", "Ր", "Տ", "Վ", "Ս", "Ռ", "Ջ", "Պ", "Չ", "Ո", "Շ", "Ն", "Յ", "Մ", "Ճ", "Ղ", "Ձ", "Հ", "Կ", "Ծ", "Խ", "Լ", "Ի", "Ժ", "Թ", "Ը", "Է", "Զ", "Ե", "Դ", "Գ", "Բ", "Ա"]
                }, _o = {
                    integers: [1e4, 9e3, 8e3, 7e3, 6e3, 5e3, 4e3, 3e3, 2e3, 1e3, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 19, 18, 17, 16, 15, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
                    values: ["י׳", "ט׳", "ח׳", "ז׳", "ו׳", "ה׳", "ד׳", "ג׳", "ב׳", "א׳", "ת", "ש", "ר", "ק", "צ", "פ", "ע", "ס", "נ", "מ", "ל", "כ", "יט", "יח", "יז", "טז", "טו", "י", "ט", "ח", "ז", "ו", "ה", "ד", "ג", "ב", "א"]
                }, Vo = {
                    integers: [1e4, 9e3, 8e3, 7e3, 6e3, 5e3, 4e3, 3e3, 2e3, 1e3, 900, 800, 700, 600, 500, 400, 300, 200, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10, 9, 8, 7, 6, 5, 4, 3, 2, 1],
                    values: ["ჵ", "ჰ", "ჯ", "ჴ", "ხ", "ჭ", "წ", "ძ", "ც", "ჩ", "შ", "ყ", "ღ", "ქ", "ფ", "ჳ", "ტ", "ს", "რ", "ჟ", "პ", "ო", "ჲ", "ნ", "მ", "ლ", "კ", "ი", "თ", "ჱ", "ზ", "ვ", "ე", "დ", "გ", "ბ", "ა"]
                }, Go = function (A, e, t, r, n, i) {
                    return A < e || A > t ? ra(A, n, i.length > 0) : r.integers.reduce((function (e, t, n) {
                        while (A >= t) A -= t, e += r.values[n];
                        return e
                    }), "") + i
                }, Jo = function (A, e, t, r) {
                    var n = "";
                    do {
                        t || A--, n = r(A) + n, A /= e
                    } while (A * e >= e);
                    return n
                }, jo = function (A, e, t, r, n) {
                    var i = t - e + 1;
                    return (A < 0 ? "-" : "") + (Jo(Math.abs(A), i, r, (function (A) {
                        return l(Math.floor(A % i) + e)
                    })) + n)
                }, Xo = function (A, e, t) {
                    void 0 === t && (t = ". ");
                    var r = e.length;
                    return Jo(Math.abs(A), r, !1, (function (A) {
                        return e[Math.floor(A % r)]
                    })) + t
                }, Wo = 1, Yo = 2, Zo = 4, qo = 8, zo = function (A, e, t, r, n, i) {
                    if (A < -9999 || A > 9999) return ra(A, 4, n.length > 0);
                    var s = Math.abs(A), o = n;
                    if (0 === s) return e[0] + o;
                    for (var a = 0; s > 0 && a <= 4; a++) {
                        var c = s % 10;
                        0 === c && ui(i, Wo) && "" !== o ? o = e[c] + o : c > 1 || 1 === c && 0 === a || 1 === c && 1 === a && ui(i, Yo) || 1 === c && 1 === a && ui(i, Zo) && A > 100 || 1 === c && a > 1 && ui(i, qo) ? o = e[c] + (a > 0 ? t[a - 1] : "") + o : 1 === c && a > 0 && (o = t[a - 1] + o), s = Math.floor(s / 10)
                    }
                    return (A < 0 ? r : "") + o
                }, $o = "十百千萬", Aa = "拾佰仟萬", ea = "マイナス", ta = "마이너스", ra = function (A, e, t) {
                    var r = t ? ". " : "", n = t ? "、" : "", i = t ? ", " : "", s = t ? " " : "";
                    switch (e) {
                        case 0:
                            return "•" + s;
                        case 1:
                            return "◦" + s;
                        case 2:
                            return "◾" + s;
                        case 5:
                            var o = jo(A, 48, 57, !0, r);
                            return o.length < 4 ? "0" + o : o;
                        case 4:
                            return Xo(A, "〇一二三四五六七八九", n);
                        case 6:
                            return Go(A, 1, 3999, Ro, 3, r).toLowerCase();
                        case 7:
                            return Go(A, 1, 3999, Ro, 3, r);
                        case 8:
                            return jo(A, 945, 969, !1, r);
                        case 9:
                            return jo(A, 97, 122, !1, r);
                        case 10:
                            return jo(A, 65, 90, !1, r);
                        case 11:
                            return jo(A, 1632, 1641, !0, r);
                        case 12:
                        case 49:
                            return Go(A, 1, 9999, Mo, 3, r);
                        case 35:
                            return Go(A, 1, 9999, Mo, 3, r).toLowerCase();
                        case 13:
                            return jo(A, 2534, 2543, !0, r);
                        case 14:
                        case 30:
                            return jo(A, 6112, 6121, !0, r);
                        case 15:
                            return Xo(A, "子丑寅卯辰巳午未申酉戌亥", n);
                        case 16:
                            return Xo(A, "甲乙丙丁戊己庚辛壬癸", n);
                        case 17:
                        case 48:
                            return zo(A, "零一二三四五六七八九", $o, "負", n, Yo | Zo | qo);
                        case 47:
                            return zo(A, "零壹貳參肆伍陸柒捌玖", Aa, "負", n, Wo | Yo | Zo | qo);
                        case 42:
                            return zo(A, "零一二三四五六七八九", $o, "负", n, Yo | Zo | qo);
                        case 41:
                            return zo(A, "零壹贰叁肆伍陆柒捌玖", Aa, "负", n, Wo | Yo | Zo | qo);
                        case 26:
                            return zo(A, "〇一二三四五六七八九", "十百千万", ea, n, 0);
                        case 25:
                            return zo(A, "零壱弐参四伍六七八九", "拾百千万", ea, n, Wo | Yo | Zo);
                        case 31:
                            return zo(A, "영일이삼사오육칠팔구", "십백천만", ta, i, Wo | Yo | Zo);
                        case 33:
                            return zo(A, "零一二三四五六七八九", "十百千萬", ta, i, 0);
                        case 32:
                            return zo(A, "零壹貳參四五六七八九", "拾百千", ta, i, Wo | Yo | Zo);
                        case 18:
                            return jo(A, 2406, 2415, !0, r);
                        case 20:
                            return Go(A, 1, 19999, Vo, 3, r);
                        case 21:
                            return jo(A, 2790, 2799, !0, r);
                        case 22:
                            return jo(A, 2662, 2671, !0, r);
                        case 22:
                            return Go(A, 1, 10999, _o, 3, r);
                        case 23:
                            return Xo(A, "あいうえおかきくけこさしすせそたちつてとなにぬねのはひふへほまみむめもやゆよらりるれろわゐゑをん");
                        case 24:
                            return Xo(A, "いろはにほへとちりぬるをわかよたれそつねならむうゐのおくやまけふこえてあさきゆめみしゑひもせす");
                        case 27:
                            return jo(A, 3302, 3311, !0, r);
                        case 28:
                            return Xo(A, "アイウエオカキクケコサシスセソタチツテトナニヌネノハヒフヘホマミムメモヤユヨラリルレロワヰヱヲン", n);
                        case 29:
                            return Xo(A, "イロハニホヘトチリヌルヲワカヨタレソツネナラムウヰノオクヤマケフコエテアサキユメミシヱヒモセス", n);
                        case 34:
                            return jo(A, 3792, 3801, !0, r);
                        case 37:
                            return jo(A, 6160, 6169, !0, r);
                        case 38:
                            return jo(A, 4160, 4169, !0, r);
                        case 39:
                            return jo(A, 2918, 2927, !0, r);
                        case 40:
                            return jo(A, 1776, 1785, !0, r);
                        case 43:
                            return jo(A, 3046, 3055, !0, r);
                        case 44:
                            return jo(A, 3174, 3183, !0, r);
                        case 45:
                            return jo(A, 3664, 3673, !0, r);
                        case 46:
                            return jo(A, 3872, 3881, !0, r);
                        case 3:
                        default:
                            return jo(A, 48, 57, !0, r)
                    }
                }, na = "data-html2canvas-ignore", ia = function () {
                    function A(A, e, t) {
                        if (this.context = A, this.options = t, this.scrolledElements = [], this.referenceElement = e, this.counters = new No, this.quoteDepth = 0, !e.ownerDocument) throw new Error("Cloned element does not have an owner document");
                        this.documentElement = this.cloneNode(e.ownerDocument.documentElement)
                    }

                    return A.prototype.toIFrame = function (A, e) {
                        var t = this, i = oa(A, e);
                        if (!i.contentWindow) return Promise.reject("Unable to find iframe window");
                        var s = A.defaultView.pageXOffset, o = A.defaultView.pageYOffset, a = i.contentWindow,
                            c = a.document, l = la(i).then((function () {
                                return r(t, void 0, void 0, (function () {
                                    var A, t;
                                    return n(this, (function (r) {
                                        switch (r.label) {
                                            case 0:
                                                return this.scrolledElements.forEach(ga), a && (a.scrollTo(e.left, e.top), !/(iPad|iPhone|iPod)/g.test(navigator.userAgent) || a.scrollY === e.top && a.scrollX === e.left || (this.context.logger.warn("Unable to restore scroll position for cloned document"), this.context.windowBounds = this.context.windowBounds.add(a.scrollX - e.left, a.scrollY - e.top, 0, 0))), A = this.options.onclone, t = this.clonedReferenceElement, "undefined" === typeof t ? [2, Promise.reject("Error finding the " + this.referenceElement.nodeName + " in the cloned document")] : c.fonts && c.fonts.ready ? [4, c.fonts.ready] : [3, 2];
                                            case 1:
                                                r.sent(), r.label = 2;
                                            case 2:
                                                return /(AppleWebKit)/g.test(navigator.userAgent) ? [4, ca(c)] : [3, 4];
                                            case 3:
                                                r.sent(), r.label = 4;
                                            case 4:
                                                return "function" === typeof A ? [2, Promise.resolve().then((function () {
                                                    return A(c, t)
                                                })).then((function () {
                                                    return i
                                                }))] : [2, i]
                                        }
                                    }))
                                }))
                            }));
                        return c.open(), c.write(Ba(document.doctype) + "<html></html>"), ha(this.referenceElement.ownerDocument, s, o), c.replaceChild(c.adoptNode(this.documentElement), c.documentElement), c.close(), l
                    }, A.prototype.createElementClone = function (A) {
                        if (bi(A, 2), xo(A)) return this.createCanvasClone(A);
                        if (Lo(A)) return this.createStyleClone(A);
                        var e = A.cloneNode(!1);
                        return So(e) && (So(A) && A.currentSrc && A.currentSrc !== A.src && (e.src = A.currentSrc, e.srcset = ""), "lazy" === e.loading && (e.loading = "eager")), e
                    }, A.prototype.createStyleClone = function (A) {
                        try {
                            var e = A.sheet;
                            if (e && e.cssRules) {
                                var t = [].slice.call(e.cssRules, 0).reduce((function (A, e) {
                                    return e && "string" === typeof e.cssText ? A + e.cssText : A
                                }), ""), r = A.cloneNode(!1);
                                return r.textContent = t, r
                            }
                        } catch (Ne) {
                            if (this.context.logger.error("Unable to access cssRules property", Ne), "SecurityError" !== Ne.name) throw Ne
                        }
                        return A.cloneNode(!1)
                    }, A.prototype.createCanvasClone = function (A) {
                        var e;
                        if (this.options.inlineImages && A.ownerDocument) {
                            var t = A.ownerDocument.createElement("img");
                            try {
                                return t.src = A.toDataURL(), t
                            } catch (Ne) {
                                this.context.logger.info("Unable to inline canvas contents, canvas is tainted", A)
                            }
                        }
                        var r = A.cloneNode(!1);
                        try {
                            r.width = A.width, r.height = A.height;
                            var n = A.getContext("2d"), i = r.getContext("2d");
                            if (i) if (!this.options.allowTaint && n) i.putImageData(n.getImageData(0, 0, A.width, A.height), 0, 0); else {
                                var s = null !== (e = A.getContext("webgl2")) && void 0 !== e ? e : A.getContext("webgl");
                                if (s) {
                                    var o = s.getContextAttributes();
                                    !1 === (null === o || void 0 === o ? void 0 : o.preserveDrawingBuffer) && this.context.logger.warn("Unable to clone WebGL context as it has preserveDrawingBuffer=false", A)
                                }
                                i.drawImage(A, 0, 0)
                            }
                            return r
                        } catch (Ne) {
                            this.context.logger.info("Unable to clone canvas as it is tainted", A)
                        }
                        return r
                    }, A.prototype.cloneNode = function (A) {
                        if (Qo(A)) return document.createTextNode(A.data);
                        if (!A.ownerDocument) return A.cloneNode(!1);
                        var e = A.ownerDocument.defaultView;
                        if (e && yo(A) && (Uo(A) || vo(A))) {
                            var t = this.createElementClone(A);
                            t.style.transitionProperty = "none";
                            var r = e.getComputedStyle(A), n = e.getComputedStyle(A, ":before"),
                                i = e.getComputedStyle(A, ":after");
                            this.referenceElement === A && Uo(t) && (this.clonedReferenceElement = t), To(t) && Qa(t);
                            for (var s = this.counters.parse(new vi(this.context, r)), o = this.resolvePseudoContent(A, t, n, is.BEFORE), a = A.firstChild; a; a = a.nextSibling) yo(a) && (Ko(a) || a.hasAttribute(na) || "function" === typeof this.options.ignoreElements && this.options.ignoreElements(a)) || this.options.copyStyles && yo(a) && Lo(a) || t.appendChild(this.cloneNode(a));
                            o && t.insertBefore(o, t.firstChild);
                            var c = this.resolvePseudoContent(A, t, i, is.AFTER);
                            return c && t.appendChild(c), this.counters.pop(s), r && (this.options.copyStyles || vo(A)) && !Do(A) && da(r, t), 0 === A.scrollTop && 0 === A.scrollLeft || this.scrolledElements.push([t, A.scrollLeft, A.scrollTop]), (ko(A) || Oo(A)) && (ko(t) || Oo(t)) && (t.value = A.value), t
                        }
                        return A.cloneNode(!1)
                    }, A.prototype.resolvePseudoContent = function (A, e, t, r) {
                        var n = this;
                        if (t) {
                            var i = t.content, s = e.ownerDocument;
                            if (s && i && "none" !== i && "-moz-alt-content" !== i && "none" !== t.display) {
                                this.counters.parse(new vi(this.context, t));
                                var o = new Ui(this.context, t), a = s.createElement("html2canvaspseudoelement");
                                da(t, a), o.content.forEach((function (e) {
                                    if (0 === e.type) a.appendChild(s.createTextNode(e.value)); else if (22 === e.type) {
                                        var t = s.createElement("img");
                                        t.src = e.value, t.style.opacity = "1", a.appendChild(t)
                                    } else if (18 === e.type) {
                                        if ("attr" === e.name) {
                                            var r = e.values.filter(Lt);
                                            r.length && a.appendChild(s.createTextNode(A.getAttribute(r[0].value) || ""))
                                        } else if ("counter" === e.name) {
                                            var i = e.values.filter(Pt), c = i[0], l = i[1];
                                            if (c && Lt(c)) {
                                                var u = n.counters.getCounterValue(c.value),
                                                    d = l && Lt(l) ? Hn.parse(n.context, l.value) : 3;
                                                a.appendChild(s.createTextNode(ra(u, d, !1)))
                                            }
                                        } else if ("counters" === e.name) {
                                            var B = e.values.filter(Pt), h = (c = B[0], B[1]);
                                            l = B[2];
                                            if (c && Lt(c)) {
                                                var g = n.counters.getCounterValues(c.value),
                                                    p = l && Lt(l) ? Hn.parse(n.context, l.value) : 3,
                                                    f = h && 0 === h.type ? h.value : "", w = g.map((function (A) {
                                                        return ra(A, p, !1)
                                                    })).join(f);
                                                a.appendChild(s.createTextNode(w))
                                            }
                                        }
                                    } else if (20 === e.type) switch (e.value) {
                                        case "open-quote":
                                            a.appendChild(s.createTextNode(fi(o.quotes, n.quoteDepth++, !0)));
                                            break;
                                        case "close-quote":
                                            a.appendChild(s.createTextNode(fi(o.quotes, --n.quoteDepth, !1)));
                                            break;
                                        default:
                                            a.appendChild(s.createTextNode(e.value))
                                    }
                                })), a.className = wa + " " + Ca;
                                var c = r === is.BEFORE ? " " + wa : " " + Ca;
                                return vo(e) ? e.className.baseValue += c : e.className += c, a
                            }
                        }
                    }, A.destroy = function (A) {
                        return !!A.parentNode && (A.parentNode.removeChild(A), !0)
                    }, A
                }();
            (function (A) {
                A[A["BEFORE"] = 0] = "BEFORE", A[A["AFTER"] = 1] = "AFTER"
            })(is || (is = {}));
            var sa, oa = function (A, e) {
                var t = A.createElement("iframe");
                return t.className = "html2canvas-container", t.style.visibility = "hidden", t.style.position = "fixed", t.style.left = "-10000px", t.style.top = "0px", t.style.border = "0", t.width = e.width.toString(), t.height = e.height.toString(), t.scrolling = "no", t.setAttribute(na, "true"), A.body.appendChild(t), t
            }, aa = function (A) {
                return new Promise((function (e) {
                    A.complete ? e() : A.src ? (A.onload = e, A.onerror = e) : e()
                }))
            }, ca = function (A) {
                return Promise.all([].slice.call(A.images, 0).map(aa))
            }, la = function (A) {
                return new Promise((function (e, t) {
                    var r = A.contentWindow;
                    if (!r) return t("No window assigned for iframe");
                    var n = r.document;
                    r.onload = A.onload = function () {
                        r.onload = A.onload = null;
                        var t = setInterval((function () {
                            n.body.childNodes.length > 0 && "complete" === n.readyState && (clearInterval(t), e(A))
                        }), 50)
                    }
                }))
            }, ua = ["all", "d", "content"], da = function (A, e) {
                for (var t = A.length - 1; t >= 0; t--) {
                    var r = A.item(t);
                    -1 === ua.indexOf(r) && e.style.setProperty(r, A.getPropertyValue(r))
                }
                return e
            }, Ba = function (A) {
                var e = "";
                return A && (e += "<!DOCTYPE ", A.name && (e += A.name), A.internalSubset && (e += A.internalSubset), A.publicId && (e += '"' + A.publicId + '"'), A.systemId && (e += '"' + A.systemId + '"'), e += ">"), e
            }, ha = function (A, e, t) {
                A && A.defaultView && (e !== A.defaultView.pageXOffset || t !== A.defaultView.pageYOffset) && A.defaultView.scrollTo(e, t)
            }, ga = function (A) {
                var e = A[0], t = A[1], r = A[2];
                e.scrollLeft = t, e.scrollTop = r
            }, pa = ":before", fa = ":after", wa = "___html2canvas___pseudoelement_before",
                Ca = "___html2canvas___pseudoelement_after",
                ma = '{\n    content: "" !important;\n    display: none !important;\n}', Qa = function (A) {
                    ya(A, "." + wa + pa + ma + "\n         ." + Ca + fa + ma)
                }, ya = function (A, e) {
                    var t = A.ownerDocument;
                    if (t) {
                        var r = t.createElement("style");
                        r.textContent = e, A.appendChild(r)
                    }
                }, Ua = function () {
                    function A() {
                    }

                    return A.getOrigin = function (e) {
                        var t = A._link;
                        return t ? (t.href = e, t.href = t.href, t.protocol + t.hostname + t.port) : "about:blank"
                    }, A.isSameOrigin = function (e) {
                        return A.getOrigin(e) === A._origin
                    }, A.setContext = function (e) {
                        A._link = e.document.createElement("a"), A._origin = A.getOrigin(e.location.href)
                    }, A._origin = "about:blank", A
                }(), va = function () {
                    function A(A, e) {
                        this.context = A, this._options = e, this._cache = {}
                    }

                    return A.prototype.addImage = function (A) {
                        var e = Promise.resolve();
                        return this.has(A) ? e : xa(A) || ba(A) ? ((this._cache[A] = this.loadImage(A)).catch((function () {
                        })), e) : e
                    }, A.prototype.match = function (A) {
                        return this._cache[A]
                    }, A.prototype.loadImage = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e, t, r, i, s = this;
                            return n(this, (function (n) {
                                switch (n.label) {
                                    case 0:
                                        return e = Ua.isSameOrigin(A), t = !Ha(A) && !0 === this._options.useCORS && Ps.SUPPORT_CORS_IMAGES && !e, r = !Ha(A) && !e && !xa(A) && "string" === typeof this._options.proxy && Ps.SUPPORT_CORS_XHR && !t, e || !1 !== this._options.allowTaint || Ha(A) || xa(A) || r || t ? (i = A, r ? [4, this.proxy(i)] : [3, 2]) : [2];
                                    case 1:
                                        i = n.sent(), n.label = 2;
                                    case 2:
                                        return this.context.logger.debug("Added image " + A.substring(0, 256)), [4, new Promise((function (A, e) {
                                            var r = new Image;
                                            r.onload = function () {
                                                return A(r)
                                            }, r.onerror = e, (Ta(i) || t) && (r.crossOrigin = "anonymous"), r.src = i, !0 === r.complete && setTimeout((function () {
                                                return A(r)
                                            }), 500), s._options.imageTimeout > 0 && setTimeout((function () {
                                                return e("Timed out (" + s._options.imageTimeout + "ms) loading image")
                                            }), s._options.imageTimeout)
                                        }))];
                                    case 3:
                                        return [2, n.sent()]
                                }
                            }))
                        }))
                    }, A.prototype.has = function (A) {
                        return "undefined" !== typeof this._cache[A]
                    }, A.prototype.keys = function () {
                        return Promise.resolve(Object.keys(this._cache))
                    }, A.prototype.proxy = function (A) {
                        var e = this, t = this._options.proxy;
                        if (!t) throw new Error("No proxy defined");
                        var r = A.substring(0, 256);
                        return new Promise((function (n, i) {
                            var s = Ps.SUPPORT_RESPONSE_TYPE ? "blob" : "text", o = new XMLHttpRequest;
                            o.onload = function () {
                                if (200 === o.status) if ("text" === s) n(o.response); else {
                                    var A = new FileReader;
                                    A.addEventListener("load", (function () {
                                        return n(A.result)
                                    }), !1), A.addEventListener("error", (function (A) {
                                        return i(A)
                                    }), !1), A.readAsDataURL(o.response)
                                } else i("Failed to proxy resource " + r + " with status code " + o.status)
                            }, o.onerror = i;
                            var a = t.indexOf("?") > -1 ? "&" : "?";
                            if (o.open("GET", "" + t + a + "url=" + encodeURIComponent(A) + "&responseType=" + s), "text" !== s && o instanceof XMLHttpRequest && (o.responseType = s), e._options.imageTimeout) {
                                var c = e._options.imageTimeout;
                                o.timeout = c, o.ontimeout = function () {
                                    return i("Timed out (" + c + "ms) proxying " + r)
                                }
                            }
                            o.send()
                        }))
                    }, A
                }(), Fa = /^data:image\/svg\+xml/i, Ia = /^data:image\/.*;base64,/i, Ea = /^data:image\/.*/i,
                ba = function (A) {
                    return Ps.SUPPORT_SVG_DRAWING || !Sa(A)
                }, Ha = function (A) {
                    return Ea.test(A)
                }, Ta = function (A) {
                    return Ia.test(A)
                }, xa = function (A) {
                    return "blob" === A.substr(0, 4)
                }, Sa = function (A) {
                    return "svg" === A.substr(-3).toLowerCase() || Fa.test(A)
                }, Da = function () {
                    function A(A, e) {
                        this.type = 0, this.x = A, this.y = e
                    }

                    return A.prototype.add = function (e, t) {
                        return new A(this.x + e, this.y + t)
                    }, A
                }(), La = function (A, e, t) {
                    return new Da(A.x + (e.x - A.x) * t, A.y + (e.y - A.y) * t)
                }, Ka = function () {
                    function A(A, e, t, r) {
                        this.type = 1, this.start = A, this.startControl = e, this.endControl = t, this.end = r
                    }

                    return A.prototype.subdivide = function (e, t) {
                        var r = La(this.start, this.startControl, e), n = La(this.startControl, this.endControl, e),
                            i = La(this.endControl, this.end, e), s = La(r, n, e), o = La(n, i, e), a = La(s, o, e);
                        return t ? new A(this.start, r, s, a) : new A(a, o, i, this.end)
                    }, A.prototype.add = function (e, t) {
                        return new A(this.start.add(e, t), this.startControl.add(e, t), this.endControl.add(e, t), this.end.add(e, t))
                    }, A.prototype.reverse = function () {
                        return new A(this.end, this.endControl, this.startControl, this.start)
                    }, A
                }(), ka = function (A) {
                    return 1 === A.type
                }, Oa = function () {
                    function A(A) {
                        var e = A.styles, t = A.bounds, r = Xt(e.borderTopLeftRadius, t.width, t.height), n = r[0],
                            i = r[1], s = Xt(e.borderTopRightRadius, t.width, t.height), o = s[0], a = s[1],
                            c = Xt(e.borderBottomRightRadius, t.width, t.height), l = c[0], u = c[1],
                            d = Xt(e.borderBottomLeftRadius, t.width, t.height), B = d[0], h = d[1], g = [];
                        g.push((n + o) / t.width), g.push((B + l) / t.width), g.push((i + h) / t.height), g.push((a + u) / t.height);
                        var p = Math.max.apply(Math, g);
                        p > 1 && (n /= p, i /= p, o /= p, a /= p, l /= p, u /= p, B /= p, h /= p);
                        var f = t.width - o, w = t.height - u, C = t.width - l, m = t.height - h, Q = e.borderTopWidth,
                            y = e.borderRightWidth, U = e.borderBottomWidth, v = e.borderLeftWidth,
                            F = Wt(e.paddingTop, A.bounds.width), I = Wt(e.paddingRight, A.bounds.width),
                            E = Wt(e.paddingBottom, A.bounds.width), b = Wt(e.paddingLeft, A.bounds.width);
                        this.topLeftBorderDoubleOuterBox = n > 0 || i > 0 ? Pa(t.left + v / 3, t.top + Q / 3, n - v / 3, i - Q / 3, sa.TOP_LEFT) : new Da(t.left + v / 3, t.top + Q / 3), this.topRightBorderDoubleOuterBox = n > 0 || i > 0 ? Pa(t.left + f, t.top + Q / 3, o - y / 3, a - Q / 3, sa.TOP_RIGHT) : new Da(t.left + t.width - y / 3, t.top + Q / 3), this.bottomRightBorderDoubleOuterBox = l > 0 || u > 0 ? Pa(t.left + C, t.top + w, l - y / 3, u - U / 3, sa.BOTTOM_RIGHT) : new Da(t.left + t.width - y / 3, t.top + t.height - U / 3), this.bottomLeftBorderDoubleOuterBox = B > 0 || h > 0 ? Pa(t.left + v / 3, t.top + m, B - v / 3, h - U / 3, sa.BOTTOM_LEFT) : new Da(t.left + v / 3, t.top + t.height - U / 3), this.topLeftBorderDoubleInnerBox = n > 0 || i > 0 ? Pa(t.left + 2 * v / 3, t.top + 2 * Q / 3, n - 2 * v / 3, i - 2 * Q / 3, sa.TOP_LEFT) : new Da(t.left + 2 * v / 3, t.top + 2 * Q / 3), this.topRightBorderDoubleInnerBox = n > 0 || i > 0 ? Pa(t.left + f, t.top + 2 * Q / 3, o - 2 * y / 3, a - 2 * Q / 3, sa.TOP_RIGHT) : new Da(t.left + t.width - 2 * y / 3, t.top + 2 * Q / 3), this.bottomRightBorderDoubleInnerBox = l > 0 || u > 0 ? Pa(t.left + C, t.top + w, l - 2 * y / 3, u - 2 * U / 3, sa.BOTTOM_RIGHT) : new Da(t.left + t.width - 2 * y / 3, t.top + t.height - 2 * U / 3), this.bottomLeftBorderDoubleInnerBox = B > 0 || h > 0 ? Pa(t.left + 2 * v / 3, t.top + m, B - 2 * v / 3, h - 2 * U / 3, sa.BOTTOM_LEFT) : new Da(t.left + 2 * v / 3, t.top + t.height - 2 * U / 3), this.topLeftBorderStroke = n > 0 || i > 0 ? Pa(t.left + v / 2, t.top + Q / 2, n - v / 2, i - Q / 2, sa.TOP_LEFT) : new Da(t.left + v / 2, t.top + Q / 2), this.topRightBorderStroke = n > 0 || i > 0 ? Pa(t.left + f, t.top + Q / 2, o - y / 2, a - Q / 2, sa.TOP_RIGHT) : new Da(t.left + t.width - y / 2, t.top + Q / 2), this.bottomRightBorderStroke = l > 0 || u > 0 ? Pa(t.left + C, t.top + w, l - y / 2, u - U / 2, sa.BOTTOM_RIGHT) : new Da(t.left + t.width - y / 2, t.top + t.height - U / 2), this.bottomLeftBorderStroke = B > 0 || h > 0 ? Pa(t.left + v / 2, t.top + m, B - v / 2, h - U / 2, sa.BOTTOM_LEFT) : new Da(t.left + v / 2, t.top + t.height - U / 2), this.topLeftBorderBox = n > 0 || i > 0 ? Pa(t.left, t.top, n, i, sa.TOP_LEFT) : new Da(t.left, t.top), this.topRightBorderBox = o > 0 || a > 0 ? Pa(t.left + f, t.top, o, a, sa.TOP_RIGHT) : new Da(t.left + t.width, t.top), this.bottomRightBorderBox = l > 0 || u > 0 ? Pa(t.left + C, t.top + w, l, u, sa.BOTTOM_RIGHT) : new Da(t.left + t.width, t.top + t.height), this.bottomLeftBorderBox = B > 0 || h > 0 ? Pa(t.left, t.top + m, B, h, sa.BOTTOM_LEFT) : new Da(t.left, t.top + t.height), this.topLeftPaddingBox = n > 0 || i > 0 ? Pa(t.left + v, t.top + Q, Math.max(0, n - v), Math.max(0, i - Q), sa.TOP_LEFT) : new Da(t.left + v, t.top + Q), this.topRightPaddingBox = o > 0 || a > 0 ? Pa(t.left + Math.min(f, t.width - y), t.top + Q, f > t.width + y ? 0 : Math.max(0, o - y), Math.max(0, a - Q), sa.TOP_RIGHT) : new Da(t.left + t.width - y, t.top + Q), this.bottomRightPaddingBox = l > 0 || u > 0 ? Pa(t.left + Math.min(C, t.width - v), t.top + Math.min(w, t.height - U), Math.max(0, l - y), Math.max(0, u - U), sa.BOTTOM_RIGHT) : new Da(t.left + t.width - y, t.top + t.height - U), this.bottomLeftPaddingBox = B > 0 || h > 0 ? Pa(t.left + v, t.top + Math.min(m, t.height - U), Math.max(0, B - v), Math.max(0, h - U), sa.BOTTOM_LEFT) : new Da(t.left + v, t.top + t.height - U), this.topLeftContentBox = n > 0 || i > 0 ? Pa(t.left + v + b, t.top + Q + F, Math.max(0, n - (v + b)), Math.max(0, i - (Q + F)), sa.TOP_LEFT) : new Da(t.left + v + b, t.top + Q + F), this.topRightContentBox = o > 0 || a > 0 ? Pa(t.left + Math.min(f, t.width + v + b), t.top + Q + F, f > t.width + v + b ? 0 : o - v + b, a - (Q + F), sa.TOP_RIGHT) : new Da(t.left + t.width - (y + I), t.top + Q + F), this.bottomRightContentBox = l > 0 || u > 0 ? Pa(t.left + Math.min(C, t.width - (v + b)), t.top + Math.min(w, t.height + Q + F), Math.max(0, l - (y + I)), u - (U + E), sa.BOTTOM_RIGHT) : new Da(t.left + t.width - (y + I), t.top + t.height - (U + E)), this.bottomLeftContentBox = B > 0 || h > 0 ? Pa(t.left + v + b, t.top + m, Math.max(0, B - (v + b)), h - (U + E), sa.BOTTOM_LEFT) : new Da(t.left + v + b, t.top + t.height - (U + E))
                    }

                    return A
                }();
            (function (A) {
                A[A["TOP_LEFT"] = 0] = "TOP_LEFT", A[A["TOP_RIGHT"] = 1] = "TOP_RIGHT", A[A["BOTTOM_RIGHT"] = 2] = "BOTTOM_RIGHT", A[A["BOTTOM_LEFT"] = 3] = "BOTTOM_LEFT"
            })(sa || (sa = {}));
            var Pa = function (A, e, t, r, n) {
                var i = (Math.sqrt(2) - 1) / 3 * 4, s = t * i, o = r * i, a = A + t, c = e + r;
                switch (n) {
                    case sa.TOP_LEFT:
                        return new Ka(new Da(A, c), new Da(A, c - o), new Da(a - s, e), new Da(a, e));
                    case sa.TOP_RIGHT:
                        return new Ka(new Da(A, e), new Da(A + s, e), new Da(a, c - o), new Da(a, c));
                    case sa.BOTTOM_RIGHT:
                        return new Ka(new Da(a, e), new Da(a, e + o), new Da(A + s, c), new Da(A, c));
                    case sa.BOTTOM_LEFT:
                    default:
                        return new Ka(new Da(a, c), new Da(a - s, c), new Da(A, e + o), new Da(A, e))
                }
            }, Na = function (A) {
                return [A.topLeftBorderBox, A.topRightBorderBox, A.bottomRightBorderBox, A.bottomLeftBorderBox]
            }, Ra = function (A) {
                return [A.topLeftContentBox, A.topRightContentBox, A.bottomRightContentBox, A.bottomLeftContentBox]
            }, Ma = function (A) {
                return [A.topLeftPaddingBox, A.topRightPaddingBox, A.bottomRightPaddingBox, A.bottomLeftPaddingBox]
            }, _a = function () {
                function A(A, e, t) {
                    this.offsetX = A, this.offsetY = e, this.matrix = t, this.type = 0, this.target = 6
                }

                return A
            }(), Va = function () {
                function A(A, e) {
                    this.path = A, this.target = e, this.type = 1
                }

                return A
            }(), Ga = function () {
                function A(A) {
                    this.opacity = A, this.type = 2, this.target = 6
                }

                return A
            }(), Ja = function (A) {
                return 0 === A.type
            }, ja = function (A) {
                return 1 === A.type
            }, Xa = function (A) {
                return 2 === A.type
            }, Wa = function (A, e) {
                return A.length === e.length && A.some((function (A, t) {
                    return A === e[t]
                }))
            }, Ya = function (A, e, t, r, n) {
                return A.map((function (A, i) {
                    switch (i) {
                        case 0:
                            return A.add(e, t);
                        case 1:
                            return A.add(e + r, t);
                        case 2:
                            return A.add(e + r, t + n);
                        case 3:
                            return A.add(e, t + n)
                    }
                    return A
                }))
            }, Za = function () {
                function A(A) {
                    this.element = A, this.inlineLevel = [], this.nonInlineLevel = [], this.negativeZIndex = [], this.zeroOrAutoZIndexOrTransformedOrOpacity = [], this.positiveZIndex = [], this.nonPositionedFloats = [], this.nonPositionedInlineLevel = []
                }

                return A
            }(), qa = function () {
                function A(A, e) {
                    if (this.container = A, this.parent = e, this.effects = [], this.curves = new Oa(this.container), this.container.styles.opacity < 1 && this.effects.push(new Ga(this.container.styles.opacity)), null !== this.container.styles.transform) {
                        var t = this.container.bounds.left + this.container.styles.transformOrigin[0].number,
                            r = this.container.bounds.top + this.container.styles.transformOrigin[1].number,
                            n = this.container.styles.transform;
                        this.effects.push(new _a(t, r, n))
                    }
                    if (0 !== this.container.styles.overflowX) {
                        var i = Na(this.curves), s = Ma(this.curves);
                        Wa(i, s) ? this.effects.push(new Va(i, 6)) : (this.effects.push(new Va(i, 2)), this.effects.push(new Va(s, 4)))
                    }
                }

                return A.prototype.getEffects = function (A) {
                    var e = -1 === [2, 3].indexOf(this.container.styles.position), t = this.parent,
                        r = this.effects.slice(0);
                    while (t) {
                        var n = t.effects.filter((function (A) {
                            return !ja(A)
                        }));
                        if (e || 0 !== t.container.styles.position || !t.parent) {
                            if (r.unshift.apply(r, n), e = -1 === [2, 3].indexOf(t.container.styles.position), 0 !== t.container.styles.overflowX) {
                                var i = Na(t.curves), s = Ma(t.curves);
                                Wa(i, s) || r.unshift(new Va(s, 6))
                            }
                        } else r.unshift.apply(r, n);
                        t = t.parent
                    }
                    return r.filter((function (e) {
                        return ui(e.target, A)
                    }))
                }, A
            }(), za = function (A, e, t, r) {
                A.container.elements.forEach((function (n) {
                    var i = ui(n.flags, 4), s = ui(n.flags, 2), o = new qa(n, A);
                    ui(n.styles.display, 2048) && r.push(o);
                    var a = ui(n.flags, 8) ? [] : r;
                    if (i || s) {
                        var c = i || n.styles.isPositioned() ? t : e, l = new Za(o);
                        if (n.styles.isPositioned() || n.styles.opacity < 1 || n.styles.isTransformed()) {
                            var u = n.styles.zIndex.order;
                            if (u < 0) {
                                var d = 0;
                                c.negativeZIndex.some((function (A, e) {
                                    return u > A.element.container.styles.zIndex.order ? (d = e, !1) : d > 0
                                })), c.negativeZIndex.splice(d, 0, l)
                            } else if (u > 0) {
                                var B = 0;
                                c.positiveZIndex.some((function (A, e) {
                                    return u >= A.element.container.styles.zIndex.order ? (B = e + 1, !1) : B > 0
                                })), c.positiveZIndex.splice(B, 0, l)
                            } else c.zeroOrAutoZIndexOrTransformedOrOpacity.push(l)
                        } else n.styles.isFloating() ? c.nonPositionedFloats.push(l) : c.nonPositionedInlineLevel.push(l);
                        za(o, l, i ? l : t, a)
                    } else n.styles.isInlineLevel() ? e.inlineLevel.push(o) : e.nonInlineLevel.push(o), za(o, e, t, a);
                    ui(n.flags, 8) && $a(n, a)
                }))
            }, $a = function (A, e) {
                for (var t = A instanceof eo ? A.start : 1, r = A instanceof eo && A.reversed, n = 0; n < e.length; n++) {
                    var i = e[n];
                    i.container instanceof Ao && "number" === typeof i.container.value && 0 !== i.container.value && (t = i.container.value), i.listValue = ra(t, i.container.styles.listStyleType, !0), t += r ? -1 : 1
                }
            }, Ac = function (A) {
                var e = new qa(A, null), t = new Za(e), r = [];
                return za(e, t, t, r), $a(e.container, r), t
            }, ec = function (A, e) {
                switch (e) {
                    case 0:
                        return sc(A.topLeftBorderBox, A.topLeftPaddingBox, A.topRightBorderBox, A.topRightPaddingBox);
                    case 1:
                        return sc(A.topRightBorderBox, A.topRightPaddingBox, A.bottomRightBorderBox, A.bottomRightPaddingBox);
                    case 2:
                        return sc(A.bottomRightBorderBox, A.bottomRightPaddingBox, A.bottomLeftBorderBox, A.bottomLeftPaddingBox);
                    case 3:
                    default:
                        return sc(A.bottomLeftBorderBox, A.bottomLeftPaddingBox, A.topLeftBorderBox, A.topLeftPaddingBox)
                }
            }, tc = function (A, e) {
                switch (e) {
                    case 0:
                        return sc(A.topLeftBorderBox, A.topLeftBorderDoubleOuterBox, A.topRightBorderBox, A.topRightBorderDoubleOuterBox);
                    case 1:
                        return sc(A.topRightBorderBox, A.topRightBorderDoubleOuterBox, A.bottomRightBorderBox, A.bottomRightBorderDoubleOuterBox);
                    case 2:
                        return sc(A.bottomRightBorderBox, A.bottomRightBorderDoubleOuterBox, A.bottomLeftBorderBox, A.bottomLeftBorderDoubleOuterBox);
                    case 3:
                    default:
                        return sc(A.bottomLeftBorderBox, A.bottomLeftBorderDoubleOuterBox, A.topLeftBorderBox, A.topLeftBorderDoubleOuterBox)
                }
            }, rc = function (A, e) {
                switch (e) {
                    case 0:
                        return sc(A.topLeftBorderDoubleInnerBox, A.topLeftPaddingBox, A.topRightBorderDoubleInnerBox, A.topRightPaddingBox);
                    case 1:
                        return sc(A.topRightBorderDoubleInnerBox, A.topRightPaddingBox, A.bottomRightBorderDoubleInnerBox, A.bottomRightPaddingBox);
                    case 2:
                        return sc(A.bottomRightBorderDoubleInnerBox, A.bottomRightPaddingBox, A.bottomLeftBorderDoubleInnerBox, A.bottomLeftPaddingBox);
                    case 3:
                    default:
                        return sc(A.bottomLeftBorderDoubleInnerBox, A.bottomLeftPaddingBox, A.topLeftBorderDoubleInnerBox, A.topLeftPaddingBox)
                }
            }, nc = function (A, e) {
                switch (e) {
                    case 0:
                        return ic(A.topLeftBorderStroke, A.topRightBorderStroke);
                    case 1:
                        return ic(A.topRightBorderStroke, A.bottomRightBorderStroke);
                    case 2:
                        return ic(A.bottomRightBorderStroke, A.bottomLeftBorderStroke);
                    case 3:
                    default:
                        return ic(A.bottomLeftBorderStroke, A.topLeftBorderStroke)
                }
            }, ic = function (A, e) {
                var t = [];
                return ka(A) ? t.push(A.subdivide(.5, !1)) : t.push(A), ka(e) ? t.push(e.subdivide(.5, !0)) : t.push(e), t
            }, sc = function (A, e, t, r) {
                var n = [];
                return ka(A) ? n.push(A.subdivide(.5, !1)) : n.push(A), ka(t) ? n.push(t.subdivide(.5, !0)) : n.push(t), ka(r) ? n.push(r.subdivide(.5, !0).reverse()) : n.push(r), ka(e) ? n.push(e.subdivide(.5, !1).reverse()) : n.push(e), n
            }, oc = function (A) {
                var e = A.bounds, t = A.styles;
                return e.add(t.borderLeftWidth, t.borderTopWidth, -(t.borderRightWidth + t.borderLeftWidth), -(t.borderTopWidth + t.borderBottomWidth))
            }, ac = function (A) {
                var e = A.styles, t = A.bounds, r = Wt(e.paddingLeft, t.width), n = Wt(e.paddingRight, t.width),
                    i = Wt(e.paddingTop, t.width), s = Wt(e.paddingBottom, t.width);
                return t.add(r + e.borderLeftWidth, i + e.borderTopWidth, -(e.borderRightWidth + e.borderLeftWidth + r + n), -(e.borderTopWidth + e.borderBottomWidth + i + s))
            }, cc = function (A, e) {
                return 0 === A ? e.bounds : 2 === A ? ac(e) : oc(e)
            }, lc = function (A, e) {
                return 0 === A ? e.bounds : 2 === A ? ac(e) : oc(e)
            }, uc = function (A, e, t) {
                var r = cc(gc(A.styles.backgroundOrigin, e), A), n = lc(gc(A.styles.backgroundClip, e), A),
                    i = hc(gc(A.styles.backgroundSize, e), t, r), s = i[0], o = i[1],
                    a = Xt(gc(A.styles.backgroundPosition, e), r.width - s, r.height - o),
                    c = pc(gc(A.styles.backgroundRepeat, e), a, i, r, n), l = Math.round(r.left + a[0]),
                    u = Math.round(r.top + a[1]);
                return [c, l, u, s, o]
            }, dc = function (A) {
                return Lt(A) && A.value === Rr.AUTO
            }, Bc = function (A) {
                return "number" === typeof A
            }, hc = function (A, e, t) {
                var r = e[0], n = e[1], i = e[2], s = A[0], o = A[1];
                if (!s) return [0, 0];
                if (_t(s) && o && _t(o)) return [Wt(s, t.width), Wt(o, t.height)];
                var a = Bc(i);
                if (Lt(s) && (s.value === Rr.CONTAIN || s.value === Rr.COVER)) {
                    if (Bc(i)) {
                        var c = t.width / t.height;
                        return c < i !== (s.value === Rr.COVER) ? [t.width, t.width / i] : [t.height * i, t.height]
                    }
                    return [t.width, t.height]
                }
                var l = Bc(r), u = Bc(n), d = l || u;
                if (dc(s) && (!o || dc(o))) {
                    if (l && u) return [r, n];
                    if (!a && !d) return [t.width, t.height];
                    if (d && a) {
                        var B = l ? r : n * i, h = u ? n : r / i;
                        return [B, h]
                    }
                    var g = l ? r : t.width, p = u ? n : t.height;
                    return [g, p]
                }
                if (a) {
                    var f = 0, w = 0;
                    return _t(s) ? f = Wt(s, t.width) : _t(o) && (w = Wt(o, t.height)), dc(s) ? f = w * i : o && !dc(o) || (w = f / i), [f, w]
                }
                var C = null, m = null;
                if (_t(s) ? C = Wt(s, t.width) : o && _t(o) && (m = Wt(o, t.height)), null === C || o && !dc(o) || (m = l && u ? C / r * n : t.height), null !== m && dc(s) && (C = l && u ? m / n * r : t.width), null !== C && null !== m) return [C, m];
                throw new Error("Unable to calculate background-size for element")
            }, gc = function (A, e) {
                var t = A[e];
                return "undefined" === typeof t ? A[0] : t
            }, pc = function (A, e, t, r, n) {
                var i = e[0], s = e[1], o = t[0], a = t[1];
                switch (A) {
                    case 2:
                        return [new Da(Math.round(r.left), Math.round(r.top + s)), new Da(Math.round(r.left + r.width), Math.round(r.top + s)), new Da(Math.round(r.left + r.width), Math.round(a + r.top + s)), new Da(Math.round(r.left), Math.round(a + r.top + s))];
                    case 3:
                        return [new Da(Math.round(r.left + i), Math.round(r.top)), new Da(Math.round(r.left + i + o), Math.round(r.top)), new Da(Math.round(r.left + i + o), Math.round(r.height + r.top)), new Da(Math.round(r.left + i), Math.round(r.height + r.top))];
                    case 1:
                        return [new Da(Math.round(r.left + i), Math.round(r.top + s)), new Da(Math.round(r.left + i + o), Math.round(r.top + s)), new Da(Math.round(r.left + i + o), Math.round(r.top + s + a)), new Da(Math.round(r.left + i), Math.round(r.top + s + a))];
                    default:
                        return [new Da(Math.round(n.left), Math.round(n.top)), new Da(Math.round(n.left + n.width), Math.round(n.top)), new Da(Math.round(n.left + n.width), Math.round(n.height + n.top)), new Da(Math.round(n.left), Math.round(n.height + n.top))]
                }
            }, fc = "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
                wc = "Hidden Text", Cc = function () {
                    function A(A) {
                        this._data = {}, this._document = A
                    }

                    return A.prototype.parseMetrics = function (A, e) {
                        var t = this._document.createElement("div"), r = this._document.createElement("img"),
                            n = this._document.createElement("span"), i = this._document.body;
                        t.style.visibility = "hidden", t.style.fontFamily = A, t.style.fontSize = e, t.style.margin = "0", t.style.padding = "0", t.style.whiteSpace = "nowrap", i.appendChild(t), r.src = fc, r.width = 1, r.height = 1, r.style.margin = "0", r.style.padding = "0", r.style.verticalAlign = "baseline", n.style.fontFamily = A, n.style.fontSize = e, n.style.margin = "0", n.style.padding = "0", n.appendChild(this._document.createTextNode(wc)), t.appendChild(n), t.appendChild(r);
                        var s = r.offsetTop - n.offsetTop + 2;
                        t.removeChild(n), t.appendChild(this._document.createTextNode(wc)), t.style.lineHeight = "normal", r.style.verticalAlign = "super";
                        var o = r.offsetTop - t.offsetTop + 2;
                        return i.removeChild(t), { baseline: s, middle: o }
                    }, A.prototype.getMetrics = function (A, e) {
                        var t = A + " " + e;
                        return "undefined" === typeof this._data[t] && (this._data[t] = this.parseMetrics(A, e)), this._data[t]
                    }, A
                }(), mc = function () {
                    function A(A, e) {
                        this.context = A, this.options = e
                    }

                    return A
                }(), Qc = 1e4, yc = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        return r._activeEffects = [], r.canvas = t.canvas ? t.canvas : document.createElement("canvas"), r.ctx = r.canvas.getContext("2d"), t.canvas || (r.canvas.width = Math.floor(t.width * t.scale), r.canvas.height = Math.floor(t.height * t.scale), r.canvas.style.width = t.width + "px", r.canvas.style.height = t.height + "px"), r.fontMetrics = new Cc(document), r.ctx.scale(r.options.scale, r.options.scale), r.ctx.translate(-t.x, -t.y), r.ctx.textBaseline = "bottom", r._activeEffects = [], r.context.logger.debug("Canvas renderer initialized (" + t.width + "x" + t.height + ") with scale " + t.scale), r
                    }

                    return e(t, A), t.prototype.applyEffects = function (A) {
                        var e = this;
                        while (this._activeEffects.length) this.popEffect();
                        A.forEach((function (A) {
                            return e.applyEffect(A)
                        }))
                    }, t.prototype.applyEffect = function (A) {
                        this.ctx.save(), Xa(A) && (this.ctx.globalAlpha = A.opacity), Ja(A) && (this.ctx.translate(A.offsetX, A.offsetY), this.ctx.transform(A.matrix[0], A.matrix[1], A.matrix[2], A.matrix[3], A.matrix[4], A.matrix[5]), this.ctx.translate(-A.offsetX, -A.offsetY)), ja(A) && (this.path(A.path), this.ctx.clip()), this._activeEffects.push(A)
                    }, t.prototype.popEffect = function () {
                        this._activeEffects.pop(), this.ctx.restore()
                    }, t.prototype.renderStack = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e;
                            return n(this, (function (t) {
                                switch (t.label) {
                                    case 0:
                                        return e = A.element.container.styles, e.isVisible() ? [4, this.renderStackContent(A)] : [3, 2];
                                    case 1:
                                        t.sent(), t.label = 2;
                                    case 2:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.renderNode = function (A) {
                        return r(this, void 0, void 0, (function () {
                            return n(this, (function (e) {
                                switch (e.label) {
                                    case 0:
                                        return ui(A.container.flags, 16), A.container.styles.isVisible() ? [4, this.renderNodeBackgroundAndBorders(A)] : [3, 3];
                                    case 1:
                                        return e.sent(), [4, this.renderNodeContent(A)];
                                    case 2:
                                        e.sent(), e.label = 3;
                                    case 3:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.renderTextWithLetterSpacing = function (A, e, t) {
                        var r = this;
                        if (0 === e) this.ctx.fillText(A.text, A.bounds.left, A.bounds.top + t); else {
                            var n = bs(A.text);
                            n.reduce((function (e, n) {
                                return r.ctx.fillText(n, e, A.bounds.top + t), e + r.ctx.measureText(n).width
                            }), A.bounds.left)
                        }
                    }, t.prototype.createFontStyle = function (A) {
                        var e = A.fontVariant.filter((function (A) {
                            return "normal" === A || "small-caps" === A
                        })).join(""), t = A.fontFamily.join(", "),
                            r = St(A.fontSize) ? "" + A.fontSize.number + A.fontSize.unit : A.fontSize.number + "px";
                        return [[A.fontStyle, e, A.fontWeight, r, t].join(" "), t, r]
                    }, t.prototype.renderTextNode = function (A, e) {
                        return r(this, void 0, void 0, (function () {
                            var t, r, i, s, o, a, c, l, u = this;
                            return n(this, (function (n) {
                                return t = this.createFontStyle(e), r = t[0], i = t[1], s = t[2], this.ctx.font = r, this.ctx.direction = 1 === e.direction ? "rtl" : "ltr", this.ctx.textAlign = "left", this.ctx.textBaseline = "alphabetic", o = this.fontMetrics.getMetrics(i, s), a = o.baseline, c = o.middle, l = e.paintOrder, A.textBounds.forEach((function (A) {
                                    l.forEach((function (t) {
                                        switch (t) {
                                            case 0:
                                                u.ctx.fillStyle = ir(e.color), u.renderTextWithLetterSpacing(A, e.letterSpacing, a);
                                                var r = e.textShadow;
                                                r.length && A.text.trim().length && (r.slice(0).reverse().forEach((function (t) {
                                                    u.ctx.shadowColor = ir(t.color), u.ctx.shadowOffsetX = t.offsetX.number * u.options.scale, u.ctx.shadowOffsetY = t.offsetY.number * u.options.scale, u.ctx.shadowBlur = t.blur.number, u.renderTextWithLetterSpacing(A, e.letterSpacing, a)
                                                })), u.ctx.shadowColor = "", u.ctx.shadowOffsetX = 0, u.ctx.shadowOffsetY = 0, u.ctx.shadowBlur = 0), e.textDecorationLine.length && (u.ctx.fillStyle = ir(e.textDecorationColor || e.color), e.textDecorationLine.forEach((function (e) {
                                                    switch (e) {
                                                        case 1:
                                                            u.ctx.fillRect(A.bounds.left, Math.round(A.bounds.top + a), A.bounds.width, 1);
                                                            break;
                                                        case 2:
                                                            u.ctx.fillRect(A.bounds.left, Math.round(A.bounds.top), A.bounds.width, 1);
                                                            break;
                                                        case 3:
                                                            u.ctx.fillRect(A.bounds.left, Math.ceil(A.bounds.top + c), A.bounds.width, 1);
                                                            break
                                                    }
                                                })));
                                                break;
                                            case 1:
                                                e.webkitTextStrokeWidth && A.text.trim().length && (u.ctx.strokeStyle = ir(e.webkitTextStrokeColor), u.ctx.lineWidth = e.webkitTextStrokeWidth, u.ctx.lineJoin = window.chrome ? "miter" : "round", u.ctx.strokeText(A.text, A.bounds.left, A.bounds.top + a)), u.ctx.strokeStyle = "", u.ctx.lineWidth = 0, u.ctx.lineJoin = "miter";
                                                break
                                        }
                                    }))
                                })), [2]
                            }))
                        }))
                    }, t.prototype.renderReplacedElement = function (A, e, t) {
                        if (t && A.intrinsicWidth > 0 && A.intrinsicHeight > 0) {
                            var r = ac(A), n = Ma(e);
                            this.path(n), this.ctx.save(), this.ctx.clip(), this.ctx.drawImage(t, 0, 0, A.intrinsicWidth, A.intrinsicHeight, r.left, r.top, r.width, r.height), this.ctx.restore()
                        }
                    }, t.prototype.renderNodeContent = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e, r, i, o, a, c, l, u, d, B, h, g, p, f, w, C, m, Q, y;
                            return n(this, (function (n) {
                                switch (n.label) {
                                    case 0:
                                        this.applyEffects(A.getEffects(4)), e = A.container, r = A.curves, i = e.styles, o = 0, a = e.textNodes, n.label = 1;
                                    case 1:
                                        return o < a.length ? (c = a[o], [4, this.renderTextNode(c, i)]) : [3, 4];
                                    case 2:
                                        n.sent(), n.label = 3;
                                    case 3:
                                        return o++, [3, 1];
                                    case 4:
                                        if (!(e instanceof qs)) return [3, 8];
                                        n.label = 5;
                                    case 5:
                                        return n.trys.push([5, 7, , 8]), [4, this.context.cache.match(e.src)];
                                    case 6:
                                        return C = n.sent(), this.renderReplacedElement(e, r, C), [3, 8];
                                    case 7:
                                        return n.sent(), this.context.logger.error("Error loading image " + e.src), [3, 8];
                                    case 8:
                                        if (e instanceof zs && this.renderReplacedElement(e, r, e.canvas), !(e instanceof $s)) return [3, 12];
                                        n.label = 9;
                                    case 9:
                                        return n.trys.push([9, 11, , 12]), [4, this.context.cache.match(e.svg)];
                                    case 10:
                                        return C = n.sent(), this.renderReplacedElement(e, r, C), [3, 12];
                                    case 11:
                                        return n.sent(), this.context.logger.error("Error loading svg " + e.svg.substring(0, 255)), [3, 12];
                                    case 12:
                                        return e instanceof ho && e.tree ? (l = new t(this.context, {
                                            scale: this.options.scale,
                                            backgroundColor: e.backgroundColor,
                                            x: 0,
                                            y: 0,
                                            width: e.width,
                                            height: e.height
                                        }), [4, l.render(e.tree)]) : [3, 14];
                                    case 13:
                                        u = n.sent(), e.width && e.height && this.ctx.drawImage(u, 0, 0, e.width, e.height, e.bounds.left, e.bounds.top, e.bounds.width, e.bounds.height), n.label = 14;
                                    case 14:
                                        if (e instanceof lo && (d = Math.min(e.bounds.width, e.bounds.height), e.type === so ? e.checked && (this.ctx.save(), this.path([new Da(e.bounds.left + .39363 * d, e.bounds.top + .79 * d), new Da(e.bounds.left + .16 * d, e.bounds.top + .5549 * d), new Da(e.bounds.left + .27347 * d, e.bounds.top + .44071 * d), new Da(e.bounds.left + .39694 * d, e.bounds.top + .5649 * d), new Da(e.bounds.left + .72983 * d, e.bounds.top + .23 * d), new Da(e.bounds.left + .84 * d, e.bounds.top + .34085 * d), new Da(e.bounds.left + .39363 * d, e.bounds.top + .79 * d)]), this.ctx.fillStyle = ir(co), this.ctx.fill(), this.ctx.restore()) : e.type === oo && e.checked && (this.ctx.save(), this.ctx.beginPath(), this.ctx.arc(e.bounds.left + d / 2, e.bounds.top + d / 2, d / 4, 0, 2 * Math.PI, !0), this.ctx.fillStyle = ir(co), this.ctx.fill(), this.ctx.restore())), Uc(e) && e.value.length) {
                                            switch (B = this.createFontStyle(i), Q = B[0], h = B[1], g = this.fontMetrics.getMetrics(Q, h).baseline, this.ctx.font = Q, this.ctx.fillStyle = ir(i.color), this.ctx.textBaseline = "alphabetic", this.ctx.textAlign = Fc(e.styles.textAlign), y = ac(e), p = 0, e.styles.textAlign) {
                                                case 1:
                                                    p += y.width / 2;
                                                    break;
                                                case 2:
                                                    p += y.width;
                                                    break
                                            }
                                            f = y.add(p, 0, 0, -y.height / 2 + 1), this.ctx.save(), this.path([new Da(y.left, y.top), new Da(y.left + y.width, y.top), new Da(y.left + y.width, y.top + y.height), new Da(y.left, y.top + y.height)]), this.ctx.clip(), this.renderTextWithLetterSpacing(new Ns(e.value, f), i.letterSpacing, g), this.ctx.restore(), this.ctx.textBaseline = "alphabetic", this.ctx.textAlign = "left"
                                        }
                                        if (!ui(e.styles.display, 2048)) return [3, 20];
                                        if (null === e.styles.listStyleImage) return [3, 19];
                                        if (w = e.styles.listStyleImage, 0 !== w.type) return [3, 18];
                                        C = void 0, m = w.url, n.label = 15;
                                    case 15:
                                        return n.trys.push([15, 17, , 18]), [4, this.context.cache.match(m)];
                                    case 16:
                                        return C = n.sent(), this.ctx.drawImage(C, e.bounds.left - (C.width + 10), e.bounds.top), [3, 18];
                                    case 17:
                                        return n.sent(), this.context.logger.error("Error loading list-style-image " + m), [3, 18];
                                    case 18:
                                        return [3, 20];
                                    case 19:
                                        A.listValue && -1 !== e.styles.listStyleType && (Q = this.createFontStyle(i)[0], this.ctx.font = Q, this.ctx.fillStyle = ir(i.color), this.ctx.textBaseline = "middle", this.ctx.textAlign = "right", y = new s(e.bounds.left, e.bounds.top + Wt(e.styles.paddingTop, e.bounds.width), e.bounds.width, In(i.lineHeight, i.fontSize.number) / 2 + 1), this.renderTextWithLetterSpacing(new Ns(A.listValue, y), i.letterSpacing, In(i.lineHeight, i.fontSize.number) / 2 + 2), this.ctx.textBaseline = "bottom", this.ctx.textAlign = "left"), n.label = 20;
                                    case 20:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.renderStackContent = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e, t, r, i, s, o, a, c, l, u, d, B, h, g, p;
                            return n(this, (function (n) {
                                switch (n.label) {
                                    case 0:
                                        return ui(A.element.container.flags, 16), [4, this.renderNodeBackgroundAndBorders(A.element)];
                                    case 1:
                                        n.sent(), e = 0, t = A.negativeZIndex, n.label = 2;
                                    case 2:
                                        return e < t.length ? (p = t[e], [4, this.renderStack(p)]) : [3, 5];
                                    case 3:
                                        n.sent(), n.label = 4;
                                    case 4:
                                        return e++, [3, 2];
                                    case 5:
                                        return [4, this.renderNodeContent(A.element)];
                                    case 6:
                                        n.sent(), r = 0, i = A.nonInlineLevel, n.label = 7;
                                    case 7:
                                        return r < i.length ? (p = i[r], [4, this.renderNode(p)]) : [3, 10];
                                    case 8:
                                        n.sent(), n.label = 9;
                                    case 9:
                                        return r++, [3, 7];
                                    case 10:
                                        s = 0, o = A.nonPositionedFloats, n.label = 11;
                                    case 11:
                                        return s < o.length ? (p = o[s], [4, this.renderStack(p)]) : [3, 14];
                                    case 12:
                                        n.sent(), n.label = 13;
                                    case 13:
                                        return s++, [3, 11];
                                    case 14:
                                        a = 0, c = A.nonPositionedInlineLevel, n.label = 15;
                                    case 15:
                                        return a < c.length ? (p = c[a], [4, this.renderStack(p)]) : [3, 18];
                                    case 16:
                                        n.sent(), n.label = 17;
                                    case 17:
                                        return a++, [3, 15];
                                    case 18:
                                        l = 0, u = A.inlineLevel, n.label = 19;
                                    case 19:
                                        return l < u.length ? (p = u[l], [4, this.renderNode(p)]) : [3, 22];
                                    case 20:
                                        n.sent(), n.label = 21;
                                    case 21:
                                        return l++, [3, 19];
                                    case 22:
                                        d = 0, B = A.zeroOrAutoZIndexOrTransformedOrOpacity, n.label = 23;
                                    case 23:
                                        return d < B.length ? (p = B[d], [4, this.renderStack(p)]) : [3, 26];
                                    case 24:
                                        n.sent(), n.label = 25;
                                    case 25:
                                        return d++, [3, 23];
                                    case 26:
                                        h = 0, g = A.positiveZIndex, n.label = 27;
                                    case 27:
                                        return h < g.length ? (p = g[h], [4, this.renderStack(p)]) : [3, 30];
                                    case 28:
                                        n.sent(), n.label = 29;
                                    case 29:
                                        return h++, [3, 27];
                                    case 30:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.mask = function (A) {
                        this.ctx.beginPath(), this.ctx.moveTo(0, 0), this.ctx.lineTo(this.canvas.width, 0), this.ctx.lineTo(this.canvas.width, this.canvas.height), this.ctx.lineTo(0, this.canvas.height), this.ctx.lineTo(0, 0), this.formatPath(A.slice(0).reverse()), this.ctx.closePath()
                    }, t.prototype.path = function (A) {
                        this.ctx.beginPath(), this.formatPath(A), this.ctx.closePath()
                    }, t.prototype.formatPath = function (A) {
                        var e = this;
                        A.forEach((function (A, t) {
                            var r = ka(A) ? A.start : A;
                            0 === t ? e.ctx.moveTo(r.x, r.y) : e.ctx.lineTo(r.x, r.y), ka(A) && e.ctx.bezierCurveTo(A.startControl.x, A.startControl.y, A.endControl.x, A.endControl.y, A.end.x, A.end.y)
                        }))
                    }, t.prototype.renderRepeat = function (A, e, t, r) {
                        this.path(A), this.ctx.fillStyle = e, this.ctx.translate(t, r), this.ctx.fill(), this.ctx.translate(-t, -r)
                    }, t.prototype.resizeImage = function (A, e, t) {
                        var r;
                        if (A.width === e && A.height === t) return A;
                        var n = null !== (r = this.canvas.ownerDocument) && void 0 !== r ? r : document,
                            i = n.createElement("canvas");
                        i.width = Math.max(1, e), i.height = Math.max(1, t);
                        var s = i.getContext("2d");
                        return s.drawImage(A, 0, 0, A.width, A.height, 0, 0, e, t), i
                    }, t.prototype.renderBackgroundImage = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e, t, r, i, s, o;
                            return n(this, (function (a) {
                                switch (a.label) {
                                    case 0:
                                        e = A.styles.backgroundImage.length - 1, t = function (t) {
                                            var i, s, o, a, c, l, u, d, B, h, g, p, f, w, C, m, Q, y, U, v, F, I, E, b, H,
                                                T, x, S, D, L, K;
                                            return n(this, (function (n) {
                                                switch (n.label) {
                                                    case 0:
                                                        if (0 !== t.type) return [3, 5];
                                                        i = void 0, s = t.url, n.label = 1;
                                                    case 1:
                                                        return n.trys.push([1, 3, , 4]), [4, r.context.cache.match(s)];
                                                    case 2:
                                                        return i = n.sent(), [3, 4];
                                                    case 3:
                                                        return n.sent(), r.context.logger.error("Error loading background-image " + s), [3, 4];
                                                    case 4:
                                                        return i && (o = uc(A, e, [i.width, i.height, i.width / i.height]), m = o[0], I = o[1], E = o[2], U = o[3], v = o[4], w = r.ctx.createPattern(r.resizeImage(i, U, v), "repeat"), r.renderRepeat(m, w, I, E)), [3, 6];
                                                    case 5:
                                                        kr(t) ? (a = uc(A, e, [null, null, null]), m = a[0], I = a[1], E = a[2], U = a[3], v = a[4], c = Cr(t.angle, U, v), l = c[0], u = c[1], d = c[2], B = c[3], h = c[4], g = document.createElement("canvas"), g.width = U, g.height = v, p = g.getContext("2d"), f = p.createLinearGradient(u, B, d, h), fr(t.stops, l).forEach((function (A) {
                                                            return f.addColorStop(A.stop, ir(A.color))
                                                        })), p.fillStyle = f, p.fillRect(0, 0, U, v), U > 0 && v > 0 && (w = r.ctx.createPattern(g, "repeat"), r.renderRepeat(m, w, I, E))) : Or(t) && (C = uc(A, e, [null, null, null]), m = C[0], Q = C[1], y = C[2], U = C[3], v = C[4], F = 0 === t.position.length ? [Jt] : t.position, I = Wt(F[0], U), E = Wt(F[F.length - 1], v), b = yr(t, I, E, U, v), H = b[0], T = b[1], H > 0 && T > 0 && (x = r.ctx.createRadialGradient(Q + I, y + E, 0, Q + I, y + E, H), fr(t.stops, 2 * H).forEach((function (A) {
                                                            return x.addColorStop(A.stop, ir(A.color))
                                                        })), r.path(m), r.ctx.fillStyle = x, H !== T ? (S = A.bounds.left + .5 * A.bounds.width, D = A.bounds.top + .5 * A.bounds.height, L = T / H, K = 1 / L, r.ctx.save(), r.ctx.translate(S, D), r.ctx.transform(1, 0, 0, L, 0, 0), r.ctx.translate(-S, -D), r.ctx.fillRect(Q, K * (y - D) + D, U, v * K), r.ctx.restore()) : r.ctx.fill())), n.label = 6;
                                                    case 6:
                                                        return e--, [2]
                                                }
                                            }))
                                        }, r = this, i = 0, s = A.styles.backgroundImage.slice(0).reverse(), a.label = 1;
                                    case 1:
                                        return i < s.length ? (o = s[i], [5, t(o)]) : [3, 4];
                                    case 2:
                                        a.sent(), a.label = 3;
                                    case 3:
                                        return i++, [3, 1];
                                    case 4:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.renderSolidBorder = function (A, e, t) {
                        return r(this, void 0, void 0, (function () {
                            return n(this, (function (r) {
                                return this.path(ec(t, e)), this.ctx.fillStyle = ir(A), this.ctx.fill(), [2]
                            }))
                        }))
                    }, t.prototype.renderDoubleBorder = function (A, e, t, i) {
                        return r(this, void 0, void 0, (function () {
                            var r, s;
                            return n(this, (function (n) {
                                switch (n.label) {
                                    case 0:
                                        return e < 3 ? [4, this.renderSolidBorder(A, t, i)] : [3, 2];
                                    case 1:
                                        return n.sent(), [2];
                                    case 2:
                                        return r = tc(i, t), this.path(r), this.ctx.fillStyle = ir(A), this.ctx.fill(), s = rc(i, t), this.path(s), this.ctx.fill(), [2]
                                }
                            }))
                        }))
                    }, t.prototype.renderNodeBackgroundAndBorders = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e, t, r, i, s, o, a, c, l = this;
                            return n(this, (function (n) {
                                switch (n.label) {
                                    case 0:
                                        return this.applyEffects(A.getEffects(2)), e = A.container.styles, t = !nr(e.backgroundColor) || e.backgroundImage.length, r = [{
                                            style: e.borderTopStyle,
                                            color: e.borderTopColor,
                                            width: e.borderTopWidth
                                        }, {
                                            style: e.borderRightStyle,
                                            color: e.borderRightColor,
                                            width: e.borderRightWidth
                                        }, {
                                            style: e.borderBottomStyle,
                                            color: e.borderBottomColor,
                                            width: e.borderBottomWidth
                                        }, {
                                            style: e.borderLeftStyle,
                                            color: e.borderLeftColor,
                                            width: e.borderLeftWidth
                                        }], i = vc(gc(e.backgroundClip, 0), A.curves), t || e.boxShadow.length ? (this.ctx.save(), this.path(i), this.ctx.clip(), nr(e.backgroundColor) || (this.ctx.fillStyle = ir(e.backgroundColor), this.ctx.fill()), [4, this.renderBackgroundImage(A.container)]) : [3, 2];
                                    case 1:
                                        n.sent(), this.ctx.restore(), e.boxShadow.slice(0).reverse().forEach((function (e) {
                                            l.ctx.save();
                                            var t = Na(A.curves), r = e.inset ? 0 : Qc,
                                                n = Ya(t, -r + (e.inset ? 1 : -1) * e.spread.number, (e.inset ? 1 : -1) * e.spread.number, e.spread.number * (e.inset ? -2 : 2), e.spread.number * (e.inset ? -2 : 2));
                                            e.inset ? (l.path(t), l.ctx.clip(), l.mask(n)) : (l.mask(t), l.ctx.clip(), l.path(n)), l.ctx.shadowOffsetX = e.offsetX.number + r, l.ctx.shadowOffsetY = e.offsetY.number, l.ctx.shadowColor = ir(e.color), l.ctx.shadowBlur = e.blur.number, l.ctx.fillStyle = e.inset ? ir(e.color) : "rgba(0,0,0,1)", l.ctx.fill(), l.ctx.restore()
                                        })), n.label = 2;
                                    case 2:
                                        s = 0, o = 0, a = r, n.label = 3;
                                    case 3:
                                        return o < a.length ? (c = a[o], 0 !== c.style && !nr(c.color) && c.width > 0 ? 2 !== c.style ? [3, 5] : [4, this.renderDashedDottedBorder(c.color, c.width, s, A.curves, 2)] : [3, 11]) : [3, 13];
                                    case 4:
                                        return n.sent(), [3, 11];
                                    case 5:
                                        return 3 !== c.style ? [3, 7] : [4, this.renderDashedDottedBorder(c.color, c.width, s, A.curves, 3)];
                                    case 6:
                                        return n.sent(), [3, 11];
                                    case 7:
                                        return 4 !== c.style ? [3, 9] : [4, this.renderDoubleBorder(c.color, c.width, s, A.curves)];
                                    case 8:
                                        return n.sent(), [3, 11];
                                    case 9:
                                        return [4, this.renderSolidBorder(c.color, s, A.curves)];
                                    case 10:
                                        n.sent(), n.label = 11;
                                    case 11:
                                        s++, n.label = 12;
                                    case 12:
                                        return o++, [3, 3];
                                    case 13:
                                        return [2]
                                }
                            }))
                        }))
                    }, t.prototype.renderDashedDottedBorder = function (A, e, t, i, s) {
                        return r(this, void 0, void 0, (function () {
                            var r, o, a, c, l, u, d, B, h, g, p, f, w, C, m, Q;
                            return n(this, (function (n) {
                                return this.ctx.save(), r = nc(i, t), o = ec(i, t), 2 === s && (this.path(o), this.ctx.clip()), ka(o[0]) ? (a = o[0].start.x, c = o[0].start.y) : (a = o[0].x, c = o[0].y), ka(o[1]) ? (l = o[1].end.x, u = o[1].end.y) : (l = o[1].x, u = o[1].y), d = 0 === t || 2 === t ? Math.abs(a - l) : Math.abs(c - u), this.ctx.beginPath(), 3 === s ? this.formatPath(r) : this.formatPath(o.slice(0, 2)), B = e < 3 ? 3 * e : 2 * e, h = e < 3 ? 2 * e : e, 3 === s && (B = e, h = e), g = !0, d <= 2 * B ? g = !1 : d <= 2 * B + h ? (p = d / (2 * B + h), B *= p, h *= p) : (f = Math.floor((d + h) / (B + h)), w = (d - f * B) / (f - 1), C = (d - (f + 1) * B) / f, h = C <= 0 || Math.abs(h - w) < Math.abs(h - C) ? w : C), g && (3 === s ? this.ctx.setLineDash([0, B + h]) : this.ctx.setLineDash([B, h])), 3 === s ? (this.ctx.lineCap = "round", this.ctx.lineWidth = e) : this.ctx.lineWidth = 2 * e + 1.1, this.ctx.strokeStyle = ir(A), this.ctx.stroke(), this.ctx.setLineDash([]), 2 === s && (ka(o[0]) && (m = o[3], Q = o[0], this.ctx.beginPath(), this.formatPath([new Da(m.end.x, m.end.y), new Da(Q.start.x, Q.start.y)]), this.ctx.stroke()), ka(o[1]) && (m = o[1], Q = o[2], this.ctx.beginPath(), this.formatPath([new Da(m.end.x, m.end.y), new Da(Q.start.x, Q.start.y)]), this.ctx.stroke())), this.ctx.restore(), [2]
                            }))
                        }))
                    }, t.prototype.render = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e;
                            return n(this, (function (t) {
                                switch (t.label) {
                                    case 0:
                                        return this.options.backgroundColor && (this.ctx.fillStyle = ir(this.options.backgroundColor), this.ctx.fillRect(this.options.x, this.options.y, this.options.width, this.options.height)), e = Ac(A), [4, this.renderStack(e)];
                                    case 1:
                                        return t.sent(), this.applyEffects([]), [2, this.canvas]
                                }
                            }))
                        }))
                    }, t
                }(mc), Uc = function (A) {
                    return A instanceof Bo || (A instanceof uo || A instanceof lo && A.type !== oo && A.type !== so)
                }, vc = function (A, e) {
                    switch (A) {
                        case 0:
                            return Na(e);
                        case 2:
                            return Ra(e);
                        case 1:
                        default:
                            return Ma(e)
                    }
                }, Fc = function (A) {
                    switch (A) {
                        case 1:
                            return "center";
                        case 2:
                            return "right";
                        case 0:
                        default:
                            return "left"
                    }
                }, Ic = function (A) {
                    function t(e, t) {
                        var r = A.call(this, e, t) || this;
                        return r.canvas = t.canvas ? t.canvas : document.createElement("canvas"), r.ctx = r.canvas.getContext("2d"), r.options = t, r.canvas.width = Math.floor(t.width * t.scale), r.canvas.height = Math.floor(t.height * t.scale), r.canvas.style.width = t.width + "px", r.canvas.style.height = t.height + "px", r.ctx.scale(r.options.scale, r.options.scale), r.ctx.translate(-t.x, -t.y), r.context.logger.debug("EXPERIMENTAL ForeignObject renderer initialized (" + t.width + "x" + t.height + " at " + t.x + "," + t.y + ") with scale " + t.scale), r
                    }

                    return e(t, A), t.prototype.render = function (A) {
                        return r(this, void 0, void 0, (function () {
                            var e, t;
                            return n(this, (function (r) {
                                switch (r.label) {
                                    case 0:
                                        return e = ks(this.options.width * this.options.scale, this.options.height * this.options.scale, this.options.scale, this.options.scale, A), [4, Ec(e)];
                                    case 1:
                                        return t = r.sent(), this.options.backgroundColor && (this.ctx.fillStyle = ir(this.options.backgroundColor), this.ctx.fillRect(0, 0, this.options.width * this.options.scale, this.options.height * this.options.scale)), this.ctx.drawImage(t, -this.options.x * this.options.scale, -this.options.y * this.options.scale), [2, this.canvas]
                                }
                            }))
                        }))
                    }, t
                }(mc), Ec = function (A) {
                    return new Promise((function (e, t) {
                        var r = new Image;
                        r.onload = function () {
                            e(r)
                        }, r.onerror = t, r.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent((new XMLSerializer).serializeToString(A))
                    }))
                }, bc = function () {
                    function A(A) {
                        var e = A.id, t = A.enabled;
                        this.id = e, this.enabled = t, this.start = Date.now()
                    }

                    return A.prototype.debug = function () {
                        for (var A = [], e = 0; e < arguments.length; e++) A[e] = arguments[e];
                        this.enabled && ("undefined" !== typeof window && window.console && "function" === typeof console.debug ? console.debug.apply(console, i([this.id, this.getTime() + "ms"], A)) : this.info.apply(this, A))
                    }, A.prototype.getTime = function () {
                        return Date.now() - this.start
                    }, A.prototype.info = function () {
                        for (var A = [], e = 0; e < arguments.length; e++) A[e] = arguments[e];
                        this.enabled && "undefined" !== typeof window && window.console && "function" === typeof console.info && console.info.apply(console, i([this.id, this.getTime() + "ms"], A))
                    }, A.prototype.warn = function () {
                        for (var A = [], e = 0; e < arguments.length; e++) A[e] = arguments[e];
                        this.enabled && ("undefined" !== typeof window && window.console && "function" === typeof console.warn ? console.warn.apply(console, i([this.id, this.getTime() + "ms"], A)) : this.info.apply(this, A))
                    }, A.prototype.error = function () {
                        for (var A = [], e = 0; e < arguments.length; e++) A[e] = arguments[e];
                        this.enabled && ("undefined" !== typeof window && window.console && "function" === typeof console.error ? console.error.apply(console, i([this.id, this.getTime() + "ms"], A)) : this.info.apply(this, A))
                    }, A.instances = {}, A
                }(), Hc = function () {
                    function A(e, t) {
                        var r;
                        this.windowBounds = t, this.instanceName = "#" + A.instanceCount++, this.logger = new bc({
                            id: this.instanceName,
                            enabled: e.logging
                        }), this.cache = null !== (r = e.cache) && void 0 !== r ? r : new va(this, e)
                    }

                    return A.instanceCount = 1, A
                }(), Tc = function (A, e) {
                    return void 0 === e && (e = {}), xc(A, e)
                };
            "undefined" !== typeof window && Ua.setContext(window);
            var xc = function (A, e) {
                return r(void 0, void 0, void 0, (function () {
                    var r, i, c, l, u, d, B, h, g, p, f, w, C, m, Q, y, U, v, F, I, E, b, H, T, x, S, D, L, K, k, O, P,
                        N, R, M, _, V, G, J;
                    return n(this, (function (n) {
                        switch (n.label) {
                            case 0:
                                if (!A || "object" !== typeof A) return [2, Promise.reject("Invalid element provided as first argument")];
                                if (r = A.ownerDocument, !r) throw new Error("Element is not attached to a Document");
                                if (i = r.defaultView, !i) throw new Error("Document is not attached to a Window");
                                return c = {
                                    allowTaint: null !== (H = e.allowTaint) && void 0 !== H && H,
                                    imageTimeout: null !== (T = e.imageTimeout) && void 0 !== T ? T : 15e3,
                                    proxy: e.proxy,
                                    useCORS: null !== (x = e.useCORS) && void 0 !== x && x
                                }, l = t({
                                    logging: null === (S = e.logging) || void 0 === S || S,
                                    cache: e.cache
                                }, c), u = {
                                    windowWidth: null !== (D = e.windowWidth) && void 0 !== D ? D : i.innerWidth,
                                    windowHeight: null !== (L = e.windowHeight) && void 0 !== L ? L : i.innerHeight,
                                    scrollX: null !== (K = e.scrollX) && void 0 !== K ? K : i.pageXOffset,
                                    scrollY: null !== (k = e.scrollY) && void 0 !== k ? k : i.pageYOffset
                                }, d = new s(u.scrollX, u.scrollY, u.windowWidth, u.windowHeight), B = new Hc(l, d), h = null !== (O = e.foreignObjectRendering) && void 0 !== O && O, g = {
                                    allowTaint: null !== (P = e.allowTaint) && void 0 !== P && P,
                                    onclone: e.onclone,
                                    ignoreElements: e.ignoreElements,
                                    inlineImages: h,
                                    copyStyles: h
                                }, B.logger.debug("Starting document clone with size " + d.width + "x" + d.height + " scrolled to " + -d.left + "," + -d.top), p = new ia(B, A, g), f = p.clonedReferenceElement, f ? [4, p.toIFrame(r, d)] : [2, Promise.reject("Unable to find element in cloned iframe")];
                            case 1:
                                return w = n.sent(), C = To(f) || bo(f) ? a(f.ownerDocument) : o(B, f), m = C.width, Q = C.height, y = C.left, U = C.top, v = Sc(B, f, e.backgroundColor), F = {
                                    canvas: e.canvas,
                                    backgroundColor: v,
                                    scale: null !== (R = null !== (N = e.scale) && void 0 !== N ? N : i.devicePixelRatio) && void 0 !== R ? R : 1,
                                    x: (null !== (M = e.x) && void 0 !== M ? M : 0) + y,
                                    y: (null !== (_ = e.y) && void 0 !== _ ? _ : 0) + U,
                                    width: null !== (V = e.width) && void 0 !== V ? V : Math.ceil(m),
                                    height: null !== (G = e.height) && void 0 !== G ? G : Math.ceil(Q)
                                }, h ? (B.logger.debug("Document cloned, using foreign object rendering"), b = new Ic(B, F), [4, b.render(f)]) : [3, 3];
                            case 2:
                                return I = n.sent(), [3, 5];
                            case 3:
                                return B.logger.debug("Document cloned, element located at " + y + "," + U + " with size " + m + "x" + Q + " using computed rendering"), B.logger.debug("Starting DOM parsing"), E = wo(B, f), v === E.styles.backgroundColor && (E.styles.backgroundColor = Br.TRANSPARENT), B.logger.debug("Starting renderer for element at " + F.x + "," + F.y + " with size " + F.width + "x" + F.height), b = new yc(B, F), [4, b.render(E)];
                            case 4:
                                I = n.sent(), n.label = 5;
                            case 5:
                                return (null === (J = e.removeContainer) || void 0 === J || J) && (ia.destroy(w) || B.logger.error("Cannot detach cloned iframe as it is not in the DOM anymore")), B.logger.debug("Finished rendering"), [2, I]
                        }
                    }))
                }))
            }, Sc = function (A, e, t) {
                var r = e.ownerDocument,
                    n = r.documentElement ? dr(A, getComputedStyle(r.documentElement).backgroundColor) : Br.TRANSPARENT,
                    i = r.body ? dr(A, getComputedStyle(r.body).backgroundColor) : Br.TRANSPARENT,
                    s = "string" === typeof t ? dr(A, t) : null === t ? Br.TRANSPARENT : 4294967295;
                return e === r.documentElement ? nr(n) ? nr(i) ? s : i : n : s
            };
            return Tc
        }))
    }, c282: function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("2582"), n = {}, i = !1, s = e.chrome && e.chrome.app && e.chrome.app.runtime;
            A.exports = {
                attachEvent: function (A, t) {
                    "undefined" !== typeof e.addEventListener ? e.addEventListener(A, t, !1) : e.document && e.attachEvent && (e.document.attachEvent("on" + A, t), e.attachEvent("on" + A, t))
                }, detachEvent: function (A, t) {
                    "undefined" !== typeof e.addEventListener ? e.removeEventListener(A, t, !1) : e.document && e.detachEvent && (e.document.detachEvent("on" + A, t), e.detachEvent("on" + A, t))
                }, unloadAdd: function (A) {
                    if (s) return null;
                    var e = r.string(8);
                    return n[e] = A, i && setTimeout(this.triggerUnloadCallbacks, 0), e
                }, unloadDel: function (A) {
                    A in n && delete n[A]
                }, triggerUnloadCallbacks: function () {
                    for (var A in n) n[A](), delete n[A]
                }
            };
            var o = function () {
                i || (i = !0, A.exports.triggerUnloadCallbacks())
            };
            s || A.exports.attachEvent("unload", o)
        }).call(this, t("c8ba"))
    }, c529: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("ada0").EventEmitter, i = t("930c"), s = t("73aa"), o = t("89bc");

        function a(A) {
            var e = this;
            n.call(this), this.ir = new o(A, s), this.ir.once("finish", (function (A, t) {
                e.ir = null, e.emit("message", i.stringify([A, t]))
            }))
        }

        r(a, n), a.transportName = "iframe-info-receiver", a.prototype.close = function () {
            this.ir && (this.ir.close(), this.ir = null), this.removeAllListeners()
        }, A.exports = a
    }, ca34: function (A, e, t) {
        (function (e) {
            A.exports = e.EventSource
        }).call(this, t("c8ba"))
    }, cc7d: function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("6945");
            A.exports = t("486c")(r), "_sockjs_onload" in e && setTimeout(e._sockjs_onload, 1)
        }).call(this, t("c8ba"))
    }, cfe6: function (A, e, t) {
        "use strict";
        (function (e) {
            e.crypto && e.crypto.getRandomValues ? A.exports.randomBytes = function (A) {
                var t = new Uint8Array(A);
                return e.crypto.getRandomValues(t), t
            } : A.exports.randomBytes = function (A) {
                for (var e = new Array(A), t = 0; t < A; t++) e[t] = Math.floor(256 * Math.random());
                return e
            }
        }).call(this, t("c8ba"))
    }, d044: function (A, e, t) {
        var r;
        (function (e, t) {
            A.exports = t()
        })(0, (function () {
            function A(A) {
                this.mode = t.MODE_8BIT_BYTE, this.data = A, this.parsedData = [];
                for (var e = 0, r = this.data.length; e < r; e++) {
                    var n = [], i = this.data.charCodeAt(e);
                    i > 65536 ? (n[0] = 240 | (1835008 & i) >>> 18, n[1] = 128 | (258048 & i) >>> 12, n[2] = 128 | (4032 & i) >>> 6, n[3] = 128 | 63 & i) : i > 2048 ? (n[0] = 224 | (61440 & i) >>> 12, n[1] = 128 | (4032 & i) >>> 6, n[2] = 128 | 63 & i) : i > 128 ? (n[0] = 192 | (1984 & i) >>> 6, n[1] = 128 | 63 & i) : n[0] = i, this.parsedData.push(n)
                }
                this.parsedData = Array.prototype.concat.apply([], this.parsedData), this.parsedData.length != this.data.length && (this.parsedData.unshift(191), this.parsedData.unshift(187), this.parsedData.unshift(239))
            }

            function e(A, e) {
                this.typeNumber = A, this.errorCorrectLevel = e, this.modules = null, this.moduleCount = 0, this.dataCache = null, this.dataList = []
            }

            A.prototype = {
                getLength: function (A) {
                    return this.parsedData.length
                }, write: function (A) {
                    for (var e = 0, t = this.parsedData.length; e < t; e++) A.put(this.parsedData[e], 8)
                }
            }, e.prototype = {
                addData: function (e) {
                    var t = new A(e);
                    this.dataList.push(t), this.dataCache = null
                }, isDark: function (A, e) {
                    if (A < 0 || this.moduleCount <= A || e < 0 || this.moduleCount <= e) throw new Error(A + "," + e);
                    return this.modules[A][e]
                }, getModuleCount: function () {
                    return this.moduleCount
                }, make: function () {
                    this.makeImpl(!1, this.getBestMaskPattern())
                }, makeImpl: function (A, t) {
                    this.moduleCount = 4 * this.typeNumber + 17, this.modules = new Array(this.moduleCount);
                    for (var r = 0; r < this.moduleCount; r++) {
                        this.modules[r] = new Array(this.moduleCount);
                        for (var n = 0; n < this.moduleCount; n++) this.modules[r][n] = null
                    }
                    this.setupPositionProbePattern(0, 0), this.setupPositionProbePattern(this.moduleCount - 7, 0), this.setupPositionProbePattern(0, this.moduleCount - 7), this.setupPositionAdjustPattern(), this.setupTimingPattern(), this.setupTypeInfo(A, t), this.typeNumber >= 7 && this.setupTypeNumber(A), null == this.dataCache && (this.dataCache = e.createData(this.typeNumber, this.errorCorrectLevel, this.dataList)), this.mapData(this.dataCache, t)
                }, setupPositionProbePattern: function (A, e) {
                    for (var t = -1; t <= 7; t++) if (!(A + t <= -1 || this.moduleCount <= A + t)) for (var r = -1; r <= 7; r++) e + r <= -1 || this.moduleCount <= e + r || (this.modules[A + t][e + r] = 0 <= t && t <= 6 && (0 == r || 6 == r) || 0 <= r && r <= 6 && (0 == t || 6 == t) || 2 <= t && t <= 4 && 2 <= r && r <= 4)
                }, getBestMaskPattern: function () {
                    for (var A = 0, e = 0, t = 0; t < 8; t++) {
                        this.makeImpl(!0, t);
                        var r = s.getLostPoint(this);
                        (0 == t || A > r) && (A = r, e = t)
                    }
                    return e
                }, createMovieClip: function (A, e, t) {
                    var r = A.createEmptyMovieClip(e, t), n = 1;
                    this.make();
                    for (var i = 0; i < this.modules.length; i++) for (var s = i * n, o = 0; o < this.modules[i].length; o++) {
                        var a = o * n, c = this.modules[i][o];
                        c && (r.beginFill(0, 100), r.moveTo(a, s), r.lineTo(a + n, s), r.lineTo(a + n, s + n), r.lineTo(a, s + n), r.endFill())
                    }
                    return r
                }, setupTimingPattern: function () {
                    for (var A = 8; A < this.moduleCount - 8; A++) null == this.modules[A][6] && (this.modules[A][6] = A % 2 == 0);
                    for (var e = 8; e < this.moduleCount - 8; e++) null == this.modules[6][e] && (this.modules[6][e] = e % 2 == 0)
                }, setupPositionAdjustPattern: function () {
                    for (var A = s.getPatternPosition(this.typeNumber), e = 0; e < A.length; e++) for (var t = 0; t < A.length; t++) {
                        var r = A[e], n = A[t];
                        if (null == this.modules[r][n]) for (var i = -2; i <= 2; i++) for (var o = -2; o <= 2; o++) this.modules[r + i][n + o] = -2 == i || 2 == i || -2 == o || 2 == o || 0 == i && 0 == o
                    }
                }, setupTypeNumber: function (A) {
                    for (var e = s.getBCHTypeNumber(this.typeNumber), t = 0; t < 18; t++) {
                        var r = !A && 1 == (e >> t & 1);
                        this.modules[Math.floor(t / 3)][t % 3 + this.moduleCount - 8 - 3] = r
                    }
                    for (t = 0; t < 18; t++) {
                        r = !A && 1 == (e >> t & 1);
                        this.modules[t % 3 + this.moduleCount - 8 - 3][Math.floor(t / 3)] = r
                    }
                }, setupTypeInfo: function (A, e) {
                    for (var t = this.errorCorrectLevel << 3 | e, r = s.getBCHTypeInfo(t), n = 0; n < 15; n++) {
                        var i = !A && 1 == (r >> n & 1);
                        n < 6 ? this.modules[n][8] = i : n < 8 ? this.modules[n + 1][8] = i : this.modules[this.moduleCount - 15 + n][8] = i
                    }
                    for (n = 0; n < 15; n++) {
                        i = !A && 1 == (r >> n & 1);
                        n < 8 ? this.modules[8][this.moduleCount - n - 1] = i : n < 9 ? this.modules[8][15 - n - 1 + 1] = i : this.modules[8][15 - n - 1] = i
                    }
                    this.modules[this.moduleCount - 8][8] = !A
                }, mapData: function (A, e) {
                    for (var t = -1, r = this.moduleCount - 1, n = 7, i = 0, o = this.moduleCount - 1; o > 0; o -= 2) {
                        6 == o && o--;
                        while (1) {
                            for (var a = 0; a < 2; a++) if (null == this.modules[r][o - a]) {
                                var c = !1;
                                i < A.length && (c = 1 == (A[i] >>> n & 1));
                                var l = s.getMask(e, r, o - a);
                                l && (c = !c), this.modules[r][o - a] = c, n--, -1 == n && (i++, n = 7)
                            }
                            if (r += t, r < 0 || this.moduleCount <= r) {
                                r -= t, t = -t;
                                break
                            }
                        }
                    }
                }
            }, e.PAD0 = 236, e.PAD1 = 17, e.createData = function (A, t, r) {
                for (var n = l.getRSBlocks(A, t), i = new u, o = 0; o < r.length; o++) {
                    var a = r[o];
                    i.put(a.mode, 4), i.put(a.getLength(), s.getLengthInBits(a.mode, A)), a.write(i)
                }
                var c = 0;
                for (o = 0; o < n.length; o++) c += n[o].dataCount;
                if (i.getLengthInBits() > 8 * c) throw new Error("code length overflow. (" + i.getLengthInBits() + ">" + 8 * c + ")");
                i.getLengthInBits() + 4 <= 8 * c && i.put(0, 4);
                while (i.getLengthInBits() % 8 != 0) i.putBit(!1);
                while (1) {
                    if (i.getLengthInBits() >= 8 * c) break;
                    if (i.put(e.PAD0, 8), i.getLengthInBits() >= 8 * c) break;
                    i.put(e.PAD1, 8)
                }
                return e.createBytes(i, n)
            }, e.createBytes = function (A, e) {
                for (var t = 0, r = 0, n = 0, i = new Array(e.length), o = new Array(e.length), a = 0; a < e.length; a++) {
                    var l = e[a].dataCount, u = e[a].totalCount - l;
                    r = Math.max(r, l), n = Math.max(n, u), i[a] = new Array(l);
                    for (var d = 0; d < i[a].length; d++) i[a][d] = 255 & A.buffer[d + t];
                    t += l;
                    var B = s.getErrorCorrectPolynomial(u), h = new c(i[a], B.getLength() - 1), g = h.mod(B);
                    o[a] = new Array(B.getLength() - 1);
                    for (d = 0; d < o[a].length; d++) {
                        var p = d + g.getLength() - o[a].length;
                        o[a][d] = p >= 0 ? g.get(p) : 0
                    }
                }
                var f = 0;
                for (d = 0; d < e.length; d++) f += e[d].totalCount;
                var w = new Array(f), C = 0;
                for (d = 0; d < r; d++) for (a = 0; a < e.length; a++) d < i[a].length && (w[C++] = i[a][d]);
                for (d = 0; d < n; d++) for (a = 0; a < e.length; a++) d < o[a].length && (w[C++] = o[a][d]);
                return w
            };
            for (var t = { MODE_NUMBER: 1, MODE_ALPHA_NUM: 2, MODE_8BIT_BYTE: 4, MODE_KANJI: 8 }, n = {
                L: 1,
                M: 0,
                Q: 3,
                H: 2
            }, i = {
                PATTERN000: 0,
                PATTERN001: 1,
                PATTERN010: 2,
                PATTERN011: 3,
                PATTERN100: 4,
                PATTERN101: 5,
                PATTERN110: 6,
                PATTERN111: 7
            }, s = {
                PATTERN_POSITION_TABLE: [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90], [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102], [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122], [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130], [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138], [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154], [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170]],
                G15: 1335,
                G18: 7973,
                G15_MASK: 21522,
                getBCHTypeInfo: function (A) {
                    var e = A << 10;
                    while (s.getBCHDigit(e) - s.getBCHDigit(s.G15) >= 0) e ^= s.G15 << s.getBCHDigit(e) - s.getBCHDigit(s.G15);
                    return (A << 10 | e) ^ s.G15_MASK
                },
                getBCHTypeNumber: function (A) {
                    var e = A << 12;
                    while (s.getBCHDigit(e) - s.getBCHDigit(s.G18) >= 0) e ^= s.G18 << s.getBCHDigit(e) - s.getBCHDigit(s.G18);
                    return A << 12 | e
                },
                getBCHDigit: function (A) {
                    var e = 0;
                    while (0 != A) e++, A >>>= 1;
                    return e
                },
                getPatternPosition: function (A) {
                    return s.PATTERN_POSITION_TABLE[A - 1]
                },
                getMask: function (A, e, t) {
                    switch (A) {
                        case i.PATTERN000:
                            return (e + t) % 2 == 0;
                        case i.PATTERN001:
                            return e % 2 == 0;
                        case i.PATTERN010:
                            return t % 3 == 0;
                        case i.PATTERN011:
                            return (e + t) % 3 == 0;
                        case i.PATTERN100:
                            return (Math.floor(e / 2) + Math.floor(t / 3)) % 2 == 0;
                        case i.PATTERN101:
                            return e * t % 2 + e * t % 3 == 0;
                        case i.PATTERN110:
                            return (e * t % 2 + e * t % 3) % 2 == 0;
                        case i.PATTERN111:
                            return (e * t % 3 + (e + t) % 2) % 2 == 0;
                        default:
                            throw new Error("bad maskPattern:" + A)
                    }
                },
                getErrorCorrectPolynomial: function (A) {
                    for (var e = new c([1], 0), t = 0; t < A; t++) e = e.multiply(new c([1, o.gexp(t)], 0));
                    return e
                },
                getLengthInBits: function (A, e) {
                    if (1 <= e && e < 10) switch (A) {
                        case t.MODE_NUMBER:
                            return 10;
                        case t.MODE_ALPHA_NUM:
                            return 9;
                        case t.MODE_8BIT_BYTE:
                            return 8;
                        case t.MODE_KANJI:
                            return 8;
                        default:
                            throw new Error("mode:" + A)
                    } else if (e < 27) switch (A) {
                        case t.MODE_NUMBER:
                            return 12;
                        case t.MODE_ALPHA_NUM:
                            return 11;
                        case t.MODE_8BIT_BYTE:
                            return 16;
                        case t.MODE_KANJI:
                            return 10;
                        default:
                            throw new Error("mode:" + A)
                    } else {
                        if (!(e < 41)) throw new Error("type:" + e);
                        switch (A) {
                            case t.MODE_NUMBER:
                                return 14;
                            case t.MODE_ALPHA_NUM:
                                return 13;
                            case t.MODE_8BIT_BYTE:
                                return 16;
                            case t.MODE_KANJI:
                                return 12;
                            default:
                                throw new Error("mode:" + A)
                        }
                    }
                },
                getLostPoint: function (A) {
                    for (var e = A.getModuleCount(), t = 0, r = 0; r < e; r++) for (var n = 0; n < e; n++) {
                        for (var i = 0, s = A.isDark(r, n), o = -1; o <= 1; o++) if (!(r + o < 0 || e <= r + o)) for (var a = -1; a <= 1; a++) n + a < 0 || e <= n + a || 0 == o && 0 == a || s == A.isDark(r + o, n + a) && i++;
                        i > 5 && (t += 3 + i - 5)
                    }
                    for (r = 0; r < e - 1; r++) for (n = 0; n < e - 1; n++) {
                        var c = 0;
                        A.isDark(r, n) && c++, A.isDark(r + 1, n) && c++, A.isDark(r, n + 1) && c++, A.isDark(r + 1, n + 1) && c++, 0 != c && 4 != c || (t += 3)
                    }
                    for (r = 0; r < e; r++) for (n = 0; n < e - 6; n++) A.isDark(r, n) && !A.isDark(r, n + 1) && A.isDark(r, n + 2) && A.isDark(r, n + 3) && A.isDark(r, n + 4) && !A.isDark(r, n + 5) && A.isDark(r, n + 6) && (t += 40);
                    for (n = 0; n < e; n++) for (r = 0; r < e - 6; r++) A.isDark(r, n) && !A.isDark(r + 1, n) && A.isDark(r + 2, n) && A.isDark(r + 3, n) && A.isDark(r + 4, n) && !A.isDark(r + 5, n) && A.isDark(r + 6, n) && (t += 40);
                    var l = 0;
                    for (n = 0; n < e; n++) for (r = 0; r < e; r++) A.isDark(r, n) && l++;
                    var u = Math.abs(100 * l / e / e - 50) / 5;
                    return t += 10 * u, t
                }
            }, o = {
                glog: function (A) {
                    if (A < 1) throw new Error("glog(" + A + ")");
                    return o.LOG_TABLE[A]
                }, gexp: function (A) {
                    while (A < 0) A += 255;
                    while (A >= 256) A -= 255;
                    return o.EXP_TABLE[A]
                }, EXP_TABLE: new Array(256), LOG_TABLE: new Array(256)
            }, a = 0; a < 8; a++) o.EXP_TABLE[a] = 1 << a;
            for (a = 8; a < 256; a++) o.EXP_TABLE[a] = o.EXP_TABLE[a - 4] ^ o.EXP_TABLE[a - 5] ^ o.EXP_TABLE[a - 6] ^ o.EXP_TABLE[a - 8];
            for (a = 0; a < 255; a++) o.LOG_TABLE[o.EXP_TABLE[a]] = a;

            function c(A, e) {
                if (void 0 == A.length) throw new Error(A.length + "/" + e);
                var t = 0;
                while (t < A.length && 0 == A[t]) t++;
                this.num = new Array(A.length - t + e);
                for (var r = 0; r < A.length - t; r++) this.num[r] = A[r + t]
            }

            function l(A, e) {
                this.totalCount = A, this.dataCount = e
            }

            function u() {
                this.buffer = [], this.length = 0
            }

            c.prototype = {
                get: function (A) {
                    return this.num[A]
                }, getLength: function () {
                    return this.num.length
                }, multiply: function (A) {
                    for (var e = new Array(this.getLength() + A.getLength() - 1), t = 0; t < this.getLength(); t++) for (var r = 0; r < A.getLength(); r++) e[t + r] ^= o.gexp(o.glog(this.get(t)) + o.glog(A.get(r)));
                    return new c(e, 0)
                }, mod: function (A) {
                    if (this.getLength() - A.getLength() < 0) return this;
                    for (var e = o.glog(this.get(0)) - o.glog(A.get(0)), t = new Array(this.getLength()), r = 0; r < this.getLength(); r++) t[r] = this.get(r);
                    for (r = 0; r < A.getLength(); r++) t[r] ^= o.gexp(o.glog(A.get(r)) + e);
                    return new c(t, 0).mod(A)
                }
            }, l.RS_BLOCK_TABLE = [[1, 26, 19], [1, 26, 16], [1, 26, 13], [1, 26, 9], [1, 44, 34], [1, 44, 28], [1, 44, 22], [1, 44, 16], [1, 70, 55], [1, 70, 44], [2, 35, 17], [2, 35, 13], [1, 100, 80], [2, 50, 32], [2, 50, 24], [4, 25, 9], [1, 134, 108], [2, 67, 43], [2, 33, 15, 2, 34, 16], [2, 33, 11, 2, 34, 12], [2, 86, 68], [4, 43, 27], [4, 43, 19], [4, 43, 15], [2, 98, 78], [4, 49, 31], [2, 32, 14, 4, 33, 15], [4, 39, 13, 1, 40, 14], [2, 121, 97], [2, 60, 38, 2, 61, 39], [4, 40, 18, 2, 41, 19], [4, 40, 14, 2, 41, 15], [2, 146, 116], [3, 58, 36, 2, 59, 37], [4, 36, 16, 4, 37, 17], [4, 36, 12, 4, 37, 13], [2, 86, 68, 2, 87, 69], [4, 69, 43, 1, 70, 44], [6, 43, 19, 2, 44, 20], [6, 43, 15, 2, 44, 16], [4, 101, 81], [1, 80, 50, 4, 81, 51], [4, 50, 22, 4, 51, 23], [3, 36, 12, 8, 37, 13], [2, 116, 92, 2, 117, 93], [6, 58, 36, 2, 59, 37], [4, 46, 20, 6, 47, 21], [7, 42, 14, 4, 43, 15], [4, 133, 107], [8, 59, 37, 1, 60, 38], [8, 44, 20, 4, 45, 21], [12, 33, 11, 4, 34, 12], [3, 145, 115, 1, 146, 116], [4, 64, 40, 5, 65, 41], [11, 36, 16, 5, 37, 17], [11, 36, 12, 5, 37, 13], [5, 109, 87, 1, 110, 88], [5, 65, 41, 5, 66, 42], [5, 54, 24, 7, 55, 25], [11, 36, 12], [5, 122, 98, 1, 123, 99], [7, 73, 45, 3, 74, 46], [15, 43, 19, 2, 44, 20], [3, 45, 15, 13, 46, 16], [1, 135, 107, 5, 136, 108], [10, 74, 46, 1, 75, 47], [1, 50, 22, 15, 51, 23], [2, 42, 14, 17, 43, 15], [5, 150, 120, 1, 151, 121], [9, 69, 43, 4, 70, 44], [17, 50, 22, 1, 51, 23], [2, 42, 14, 19, 43, 15], [3, 141, 113, 4, 142, 114], [3, 70, 44, 11, 71, 45], [17, 47, 21, 4, 48, 22], [9, 39, 13, 16, 40, 14], [3, 135, 107, 5, 136, 108], [3, 67, 41, 13, 68, 42], [15, 54, 24, 5, 55, 25], [15, 43, 15, 10, 44, 16], [4, 144, 116, 4, 145, 117], [17, 68, 42], [17, 50, 22, 6, 51, 23], [19, 46, 16, 6, 47, 17], [2, 139, 111, 7, 140, 112], [17, 74, 46], [7, 54, 24, 16, 55, 25], [34, 37, 13], [4, 151, 121, 5, 152, 122], [4, 75, 47, 14, 76, 48], [11, 54, 24, 14, 55, 25], [16, 45, 15, 14, 46, 16], [6, 147, 117, 4, 148, 118], [6, 73, 45, 14, 74, 46], [11, 54, 24, 16, 55, 25], [30, 46, 16, 2, 47, 17], [8, 132, 106, 4, 133, 107], [8, 75, 47, 13, 76, 48], [7, 54, 24, 22, 55, 25], [22, 45, 15, 13, 46, 16], [10, 142, 114, 2, 143, 115], [19, 74, 46, 4, 75, 47], [28, 50, 22, 6, 51, 23], [33, 46, 16, 4, 47, 17], [8, 152, 122, 4, 153, 123], [22, 73, 45, 3, 74, 46], [8, 53, 23, 26, 54, 24], [12, 45, 15, 28, 46, 16], [3, 147, 117, 10, 148, 118], [3, 73, 45, 23, 74, 46], [4, 54, 24, 31, 55, 25], [11, 45, 15, 31, 46, 16], [7, 146, 116, 7, 147, 117], [21, 73, 45, 7, 74, 46], [1, 53, 23, 37, 54, 24], [19, 45, 15, 26, 46, 16], [5, 145, 115, 10, 146, 116], [19, 75, 47, 10, 76, 48], [15, 54, 24, 25, 55, 25], [23, 45, 15, 25, 46, 16], [13, 145, 115, 3, 146, 116], [2, 74, 46, 29, 75, 47], [42, 54, 24, 1, 55, 25], [23, 45, 15, 28, 46, 16], [17, 145, 115], [10, 74, 46, 23, 75, 47], [10, 54, 24, 35, 55, 25], [19, 45, 15, 35, 46, 16], [17, 145, 115, 1, 146, 116], [14, 74, 46, 21, 75, 47], [29, 54, 24, 19, 55, 25], [11, 45, 15, 46, 46, 16], [13, 145, 115, 6, 146, 116], [14, 74, 46, 23, 75, 47], [44, 54, 24, 7, 55, 25], [59, 46, 16, 1, 47, 17], [12, 151, 121, 7, 152, 122], [12, 75, 47, 26, 76, 48], [39, 54, 24, 14, 55, 25], [22, 45, 15, 41, 46, 16], [6, 151, 121, 14, 152, 122], [6, 75, 47, 34, 76, 48], [46, 54, 24, 10, 55, 25], [2, 45, 15, 64, 46, 16], [17, 152, 122, 4, 153, 123], [29, 74, 46, 14, 75, 47], [49, 54, 24, 10, 55, 25], [24, 45, 15, 46, 46, 16], [4, 152, 122, 18, 153, 123], [13, 74, 46, 32, 75, 47], [48, 54, 24, 14, 55, 25], [42, 45, 15, 32, 46, 16], [20, 147, 117, 4, 148, 118], [40, 75, 47, 7, 76, 48], [43, 54, 24, 22, 55, 25], [10, 45, 15, 67, 46, 16], [19, 148, 118, 6, 149, 119], [18, 75, 47, 31, 76, 48], [34, 54, 24, 34, 55, 25], [20, 45, 15, 61, 46, 16]], l.getRSBlocks = function (A, e) {
                var t = l.getRsBlockTable(A, e);
                if (void 0 == t) throw new Error("bad rs block @ typeNumber:" + A + "/errorCorrectLevel:" + e);
                for (var r = t.length / 3, n = [], i = 0; i < r; i++) for (var s = t[3 * i + 0], o = t[3 * i + 1], a = t[3 * i + 2], c = 0; c < s; c++) n.push(new l(o, a));
                return n
            }, l.getRsBlockTable = function (A, e) {
                switch (e) {
                    case n.L:
                        return l.RS_BLOCK_TABLE[4 * (A - 1) + 0];
                    case n.M:
                        return l.RS_BLOCK_TABLE[4 * (A - 1) + 1];
                    case n.Q:
                        return l.RS_BLOCK_TABLE[4 * (A - 1) + 2];
                    case n.H:
                        return l.RS_BLOCK_TABLE[4 * (A - 1) + 3];
                    default:
                        return
                }
            }, u.prototype = {
                get: function (A) {
                    var e = Math.floor(A / 8);
                    return 1 == (this.buffer[e] >>> 7 - A % 8 & 1)
                }, put: function (A, e) {
                    for (var t = 0; t < e; t++) this.putBit(1 == (A >>> e - t - 1 & 1))
                }, getLengthInBits: function () {
                    return this.length
                }, putBit: function (A) {
                    var e = Math.floor(this.length / 8);
                    this.buffer.length <= e && this.buffer.push(0), A && (this.buffer[e] |= 128 >>> this.length % 8), this.length++
                }
            };
            var d = [[17, 14, 11, 7], [32, 26, 20, 14], [53, 42, 32, 24], [78, 62, 46, 34], [106, 84, 60, 44], [134, 106, 74, 58], [154, 122, 86, 64], [192, 152, 108, 84], [230, 180, 130, 98], [271, 213, 151, 119], [321, 251, 177, 137], [367, 287, 203, 155], [425, 331, 241, 177], [458, 362, 258, 194], [520, 412, 292, 220], [586, 450, 322, 250], [644, 504, 364, 280], [718, 560, 394, 310], [792, 624, 442, 338], [858, 666, 482, 382], [929, 711, 509, 403], [1003, 779, 565, 439], [1091, 857, 611, 461], [1171, 911, 661, 511], [1273, 997, 715, 535], [1367, 1059, 751, 593], [1465, 1125, 805, 625], [1528, 1190, 868, 658], [1628, 1264, 908, 698], [1732, 1370, 982, 742], [1840, 1452, 1030, 790], [1952, 1538, 1112, 842], [2068, 1628, 1168, 898], [2188, 1722, 1228, 958], [2303, 1809, 1283, 983], [2431, 1911, 1351, 1051], [2563, 1989, 1423, 1093], [2699, 2099, 1499, 1139], [2809, 2213, 1579, 1219], [2953, 2331, 1663, 1273]];

            function B() {
                return "undefined" != typeof CanvasRenderingContext2D
            }

            function h() {
                var A = !1, e = navigator.userAgent;
                if (/android/i.test(e)) {
                    A = !0;
                    var t = e.toString().match(/android ([0-9]\.[0-9])/i);
                    t && t[1] && (A = parseFloat(t[1]))
                }
                return A
            }

            var g = function () {
                var A = function (A, e) {
                    this._el = A, this._htOption = e
                };
                return A.prototype.draw = function (A) {
                    var e = this._htOption, t = this._el, r = A.getModuleCount();
                    Math.floor(e.width / r), Math.floor(e.height / r);

                    function n(A, e) {
                        var t = document.createElementNS("http://www.w3.org/2000/svg", A);
                        for (var r in e) e.hasOwnProperty(r) && t.setAttribute(r, e[r]);
                        return t
                    }

                    this.clear();
                    var i = n("svg", {
                        viewBox: "0 0 " + String(r) + " " + String(r),
                        width: "100%",
                        height: "100%",
                        fill: e.colorLight
                    });
                    i.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xlink", "http://www.w3.org/1999/xlink"), t.appendChild(i), i.appendChild(n("rect", {
                        fill: e.colorLight,
                        width: "100%",
                        height: "100%"
                    })), i.appendChild(n("rect", { fill: e.colorDark, width: "1", height: "1", id: "template" }));
                    for (var s = 0; s < r; s++) for (var o = 0; o < r; o++) if (A.isDark(s, o)) {
                        var a = n("use", { x: String(o), y: String(s) });
                        a.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#template"), i.appendChild(a)
                    }
                }, A.prototype.clear = function () {
                    while (this._el.hasChildNodes()) this._el.removeChild(this._el.lastChild)
                }, A
            }(), p = "svg" === document.documentElement.tagName.toLowerCase(), f = p ? g : B() ? function () {
                function A() {
                    this._elImage.src = this._elCanvas.toDataURL("image/png"), this._elImage.style.display = "block", this._elCanvas.style.display = "none"
                }

                if (this._android && this._android <= 2.1) {
                    var e = 1 / window.devicePixelRatio, t = CanvasRenderingContext2D.prototype.drawImage;
                    CanvasRenderingContext2D.prototype.drawImage = function (A, r, n, i, s, o, a, c, l) {
                        if ("nodeName" in A && /img/i.test(A.nodeName)) for (var u = arguments.length - 1; u >= 1; u--) arguments[u] = arguments[u] * e; else "undefined" == typeof c && (arguments[1] *= e, arguments[2] *= e, arguments[3] *= e, arguments[4] *= e);
                        t.apply(this, arguments)
                    }
                }

                function r(A, e) {
                    var t = this;
                    if (t._fFail = e, t._fSuccess = A, null === t._bSupportDataURI) {
                        var r = document.createElement("img"), n = function () {
                            t._bSupportDataURI = !1, t._fFail && t._fFail.call(t)
                        }, i = function () {
                            t._bSupportDataURI = !0, t._fSuccess && t._fSuccess.call(t)
                        };
                        return r.onabort = n, r.onerror = n, r.onload = i, void (r.src = "data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==")
                    }
                    !0 === t._bSupportDataURI && t._fSuccess ? t._fSuccess.call(t) : !1 === t._bSupportDataURI && t._fFail && t._fFail.call(t)
                }

                var n = function (A, e) {
                    this._bIsPainted = !1, this._android = h(), this._htOption = e, this._elCanvas = document.createElement("canvas"), this._elCanvas.width = e.width, this._elCanvas.height = e.height, A.appendChild(this._elCanvas), this._el = A, this._oContext = this._elCanvas.getContext("2d"), this._bIsPainted = !1, this._elImage = document.createElement("img"), this._elImage.alt = "Scan me!", this._elImage.style.display = "none", this._el.appendChild(this._elImage), this._bSupportDataURI = null
                };
                return n.prototype.draw = function (A) {
                    var e = this._elImage, t = this._oContext, r = this._htOption, n = A.getModuleCount(),
                        i = r.width / n, s = r.height / n, o = Math.round(i), a = Math.round(s);
                    e.style.display = "none", this.clear();
                    for (var c = 0; c < n; c++) for (var l = 0; l < n; l++) {
                        var u = A.isDark(c, l), d = l * i, B = c * s;
                        t.strokeStyle = u ? r.colorDark : r.colorLight, t.lineWidth = 1, t.fillStyle = u ? r.colorDark : r.colorLight, t.fillRect(d, B, i, s), t.strokeRect(Math.floor(d) + .5, Math.floor(B) + .5, o, a), t.strokeRect(Math.ceil(d) - .5, Math.ceil(B) - .5, o, a)
                    }
                    this._bIsPainted = !0
                }, n.prototype.makeImage = function () {
                    this._bIsPainted && r.call(this, A)
                }, n.prototype.isPainted = function () {
                    return this._bIsPainted
                }, n.prototype.clear = function () {
                    this._oContext.clearRect(0, 0, this._elCanvas.width, this._elCanvas.height), this._bIsPainted = !1
                }, n.prototype.round = function (A) {
                    return A ? Math.floor(1e3 * A) / 1e3 : A
                }, n
            }() : function () {
                var A = function (A, e) {
                    this._el = A, this._htOption = e
                };
                return A.prototype.draw = function (A) {
                    for (var e = this._htOption, t = this._el, r = A.getModuleCount(), n = Math.floor(e.width / r), i = Math.floor(e.height / r), s = ['<table style="border:0;border-collapse:collapse;">'], o = 0; o < r; o++) {
                        s.push("<tr>");
                        for (var a = 0; a < r; a++) s.push('<td style="border:0;border-collapse:collapse;padding:0;margin:0;width:' + n + "px;height:" + i + "px;background-color:" + (A.isDark(o, a) ? e.colorDark : e.colorLight) + ';"></td>');
                        s.push("</tr>")
                    }
                    s.push("</table>"), t.innerHTML = s.join("");
                    var c = t.childNodes[0], l = (e.width - c.offsetWidth) / 2, u = (e.height - c.offsetHeight) / 2;
                    l > 0 && u > 0 && (c.style.margin = u + "px " + l + "px")
                }, A.prototype.clear = function () {
                    this._el.innerHTML = ""
                }, A
            }();

            function w(A, e) {
                for (var t = 1, r = C(A), i = 0, s = d.length; i <= s; i++) {
                    var o = 0;
                    switch (e) {
                        case n.L:
                            o = d[i][0];
                            break;
                        case n.M:
                            o = d[i][1];
                            break;
                        case n.Q:
                            o = d[i][2];
                            break;
                        case n.H:
                            o = d[i][3];
                            break
                    }
                    if (r <= o) break;
                    t++
                }
                if (t > d.length) throw new Error("Too long data");
                return t
            }

            function C(A) {
                var e = encodeURI(A).toString().replace(/\%[0-9a-fA-F]{2}/g, "a");
                return e.length + (e.length != A ? 3 : 0)
            }

            return r = function (A, e) {
                if (this._htOption = {
                    width: 256,
                    height: 256,
                    typeNumber: 4,
                    colorDark: "#000000",
                    colorLight: "#ffffff",
                    correctLevel: n.H
                }, "string" === typeof e && (e = { text: e }), e) for (var t in e) this._htOption[t] = e[t];
                "string" == typeof A && (A = document.getElementById(A)), this._htOption.useSVG && (f = g), this._android = h(), this._el = A, this._oQRCode = null, this._oDrawing = new f(this._el, this._htOption), this._htOption.text && this.makeCode(this._htOption.text)
            }, r.prototype.makeCode = function (A) {
                this._oQRCode = new e(w(A, this._htOption.correctLevel), this._htOption.correctLevel), this._oQRCode.addData(A), this._oQRCode.make(), this._el.title = A, this._oDrawing.draw(this._oQRCode), this.makeImage()
            }, r.prototype.makeImage = function () {
                "function" == typeof this._oDrawing.makeImage && (!this._android || this._android >= 3) && this._oDrawing.makeImage()
            }, r.prototype.clear = function () {
                this._oDrawing.clear()
            }, r.CorrectLevel = n, r
        }))
    }, d233: function (A, e, t) {
        "use strict";
        var r = Object.prototype.hasOwnProperty, n = function () {
            for (var A = [], e = 0; e < 256; ++e) A.push("%" + ((e < 16 ? "0" : "") + e.toString(16)).toUpperCase());
            return A
        }(), i = function (A) {
            var e;
            while (A.length) {
                var t = A.pop();
                if (e = t.obj[t.prop], Array.isArray(e)) {
                    for (var r = [], n = 0; n < e.length; ++n) "undefined" !== typeof e[n] && r.push(e[n]);
                    t.obj[t.prop] = r
                }
            }
            return e
        }, s = function (A, e) {
            for (var t = e && e.plainObjects ? Object.create(null) : {}, r = 0; r < A.length; ++r) "undefined" !== typeof A[r] && (t[r] = A[r]);
            return t
        }, o = function A(e, t, n) {
            if (!t) return e;
            if ("object" !== typeof t) {
                if (Array.isArray(e)) e.push(t); else {
                    if ("object" !== typeof e) return [e, t];
                    (n.plainObjects || n.allowPrototypes || !r.call(Object.prototype, t)) && (e[t] = !0)
                }
                return e
            }
            if ("object" !== typeof e) return [e].concat(t);
            var i = e;
            return Array.isArray(e) && !Array.isArray(t) && (i = s(e, n)), Array.isArray(e) && Array.isArray(t) ? (t.forEach((function (t, i) {
                r.call(e, i) ? e[i] && "object" === typeof e[i] ? e[i] = A(e[i], t, n) : e.push(t) : e[i] = t
            })), e) : Object.keys(t).reduce((function (e, i) {
                var s = t[i];
                return r.call(e, i) ? e[i] = A(e[i], s, n) : e[i] = s, e
            }), i)
        }, a = function (A, e) {
            return Object.keys(e).reduce((function (A, t) {
                return A[t] = e[t], A
            }), A)
        }, c = function (A) {
            try {
                return decodeURIComponent(A.replace(/\+/g, " "))
            } catch (e) {
                return A
            }
        }, l = function (A) {
            if (0 === A.length) return A;
            for (var e = "string" === typeof A ? A : String(A), t = "", r = 0; r < e.length; ++r) {
                var i = e.charCodeAt(r);
                45 === i || 46 === i || 95 === i || 126 === i || i >= 48 && i <= 57 || i >= 65 && i <= 90 || i >= 97 && i <= 122 ? t += e.charAt(r) : i < 128 ? t += n[i] : i < 2048 ? t += n[192 | i >> 6] + n[128 | 63 & i] : i < 55296 || i >= 57344 ? t += n[224 | i >> 12] + n[128 | i >> 6 & 63] + n[128 | 63 & i] : (r += 1, i = 65536 + ((1023 & i) << 10 | 1023 & e.charCodeAt(r)), t += n[240 | i >> 18] + n[128 | i >> 12 & 63] + n[128 | i >> 6 & 63] + n[128 | 63 & i])
            }
            return t
        }, u = function (A) {
            for (var e = [{
                obj: { o: A },
                prop: "o"
            }], t = [], r = 0; r < e.length; ++r) for (var n = e[r], s = n.obj[n.prop], o = Object.keys(s), a = 0; a < o.length; ++a) {
                var c = o[a], l = s[c];
                "object" === typeof l && null !== l && -1 === t.indexOf(l) && (e.push({ obj: s, prop: c }), t.push(l))
            }
            return i(e)
        }, d = function (A) {
            return "[object RegExp]" === Object.prototype.toString.call(A)
        }, B = function (A) {
            return null !== A && "undefined" !== typeof A && !!(A.constructor && A.constructor.isBuffer && A.constructor.isBuffer(A))
        };
        A.exports = { arrayToObject: s, assign: a, compact: u, decode: c, encode: l, isBuffer: B, isRegExp: d, merge: o }
    }, d26f: function (A, e, t) {
        "use strict";
        var r = t("9fee"), n = t.n(r);
        n.a
    }, d46a: function (A, e, t) {
        A.exports = t.p + "static/img/xsz-no.828b8a52.png"
    }, d5e5: function (A, e, t) {
        "use strict";
        A.exports = {
            isObject: function (A) {
                var e = typeof A;
                return "function" === e || "object" === e && !!A
            }, extend: function (A) {
                if (!this.isObject(A)) return A;
                for (var e, t, r = 1, n = arguments.length; r < n; r++) for (t in e = arguments[r], e) Object.prototype.hasOwnProperty.call(e, t) && (A[t] = e[t]);
                return A
            }
        }
    }, d8d69: function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("ada0").EventEmitter, n = t("3fb5"), i = t("c282"), s = t("621f"), o = e.XMLHttpRequest,
                a = function () {
                };

            function c(A, e, t, n) {
                a(A, e);
                var i = this;
                r.call(this), setTimeout((function () {
                    i._start(A, e, t, n)
                }), 0)
            }

            n(c, r), c.prototype._start = function (A, e, t, r) {
                var n = this;
                try {
                    this.xhr = new o
                } catch (u) {
                }
                if (!this.xhr) return a("no xhr"), this.emit("finish", 0, "no xhr support"), void this._cleanup();
                e = s.addQuery(e, "t=" + +new Date), this.unloadRef = i.unloadAdd((function () {
                    a("unload cleanup"), n._cleanup(!0)
                }));
                try {
                    this.xhr.open(A, e, !0), this.timeout && "timeout" in this.xhr && (this.xhr.timeout = this.timeout, this.xhr.ontimeout = function () {
                        a("xhr timeout"), n.emit("finish", 0, ""), n._cleanup(!1)
                    })
                } catch (d) {
                    return a("exception", d), this.emit("finish", 0, ""), void this._cleanup(!1)
                }
                if (r && r.noCredentials || !c.supportsCORS || (a("withCredentials"), this.xhr.withCredentials = !0), r && r.headers) for (var l in r.headers) this.xhr.setRequestHeader(l, r.headers[l]);
                this.xhr.onreadystatechange = function () {
                    if (n.xhr) {
                        var A, e, t = n.xhr;
                        switch (a("readyState", t.readyState), t.readyState) {
                            case 3:
                                try {
                                    e = t.status, A = t.responseText
                                } catch (d) {
                                }
                                a("status", e), 1223 === e && (e = 204), 200 === e && A && A.length > 0 && (a("chunk"), n.emit("chunk", e, A));
                                break;
                            case 4:
                                e = t.status, a("status", e), 1223 === e && (e = 204), 12005 !== e && 12029 !== e || (e = 0), a("finish", e, t.responseText), n.emit("finish", e, t.responseText), n._cleanup(!1);
                                break
                        }
                    }
                };
                try {
                    n.xhr.send(t)
                } catch (d) {
                    n.emit("finish", 0, ""), n._cleanup(!1)
                }
            }, c.prototype._cleanup = function (A) {
                if (a("cleanup"), this.xhr) {
                    if (this.removeAllListeners(), i.unloadDel(this.unloadRef), this.xhr.onreadystatechange = function () {
                    }, this.xhr.ontimeout && (this.xhr.ontimeout = null), A) try {
                        this.xhr.abort()
                    } catch (e) {
                    }
                    this.unloadRef = this.xhr = null
                }
            }, c.prototype.close = function () {
                a("close"), this._cleanup(!0)
            }, c.enabled = !!o;
            var l = ["Active"].concat("Object").join("X");
            !c.enabled && l in e && (a("overriding xmlhttprequest"), o = function () {
                try {
                    return new e[l]("Microsoft.XMLHTTP")
                } catch (A) {
                    return null
                }
            }, c.enabled = !!new o);
            var u = !1;
            try {
                u = "withCredentials" in new o
            } catch (d) {
            }
            c.supportsCORS = u, A.exports = c
        }).call(this, t("c8ba"))
    }, da3d: function (A, e, t) {
        "use strict";
        var r = t("74e3"), n = t.n(r);
        n.a
    }, da9d: function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAADuUlEQVRoBe2aW28TMRBGG0opUAq0XFtagUAIgUBIvMH/l7gjXvkFIKClFyiXlobvhBi5m83a3rXXD3ikYW0n6+94duykE2aGw+EV+exMJjsm3TPydUGczsEAAEYEVgRxSW7GRi+k/qcqdlaCa4I4mVrYzF8FYHxOfk0Qy/KBeWOqax2A0VpSg2icMAMprk0A6CFOgp5PFQ0XgFn0BTVWBcHjiWq+AIiSmESDRI1mIQCIkpRsVbbs8RgUoQBGk0OLaCyYgbbXtgDoce9VQVyWt56n9Y3WihfVJhqnrDHvZgwAxMgHdsnF0GjEAjArPqcGh9e8GXBdYwOgx1kBxJLceZSnADCLXlaDz5TGozwlACA8CqLBo6m11ACI8hhITpJ04vDqA8CsnG3KduUb2D/rEwBR9PgOykf9yPoGMLp82eEAGxGZwb6v5MVsrgiYxS/mBABiITfAXG6ArDkwSvrcEci6DUsESgRKBEoESgRKBEoESgRKBJJFgHqid0Ez9pdSxJ/IH/tCxAQw4tQQqaZ6QcQCsMWlPTIgbo3bUy8xAOrEEfwgfzdVefxCV4Am8dfSGKYE6CwOXNsIRBFvCxBNvA1AVPFQgOjiIQBJxH0Bkon7AvzWGw94c8UO1Xfu88o9E12fbbivu57Jv1XuXlX/YWUsuOsDwKS/5E/l3+lYtq72fasf3PQFYOIfciC42nZDnbv2QEg7BIB59+RA/KRjGZ96t62+dzMUgInJBXKC3LDtjjo37QGfdhsA5t2VA1HdHfc0dl3ubW0BENiWP5ezTW17oM6aPdDU7gLAvF/kL+TV84DtuSJ3WlcABDbkL+U2BL8TPZLPyxstBgACH+Vv5AaCK/3qbtHQUYsFwKzv5W/lHNGvxn1dmm2gn02c31ybp5h4lbA7V27uihkBM6e3ODekADAgXtcCUCJQIlAiUCJQIlAiUCJQIlAikDsCh7kBDnID7OUG2MkJsDUYDPZzAVBr2uRPp4n/4+n191S3N23p9k2tfvSnfJ8AFLU+SfhIrbEPAFZKKYdnbgoY6v611ACs9rOEqbTWWioAqiQIU85rtBQAiG5IvFq+qwWJCUCSsWq2mLfFAjBJRuiDrCsAlXO21tQkc9G0BWClFCh3JT6xtVyi9uttAKiW86yrhWp7Xu92CACCCFd/uvEWq3ujLwCVcc7v4CSrE7XHXAAUHUmyoOKjLeBqTwMgsfi43JZ4pyRrA8BBwqqjJFkIAEcnSfbVdVPM180j2NGknN/Rk8wJq3I9vw3/v/YHErbwICLhC4UAAAAASUVORK5CYII="
    }, dd49: function (A, e, t) {
        "use strict";
        t.r(e);
        var r = function () {
            var A = this, e = A.$createElement, r = A._self._c || e;
            return r("div", { staticClass: "course-play-main" }, [r("div", {
                staticClass: "course-play-container",
                style: { height: "preview" === A.$route.query.from ? "100%" : A.coursePlayBoxHeight }
            }, [r("div", {
                staticClass: "player-container", on: {
                    click: function (e) {
                        return e.stopPropagation(), A.checkoutStatus(e)
                    }
                }
            }, [r("div", [A.hangUpFlag ? r("hangUp", {
                attrs: {
                    preventHangTime: A.preventHangTime,
                    maxTime: A.maxTime,
                    minTime: A.minTime
                }, on: { pauseOrPlay: A.pauseOrPlay, saveStudyLog: A.saveStudyLog }
            }) : A._e(), A.preventCheatFlag ? r("preventCheat", {
                ref: "preventCheat",
                attrs: {
                    preventCheatTime: A.preventCheatTime,
                    maxTime: A.maxTime,
                    minTime: A.minTime,
                    checkType: A.checkType
                },
                on: { pauseOrPlay: A.pauseOrPlay, saveStudyLog: A.saveStudyLog }
            }) : A._e()], 1), A.handoutVideo ? r("div", { staticClass: "handout-iframe-content" }, ["video" !== A.curType && "url" !== A.curType && "audio" !== A.curType && "" !== A.curType ? r("div", { staticStyle: { height: "100%" } }, [r("div", { staticStyle: { height: "calc(100% - 50px)" } }, [r("iframe", {
                staticClass: "handout-iframe",
                attrs: { src: A.handoutVideoNoteId }
            })]), r("div", { staticClass: "tips_area" }, [A.currentStudyTime > 0 && "preview" !== A.$route.query.from ? r("span", { staticClass: "tips" }, [A._v("需要 "), r("span", { staticClass: "tips-content" }, [A._v(A._s(A._f("TimeToString")(A.currentStudyTime)))]), A._v(" 完成学习")]) : A._e(), "preview" === A.$route.query.from ? r("span", { staticClass: "tips" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.preview")))]) : A._e(), r("span", {
                staticClass: "handout_span",
                on: {
                    click: function (e) {
                        return A.openHandoutOperate(A.noteId)
                    }
                }
            }, [A._v("关闭讲义")])])]) : r("iframe", {
                staticClass: "handout-iframe",
                attrs: { src: A.handoutVideoNoteId }
            })]) : A._e(), !A.isVideo || "video" !== A.curType && "audio" !== A.curType ? A._e() : r("div", { staticClass: "aliPlayer-content" }, [r("div", { staticClass: "ac-main" }, [r("aliPlayer", {
                ref: "aliPlayer",
                attrs: {
                    resetHandoutAndVideoProps: A.resetHandoutAndVideoProps,
                    id: "aliPlayer",
                    type: A.curType,
                    allowHighSpeed: A.allowHighSpeed,
                    allowMinStudyTime: A.allowMinStudyTime,
                    videoId: A.curVideoId,
                    curTime: A.curTime,
                    recordTime: A.recordTimeTemp,
                    noteId: A.noteId,
                    resourceRelId: A.resourceRelIdNoteId,
                    settingBtn: A.settingBtn,
                    seek: A.seek,
                    heartBeatFlag: A.heartBeatFlag,
                    courseId: A.courseId,
                    isNewPlay: !0
                },
                on: {
                    seeking: A.videoSeeking,
                    openAndCloseVideoParent: A.openAndCloseVideo,
                    play: A.play,
                    pause: A.pause,
                    ended: A.ended,
                    ready: A.ready,
                    timeupdate: A.timeupdate,
                    isReady: A.isReady,
                    updateAndClear: A.updateCourseRecord
                }
            })], 1), r("div", { staticClass: "additional" }, [r("div", {
                staticClass: "additional-item",
                on: {
                    click: function (e) {
                        return A.toggleCollection(A.courseInfo.hasCollected)
                    }
                }
            }, [r("div", {
                staticClass: "ai-item ai-collection",
                class: { "ai-collection_active": A.courseInfo.hasCollected }
            }), r("span", { class: { span_active: A.courseInfo.hasCollected } }, [A._v(A._s(A.courseInfo.collectionCount || 0))])]), r("div", {
                staticClass: "additional-item",
                on: {
                    click: function (e) {
                        return A.toggleThumbsUp(A.courseInfo.hasPraised)
                    }
                }
            }, [r("div", {
                staticClass: "ai-item ai-thumbs-up",
                class: { "ai-thumbs-up_active": A.courseInfo.hasPraised }
            }), r("span", { class: { span_active: A.courseInfo.hasPraised } }, [A._v(A._s(A.courseInfo.praiseCount || 0))])]), r("div", {
                staticClass: "additional-item",
                on: { click: A.shareCourse }
            }, [r("div", { staticClass: "ai-item ai-share" }), r("span", [A._v("分享")])])])]), "url" === A.curType ? [r("div", { staticClass: "aliPlayer-content" }, [r("div", {
                staticClass: "ac-main",
                staticStyle: { position: "relative" }
            }, [A.urlJson && A.urlJson.content ? r("iframe", {
                ref: "urlContent",
                staticClass: "iframe-content",
                attrs: { src: A.urlJson.content }
            }) : r("div", {
                ref: "urlContent",
                staticClass: "iframe-content",
                domProps: { innerHTML: A._s(A.urlJson && A.urlJson.code) }
            }), "preview" !== A.$route.query.from && A.currentStudyTime > 0 && A.urlJson && A.urlJson.minStudyTime ? r("span", { staticClass: "min-study" }, [A._v("需要 " + A._s(A._f("TimeToString")(A.currentStudyTime)) + "完成学习\n        "), r("span", {
                staticClass: "icon iconfont icon-quanping full-screen",
                on: {
                    click: function (e) {
                        return A.toFullVideo(A.$refs.urlContent)
                    }
                }
            })]) : A._e(), "preview" !== A.$route.query.from && A.urlJson && (0 === A.currentStudyTime || A.urlJson.confirmFinish) && A.urlJson.minStudyTime ? r("span", { staticClass: "min-study" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.completedLearning")) + "\n        "), r("span", {
                staticClass: "icon iconfont icon-quanping full-screen",
                on: {
                    click: function (e) {
                        return A.toFullVideo(A.$refs.urlContent)
                    }
                }
            })]) : A._e(), "preview" === A.$route.query.from ? r("span", { staticClass: "min-study" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.preview")) + "\n        "), r("span", {
                staticClass: "icon iconfont icon-quanping full-screen",
                on: {
                    click: function (e) {
                        return A.toFullVideo(A.$refs.urlContent)
                    }
                }
            })]) : A._e()]), r("div", { staticClass: "additional" }, [r("div", {
                staticClass: "additional-item",
                on: {
                    click: function (e) {
                        return A.toggleCollection(A.courseInfo.hasCollected)
                    }
                }
            }, [r("div", {
                staticClass: "ai-item ai-collection",
                class: { "ai-collection_active": A.courseInfo.hasCollected }
            }), r("span", { class: { span_active: A.courseInfo.hasCollected } }, [A._v(A._s(A.courseInfo.collectionCount || 0))])]), r("div", {
                staticClass: "additional-item",
                on: {
                    click: function (e) {
                        return A.toggleThumbsUp(A.courseInfo.hasPraised)
                    }
                }
            }, [r("div", {
                staticClass: "ai-item ai-thumbs-up",
                class: { "ai-thumbs-up_active": A.courseInfo.hasPraised }
            }), r("span", { class: { span_active: A.courseInfo.hasPraised } }, [A._v(A._s(A.courseInfo.praiseCount || 0))])]), r("div", {
                staticClass: "additional-item",
                on: { click: A.shareCourse }
            }, [r("div", { staticClass: "ai-item ai-share" }), r("span", [A._v("分享")])])])])] : A._e(), "video" !== A.curType && "url" !== A.curType && "audio" !== A.curType && "" !== A.curType ? r("div", { staticClass: "aliPlayer-content" }, [r("div", { staticClass: "ac-main" }, [A.handoutVideo ? A._e() : r("aliyun-preview", {
                ref: "aliPreview",
                attrs: {
                    allowDrag: A.allowDrag,
                    noteId: A.noteId,
                    resourceRelId: A.curVideoId,
                    pageIndex: A.pageIndex,
                    isFinish: A.curInfo.finish
                },
                on: { isReady: A.isReady },
                scopedSlots: A._u([{
                    key: "handoutSpan", fn: function () {
                        return [r("span", {
                            staticClass: "handout_span", on: {
                                click: function (e) {
                                    return A.openHandoutOperate(A.noteId)
                                }
                            }
                        }, [A._v("讲义")])]
                    }, proxy: !0
                }], null, !1, 3578998395)
            }, [A.currentStudyTime > 0 && "preview" !== A.$route.query.from ? r("span", { staticClass: "tips" }, [A._v("需要 "), r("span", { staticClass: "tips-content" }, [A._v(A._s(A._f("TimeToString")(A.currentStudyTime)))]), A._v(" 完成学习")]) : A._e(), "preview" === A.$route.query.from ? r("span", { staticClass: "tips" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.preview")))]) : A._e()])], 1), r("div", { staticClass: "additional" }, [r("div", {
                staticClass: "additional-item",
                on: {
                    click: function (e) {
                        return A.toggleCollection(A.courseInfo.hasCollected)
                    }
                }
            }, [r("div", {
                staticClass: "ai-item ai-collection",
                class: { "ai-collection_active": A.courseInfo.hasCollected }
            }), r("span", { class: { span_active: A.courseInfo.hasCollected } }, [A._v(A._s(A.courseInfo.collectionCount || 0))])]), r("div", {
                staticClass: "additional-item",
                on: {
                    click: function (e) {
                        return A.toggleThumbsUp(A.courseInfo.hasPraised)
                    }
                }
            }, [r("div", {
                staticClass: "ai-item ai-thumbs-up",
                class: { "ai-thumbs-up_active": A.courseInfo.hasPraised }
            }), r("span", { class: { span_active: A.courseInfo.hasPraised } }, [A._v(A._s(A.courseInfo.praiseCount || 0))])]), r("div", {
                staticClass: "additional-item",
                on: { click: A.shareCourse }
            }, [r("div", { staticClass: "ai-item ai-share" }), r("span", [A._v("分享")])])])]) : A._e(), r("el-dialog", {
                staticClass: "share-window",
                attrs: { width: "404px", visible: A.shareVisible, "append-to-body": "", "show-close": !1 },
                on: {
                    "update:visible": function (e) {
                        A.shareVisible = e
                    }
                }
            }, [r("div", { staticClass: "sw-main" }, [r("div", {
                staticStyle: {
                    "background-color": "#FFFFFF",
                    "border-radius": "15px"
                }
            }, [r("img", { attrs: { src: A.courseInfo.courseImage || "", alt: "" } }), r("i", {
                staticClass: "el-icon-close",
                on: { click: A.closeDialog }
            }), r("div", { staticClass: "swm-content" }, [r("div", { staticClass: "sc-top" }, [r("div", { staticClass: "top-line" }), r("p", { staticClass: "rate-title" }, [A._v(A._s(A.courseInfo.courseTitle || ""))]), r("div", { staticClass: "rate-area" }, [A.courseInfo && A.courseInfo.teacherList && A.courseInfo.teacherList.length ? r("div", { staticClass: "rate-area-span" }, [r("div", { staticStyle: { width: "38px" } }, [A._v("讲师：")]), r("div", {
                staticStyle: {
                    width: "80px",
                    "text-overflow": "ellipsis",
                    "overflow-x": "hidden",
                    "white-space": "nowrap"
                }
            }, [A._v("\n                      " + A._s(A.ellipsisSpan()) + "\n                    ")]), r("span", [A._v("等" + A._s(A.courseInfo.teacherList.length) + "人")])]) : A._e(), r("el-rate", {
                attrs: {
                    disabled: "",
                    "show-score": "",
                    "text-color": "rgba(0,0,0,0.65)",
                    "score-template": "{value}"
                }, model: {
                    value: A.courseInfo.avgPoint, callback: function (e) {
                        A.$set(A.courseInfo, "avgPoint", e)
                    }, expression: "courseInfo.avgPoint"
                }
            }), r("span", { staticStyle: { color: "rgba(0,0,0,0.65)" } }, [A._v("分")])], 1)]), r("div", { staticClass: "sc-bottom" }, [r("div", { staticClass: "scb-href-area" }, [r("div", { staticClass: "area-item" }, [r("div", { staticClass: "ai-l" }, [r("span", [A._v("PC端：")]), r("span", { attrs: { title: A.courseInfo.courseInfoShortUrl || "" } }, [A._v(A._s(A.courseInfo.courseInfoShortUrl || ""))])]), r("div", {
                staticClass: "ai-r",
                on: {
                    click: function (e) {
                        return A.copyText(A.courseInfo.courseInfoShortUrl || "")
                    }
                }
            }, [A._v("复制")])]), r("div", { staticClass: "area-item" }, [r("div", { staticClass: "ai-l" }, [r("span", [A._v("移动端：")]), r("span", { attrs: { title: A.courseInfo.qrCodePath || "" } }, [A._v(A._s(A.courseInfo.qrCodePath || ""))])]), r("div", {
                staticClass: "ai-r",
                on: {
                    click: function (e) {
                        return A.copyText(A.courseInfo.qrCodePath || "")
                    }
                }
            }, [A._v("复制")])])]), r("div", { staticClass: "qrcode-area" }, [r("el-image", {
                ref: "myImg",
                staticClass: "my-img",
                attrs: {
                    src: "/els/html/courseInfo/courseinfo.createQRCodeForGeneral.do?courseId=" + A.courseId,
                    "preview-src-list": ["/els/html/courseInfo/courseinfo.createQRCodeForGeneral.do?courseId=" + A.courseId]
                }
            })], 1)])])]), r("div", { staticClass: "swm-download" }, [r("div", {
                staticClass: "swm-download-btn",
                on: {
                    click: function (e) {
                        return A.saveDownload("sw-main")
                    }
                }
            }, [r("img", {
                attrs: {
                    src: A.icon_download,
                    alt: ""
                }
            }), r("span", [A._v("下载到本地")])])])])]), r("div", {
                staticClass: "share-window",
                staticStyle: { display: "none" },
                attrs: { id: "sw-main-content" }
            }, [r("div", {
                staticClass: "sw-main",
                attrs: { id: "sw-main" }
            }, [r("div", {
                staticStyle: {
                    "background-color": "#FFFFFF",
                    "border-radius": "15px"
                }
            }, [r("img", {
                attrs: {
                    crossOrigin: "anonymous",
                    id: "sw-main-img",
                    src: A.courseInfo.courseImage || "",
                    alt: ""
                }
            }), r("div", { staticClass: "swm-content" }, [r("div", { staticClass: "sc-top" }, [r("div", { staticClass: "top-line" }), r("p", { staticClass: "rate-title" }, [A._v(A._s(A.courseInfo.courseTitle || ""))]), r("div", { staticClass: "rate-area" }, [A.courseInfo && A.courseInfo.teacherList && A.courseInfo.teacherList.length ? r("div", { staticClass: "rate-area-span" }, [r("div", { staticStyle: { width: "38px" } }, [A._v("讲师：")]), r("div", {
                staticStyle: {
                    width: "80px",
                    "text-overflow": "ellipsis",
                    "overflow-x": "hidden",
                    "white-space": "nowrap"
                }
            }, [A._v("\n                    " + A._s(A.ellipsisSpan()) + "\n")]), r("span", [A._v("等" + A._s(A.courseInfo.teacherList.length) + "人")])]) : A._e(), r("el-rate", {
                attrs: {
                    disabled: "",
                    "show-score": "",
                    "text-color": "rgba(0,0,0,0.65)",
                    "score-template": "{value}"
                }, model: {
                    value: A.courseInfo.avgPoint, callback: function (e) {
                        A.$set(A.courseInfo, "avgPoint", e)
                    }, expression: "courseInfo.avgPoint"
                }
            }), r("span", { staticStyle: { color: "rgba(0,0,0,0.65)" } }, [A._v("分")])], 1)]), r("div", { staticClass: "sc-bottom" }, [A._m(0), r("div", { staticClass: "qrcode-area-download" }, [r("img", {
                attrs: {
                    src: "/els/html/courseInfo/courseinfo.createQRCodeForGeneral.do?courseId=" + A.courseId,
                    alt: ""
                }
            })])])])])])]), !A.isPlaying && A.isReplayBtn ? r("div", {
                staticClass: "player-endInfo",
                class: { "has-replay-btn": A.mustReplayCanFinish }
            }, [A.mustReplayCanFinish ? r("div", { staticClass: "player-replay-tip" }, [r("span", [A._v(A._s(A.$t("v4.js.pc.ocmt.replayTips1")))]), r("span", [A._v(A._s(A.$t("v4.js.pc.ocmt.replayTips2")))])]) : A._e(), r("div", { staticClass: "player-opt-btn" }, [A.mustReplayCanFinish ? r("button", {
                staticClass: "replay-btn",
                on: { click: A.rePlay }
            }, [A._v(A._s(A.$t("v4.js.pc.ocmt.reView")))]) : A._e(), "unionpay" === A.corpCode ? [A.nextIndex ? A._e() : r("p", ["zh" === A.language ? r("span", [A._v(A._s(A.$t("v4.js.pc.ocmt.Islastsection")))]) : r("span", [A._v("This is the last section")])])] : [A.nextIndex ? r("button", {
                staticClass: "next-button",
                on: { click: A.playNextSection }
            }, [A._v(A._s(A.$t("v4.js.pc.ocmt.nextSection")))]) : r("p", ["zh" === A.language ? r("span", [A._v("已是最后一节")]) : r("span", [A._v("This is the last section")])])]], 2)]) : A._e()], 2), r("div", {
                staticClass: "rightList-container",
                style: A.open ? "" : "width:0;"
            }, [r("div", { style: A.open ? "width: 100%;border-bottom: 1px solid rgba(255,255,255,0.14);" : "width: 100%;" }, [r("el-tabs", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: A.open,
                    expression: "open"
                }],
                staticClass: "el-tabs",
                attrs: { id: "el-tabsA", stretch: "" },
                on: { "tab-click": A.handletabClick },
                model: {
                    value: A.activeName, callback: function (e) {
                        A.activeName = e
                    }, expression: "activeName"
                }
            }, [r("el-tab-pane", {
                attrs: {
                    label: A.$t("v4.js.pc.ocmt.contents"),
                    name: "contents"
                }
            }), "preview" !== A.$route.query.from ? r("el-tab-pane", {
                attrs: {
                    label: A.$t("v4.js.pc.ocmt.note"),
                    name: "note"
                }
            }) : A._e(), "preview" !== A.$route.query.from ? r("el-tab-pane", {
                attrs: {
                    label: A.$t("v4.js.pc.ocmt.QA"),
                    name: "QA"
                }
            }) : A._e()], 1)], 1), r("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "contents" === A.activeName,
                    expression: 'activeName ==="contents"'
                }],
                staticClass: "chapter-container",
                class: { "bg-black": !A.open },
                style: { height: A.open ? "calc(100% - 104px)" : "calc(100% - 48px)" }
            }, [r("div", {
                staticClass: "collapse-box-btn",
                on: { mouseenter: A.enterDefault, mouseleave: A.leaveDefault }
            }, [r("img", {
                directives: [{ name: "show", rawName: "v-show", value: A.open, expression: "open" }],
                staticStyle: { transform: "scale(0.5)" },
                attrs: { src: A.isHoverActive ? A.btnRightActive : A.btnRightDefault, alt: "" },
                on: {
                    click: function (e) {
                        A.open = !A.open
                    }
                }
            }), r("img", {
                directives: [{ name: "show", rawName: "v-show", value: !A.open, expression: "!open" }],
                staticStyle: { transform: "scale(0.5)" },
                attrs: { src: A.isHoverActive ? A.btnLeftActive : A.btnLeftDefault, alt: "" },
                on: {
                    click: function (e) {
                        A.open = !A.open
                    }
                }
            })]), r("div", {
                directives: [{ name: "show", rawName: "v-show", value: A.open, expression: "open" }],
                staticClass: "chapter-section-box"
            }, [r("div", { staticClass: "chapter-box" }, A._l(A.courseData, (function (e, t) {
                return r("ul", { key: t }, [A.courseData && A.courseData.length > 1 ? r("li", {
                    staticClass: "chapter",
                    attrs: { title: e.chapterName },
                    on: {
                        click: function (r) {
                            return A.toggleCollapse(e, t)
                        }
                    }
                }, ["zh_CN" === A.language ? r("span", [A._v("第" + A._s(A._f("convertToChinaNum")(t + 1)) + "章 " + A._s(e.chapterName))]) : r("span", [A._v("Chapter " + A._s(t + 1))])]) : A._e(), r("div", { staticClass: "section" }, A._l(e.resourceDTOS, (function (e, n) {
                    return r("li", {
                        key: n,
                        staticClass: "section-item",
                        class: { finish: e.finish },
                        on: {
                            click: function (r) {
                                return A.checkoutSection(e, t, n)
                            }
                        }
                    }, [r("div", {
                        class: {
                            "first-line": !0,
                            active: A.curId === e.resourceId
                        }
                    }, [r("span", {
                        staticClass: "icon-box",
                        attrs: { title: e.resourceName }
                    }, ["video" === e.resourceType ? r("div", { staticClass: "icon-span-block" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.icon_video")))]) : A._e(), "audio" === e.resourceType ? r("div", { staticClass: "icon-span-block" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.icon_audio")))]) : A._e(), "document" === e.resourceType ? r("div", { staticClass: "icon-span-block" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.icon_document")))]) : A._e(), "url" === e.resourceType ? r("div", { staticClass: "icon-span-block" }, [A._v(A._s(A.$t("v4.js.pc.ocmt.icon_url")))]) : A._e(), r("span", {
                        staticClass: "section-title",
                        style: { maxWidth: e.finish || !e.finish && A.curId === e.resourceId ? "140px" : "240px" }
                    }, [A._v(A._s(e.resourceName))])]), e.finish ? r("span", { staticClass: "finish-tig finish-tig-item" }, [r("img", {
                        staticStyle: {
                            transform: "scale(0.5,0.5)",
                            "margin-right": "4px"
                        }, attrs: { src: A.icon_completed, alt: "" }
                    }), A._v("\n                      " + A._s(A.$t("v4.js.pc.ocmt.completed")) + "\n                    ")]) : A._e(), e.finish || A.curId !== e.resourceId ? A._e() : r("span", { staticClass: "finish-tig-item" }, [r("img", {
                        staticStyle: {
                            transform: "scale(0.5,0.5)",
                            "margin-right": "4px"
                        }, attrs: { src: A.icon_learning, alt: "" }
                    }), "zh_CN" === A.language ? r("span", [A._v("学习中")]) : r("span", [A._v("learning")])])]), r("div", { staticClass: "second-line" }, ["video" !== e.resourceType && "audio" !== e.resourceType && e.minStudyTime ? r("span", [A._v("\n                      " + A._s(A.$t("v4.js.pc.ocmt.minStudyTime")) + ": " + A._s(A._f("TimeToString")(e.minStudyTime)) + "\n                    ")]) : A._e(), "video" === e.resourceType || "audio" === e.resourceType ? [A.allowMinStudyTime && e.minStudyTime ? r("span", [A._v("\n                          " + A._s(A.$t("v4.js.pc.ocmt.minStudyTime")) + ": " + A._s(A._f("TimeToString")(e.minStudyTime)) + "\n                        ")]) : r("span", [A._v("\n                            " + A._s("video" === e.resourceType ? "zh_CN" === A.language ? "视频时长:" : "Video Duration: " : "zh_CN" === A.language ? "音频时长: " : "Audio Duration: ") + A._s(A._f("TimeToString")(e.playTime)) + "\n                        ")])] : A._e()], 2)])
                })), 0)])
            })), 0)])]), r("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "note" === A.activeName,
                    expression: 'activeName ==="note"'
                }],
                staticClass: "QA-container",
                class: { "bg-black": !A.open },
                style: { height: A.open ? "calc(100% - 104px)" : "calc(100% - 48px)" }
            }, [r("div", {
                staticClass: "QA-box-btn",
                on: { mouseenter: A.enterDefault, mouseleave: A.leaveDefault }
            }, [r("img", {
                directives: [{ name: "show", rawName: "v-show", value: A.open, expression: "open" }],
                staticStyle: { transform: "scale(0.5)" },
                attrs: { src: A.isHoverActive ? A.btnRightActive : A.btnRightDefault, alt: "" },
                on: {
                    click: function (e) {
                        A.open = !A.open
                    }
                }
            }), r("img", {
                directives: [{ name: "show", rawName: "v-show", value: !A.open, expression: "!open" }],
                staticStyle: { transform: "scale(0.5)" },
                attrs: { src: A.isHoverActive ? A.btnLeftActive : A.btnLeftDefault, alt: "" },
                on: {
                    click: function (e) {
                        A.open = !A.open
                    }
                }
            })]), r("div", {
                directives: [{ name: "show", rawName: "v-show", value: A.open, expression: "open" }],
                staticClass: "QA-section-box"
            }, [r("div", { staticClass: "note-nav" }, [r("span", {
                style: { color: "myNote" === A.navMsg ? "#1888FF" : "" },
                on: {
                    click: function (e) {
                        return A.navToggle("myNote")
                    }
                }
            }, [A._v("我的笔记")]), r("span", {
                style: { color: "otherNote" === A.navMsg ? "#1888FF" : "" },
                on: {
                    click: function (e) {
                        return A.navToggle("otherNote")
                    }
                }
            }, [A._v("他人笔记")])]), A.isCreateNote || "myNote" !== A.navMsg ? A._e() : r("div", { staticClass: "note-list" }, [r("div", { staticClass: "note-list-content" }, [A._l(A.myNotes, (function (e, n) {
                return r("div", {
                    key: n, staticClass: "nlc-item", on: {
                        mouseenter: function (e) {
                            return A.noteEnter("note-item-s" + n)
                        }, mouseleave: function (e) {
                            return A.noteLeave("note-item-s" + n)
                        }
                    }
                }, [r("img", {
                    staticClass: "nlc-item-title",
                    attrs: { src: t("15ba"), alt: "" }
                }), r("div", {
                    staticClass: "nlc-item-text",
                    style: { width: A.noteMsg === "note-item-s" + n + "-enter" ? "120px" : "254px" },
                    on: {
                        click: function (t) {
                            return A.showDownLoadDialog(e)
                        }
                    }
                }, [A._v("\n                  " + A._s(e.noteName || e.content || "") + "\n                ")]), A.noteMsg === "note-item-s" + n + "-enter" ? r("div", { staticClass: "icon-area" }, [e.isSecret ? A._e() : r("div", {
                    staticClass: "icon_open_item",
                    attrs: { title: "已公开" },
                    on: {
                        click: function (t) {
                            return A.sendNote("toggle", e, "close")
                        }
                    }
                }), e.isSecret ? r("div", {
                    staticClass: "icon_close_item",
                    attrs: { title: "已保密" },
                    on: {
                        click: function (t) {
                            return A.sendNote("toggle", e, "open")
                        }
                    }
                }) : A._e(), A.isShowJumpPeriod(e) ? r("div", {
                    staticClass: "icon_href_item",
                    attrs: { title: "跳转" },
                    on: {
                        click: function (t) {
                            return A.jumpPeriod(e)
                        }
                    }
                }) : A._e(), r("div", {
                    staticClass: "icon_edit_item", attrs: { title: "编辑" }, on: {
                        click: function (t) {
                            return A.editPeriod(e)
                        }
                    }
                }), r("div", {
                    staticClass: "icon_delete_item", attrs: { title: "删除" }, on: {
                        click: function (t) {
                            return A.delMyNote(e)
                        }
                    }
                })]) : A._e()])
            })), A.myNotes.length ? A._e() : r("div", {
                staticStyle: {
                    width: "100%",
                    "text-align": "center",
                    "font-size": "14px"
                }
            }, [A._v("\n                暂无笔记~~\n              ")])], 2), r("div", { staticClass: "note-toggle-btn" }, [r("div", {
                staticClass: "note-toggle-btn__block",
                on: { click: A.toggleCreateNote }
            }, [r("i", { staticClass: "el-icon-notebook-2" }), r("span", [A._v("添加笔记")])])])]), "otherNote" === A.navMsg ? r("div", { staticClass: "note-list other-note-list" }, [A.otherNotes.length ? r("div", { staticStyle: { width: "100%" } }, [r("div", {
                staticStyle: {
                    width: "100%",
                    height: "326px",
                    "overflow-y": "auto"
                }
            }, A._l(A.otherNotes, (function (e, n) {
                return r("div", { key: n, staticClass: "nlh-content nlh-content-new" }, [r("div", {
                    staticClass: "nc-left",
                    on: {
                        click: function (t) {
                            return A.showDownLoadDialog(e)
                        }
                    }
                }, [r("img", { attrs: { src: t("15ba"), alt: "" } })]), r("div", {
                    staticClass: "nc-right",
                    staticStyle: { cursor: "pointer" }
                }, [r("div", {
                    staticClass: "nlh-content-title nlh-content-dir", on: {
                        click: function (t) {
                            return A.showDownLoadDialog(e)
                        }
                    }
                }, [r("span", { staticClass: "note-name" }, [A._v(A._s(e.noteName || ""))])]), r("div", { staticClass: "nlh-content-info" }, [r("div", {
                    staticClass: "info-time",
                    on: {
                        click: function (t) {
                            return A.showDownLoadDialog(e)
                        }
                    }
                }, [A._v(A._s(e.lastModifyTime || e.createTime || ""))]), r("div", { staticClass: "info-icons" }, [A.isShowJumpPeriod(e) ? r("div", {
                    staticClass: "info-icons-item jump",
                    attrs: { title: "跳转" },
                    on: {
                        click: function (t) {
                            return A.jumpPeriod(e)
                        }
                    }
                }, [r("div")]) : A._e()])])])])
            })), 0)]) : A._e(), A.otherNotes.length ? A._e() : r("div", {
                staticStyle: {
                    width: "100%",
                    "text-align": "center",
                    "font-size": "14px",
                    "padding-left": "18px"
                }
            }, [A._v("\n                暂无笔记~~\n            ")])]) : A._e(), A.isCreateNote ? r("div", { staticClass: "note-create" }, [r("el-input", {
                staticClass: "note-create-textarea-1",
                staticStyle: { height: "64px" },
                attrs: {
                    type: "textarea",
                    placeholder: "请输入你的笔记标题",
                    maxlength: "50",
                    "show-word-limit": "",
                    resize: "none"
                },
                model: {
                    value: A.createNote.note_title, callback: function (e) {
                        A.$set(A.createNote, "note_title", e)
                    }, expression: "createNote.note_title"
                }
            }), r("el-input", {
                staticClass: "note-create-textarea-2",
                attrs: {
                    type: "textarea",
                    placeholder: "请输入你的笔记内容（必填）",
                    resize: "none",
                    maxlength: "1300",
                    "show-word-limit": ""
                },
                model: {
                    value: A.createNote.note_content, callback: function (e) {
                        A.$set(A.createNote, "note_content", e)
                    }, expression: "createNote.note_content"
                }
            }), r("div", { staticClass: "secrecy_submit_footer" }, [r("div", { staticClass: "ssf-l" }, [r("el-checkbox", {
                class: { "secrecy-create": !A.createNote.secrecy },
                model: {
                    value: A.createNote.secrecy, callback: function (e) {
                        A.$set(A.createNote, "secrecy", e)
                    }, expression: "createNote.secrecy"
                }
            }), A._m(1)], 1), r("div", { staticClass: "ssf-r" }, [r("el-button", {
                attrs: {
                    type: "primary",
                    size: "mini",
                    disabled: A.createNote.isSendShow
                }, on: { click: A.sendNote }
            }, [A._v(A._s("create" === A.noteStatus ? "发布" : "保存"))])], 1)])], 1) : A._e()])]), r("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "QA" === A.activeName,
                    expression: 'activeName ==="QA"'
                }],
                staticClass: "QA-container",
                class: { "bg-black": !A.open },
                style: { height: A.open ? "calc(100% - 104px)" : "calc(100% - 48px)" }
            }, [r("div", {
                staticClass: "QA-box-btn",
                on: { mouseenter: A.enterDefault, mouseleave: A.leaveDefault }
            }, [r("img", {
                directives: [{ name: "show", rawName: "v-show", value: A.open, expression: "open" }],
                staticStyle: { transform: "scale(0.5)" },
                attrs: { src: A.isHoverActive ? A.btnRightActive : A.btnRightDefault, alt: "" },
                on: {
                    click: function (e) {
                        A.open = !A.open
                    }
                }
            }), r("img", {
                directives: [{ name: "show", rawName: "v-show", value: !A.open, expression: "!open" }],
                staticStyle: { transform: "scale(0.5)" },
                attrs: { src: A.isHoverActive ? A.btnLeftActive : A.btnLeftDefault, alt: "" },
                on: {
                    click: function (e) {
                        A.open = !A.open
                    }
                }
            })]), r("div", {
                directives: [{ name: "show", rawName: "v-show", value: A.open, expression: "open" }],
                staticClass: "QA-section-box"
            }, [r("div", { staticClass: "QA-box" }, [r("div", { staticClass: "QA-tabs" }, [r("div", {
                staticClass: "quiz",
                class: { isActive: "quiz" === A.QAactiveName },
                on: {
                    click: function (e) {
                        return A.handleTabChange("quiz")
                    }
                }
            }, [A._v(A._s(A.$t("v4.js.pc.ocmt.quiz")))]), r("div", {
                staticClass: "relatedQuestion",
                class: { isActive: "relatedQuestion" === A.QAactiveName },
                on: {
                    click: function (e) {
                        return A.handleTabChange("relatedQuestion")
                    }
                }
            }, [A._v(A._s(A.$t("v4.js.pc.ocmt.relatedQuestion")))])]), r("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "quiz" === A.QAactiveName,
                    expression: 'QAactiveName === "quiz"'
                }], staticClass: "quiz-box"
            }, [r("el-form", {
                ref: "form",
                staticClass: "que-form note-create",
                attrs: { model: A.QAformData, "label-width": "13px" },
                nativeOn: {
                    submit: function (A) {
                        A.preventDefault()
                    }
                }
            }, [r("el-form-item", { staticStyle: { "margin-bottom": "16px" } }, [r("el-input", {
                staticStyle: { "min-height": "80px" },
                attrs: {
                    type: "textarea",
                    maxlength: "140",
                    placeholder: "请输入你的问题",
                    "show-word-limit": "",
                    resize: "none"
                },
                model: {
                    value: A.QAformData.title, callback: function (e) {
                        A.$set(A.QAformData, "title", e)
                    }, expression: "QAformData.title"
                }
            })], 1), r("el-form-item", { staticStyle: { "margin-bottom": "16px" } }, [r("el-input", {
                staticStyle: { "min-height": "80px" },
                attrs: {
                    type: "textarea",
                    maxlength: "140",
                    placeholder: "请输入你的问题补充",
                    "show-word-limit": "",
                    resize: "none"
                },
                model: {
                    value: A.QAformData.content, callback: function (e) {
                        A.$set(A.QAformData, "content", e)
                    }, expression: "QAformData.content"
                }
            })], 1), r("el-form-item", { staticStyle: { "margin-bottom": "5px" } }, [r("div", {
                staticClass: "quiz-topic",
                staticStyle: { "border-radius": "4px" }
            }, [A._l(A.topicData, (function (e, t) {
                return r("span", { staticClass: "topic-item" }, [A._v("\n                    " + A._s(e) + "\n                    "), r("span", {
                    staticClass: "deleteItem",
                    on: {
                        click: function (e) {
                            return A.deleteTopicItem(t)
                        }
                    }
                }, [A._v("x")])])
            })), r("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: A.inputTopicText,
                    expression: "inputTopicText"
                }, {
                    name: "show",
                    rawName: "v-show",
                    value: A.topicData.length <= 3,
                    expression: "topicData.length <= 3"
                }],
                attrs: { type: "text", maxlength: "10" },
                domProps: { value: A.inputTopicText },
                on: {
                    focus: A.inputFocus, blur: A.inputBlur, input: function (e) {
                        e.target.composing || (A.inputTopicText = e.target.value)
                    }
                }
            }), r("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: A.showPlaceholder && 0 === A.topicData.length,
                    expression: "showPlaceholder && topicData.length === 0"
                }], staticClass: "placeholder"
            }, [A._v("请输入话题，每个话题长度10个")])], 2)]), r("el-form-item", { staticStyle: { "margin-bottom": "20px" } }, [r("div", { staticClass: "choice_img" }, [r("div", {
                staticClass: "img_bg",
                on: {
                    click: function (e) {
                        A.showChoiceVisible = !A.showChoiceVisible
                    }
                }
            }), r("span", {
                on: {
                    click: function (e) {
                        A.showChoiceVisible = !A.showChoiceVisible
                    }
                }
            }, [A._v("图片")]), A.showChoiceVisible ? r("div", { staticClass: "choice_img_area" }, [r("div", [r("div", { staticClass: "choice-header" }, [r("span", [A._v("上传图片")]), r("i", {
                staticClass: "el-icon-close",
                on: {
                    click: function (e) {
                        A.showChoiceVisible = !1
                    }
                }
            })]), r("div", { staticClass: "choice-item-container" }, [A._l(A.uploadList, (function (e, t) {
                return r("div", {
                    key: t,
                    staticClass: "cic-item"
                }, [r("div", { staticClass: "ci-content" }, [r("img", {
                    attrs: {
                        src: e.url || "",
                        alt: ""
                    }
                }), r("div", [r("i", {
                    staticClass: "el-icon-close", on: {
                        click: function (e) {
                            return A.deleteItem(t)
                        }
                    }
                })])])])
            })), A.uploadList.length < 9 ? r("div", { staticClass: "cic-item" }, [r("div", { staticClass: "ci-content-add" }, [r("input", {
                ref: "uploadFile",
                staticClass: "add-file",
                attrs: { type: "file", accept: "image/gif, image/jpeg, image/png, image/jpg", multiple: "" },
                on: { click: A.clickUpLoad, change: A.changeUpLoad }
            }), r("i", { staticClass: "el-icon-plus" }), r("span", [A._v("还可上传" + A._s(9 - A.uploadList.length) + "张")])])]) : A._e()], 2), r("div", { staticClass: "choice-triangle" })])]) : A._e()])]), r("span", {
                staticClass: "course_area",
                staticStyle: { "margin-bottom": "20px" }
            }, [A._v("\n                # " + A._s(A.courseInfo.courseTitle || "") + "\n              ")]), r("el-form-item", [r("div", { staticClass: "QA-saveBtn" }, [r("div", {
                staticClass: "note-toggle-btn__block_save",
                on: { click: A.saveQuestion }
            }, [r("span", [A._v(A._s(A.$t("v4.js.pc.ocmt.release")))])])])])], 1)], 1), r("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "relatedQuestion" === A.QAactiveName,
                    expression: 'QAactiveName === "relatedQuestion"'
                }], staticClass: "question-box"
            }, [A._l(A.questionData, (function (e, n) {
                return A.questionData.length ? r("div", { staticClass: "qusetion-item" }, [r("div", { staticClass: "qusetion-item-header" }, [e.userFaceUrl ? r("img", {
                    attrs: {
                        src: e.userFaceUrl,
                        alt: ""
                    }
                }) : r("img", {
                    attrs: {
                        src: A.defaultAvatar,
                        alt: ""
                    }
                }), r("div", { staticClass: "header-detail" }, [r("div", { staticClass: "hd-content" }, [r("span", [A._v(A._s(e.nickName))]), r("img", {
                    staticClass: "dot-span",
                    attrs: { src: t("12ef") }
                }), r("span", {
                    staticClass: "answer", on: {
                        click: function (t) {
                            return A.goToQuestion(e.questionId)
                        }
                    }
                }, [A._v(A._s(e.answerCount) + "个答案")])]), r("p", {
                    staticClass: "qusetion-title",
                    on: {
                        click: function (t) {
                            return A.goToQuestion(e.questionId)
                        }
                    }
                }, [A._v(A._s(e.title))]), r("p", { staticClass: "time" }, [A._v(A._s(e.lastModifyTime))])])])]) : A._e()
            })), A.questionData.length ? A._e() : r("div", {
                staticStyle: {
                    width: "100%",
                    "font-size": "14px",
                    "text-align": "center",
                    "margin-top": "15px"
                }
            }, [A._v("\n                暂无相关问题~~\n              ")])], 2)])])])]), r("el-dialog", {
                staticClass: "note-download-dialog",
                staticStyle: { "border-radius": "15px" },
                attrs: { width: "400px", visible: A.noteDownLoadVisible, "append-to-body": "", "show-close": !1 },
                on: {
                    "update:visible": function (e) {
                        A.noteDownLoadVisible = e
                    }
                }
            }, [A.otherNoteDownloadItem ? r("div", {
                staticClass: "note-download-dialog__container",
                staticStyle: { "border-radius": "15px!important" }
            }, [r("i", {
                staticClass: "el-icon-close", on: {
                    click: function (e) {
                        A.noteDownLoadVisible = !1
                    }
                }
            }), r("div", { staticClass: "ndc_userInfo" }, [A.otherNoteDownloadItem && A.otherNoteDownloadItem.faceUrl ? r("img", {
                attrs: {
                    src: A.hostName + A.otherNoteDownloadItem.faceUrl,
                    alt: ""
                }
            }) : r("img", {
                attrs: {
                    src: A.defaultAvatar || "",
                    alt: ""
                }
            }), r("div", { staticClass: "ndc_userInfo__msg" }, [r("span", [A._v(A._s(A.otherNoteDownloadItem.createByName ? A.otherNoteDownloadItem.createByName : ""))]), r("span", [A._v(A._s(A.otherNoteDownloadItem.lastModifyTime || ""))])])]), r("div", { staticClass: "ndc_note_title" }, [A._v(A._s(A.otherNoteDownloadItem.noteName || ""))]), r("div", {
                staticClass: "ndc_note_content",
                staticStyle: { "min-height": "132px" }
            }, [A._v("\n          " + A._s(A.otherNoteDownloadItem.content || "") + "\n        ")]), r("div", { staticClass: "ndc_form" }, [A._v("摘自《" + A._s(A.chapterInfo && A.chapterInfo.resourceName ? A.chapterInfo.resourceName : "") + "》")]), A.chapterInfo ? r("div", { staticClass: "ndc_chapter" }, [A._v("第" + A._s(A._f("convertToChinaNum")(A.chapterInfo.mIndex + 1)) + "章 " + A._s(A.chapterInfo ? A.chapterInfo.chapterName : ""))]) : A._e(), !A.chapterInfo || "video" !== A.chapterInfo.resourceClass && "audio" !== A.chapterInfo.resourceClass && "video" !== A.chapterInfo.resourceType && "audio" !== A.chapterInfo.resourceType ? A._e() : r("div", { staticClass: "ndc_time" }, [A._v("笔记所在时段:  "), r("img", {
                attrs: {
                    src: t("7ff9"),
                    alt: ""
                }, on: {
                    click: function (e) {
                        return A.jumpPeriod(A.otherNoteDownloadItem, "window")
                    }
                }
            }), r("span", {
                on: {
                    click: function (e) {
                        return A.jumpPeriod(A.otherNoteDownloadItem, "window")
                    }
                }
            }, [A._v(A._s(A.jumpPeriodTime))])]), r("div", { staticClass: "ndc_btns" }, [r("el-button", {
                staticStyle: { "margin-right": "20px" },
                attrs: { type: "primary" },
                on: {
                    click: function (e) {
                        return A.downLoadTxt(A.otherNoteDownloadItem.noteName, A.otherNoteDownloadItem.content)
                    }
                }
            }, [A._v("下载")]), r("el-button", {
                on: {
                    click: function (e) {
                        A.noteDownLoadVisible = !1
                    }
                }
            }, [A._v("取消")])], 1)]) : A._e()]), r("el-dialog", {
                staticClass: "note-jumpPeriod-dialog",
                staticStyle: { "border-radius": "15px" },
                attrs: { width: "480px", visible: A.noteJumpPeriodVisible, "append-to-body": "", "show-close": !1 },
                on: {
                    "update:visible": function (e) {
                        A.noteJumpPeriodVisible = e
                    }
                }
            }, [r("div", { staticClass: "njd-header" }, [r("span", [A._v("提示")]), r("i", {
                staticClass: "el-icon-close",
                on: { click: A.closePositionPlay }
            })]), r("div", { staticClass: "njd-main" }, [A.isRead() || A.userInfo && A.notejumpPeriod && A.userInfo.userId === A.notejumpPeriod.createBy || A.userInfo && A.notejumpPeriod && A.userInfo.userId !== A.notejumpPeriod.createBy && A.notejumpPeriodInfo && A.notejumpPeriodInfo.currentPosition && A.notejumpPeriodInfo.currentPosition >= A.jumpPeriodSecond ? r("p", [A._v("是否要跳转至笔记所在时段：" + A._s(A.jumpPeriodTime) + "?")]) : r("p", [A._v("笔记所在时段尚未学习，请先完成学习哦～")]), r("div", { staticClass: "njd-main-body" }, [r("el-button", {
                staticStyle: { "margin-right": "24px" },
                attrs: { type: "primary" },
                on: { click: A.confirmPositionPlay }
            }, [A._v("确定")]), r("el-button", { on: { click: A.closePositionPlay } }, [A._v("取消")])], 1)])])], 1), "preview" !== A.$route.query.from ? r("div", { staticClass: "course-play-footer" }, [r("div", { staticClass: "cpf-left" }, [r("div", { staticClass: "cpf-left-header" }, [r("div", {
                staticClass: "clh-item",
                class: { "clh-item-active": "1" === A.navActive },
                on: {
                    click: function (e) {
                        return A.toggleNavItem("1")
                    }
                }
            }, [A._v("课程简介 "), r("span")]), A.courseInfo && A.courseInfo.openDsc ? r("div", {
                staticClass: "clh-item",
                class: { "clh-item-active": "2" === A.navActive },
                on: {
                    click: function (e) {
                        return A.toggleNavItem("2")
                    }
                }
            }, [A._v("讨论区 "), r("span")]) : A._e(), r("div", {
                staticClass: "clh-item",
                class: { "clh-item-active": "3" === A.navActive },
                on: {
                    click: function (e) {
                        return A.toggleNavItem("3")
                    }
                }
            }, [A._v("参考资料 "), r("span")])]), "1" === A.navActive ? r("div", { staticClass: "cpf-left-main course_introduction" }, [r("div", { staticClass: "ci-item" }, [A._m(2), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A._v(A._s(A.courseInfo.selectCount || 0) + "人")])]), r("div", { staticClass: "ci-item" }, [A._m(3), A._v("\n          :\n          "), r("div", {
                staticClass: "ci-item-r",
                staticStyle: {
                    display: "flex",
                    "flex-direction": "row",
                    "justify-content": "flex-start",
                    "align-items": "center"
                }
            }, [r("el-rate", {
                attrs: {
                    disabled: "",
                    "show-score": "",
                    "text-color": "#ff9900",
                    "score-template": "{value}"
                }, model: {
                    value: A.courseInfo.avgPoint || 0, callback: function (e) {
                        A.$set(A.courseInfo, "avgPoint || 0", e)
                    }, expression: "courseInfo.avgPoint || 0"
                }
            }), r("span", [A._v("分")])], 1)]), r("div", { staticClass: "ci-item" }, [A._m(4), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A._v("\n            " + A._s(A.courseInfo.coursePeriod || 0) + "\n          ")])]), r("div", { staticClass: "ci-item" }, [A._m(5), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A._v("\n            " + A._s(A.courseInfo.courseScore || 0) + "\n          ")])]), r("div", { staticClass: "ci-item" }, [A._m(6), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A._v("\n            " + A._s(A.courseInfo.categoryNamePath || "") + "\n          ")])]), r("div", { staticClass: "ci-item" }, [A._m(7), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A._v("\n            " + A._s(A.gWay) + "\n          ")])]), r("div", { staticClass: "ci-item" }, [A._m(8), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A._v("\n            " + A._s(A.courseInfo.publishDate ? A.moment(A.courseInfo.publishDate).format("YYYY-MM-DD") : "") + "\n          ")])]), A.courseInfo && A.courseInfo.teacherList && A.courseInfo.teacherList.length && A.courseInfo.teacherList[0].teacherName ? r("div", { staticClass: "ci-item" }, [A._m(9), A._v("\n          :\n          "), A.courseInfo.teacherList && A.courseInfo.teacherList.length ? r("div", { staticClass: "ci-item-r" }, A._l(A.courseInfo.teacherList, (function (e, t) {
                return r("span", [r("span", [A._v(A._s(e.teacherName))]), t !== A.courseInfo.teacherList.length - 1 ? r("span", [A._v(", ")]) : A._e()])
            })), 0) : A._e()]) : A._e(), A.courseInfo && A.courseInfo.meaning ? r("div", { staticClass: "ci-item" }, [A._m(10), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A.courseInfo.meaning ? r("div", { domProps: { innerHTML: A._s(A.courseInfo.meaning) } }) : A._e()])]) : A._e(), A.courseInfo && A.courseInfo.orientObj ? r("div", { staticClass: "ci-item" }, [A._m(11), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A.courseInfo.orientObj ? r("div", { domProps: { innerHTML: A._s(A.courseInfo.orientObj) } }) : A._e()])]) : A._e(), A.courseInfo && A.courseInfo.objectives ? r("div", { staticClass: "ci-item" }, [A._m(12), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A.courseInfo.objectives ? r("div", { domProps: { innerHTML: A._s(A.courseInfo.objectives) } }) : A._e()])]) : A._e(), A.courseInfo && A.courseInfo.outline ? r("div", { staticClass: "ci-item" }, [A._m(13), A._v("\n          :\n          "), r("div", { staticClass: "ci-item-r" }, [A.courseInfo.outline ? r("div", { domProps: { innerHTML: A._s(A.courseInfo.outline) } }) : A._e()])]) : A._e()]) : A._e(), "2" === A.navActive ? r("div", { staticClass: "cpf-left-main discussion_area" }, [r("el-input", {
                attrs: {
                    type: "textarea",
                    placeholder: "发布一条友善的评论",
                    maxlength: "140",
                    "show-word-limit": "",
                    rows: "6"
                }, model: {
                    value: A.discussionValue, callback: function (e) {
                        A.discussionValue = e
                    }, expression: "discussionValue"
                }
            }), r("div", { staticClass: "comment-block" }, [r("el-button", {
                staticClass: "comment-btn",
                attrs: { type: "primary", size: "mini", disabled: A.sendCommentIsShow },
                on: { click: A.sendDiscuss }
            }, [A._v("发表评论")])], 1), r("div", {
                staticClass: "infinite-list-wrapper",
                staticStyle: { overflow: "auto", height: "800px" }
            }, [r("div", {
                directives: [{
                    name: "infinite-scroll",
                    rawName: "v-infinite-scroll",
                    value: A.load,
                    expression: "load"
                }], staticClass: "comment-list", attrs: { "infinite-scroll-disabled": A.disabled }
            }, A._l(A.commentList, (function (e, t) {
                return r("div", {
                    key: t,
                    staticClass: "comment-list-item"
                }, [r("div", { staticClass: "cli-l" }, [r("img", {
                    attrs: {
                        src: e.faceUrl || A.defaultAvatar || "",
                        alt: ""
                    }
                })]), r("div", { staticClass: "cli-r" }, [r("div", [r("span", { staticClass: "cli-r-title" }, [A._v(A._s(e.userName || ""))])]), r("div", {
                    staticStyle: {
                        "white-space": "normal",
                        "word-break": "break-all"
                    }
                }, [A._v("\n                  " + A._s(e.contentPreview || "") + "\n                ")]), r("div", [r("div", { staticClass: "comment-time" }, [A._v(A._s(e.createTime ? A.moment(e.createTime).format("YYYY-MM-DD HH:mm") : ""))]), r("div", { staticClass: "comment-priview" }, [r("div", {
                    staticClass: "cp-item cp-reply",
                    on: {
                        click: function (r) {
                            return A.choiceReply(e, t)
                        }
                    }
                }, [r("div", { staticClass: "cpr-block" }), r("span", [A._v("回复")])]), A.userInfo && A.userInfo.userId === e.createBy && !A.isbizResultShow || A.isbizResultShow ? r("div", {
                    staticClass: "cp-item cp-delete",
                    on: {
                        click: function (r) {
                            return A.delComment(e, t)
                        }
                    }
                }, [r("div", { staticClass: "cpd-block" }), r("span", [A._v("删除")])]) : A._e()])]), e.isReplyShow ? r("div", {
                    staticClass: "child_item reply_area",
                    staticStyle: { "margin-bottom": "32px" }
                }, [r("el-input", {
                    attrs: {
                        type: "textarea",
                        placeholder: "请输入回复信息",
                        maxlength: "140",
                        "show-word-limit": "",
                        rows: "4",
                        resize: "none"
                    }, model: {
                        value: A.replyValue, callback: function (e) {
                            A.replyValue = e
                        }, expression: "replyValue"
                    }
                }), r("div", { staticClass: "reply-block" }, [r("el-button", {
                    staticClass: "reply-btn-send",
                    attrs: { type: "primary", size: "mini", disabled: A.sendReplyIsShow },
                    on: {
                        click: function (t) {
                            return A.sendReply(e)
                        }
                    }
                }, [A._v("回复")])], 1)], 1) : A._e(), A._l(e.discussList, (function (t, n) {
                    return r("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: e.discussList.length,
                            expression: "item.discussList.length"
                        }], key: n, staticClass: "child_item", staticStyle: { "margin-bottom": "32px" }
                    }, [r("div", {
                        staticClass: "comment-list-item",
                        staticStyle: { "border-bottom": "none", "margin-bottom": "0", padding: "0 0" }
                    }, [r("div", { staticClass: "cli-l" }, [r("img", {
                        attrs: {
                            src: t.faceUrl || A.defaultAvatar || "",
                            alt: ""
                        }
                    })]), r("div", { staticClass: "cli-r" }, [r("div", { staticClass: "cli-r-child" }, [r("span", { staticClass: "cli-r-title" }, [A._v(A._s(t.userName))]), A.userInfo && A.userInfo.userId === t.createBy && !A.isbizResultShow || A.isbizResultShow ? r("div", {
                        staticClass: "cp-item cp-delete",
                        on: {
                            click: function (e) {
                                return A.delComment(t, n)
                            }
                        }
                    }, [r("div", { staticClass: "cpd-block" }), r("span", [A._v("删除")])]) : A._e()]), r("div", {
                        staticStyle: {
                            "white-space": "normal",
                            "word-break": "break-all"
                        }
                    }, [A._v("\n                        " + A._s(t.contentPreview || "") + "\n                      ")]), r("div", { staticStyle: { "margin-bottom": "0" } }, [r("div", { staticClass: "comment-time" }, [A._v(A._s(t.createTime ? A.moment(t.createTime).format("YYYY-MM-DD HH:mm") : ""))]), r("div", { staticClass: "comment-priview" })])])])])
                }))], 2)])
            })), 0), A.loading ? r("p", {
                staticStyle: {
                    "margin-top": "15px",
                    "margin-bottom": "30px",
                    "text-align": "center",
                    "font-size": "12px",
                    color: "rgba(0,0,0,0.25)"
                }
            }, [A._v("加载中...")]) : A._e(), A.noMore ? r("p", {
                staticStyle: {
                    "margin-top": "15px",
                    "margin-bottom": "30px",
                    "text-align": "center",
                    "font-size": "12px",
                    color: "rgba(0,0,0,0.25)"
                }
            }, [A._v("到底了~")]) : A._e()])], 1) : A._e(), "3" === A.navActive ? r("div", { staticClass: "cpf-left-main reference_material" }, [A.referenceMaterial.length > 0 ? r("div", [r("div", { staticClass: "reference_material_header" }, [A._v("共有" + A._s(A.referenceMaterial.length) + "份资料")]), A._l(A.referenceMaterial, (function (e, t) {
                return r("div", {
                    key: t,
                    staticClass: "rmh-data-item"
                }, [r("span", [A._v(A._s(e.refName))]), "RESOURSESTATION" === e.refSource ? r("span", {
                    on: {
                        click: function (t) {
                            return A.showRefer(e)
                        }
                    }
                }, [A._v("查看")]) : r("span", {
                    on: {
                        click: function (t) {
                            return A.downLoadRefer(e)
                        }
                    }
                }, [A._v("下载")])])
            }))], 2) : r("div", { staticClass: "no-area" }, [r("img", {
                attrs: {
                    src: t("d46a"),
                    alt: ""
                }
            }), r("span", [A._v("暂无参考资料")])])]) : A._e()]), A._m(14)]) : A._e()])
        }, n = [function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "qrcode-area-title" }, [t("span", [A._v("扫一扫，观看精彩课程")]), t("span", [A._v("学习成就卓越")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("span", [A._v("保密"), t("span", [A._v("（只有本人可以查看）")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("学")]), t("span", [A._v("习")]), t("span", [A._v("人")]), t("span", [A._v("次")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("评")]), t("span", [A._v("分")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("学")]), t("span", [A._v("时")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("学")]), t("span", [A._v("分")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("课")]), t("span", [A._v("程")]), t("span", [A._v("分")]), t("span", [A._v("类")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("学")]), t("span", [A._v("习")]), t("span", [A._v("来")]), t("span", [A._v("源")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("发")]), t("span", [A._v("布")]), t("span", [A._v("日")]), t("span", [A._v("期")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("讲")]), t("span", [A._v("师")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("课")]), t("span", [A._v("程")]), t("span", [A._v("意")]), t("span", [A._v("义")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("课")]), t("span", [A._v("程")]), t("span", [A._v("对")]), t("span", [A._v("象")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("课")]), t("span", [A._v("程")]), t("span", [A._v("目")]), t("span", [A._v("标")])])
        }, function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", { staticClass: "ci-item-l" }, [t("span", [A._v("课")]), t("span", [A._v("程")]), t("span", [A._v("提")]), t("span", [A._v("纲")])])
        }, function () {
            var A = this, e = A.$createElement, r = A._self._c || e;
            return r("div", { staticClass: "cpf-right" }, [r("span", { staticClass: "cpf-right-title" }, [A._v("大家都在看")]), r("div", {
                staticClass: "no-area",
                staticStyle: { width: "100%", "padding-top": "10px" }
            }, [r("img", { attrs: { src: t("d46a"), alt: "" } }), r("span", [A._v("敬请期待")])])])
        }], i = (t("8e6e"), t("456d"), t("3b2b"), t("96cf"), t("3b8d")),
            s = (t("7f7f"), t("a481"), t("20d6"), t("34ef"), t("6762"), t("2fdb"), t("5df3"), t("1c4c"), t("bd86")),
            o = t("75fc"), a = (t("7514"), t("28a5"), t("ac6a"), t("8e44")), c = t("527b"), l = t("b775"),
            u = (t("9e1f"), t("450d"), t("6ed5")), d = t.n(u), B = (t("0fb7"), t("f529")), h = t.n(B), g = t("bc3a"),
            p = t.n(g), f = t("4360"), w = t("4328"), C = t.n(w), m = p.a.create({
                baseURL: Object({ NODE_ENV: "production", BASE_URL: "/courseSetting/" }).VUE_APP_BASE_API,
                timeout: 5e3,
                headers: { "Content-Type": "application/x-www-form-urlencoded" }
            });
        m.interceptors.request.use((function (A) {
            return f["a"].getters.token, A.data = C.a.stringify(A.data), A
        }), (function (A) {
            return console.log(A), Promise.reject(A)
        })), m.interceptors.response.use((function (A) {
            var e = A.data;
            return 0 !== e.code && 1001 !== e.code || 200 !== A.status ? (h()({
                message: e.message || e.msg || "Error",
                type: "error",
                duration: 5e3
            }), 50008 !== e.code && 50012 !== e.code && 50014 !== e.code || d.a.confirm("You have been logged out, you can cancel to stay on this page, or log in again", "Confirm logout", {
                confirmButtonText: "Re-Login",
                cancelButtonText: "Cancel",
                type: "warning"
            }).then((function () {
                f["a"].dispatch("user/resetToken").then((function () {
                    location.reload()
                }))
            })), Promise.reject(new Error(e.message || e.msg || "Error"))) : e
        }), (function (A) {
            console.log("err" + A), console.log(A.response.status), h()({
                message: A.response.data.message,
                type: "error",
                duration: 5e3
            });
            var e = window.vm.$route.path, t = {};
            return "/login" !== e && (t.redirect = e), 401 === A.response.status && window.vm.$router.push({
                path: "/login",
                query: t
            }), Promise.reject(A)
        }));
        var Q = m;

        function y(A) {
            return Object(l["a"])({
                url: "/els/html/course/course.getCourseReferenceJson.do?courseId=".concat(A.courseId),
                method: "get"
            })
        }

        function U(A) {
            return Object(l["a"])({
                url: "/els/html/discussAndNote/discussAndNote.batchDeleteDiscussJson.do?discussIds=".concat(A.discussIds, "&csrfToken=").concat(A.csrfToken),
                method: "get"
            })
        }

        function v(A) {
            return Object(l["a"])({
                url: "/els/html/coursebasic/coursebasic.saveDiscuss.do?discuss.idPath=".concat(A.discuss.idPath, "&discuss.objectId=").concat(A.discuss.objectId, "&discuss.contentPreview=").concat(A.discuss.contentPreview),
                method: "get"
            })
        }

        function F(A) {
            return Object(l["a"])({
                url: "/els/html/coursebasic/coursebasic.saveDiscuss.do?discuss.objectId=".concat(A.discuss.objectId, "&discuss.contentPreview=").concat(A.discuss.contentPreview, "&isShare=").concat(A.isShare),
                method: "get"
            })
        }

        function I(A) {
            return Object(l["a"])({
                url: "/els/html/coursebasic/coursebasic.getCourseDiscussJson.do?courseType=".concat(A.courseType, "&courseId=").concat(A.courseId, "&page.pageNo=").concat(A.page.pageNo, "&page.pageSize=").concat(A.page.pageSize),
                method: "get"
            })
        }

        function E(A) {
            return Object(l["a"])({ url: "/els/html/course/course.getCourseInfoJson.do", method: "get", params: A })
        }

        function b(A) {
            return Q({ url: "/els/html/course/courseStudy.saveOrUpdateCourseNoteJson.do", method: "post", data: A })
        }

        function H(A) {
            var e = A.courseId, t = A.processType, r = A.page, n = r.pageNo, i = r.pageSize,
                s = "?courseId=".concat(e, "&processType=").concat(t, "&page.pageNo=").concat(n, "&page.pageSize=").concat(i);
            return Object(l["a"])({ url: "/els/html/course/courseStudy.courseNoteListJson.do".concat(s), method: "get" })
        }

        function T(A) {
            var e = A.noteId, t = "?noteId=".concat(e);
            return Object(l["a"])({
                url: "/els/html/course/courseStudy.deleteCourseNoteJson.do".concat(t),
                method: "get"
            })
        }

        function x(A) {
            return Object(l["a"])({
                url: "/els/html/collection/collection.collectionCourseJson.do?courseId=".concat(A.courseId),
                method: "get"
            })
        }

        function S(A) {
            return Object(l["a"])({
                url: "/els/html/collection/collection.cancelCollectionJson.do?courseId=".concat(A.courseId),
                method: "get"
            })
        }

        function D(A) {
            return Object(l["a"])({
                url: "/els/html/coursePraise/coursePraise.getCountPraiseAndUserJson.do?coursePraise.courseId=".concat(A.coursePraise.courseId, "&coursePraise.praiseStatus=").concat(A.coursePraise.praiseStatus),
                method: "get"
            })
        }

        function L(A) {
            return Object(l["a"])({
                url: "/els/html/discussAndNote/discussAndNote.checkAllowDeleteDiscuss.do?courseId=".concat(A.courseId),
                method: "get"
            })
        }

        var K = t("704d"), k = t("9ff8"), O = function () {
            var A = this, e = A.$createElement, t = A._self._c || e;
            return t("div", [A.preventCheatFlag && 2 == A.checkType ? t("div", {
                staticClass: "pCheat-box",
                staticStyle: { width: "100%", height: "100%" }
            }, [t("div", { staticClass: "pCheat-wrap" }, [t("div", { staticClass: "header-tips" }, [A._v("\n               " + A._s(A.$t("v4.js.pc.ocmt.systemHint")) + "\n            ")]), t("div", { staticStyle: { padding: "20px" } }, [t("div", { staticClass: "pCheat-title" }, [A._v("请完成下方的题目，"), t("span", {
                staticClass: "pCheat-title-count",
                staticStyle: { color: "#14ABEF" }
            }, [A._v(A._s(A.timeCount))]), A._v(" 秒内未完成将退出课程学习")]), t("div", { staticClass: "pCheat-img-box" }, [t("img", {
                staticClass: "pCheat-img",
                staticStyle: { cursor: "pointer" },
                attrs: { id: "identifyCode", src: A.imgUrl }
            }), t("input", {
                directives: [{ name: "model", rawName: "v-model", value: A.imgTime, expression: "imgTime" }],
                attrs: { id: "imgTime", type: "hidden" },
                domProps: { value: A.imgTime },
                on: {
                    input: function (e) {
                        e.target.composing || (A.imgTime = e.target.value)
                    }
                }
            }), t("a", {
                staticClass: "pCheat-img-link",
                attrs: { href: "javascript:;", id: "changeNext" },
                on: { click: A.changeNext }
            }, [A._v(A._s(A.$t("v4.js.pc.ocmt.changeOne")))])]), t("div", {
                staticClass: "vld-row",
                staticStyle: { "text-align": "center", "margin-top": "20px" }
            }, [t("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: A.answerVal,
                    expression: "answerVal"
                }],
                staticClass: "pCheat-input-text",
                attrs: { type: "text", id: "answer", placeholder: "", maxlength: "10" },
                domProps: { value: A.answerVal },
                on: {
                    blur: A.validate, input: function (e) {
                        e.target.composing || (A.answerVal = e.target.value)
                    }
                }
            }), t("span", {
                staticStyle: { color: "#000" },
                attrs: { id: "tip" }
            }, [A._v(A._s(A.tips))])])]), t("div", { staticClass: "confirmBtn" }, [t("div", {
                staticClass: "btn",
                on: { click: A.submitAnswer }
            }, [A._v("\n                    " + A._s(A.$t("v4.js.pc.ocmt.confirm")) + "\n                ")])])])]) : A._e(), A.preventCheatFlag && 1 == A.checkType ? t("div", { staticClass: "pCheat-box" }, [t("div", { staticClass: "erweima-wrap" }, [t("p", [A._v(A._s(A.$t("v4.js.pc.ocmt.systemHint")))]), t("div", { attrs: { id: "erweima-img" } }), t("p", { staticStyle: { "text-align": "center" } }, [A._v(A._s(A.$t("v4.js.pc.ocmt.APPScanIt")))]), t("p", { staticStyle: { "text-align": "center" } }, [t("span", [A._v(A._s(A.minute))]), A._v("分"), t("span", [A._v(A._s(A.second))]), A._v("秒内未完成将退出课程学习")])])]) : A._e()])
        }, P = [], N = (t("c5f6"), t("fa7d")), R = t("d044"), M = t.n(R), _ = t("cc7d"), V = t.n(_), G = {
            data: function () {
                return {
                    preventCheatFlag: !1,
                    timeCount: 60,
                    preventCheatInterval: null,
                    countTimer: null,
                    preventCheatTime: 0,
                    imgUrl: "",
                    answerVal: "",
                    tips: "",
                    playTime: 0,
                    playTimer: null,
                    lastTimer: null,
                    nextPlayTime: 0,
                    qrcode: null,
                    minute: 2,
                    second: 59,
                    faceTimer: null,
                    userId: ""
                }
            },
            props: {
                maxTime: { type: Number, default: 0 },
                minTime: { type: Number, default: 0 },
                checkType: { type: Number, default: 2 }
            },
            computed: {},
            watch: {},
            methods: {
                initPreventCheat: function (A) {
                    var e = this;
                    if ("video" == A) e.exitfullscreen(), e.$emit("saveStudyLog", "PREVENT_CHEAT_POPUP"), e.preventCheatFlag = !0, clearInterval(e.countTimer), e.$emit("pauseOrPlay", !1), "1" == e.checkType ? setTimeout((function () {
                        e.initErWeima()
                    }), 100) : "2" == e.checkType && (e.preventCheat(), e.timeCount = 60, e.countTimer = setInterval((function () {
                        e.timeCount--, e.timeCount <= 0 && (e.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), e.timeCount = 0, console.log("退出登录"), setTimeout((function () {
                            top.open("about:blank", "_self").close()
                        }), 1e3), clearInterval(e.countTimer))
                    }), 1e3)); else {
                        clearInterval(this.preventCheatInterval);
                        var t = A ? 60 * A * 1e3 : 60 * e.preventCheatTime * 1e3;
                        console.log("自动验证的时间：" + t), this.preventCheatInterval = setTimeout((function () {
                            e.exitfullscreen(), e.$emit("saveStudyLog", "PREVENT_CHEAT_POPUP"), e.preventCheatFlag = !0, e.$emit("pauseOrPlay", !1), "1" == e.checkType ? setTimeout((function () {
                                e.initErWeima()
                            }), 100) : (e.preventCheat(), e.timeCount = 60, clearInterval(e.countTimer), e.countTimer = setInterval((function () {
                                e.timeCount--, e.timeCount <= 0 && (e.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), e.timeCount = 0, console.log("退出登录"), setTimeout((function () {
                                    top.open("about:blank", "_self").close()
                                }), 1e3), clearInterval(e.countTimer))
                            }), 1e3))
                        }), t)
                    }
                }, randomWord: function (A, e, t) {
                    var r = "", n = e,
                        i = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
                    A && (n = Math.round(Math.random() * (t - e)) + e);
                    for (var s = 0; s < n; s++) {
                        var o = Math.round(Math.random() * (i.length - 1));
                        r += i[o]
                    }
                    return r
                }, initErWeima: function () {
                    var A = this, e = this;
                    clearInterval(this.faceTimer), e.minute = 2, e.second = 59, this.faceTimer = setInterval((function () {
                        e.second--, e.second < 0 && (e.second = 59, e.minute--, e.minute < 0 && (e.second = 0, e.minute = 0, e.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), setTimeout((function () {
                            top.open("about:blank", "_self").close()
                        }), 1e3), clearInterval(A.faceTimer)))
                    }), 1e3), this.qrcode = new M.a(document.getElementById("erweima-img"), {
                        text: "",
                        width: 200,
                        height: 200
                    }), this.webSK()
                }, webSK: function () {
                    var A, e, t = this, r = this.randomWord(!1, 10), n = window.location.origin,
                        i = this.randomWord(!1, 32);
                    A = new V.a(n + "/biz-oim/webSocket/handler?deviceId=" + i);
                    var s = window.$cookies.get("_local");
                    A.onopen = function (e) {
                        var n = '{"code" : 1, "params" : {"qrCode" : "' + r + '", "oldQrCode" : "", "local" : "' + s + '", "type" : "QR_STUDYCOURSE_SIGN", "userId" :"' + t.userId + '" }}';
                        A.send(n)
                    }, A.onmessage = function (A) {
                        var r = JSON.parse(A.data);
                        1 == r.code ? (e = r.bizResult + "&userId=" + t.userId, t.qrcode.makeCode(e), document.getElementById("erweima-img").setAttribute("title", "")) : 2 == r.code || (6 == r.code ? (clearInterval(this.faceTimer), t.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), setTimeout((function () {
                            top.open("about:blank", "_self").close()
                        }), 1e3)) : 7 == r.code ? (console.log("用户扫码确认"), clearInterval(t.faceTimer), t.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_SUCCESS"), clearInterval(t.countTimer), clearInterval(t.playTimer), clearTimeout(t.lastTimer), clearInterval(t.preventCheatInterval), t.preventCheatFlag = !1, t.playTime = 0, t.answerVal = "", console.log("上次执行的时间:" + t.preventCheatTime), t.nextPlayTime = t.maxTime - t.preventCheatTime, console.log("上次剩余的时间：" + t.nextPlayTime), t.preventCheatTime = (Math.random() * (t.maxTime - t.minTime) + t.minTime).toFixed(1), console.log("这次摇到的时间:" + t.preventCheatTime), t.nextPlayTime = Number(t.nextPlayTime) + Number(t.preventCheatTime), console.log("下次执行的时间:" + t.nextPlayTime), document.getElementsByTagName("video")[0] ? t.addVideoClick(t.nextPlayTime) : t.initPreventCheat(t.nextPlayTime)) : 4 == r.code && !0)
                    }, A.onclose = function (A) {
                    }, A.onerror = function (A) {
                        alert("WebSocket连接发生错误，请刷新页面！")
                    }
                }, exitfullscreen: function () {
                    try {
                        document.exitFullscreen ? document.exitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen()
                    } catch (A) {
                    }
                }, preventCheat: function () {
                    var A = document.getElementsByTagName("head")[0], e = document.createElement("script");
                    e.type = "text/javascript", A.appendChild(e), e.onload = e.onreadystatechange = function () {
                        !this.readyState || "loaded" === this.readyState || this.readyState
                    };
                    var t = parent.location.origin + "/els", r = Object(N["getUrl"])("eln_session_id"),
                        n = "".concat(t, "/html/preventCheat/preventCheat.loadIdentifyCode.do?eln_session_id=").concat(r, "&imgTime="),
                        i = (new Date).getTime();
                    this.imgUrl = n + i, this.imgTime = i
                }, changeNext: function () {
                    var A = parent.location.origin + "/els", e = Object(N["getUrl"])("eln_session_id"),
                        t = "".concat(A, "/html/preventCheat/preventCheat.loadIdentifyCode.do?eln_session_id=").concat(e, "&imgTime="),
                        r = (new Date).getTime();
                    this.imgUrl = t + r, this.imgTime = r
                }, validate: function () {
                    var A = new RegExp("^[0-9]*$"), e = new RegExp("^-[1-9][0-9]*$");
                    return "" == this.answerVal ? (this.tips = this.$t("v4.js.pc.ocmt.PleaseEnterTheCorrectAnswer"), !1) : A.test(this.answerVal) || e.test(this.answerVal) ? (this.tips = "", !0) : (this.answerVal = "", this.tips = this.$t("v4.js.pc.ocmt.numPlease"), !1)
                }, submitAnswer: function () {
                    this.imgTime, Number(this.answerVal);
                    var A = Object(N["getUrl"])("courseId"),
                        e = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP"),
                        t = new FormData;
                    t.append("imgTime", this.imgTime), t.append("answer", Number(this.answerVal));
                    var r = this;
                    e && (e.open("post", parent.location.origin + "/els/html/preventCheat/preventCheat.checkAnswer.do?courseId=" + A), e.onreadystatechange = function () {
                        if (4 == e.readyState && 200 == e.status) {
                            var A = JSON.stringify(e.responseText);
                            A.includes("true") ? (r.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_SUCCESS"), clearInterval(r.countTimer), clearInterval(r.playTimer), clearTimeout(r.lastTimer), clearInterval(r.preventCheatInterval), r.preventCheatFlag = !1, r.playTime = 0, r.answerVal = "", console.log("上次执行的时间:" + r.preventCheatTime), r.nextPlayTime = r.maxTime - r.preventCheatTime, console.log("上次剩余的时间：" + r.nextPlayTime), r.preventCheatTime = (Math.random() * (r.maxTime - r.minTime) + r.minTime).toFixed(1), console.log("这次摇到的时间:" + r.preventCheatTime), r.nextPlayTime = Number(r.nextPlayTime) + Number(r.preventCheatTime), console.log("下次执行的时间:" + r.nextPlayTime), document.getElementsByTagName("video")[0] ? r.addVideoClick(r.nextPlayTime) : r.initPreventCheat(r.nextPlayTime)) : (A.includes("Error"), r.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_FAIL"), r.tips = r.$t("v4.js.pc.ocmt.PleaseEnterTheCorrectAnswer"))
                        }
                    }), e.send(t)
                }, resetPlayTime: function (A, e) {
                    clearTimeout(this.preventCheatInterval), clearInterval(this.countTimer), clearInterval(this.playTimer), clearTimeout(this.lastTimer), clearInterval(this.faceTimer), this.playTime = 0, this.preventCheatTime = (Math.random() * (this.maxTime - this.minTime) + this.minTime).toFixed(1)
                }, addVideoClick: function (A) {
                    var e = this;
                    document.getElementsByTagName("video")[0].onplay = function () {
                        clearTimeout(e.lastTimer), clearInterval(e.playTimer);
                        var t = A ? 1e3 * (60 * A - e.playTime) : 1e3 * (60 * e.preventCheatTime - e.playTime);
                        console.log("剩余触发时间:" + t), e.playTimer = setInterval((function () {
                            e.playTime++
                        }), 1e3), e.lastTimer = setTimeout((function () {
                            e.preventCheatFlag = !0, e.initPreventCheat("video")
                        }), t)
                    }, document.getElementsByTagName("video")[0].onpause = function () {
                        clearInterval(e.playTimer), clearTimeout(e.lastTimer)
                    }, document.getElementsByTagName("video")[0].pause(), document.getElementsByTagName("video")[0].play(), e.$store.state.home.jumpFlag && document.getElementsByTagName("video")[0].pause()
                }, addPlayEvent: function () {
                    this.preventCheatTime = (Math.random() * (this.maxTime - this.minTime) + this.minTime).toFixed(1), this.playTime = 0, document.getElementsByTagName("video")[0] ? this.addVideoClick() : this.initPreventCheat()
                }
            },
            mounted: function () {
                var A = this;
                a["c"].getUserInfo().then((function (e) {
                    A.userId = e.bizResult.userId
                })), this.addPlayEvent()
            },
            beforeDestroy: function () {
                clearTimeout(this.lastTimer), clearInterval(this.playTimer), clearInterval(this.countTimer), clearInterval(this.preventCheatInterval), clearInterval(this.faceTimer)
            }
        }, J = G, j = (t("4812"), t("2877")), X = Object(j["a"])(J, O, P, !1, null, "43fe5bcf", null), W = X.exports,
            Y = function () {
                var A = this, e = A.$createElement, t = A._self._c || e;
                return A.hangUpFlag ? t("div", {
                    staticClass: "hangUp-box",
                    staticStyle: { width: "100%", height: "100%" }
                }, [A.loginFlag ? t("div", { staticClass: "loginOut-wrap" }, [t("div", { staticClass: "header-tips" }, [A._v("\n            " + A._s(A.$t("v4.js.pc.ocmt.systemHint")) + "\n        ")]), t("div", {
                    staticClass: "tips-content",
                    staticStyle: { padding: "20px", "font-size": "18px" }
                }, [A._v("\n            " + A._s(A.$t("v4.js.pc.ocmt.loginOutSystem")) + "\n            \n        ")]), t("div", { staticClass: "confirmBtn" }, [t("div", {
                    staticClass: "btn",
                    on: { click: A.loginOutConfirm }
                }, [A._v("\n                " + A._s(A.$t("v4.js.pc.ocmt.confirm")) + "\n            ")])])]) : t("div", { staticClass: "hangUp-wrap" }, [t("div", { staticClass: "header-tips" }, [A._v("\n            " + A._s(A.$t("v4.js.pc.ocmt.systemHint")) + "\n        ")]), t("div", {
                    staticClass: "tips-content",
                    staticStyle: { padding: "20px", "font-size": "18px" }
                }, [A._v("\n            长时间未操作页面,"), t("span", { staticStyle: { color: "#eb5352" } }, [A._v(A._s(A.timeCount))]), A._v("秒后退出登录\n        ")]), t("div", { staticClass: "confirmBtn" }, [t("div", {
                    staticClass: "btn",
                    on: { click: A.confirm }
                }, [A._v("\n                " + A._s(A.$t("v4.js.pc.ocmt.confirm")) + "\n            ")])])])]) : A._e()
            }, Z = [], q = {
                data: function () {
                    return {
                        hangUpFlag: !1,
                        operateTime: 0,
                        timeCount: 60,
                        timer: null,
                        timeInterval: 3e4,
                        xys: { x0: 0, y0: 0 },
                        xy: { x0: 0, y0: 0 },
                        loginFlag: !1,
                        timerNoOperate: null
                    }
                }, props: { preventHangTime: { type: Number, default: 0 } }, computed: {}, watch: {}, methods: {
                    initHangUp: function () {
                        var A = this;
                        document.body.onmousemove = function (e) {
                            A.xys = { x0: e.clientX, y0: e.clientY }
                        }, this.startTimer()
                    }, startTimer: function () {
                        var A = this;
                        clearInterval(this.timerNoOperate), clearInterval(this.timer), this.timerNoOperate = setInterval((function () {
                            A.checkMouseMove(A.xys)
                        }), A.timeInterval)
                    }, exitfullscreen: function () {
                        try {
                            document.exitFullscreen ? document.exitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen()
                        } catch (A) {
                        }
                    }, checkMouseMove: function (A) {
                        var e = this;
                        this.xy.x0 == A.x0 && this.xy.y0 == A.y0 ? (this.operateTime += this.timeInterval, this.operateTime / 1e3 / 60 >= this.preventHangTime && (e.timeCount = 60, this.$emit("pauseOrPlay", !1), this.$emit("saveStudyLog", "PREVENT_HANG_POPUP"), this.exitfullscreen(), this.hangUpFlag = !0, clearInterval(this.timerNoOperate), this.timer = setInterval((function () {
                            if (e.timeCount--, e.timeCount < 0) {
                                var A = 0;
                                document.body.onmousemove = function () {
                                    0 == A && (console.log("PREVENT_HANG_LOGOUT"), e.$emit("saveStudyLog", "PREVENT_HANG_LOGOUT"), e.hangUpFlag = !0, e.loginFlag = !0, console.log("loginOut!!"), a["a"].APILoginOut()), A++
                                }, e.hangUpFlag = !1, clearInterval(e.timer), console.log("退出登录")
                            }
                        }), 1e3))) : (this.operateTime = 0, this.xy.x0 = A.x0, this.xy.y0 = A.y0)
                    }, confirm: function () {
                        this.timeCount = 0, clearInterval(this.timer), this.operateTime = 0, this.xys = {
                            x0: 0,
                            y0: 0
                        }, this.xy = {
                            x0: 0,
                            y0: 0
                        }, this.$emit("pauseOrPlay", !0), this.hangUpFlag = !1, this.startTimer(), this.$emit("saveStudyLog", "PREVENT_HANG_OPERATE")
                    }, loginOutConfirm: function () {
                        top.open("/login/login.logout.do", "_self")
                    }
                }, mounted: function () {
                    clearInterval(this.timer), this.initHangUp()
                }, beforeDestroy: function () {
                    clearInterval(this.timerNoOperate), clearInterval(this.timer)
                }
            }, z = q, $ = (t("d26f"), Object(j["a"])(z, Y, Z, !1, null, "91b5bc54", null)), AA = $.exports, eA = t("6846"),
            tA = t.n(eA), rA = t("49fb"), nA = t.n(rA), iA = t("9a48"), sA = t.n(iA), oA = t("2d5a"), aA = t.n(oA),
            cA = t("8170"), lA = t.n(cA), uA = t("aef4"), dA = t.n(uA), BA = t("da9d"), hA = t.n(BA), gA = t("c1df"),
            pA = t.n(gA), fA = t("c0e9"), wA = t.n(fA), CA = t("2ef0"), mA = t("52db"), QA = t.n(mA);

        function yA(A, e) {
            var t = Object.keys(A);
            if (Object.getOwnPropertySymbols) {
                var r = Object.getOwnPropertySymbols(A);
                e && (r = r.filter((function (e) {
                    return Object.getOwnPropertyDescriptor(A, e).enumerable
                }))), t.push.apply(t, r)
            }
            return t
        }

        function UA(A) {
            for (var e = 1; e < arguments.length; e++) {
                var t = null != arguments[e] ? arguments[e] : {};
                e % 2 ? yA(Object(t), !0).forEach((function (e) {
                    Object(s["a"])(A, e, t[e])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(A, Object.getOwnPropertyDescriptors(t)) : yA(Object(t)).forEach((function (e) {
                    Object.defineProperty(A, e, Object.getOwnPropertyDescriptor(t, e))
                }))
            }
            return A
        }

        var vA = {
            name: "course-play", data: function () {
                return {
                    urlJson: null,
                    isPlaying: !0,
                    TimeId1: null,
                    courseData: [],
                    curId: "",
                    curType: "",
                    minStudyTime: "",
                    curVideoId: "",
                    noteId: "",
                    resourceRelIdNoteId: "",
                    resourceRelId: "",
                    curTime: null,
                    seek: 0,
                    curIndex: [0, 0],
                    open: !0,
                    recordList: [],
                    recordTime: 0,
                    recordTimeId: null,
                    recordTimeTemp: 0,
                    recordTimeIdTemp: null,
                    studyRate: 0,
                    isReplayBtn: !1,
                    canSaveRecord: !0,
                    seeking: !1,
                    seeked: "",
                    videoCheck: !0,
                    canRecord: !0,
                    startTime: 0,
                    endTime: 0,
                    continueTime: 0,
                    isVideo: !1,
                    pageIndex: 0,
                    pcEdgeBrowerPreview: !1,
                    curTimeToFinish: 0,
                    noPreviewCurTimeToFinish: 0,
                    corpCode: "",
                    excludeCorpCodeList: [],
                    isIE11: !1,
                    isEdge: !1,
                    mustReplayCanFinish: !1,
                    verificationType: "",
                    hangUpFlag: !1,
                    preventCheatFlag: !1,
                    preventCheatTime: 0,
                    preventHangTime: 0,
                    pauseCountTime: 0,
                    maxTime: 0,
                    minTime: 0,
                    checkType: 2,
                    pausecountTimer: null,
                    firstEnterStudyFlag: !1,
                    studyLogData: {
                        studyLogVO: {
                            minStudyTime: "",
                            courseCode: "",
                            courseStandard: "ONLINEVIDEOCOURSE",
                            courseItemId: "",
                            courseTitle: "",
                            videoDuration: "",
                            courseItemName: "",
                            courseId: "",
                            mark: ""
                        }, eventType: ""
                    },
                    allowDrag: !1,
                    allowHighSpeed: !1,
                    allowMinStudyTime: !1,
                    addVideoClickFlag: !1,
                    settingBtn: !1,
                    heartBeatFlag: !1,
                    handoutVideo: !1,
                    handoutVideoNoteId: "/courseSetting/preview/handout?id=null",
                    resetHandoutAndVideoProps: !1,
                    seekingTimer: null,
                    seekingSaveFlag: !0,
                    activeName: "contents",
                    QAactiveName: "quiz",
                    QAformData: {},
                    questionData: [],
                    showPlaceholder: !0,
                    topicData: [],
                    inputTopicText: "",
                    icon_completed: tA.a,
                    icon_learning: nA.a,
                    shareVisible: !1,
                    teacherValue: 3.7,
                    icon_download: sA.a,
                    isHoverActive: !1,
                    btnRightActive: aA.a,
                    btnRightDefault: lA.a,
                    btnLeftActive: dA.a,
                    btnLeftDefault: hA.a,
                    navMsg: "myNote",
                    noteMsg: "",
                    isCreateNote: !1,
                    createNote: { note_title: "", note_content: "", secrecy: !1, isSendShow: !1, noteId: "" },
                    noteDownLoadVisible: !1,
                    otherNoteDownloadItem: null,
                    noteJumpPeriodVisible: !1,
                    uploadList: [],
                    showChoiceVisible: !1,
                    navActive: "1",
                    discussionValue: "",
                    replyValue: "",
                    commentList: [],
                    sendCommentIsShow: !1,
                    sendReplyIsShow: !1,
                    referenceMaterial: [],
                    courseInfo: {
                        selectCount: 0,
                        coursePeriod: 0,
                        courseScore: 0,
                        categoryNamePath: "",
                        getWay: "",
                        publishDate: "",
                        teacherList: [],
                        meaning: "",
                        orientObj: "",
                        objectives: "",
                        avgPoint: 0
                    },
                    moment: pA.a,
                    userInfo: null,
                    loading: !1,
                    condition: { pageNo: 1, pageSize: 10 },
                    satelliteList: [],
                    totalNumber: 0,
                    totalPages: 0,
                    listLoading: !1,
                    myNotes: [],
                    myNoteCondition: { pageNo: 1, pageSize: 1e4 },
                    otherNotes: [],
                    otherNoteCondition: { pageNo: 1, pageSize: 1e4 },
                    jumpPeriodSecond: 0,
                    jumpPeriodTime: 0,
                    noteStatus: "create",
                    isUploadImage: !0,
                    defaultAvatar: QA.a,
                    notejumpPeriod: null,
                    singleNoteInfo: null,
                    notejumpPeriodInfo: null,
                    chapterInfo: null,
                    isfullscreen: "",
                    timer: null,
                    isbizResultShow: !1,
                    hostName: window.location.origin,
                    coursePlayBoxHeight: "670px"
                }
            }, components: { AliPlayer: K["a"], AliyunPreview: k["a"], PreventCheat: W, HangUp: AA }, computed: {
                isRead: function () {
                    return function () {
                        var A = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].itemId : "";
                        if (A && this.notejumpPeriod && this.notejumpPeriod.chapterId && this.curChapterId && this.userInfo && this.userInfo.userId && this.notejumpPeriod.createBy && this.notejumpPeriod.sectionId === A && this.curChapterId === this.notejumpPeriod.chapterId && this.userInfo.userId !== this.notejumpPeriod.createBy) {
                            var e = "";
                            "video" === this.curType ? e = document.querySelector("#J_prismPlayer>video") : "audio" === this.curType && (e = document.querySelector("#J_prismPlayer>audio"), e || (e = document.querySelector("#J_prismPlayer>video")));
                            var t = 0;
                            if (e && (t = e.currentTime ? e.currentTime : 0), t >= this.notejumpPeriod.playbackPosition) return !0
                        }
                        return !1
                    }
                }, ellipsisSpan: function () {
                    return function () {
                        var A = this;
                        if (this.courseInfo.teacherList && this.courseInfo.teacherList.length) {
                            var e = "";
                            return this.courseInfo.teacherList.forEach((function (t, r) {
                                e += t.teacherName, r !== A.courseInfo.teacherList.length && (e += ",")
                            })), e.length > 8 ? e.slice(0, 8) + "..." : e.slice(0, this.courseInfo.teacherList.length)
                        }
                        return ""
                    }
                }, isShowJumpPeriod: function () {
                    var A = this;
                    return function (e) {
                        var t = "";
                        return A.courseData.forEach((function (A, r) {
                            A.chapterId === e.chapterId && A.resourceDTOS.forEach((function (A, r) {
                                A.itemId === e.sectionId && (t = A.resourceType || A.resourceClass || "")
                            }))
                        })), "video" === t || "audio" === t
                    }
                }, gWay: function () {
                    if (this.courseInfo) {
                        var A = this.courseInfo.getWay;
                        if (A) {
                            if ("STUDYPLAN" === A || "STUDY_PLAN" === A) return "安排课程";
                            if ("SELF" === A) return "自选";
                            if ("BTM_PROJECT" === A) return "培训项目";
                            if ("RM_PORJECT" === A) return "学习地图";
                            if ("POST_SYSTEM" === A) return "岗位体系";
                            if ("EP_PROJECT" === A) return "时光易培";
                            if ("CIRCLE_PROJECT" === A) return "岗位课程包"
                        }
                        return ""
                    }
                    return ""
                }, noMore: function () {
                    return this.commentList.length === this.totalNumber
                }, disabled: function () {
                    return this.loading || this.noMore
                }, QANum: function () {
                    return this.QAformData.title ? 140 - this.QAformData.title.length : 140
                }, arrowLeft: function () {
                    return "quiz" === this.QAactiveName ? 29 : 124
                }, language: function () {
                    return window.$cookies.get("local_") || "zh_CN"
                }, aliPlayer: function () {
                    return "video" === this.curType || "audio" === this.curType ? this.$refs.aliPlayer : null
                }, player: function () {
                    return "video" === this.curType || "audio" === this.curType ? this.$refs.aliPlayer.player : null
                }, curChapterId: function () {
                    return this.courseData[this.curIndex[0]].chapterId
                }, curChapterName: function () {
                    return this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].chapterName ? this.courseData[this.curIndex[0]].chapterName : ""
                }, curChapterContent: function () {
                    return this.courseData[this.curIndex[0]]
                }, curInfo: function () {
                    return this.curIndex && this.courseData && this.courseData.length > 0 ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]] : null
                }, currentStudyTime: function () {
                    var A = this.curIndex && this.courseData && this.courseData.length > 0 ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]] : null,
                        e = A && A.currentStudyTime ? A.currentStudyTime : 0;
                    return A ? A.minStudyTime - e - this.recordTime : 0
                }, nextIndex: function () {
                    return this.courseData[this.curIndex[0]] && !this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1] + 1] ? this.courseData[this.curIndex[0] + 1] ? [this.curIndex[0] + 1, 0] : null : [this.curIndex[0], this.curIndex[1] + 1]
                }, nextInfo: function () {
                    return this.nextIndex ? this.courseData[this.nextIndex[0]].resourceDTOS[this.nextIndex[1]] : null
                }, nextId: function () {
                    return this.nextInfo ? this.nextInfo.resourceId : ""
                }, courseParams: function () {
                    return decodeURIComponent(this.$route.params.courseInfo).split("&")
                }, courseId: function () {
                    return this.courseParams[0]
                }, providerCorpCode: function () {
                    return this.courseParams[1]
                }, sourceId: function () {
                    return this.courseParams[2]
                }, courseTitle: function () {
                    return parent.document.title
                }
            }, watch: {
                curIndex: {
                    handler: function () {
                        var A = this;
                        this.curVideoId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId : "", this.noteId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId : "", this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "", this.curTime = {
                            minStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                            currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                        }, this.courseData[this.curIndex[0]] && "url" === this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType && this.$store.dispatch("preview/fetchPreviewAction", {
                            param: {
                                providerCorpCode: this.providerCorpCode,
                                chapterId: this.courseData[this.curIndex[0]].chapterId,
                                id: this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceId
                            }, callback: function (e) {
                                A.urlJson = e;
                                var t = A.recordList.find((function (e) {
                                    return e.resourceId === A.curId
                                }));
                                t && A.$set(A.urlJson, "confirmFinish", t.confirmFinish), e.content || (setTimeout((function () {
                                    var A = document.getElementsByTagName("iframe")[0];
                                    A.style.display = "none"
                                }), 0), setTimeout((function () {
                                    var A = document.getElementsByTagName("iframe")[0];
                                    A.style.display = "block", A.style.height = "100%", A.style.width = "100%"
                                }), 0))
                            }
                        })
                    }, deep: !0
                }, courseData: {
                    handler: function () {
                        var A = this;
                        this.curVideoId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId : "", this.noteId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId : "", this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "", this.curTime = {
                            minStudyTime: this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                            currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                        }, this.courseData[this.curIndex[0]] && "url" === this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType && this.$store.dispatch("preview/fetchPreviewAction", {
                            param: {
                                providerCorpCode: this.providerCorpCode,
                                chapterId: this.courseData[this.curIndex[0]].chapterId,
                                id: this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceId
                            }, callback: function (e) {
                                A.urlJson = e;
                                var t = A.recordList.find((function (e) {
                                    return e.resourceId === A.curId
                                }));
                                A.initHeart(), t && A.$set(A.urlJson, "confirmFinish", t.confirmFinish), e.content || (setTimeout((function () {
                                    var A = document.getElementsByTagName("iframe")[0];
                                    A.style.display = "none"
                                }), 0), setTimeout((function () {
                                    var A = document.getElementsByTagName("iframe")[0];
                                    A.style.display = "block", A.style.height = "100%", A.style.width = "100%"
                                }), 0))
                            }
                        })
                    }, deep: !0
                }, currentStudyTime: function (A) {
                    0 === A && "video" !== this.curType && "audio" !== this.curType && (this.recordTimeId && clearInterval(this.recordTimeId), this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), this.updateCourseRecord())
                }, recordTime: function (A) {
                    var e = this;
                    "video" !== this.curType && "audio" !== this.curType && A % 180 === 0 && 0 !== A && (this.updateCourseRecord(1), this.recordTimeId && clearInterval(this.recordTimeId)), ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && (this.curTimeToFinish = Math.round(this.player.getDuration() * this.courseData[this.curIndex[0]].finishPercent), this.noPreviewCurTimeToFinish = Math.round(.5 * this.player.getDuration())), ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && A === this.noPreviewCurTimeToFinish && (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                        e.canRecord = !0
                    }), 1e3)), ("video" === this.curType || "audio" === this.curType) && this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && A === this.noPreviewCurTimeToFinish && !this.allowDrag && (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                        e.canRecord = !0
                    }), 1e3))
                }
            }, directives: {
                focus: {
                    inserted: function (A, e) {
                        var t = e.value;
                        t && A.focus()
                    }
                }
            }, methods: {
                downLoadTxt: function (A, e) {
                    var t = document.createElement("a");
                    if (t.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(e)), t.setAttribute("download", A), document.createEvent) {
                        var r = document.createEvent("MouseEvents");
                        r.initEvent("click", !0, !0), t.dispatchEvent(r)
                    } else t.click();
                    this.noteDownLoadVisible = !1
                }, toggleThumbsUp: Object(CA["throttle"])((function (A) {
                    var e = this, t = { coursePraise: { courseId: this.courseId, praiseStatus: !A } };
                    D(t).then((function () {
                        e.getCourseInfo()
                    }))
                }), 300), toggleCollection: Object(CA["throttle"])((function (A) {
                    var e = this, t = { courseId: this.courseId };
                    A ? S(t).then((function () {
                        e.getCourseInfo()
                    })) : x(t).then((function () {
                        e.getCourseInfo()
                    }))
                }), 300), downLoadRefer: function (A) {
                    window.open(A.refStoredFileId, "target")
                }, showRefer: function (A) {
                    window.open(A.refStoredFileId, "target")
                }, queryReferences: function () {
                    var A = this, e = { courseId: this.courseId };
                    y(e).then((function (e) {
                        var t = e.bizResult;
                        A.referenceMaterial = t || []
                    }))
                }, initScroll: function () {
                    this.loading = !1, this.condition.pageNo = 1, this.commentList = [], this.totalNumber = 0, this.totalPages = 0
                }, load: function () {
                    this.commentList.length < this.totalNumber && (this.loading = !0), this.getCourseDiscuss("load")
                }, delComment: function (A, e) {
                    var t = this;
                    this.$confirm("确认删除当前评论吗？", "提示", {
                        confirmButtonText: "确定",
                        cancelButtonText: "取消",
                        type: "warning"
                    }).then((function () {
                        var e = { discussIds: A.discussId || "", csrfToken: "" };
                        U(e).then((function (A) {
                            "1001" == A.code && (t.$message.success("讨论删除成功！"), t.getCourseDiscuss("init"))
                        }))
                    })).catch((function () {
                    }))
                }, choiceReply: function (A, e) {
                    A.isReplyShow = !A.isReplyShow, this.commentList[e] = A
                }, sendReply: function (A) {
                    var e = this;
                    if (this.replyValue) {
                        var t = {
                            discuss: {
                                idPath: A.idPath,
                                objectId: this.courseId,
                                contentPreview: this.replyValue || ""
                            }
                        };
                        this.sendReplyIsShow = !0, v(t).then((function (A) {
                            e.sendReplyIsShow = !1, A.bizResult ? (e.$message.success("回复成功！"), e.replyValue = "", e.getCourseDiscuss("init")) : e.$message.warning("回复失败！")
                        }))
                    } else this.$message.warning("请先输入回复信息。")
                }, sendDiscuss: function () {
                    var A = this;
                    if (this.discussionValue) {
                        var e = { discuss: { objectId: this.courseId, contentPreview: this.discussionValue }, isShare: !0 };
                        this.sendCommentIsShow = !0, F(e).then((function (e) {
                            A.sendCommentIsShow = !1, e.bizResult ? (A.$message.success("发表成功！"), A.discussionValue = "", A.getCourseDiscuss("init")) : A.$message.warning("发表失败！")
                        })).catch((function () {
                            A.sendCommentIsShow = !1
                        })).finally((function () {
                            A.sendCommentIsShow = !1
                        }))
                    } else this.$message.warning("请先输入评论信息。")
                }, getCourseDiscuss: function () {
                    var A = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    "init" === e && (this.condition.pageNo = 1, this.condition.pageSize = 10, this.initScroll());
                    var t = {
                        courseType: "NEW_COURSE_CENTER",
                        courseId: this.courseId,
                        page: { pageNo: this.condition.pageNo, pageSize: this.condition.pageSize }
                    };
                    I(t).then((function (e) {
                        var t = e.bizResult, r = t.rows, n = t.total, i = t.totalPages;
                        r && (A.commentList = [].concat(Object(o["a"])(A.commentList), Object(o["a"])(r.map((function (A) {
                            return UA(UA({}, A), {}, { isReplyShow: !1 })
                        }))))), A.totalNumber = n, A.totalPages = i, A.loading = !1, A.condition.pageNo > A.totalPages || A.condition.pageNo++
                    }))
                }, navToTeacherPage: function (A) {
                    if (this.courseInfo.teacherList.length) {
                        var e = "NEW_COURSE_CENTER";
                        window.open(location.origin + "/els/html/teacher/teacher.teacherTopHeader.do?teacherId=".concat(A, "&courseType=").concat(e))
                    }
                }, getCourseInfo: function () {
                    var A = this, e = { courseId: this.courseId };
                    E(e).then((function (e) {
                        console.log("getCourseInfoJson", e.bizResult), A.courseInfo = e.bizResult || {
                            selectCount: 0,
                            coursePeriod: 0,
                            courseScore: 0,
                            categoryNamePath: "",
                            getWay: "",
                            publishDate: "",
                            teacherList: [],
                            meaning: "",
                            orientObj: "",
                            objectives: "",
                            avgPoint: 0
                        }
                    }))
                }, toggleNavItem: function (A) {
                    this.navActive = A
                }, clickUpLoad: function () {
                    this.$refs.uploadFile.type = "file"
                }, changeUpLoad: function (A) {
                    var e = this.uploadList.length, t = !0;
                    if (A.target.files && A.target.files.length) {
                        console.log("files", A.target.files[0]);
                        for (var r = Array.from(A.target.files), n = 0; n <= r.length - 1; n++) if (!r[n].type.includes("image")) {
                            t = !1;
                            break
                        }
                        if (!t) return void this.$message.warning("请选择图片文件！！！")
                    }
                    e ? e + Array.from(A.target.files).length <= 9 ? (this.isUploadImage = !1, this.uploadImageFile(Array.from(A.target.files)), this.$refs.uploadFile.type = "") : this.$message.warning("图片最多可上传9张") : Array.from(A.target.files).length <= 9 ? (this.isUploadImage = !1, this.uploadImageFile(Array.from(A.target.files)), this.$refs.uploadFile.type = "") : this.$message.warning("图片最多可上传9张")
                }, deleteItem: function (A) {
                    this.uploadList = this.uploadList.filter((function (e, t) {
                        return A !== t
                    }))
                }, jumpPeriod: function (A, e) {
                    var t = this;
                    this.updateCourseRecord();
                    var r = null;
                    if ("video" === this.curType ? r = document.querySelector("#J_prismPlayer>video") : "audio" === this.curType && (r = document.querySelector("#J_prismPlayer>audio"), r || (r = document.querySelector("#J_prismPlayer>video"))), r && r.pause(), this.notejumpPeriod = A, this.courseData.forEach((function (A, e) {
                        A.chapterId === t.notejumpPeriod.chapterId && A.resourceDTOS.forEach((function (A, e) {
                            A.itemId === t.notejumpPeriod.sectionId && (t.notejumpPeriodInfo = UA({}, A))
                        }))
                    })), this.jumpPeriodSecond = A.playbackPosition || 0, this.jumpPeriodTime = this.showTime(A.playbackPosition), "window" === e) {
                        var n = this.userInfo, i = this.notejumpPeriod, s = this.notejumpPeriodInfo,
                            o = this.jumpPeriodSecond;
                        !n || !i || n.userId !== i.createBy || n && i && n.userId !== i.createBy && s && s.currentPosition && s.currentPosition >= o ? this.noteJumpPeriodVisible = !0 : this.confirmPositionPlay()
                    } else this.noteJumpPeriodVisible = !0
                }, showTime: function (A) {
                    if (A < 60) return A < 10 ? "00:0" + A : "00:" + A;
                    var e = Math.floor(A / 60), t = Math.floor(A % 60);
                    if (e < 60) return e < 10 ? t < 10 ? "0" + e + ":0" + t : "0" + e + ":" + t : t < 10 ? e + ":0" + t : e + ":" + t;
                    var r = Math.floor(e / 60), n = Math.floor(e % 60), i = r < 10 ? "0" + r : r,
                        s = n < 10 ? "0" + n : n, o = t < 10 ? "0" + t : t;
                    return i + ":" + s + ":" + o
                }, editPeriod: function (A) {
                    this.singleNoteInfo = A, this.createNote.note_title = A.noteName, this.createNote.note_content = A.content, this.createNote.secrecy = A.isSecret, this.createNote.noteId = A.noteId, this.isCreateNote = !0, this.noteStatus = "update"
                }, confirmPositionPlay: function () {
                    var A = this;
                    this.noteJumpPeriodVisible = !1;
                    var e = this.userInfo, t = this.notejumpPeriod, r = this.notejumpPeriodInfo,
                        n = this.jumpPeriodSecond;
                    console.log(e, t, r, n), (e && t && e.userId === t.createBy || e && t && e.userId !== t.createBy && r && r.currentPosition && r.currentPosition >= n) && this.$nextTick((function () {
                        A.courseData.forEach((function (e, t) {
                            e.chapterId === A.notejumpPeriod.chapterId && e.resourceDTOS.forEach((function (e, r) {
                                e.itemId === A.notejumpPeriod.sectionId && (A.curIndex = [t, r], A.curId = e.resourceId, A.curVideoId = e.resourceRelId, A.isVideo = !0, A.curType = e.resourceType || e.resourceClass, setTimeout((function () {
                                    A.seek = A.jumpPeriodSecond || 0, A.$refs.aliPlayer.aliPlayer(A.curVideoId, "pause")
                                }), 0))
                            }))
                        }))
                    }))
                }, closePositionPlay: function () {
                    this.noteJumpPeriodVisible = !1
                }, showDownLoadDialog: function (A) {
                    var e = this;
                    console.log(A), this.noteDownLoadVisible = !0, this.jumpPeriodTime = this.showTime(A.playbackPosition), this.otherNoteDownloadItem = A, this.otherNoteDownloadItem.faceUrl = this.otherNoteDownloadItem.faceUrl.includes("default_180") ? this.otherNoteDownloadItem.faceUrl : "/".concat(this.otherNoteDownloadItem.faceUrl), this.courseData.forEach((function (t, r) {
                        t.chapterId === A.chapterId && t.resourceDTOS.forEach((function (n, i) {
                            n.itemId === A.sectionId && (e.chapterInfo = UA(UA(UA({}, n), t), {}, { mIndex: r }))
                        }))
                    }))
                }, initNoteInfo: function () {
                    this.createNote = {
                        note_title: "",
                        note_content: "",
                        secrecy: "",
                        isSendShow: !1
                    }, this.isCreateNote = !1
                }, sendNote: function () {
                    var A = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        t = arguments.length > 1 ? arguments[1] : void 0,
                        r = arguments.length > 2 ? arguments[2] : void 0;
                    "toggle" === e && (this.createNote.note_title = t.noteName, this.createNote.note_content = t.content, this.createNote.secrecy = t.isSecret, this.createNote.noteId = t.noteId, this.noteStatus = "update", this.createNote.secrecy = !this.createNote.secrecy);
                    var n = this.createNote, i = n.note_title, s = n.note_content, o = n.secrecy, a = n.noteId;
                    if (i.trim()) if (s.trim()) {
                        var c = "";
                        "video" === this.curType ? c = document.querySelector("#J_prismPlayer>video") : "audio" === this.curType && (c = document.querySelector("#J_prismPlayer>audio"), c || (c = document.querySelector("#J_prismPlayer>video")));
                        var l = 0;
                        c && (l = c.currentTime ? parseInt(c.currentTime) : 0), "toggle" === e && t.playbackPosition && (l = t.playbackPosition);
                        var u = this.curChapterContent.chapterId || "", d = this.curInfo.itemId || "";
                        t && (u = t.chapterId || "", d = t.sectionId || ""), console.log("!msg && !item && this.singleNoteInfo", e, !t, this.singleNoteInfo), !t && this.singleNoteInfo && "update" === this.noteStatus && (u = this.singleNoteInfo.chapterId || "", d = this.singleNoteInfo.sectionId || "", l = this.singleNoteInfo.playbackPosition || "");
                        var B = {
                            "courseNote.courseId": this.courseId,
                            "courseNote.noteId": "create" === this.noteStatus ? "" : a,
                            "courseNote.noteName": i,
                            "courseNote.content": s,
                            "courseNote.isSecret": o,
                            "courseNote.playbackPosition": l,
                            "courseNote.chapterId": u,
                            "courseNote.sectionId": d
                        };
                        this.createNote.isSendShow = !0, b(B).then((function () {
                            A.createNote.isSendShow = !1, A.initNoteInfo(), "create" === A.noteStatus ? A.$message.success("笔记发布成功！") : r ? "open" === r ? A.$message.success("笔记状态已公开！") : "close" === r && A.$message.success("笔记状态已保密！") : A.$message.success("笔记更新成功！"), A.getMyNoteAndOtherNoteList("me", A.myNoteCondition), A.singleNoteInfo = null
                        }))
                    } else this.$message.warning("笔记内容不能为空！"); else this.$message.warning("笔记标题不能为空！")
                }, delMyNote: function (A) {
                    var e = this;
                    this.$confirm("确认删除当前笔记吗？", "提示", {
                        confirmButtonText: "确定",
                        cancelButtonText: "取消",
                        type: "warning"
                    }).then((function () {
                        var t = { noteId: A.noteId || "" };
                        T(t).then((function (A) {
                            e.getMyNoteAndOtherNoteList("me", e.myNoteCondition, "init")
                        }))
                    })).catch((function () {
                    }))
                }, toggleCreateNote: function () {
                    this.isCreateNote = !0, this.noteStatus = "create", this.createNote.note_title = "", this.createNote.note_content = "", this.createNote.secrecy = !1, this.createNote.isSendShow = !1, this.createNote.noteId = ""
                }, noteEnter: function (A) {
                    this.noteMsg = A + "-enter"
                }, noteLeave: function (A) {
                    this.noteMsg = A + "-leave"
                }, navToggle: function (A) {
                    this.navMsg = A, this.isCreateNote = !1, "myNote" === A ? this.getMyNoteAndOtherNoteList("me", this.myNoteCondition) : "otherNote" === A && this.getMyNoteAndOtherNoteList("other", this.otherNoteCondition)
                }, enterDefault: function () {
                    this.isHoverActive = !0
                }, leaveDefault: function () {
                    this.isHoverActive = !1
                }, getImage: function (A, e) {
                    return new Promise((function (t, r) {
                        var n = new XMLHttpRequest;
                        n.open("get", A, !0), n.setRequestHeader("Cache-Control", "no-cache"), n.responseType = "blob", n.onload = function () {
                            200 == this.status && (document.getElementById(e).src = URL.createObjectURL(this.response), t())
                        }, n.onerror = function () {
                            r()
                        }, n.send()
                    }))
                }, saveDownload: function (A) {
                    var e = this, t = document.querySelector("#sw-main-img");
                    this.getImage(t.src, "sw-main-img").then((function (A) {
                        console.log("res", A)
                    })).finally((function () {
                        var A = document.getElementById("sw-main-content");
                        A.style.display = "block", e.$nextTick((function () {
                            wA()(document.getElementById("sw-main"), { allowTaint: !1, useCORS: !0 }).then((function (t) {
                                var r = t.toDataURL("image/png"),
                                    n = e.courseInfo && e.courseInfo.courseTitle ? e.courseInfo.courseTitle + "分享" : "默认课程分享";
                                e.downloadShareFile(n, r), A.style.display = "none"
                            }))
                        }))
                    }))
                }, downloadShareFile: function (A, e) {
                    var t = function (A) {
                        for (var e = A.split(";base64,"), t = e[0].split(":")[1], r = window.atob(e[1]), n = r.length, i = new Uint8Array(n), s = 0; s < n; ++s) i[s] = r.charCodeAt(s);
                        return new Blob([i], { type: t })
                    }, r = document.createElement("a"), n = t(e), i = document.createEvent("HTMLEvents");
                    i.initEvent("click", !0, !0), r.download = A, r.href = URL.createObjectURL(n), r.click()
                }, copyText: function (A) {
                    var e = document.createElement("input");
                    e.setAttribute("id", "cp_hgz_input"), e.value = A, document.getElementsByTagName("body")[0].appendChild(e), document.getElementById("cp_hgz_input").select(), document.execCommand("copy"), document.getElementById("cp_hgz_input").remove(), this.$message.success("课程链接已复制，快去分享吧~")
                }, closeDialog: function () {
                    this.shareVisible = !1
                }, shareCourse: function () {
                    this.shareVisible = !0
                }, videoSeeking: function () {
                    var A = this;
                    this.seekingSaveFlag = !1, clearTimeout(this.seekingTimer), this.seekingTimer = setTimeout((function () {
                        A.seekingSaveFlag = !0, clearTimeout(A.seekingTimer)
                    }), 5e3)
                }, initHeart: function () {
                    var A = this;
                    clearInterval(this.heartTimer);
                    var e = { courseId: this.courseId, eln_session_id: Object(N["getUrl"])("eln_session_id") };
                    a["c"].loadCourseSystemSeting(e).then((function (e) {
                        "1001" == e.code && (!e.bizResult.heartBeat || A.curInfo.finish && !e.bizResult.continueHeartBeat || (A.heartTimer = setInterval((function () {
                            a["c"].heartBeatSetData(A.courseId)
                        }), 6e4), A.heartBeatFlag = !0))
                    }))
                }, resetHandoutAndVideo: function () {
                    this.resetHandoutAndVideoProps = !0
                }, openAndCloseVideo: function (A) {
                    this.handoutVideoNoteId = "/courseSetting/preview/handout?id=" + A.noteId;
                    document.getElementById("aliPlayer");
                    this.handoutVideo = !!A.flag, this.resetHandoutAndVideoProps = !A.flag
                }, openHandoutOperate: function (A) {
                    A && (this.handoutVideoNoteId = "/courseSetting/preview/handout?id=" + A, this.handoutVideo = !this.handoutVideo, this.resetHandoutAndVideoProps = !this.resetHandoutAndVideoProps)
                }, toFullVideo: function (A) {
                    A.requestFullscreen ? A.requestFullscreen() : A.webkitRequestFullScreen ? A.webkitRequestFullScreen() : A.mozRequestFullScreen ? A.mozRequestFullScreen() : A.msRequestFullscreen()
                }, exitFullscreen: function () {
                    document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen()
                }, getCourseData: function () {
                    var A = this, e = { courseId: this.sourceId, providerCorpCode: this.providerCorpCode };
                    a["b"].APIshowCourseChapter(e).then((function (e) {
                        A.courseData = e.bizResult.filter((function (A) {
                            return A.resourceDTOS.length > 0
                        })), A.settingBtn = A.courseData[0].customAliVideoCorp, "preview" !== A.$route.query.from && !1 === A.pcEdgeBrowerPreview ? A.getStudyRecordList(A.setPlaytimePosition) : A.setPlaytimePosition(), A.isPlaying = !0
                    }))
                }, setPlaytimePosition: function () {
                    var A = this;
                    this.recordLearningStatus("ENTER_STUDY"), this.recordLearningStatus("COURSE_SIGN_IN");
                    var e, t = this.recordList.find((function (A) {
                        return 1 === A.confirmLearning
                    })), r = t ? this.courseData.findIndex((function (A) {
                        return A.resourceDTOS.some((function (A) {
                            return A.resourceId === t.resourceId
                        }))
                    })) : -1;
                    void 0 !== t && r >= 0 ? (e = this.courseData.findIndex((function (A) {
                        return A.resourceDTOS.some((function (A) {
                            return A.resourceId === t.resourceId
                        }))
                    })), this.curIndex = [e, this.courseData[e].resourceDTOS.findIndex((function (A) {
                        return A.resourceId === t.resourceId
                    }))], this.pageIndex = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].pageIndex || 0, this.curType = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType, this.minStudyTime = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime, "video" !== this.curType && "audio" !== this.curType || (this.isVideo = !0), this.curId = t.resourceId, this.minStudyTime = t.minStudyTime, this.curVideoId = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId, this.noteId = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId, this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "", this.curTime = {
                        minStudyTime: this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                        currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                    }) : (this.pageIndex = this.courseData[0] && this.courseData[0].resourceDTOS[0] && this.courseData[0].resourceDTOS[0].pageIndex || 0, this.curType = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].resourceType : "", this.minStudyTime = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].minStudyTime : "", "video" !== this.curType && "audio" !== this.curType || (this.isVideo = !0), this.curId = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].resourceId : "");
                    var n = this.recordList.find((function (e) {
                        return e.resourceId === A.curId
                    }));
                    void 0 === n || null === n.currentPosition || 1 === n.confirmFinish || "video" !== this.curType && "audio" !== this.curType || (this.seek = n.currentPosition), this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), this.recordTimeTemp = this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0, ("video" !== this.curType && "audio" !== this.curType || ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1) && ("video" !== this.curType && "audio" !== this.curType || this.allowDrag || this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                        confirmButtonText: "确定",
                        showClose: !1,
                        dangerouslyUseHTMLString: !0
                    }), this.recordTime = 0, this.recordTimeId = setInterval((function () {
                        A.recordTime++
                    }), 1e3))
                }, syncStudyRecord: function () {
                    if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                        var A = {
                            courseId: this.courseId,
                            sourceId: this.sourceId,
                            providerCorpCode: this.providerCorpCode
                        };
                        a["c"].APIsyncStudyRecord(A)
                    }
                }, getStudyRecordList: function () {
                    var A = this, e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                        t = { courseId: this.courseId, sourceId: this.sourceId, providerCorpCode: this.providerCorpCode };
                    a["c"].APIgetStudyRecordList(t).then((function (t) {
                        A.recordList = t.bizResult, A.recordList && A.recordList.length > 0 && A.recordList[0].alert && A.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">管理员调整了这门课程的内容，您的学习记录可能因此发生变化。</span>', "", {
                            confirmButtonText: A.$t("v4.js.pc.ocmt.confirm"),
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }), A.recordList.forEach((function (e) {
                            A.courseData.forEach((function (t) {
                                t.resourceDTOS.forEach((function (t) {
                                    t.resourceId === e.resourceId && (1 === e.confirmFinish && A.$set(t, "finish", !0), A.$set(t, "currentStudyTime", e.currentStudyTime), A.$set(t, "currentPosition", e.currentPosition), A.$set(t, "pageIndex", e.pageIndex))
                                }))
                            }))
                        })), e && e()
                    }))
                }, updateCourseRecord: function (A, e) {
                    var t = this;
                    if ("preview" !== this.$route.query.from && (!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1) && this.canSaveRecord) {
                        if (!this.allowDrag && !this.seekingSaveFlag && ("video" === this.curType || "audio" === this.curType)) return;
                        e && clearInterval(this.recordTimeIdTemp);
                        var r = this.recordList.find((function (A) {
                            return A.resourceId === t.curId
                        })), n = void 0 !== r ? r.recordId : null;
                        if (void 0 !== r && 1 !== r.confirmFinish || void 0 === r) {
                            var i = 0;
                            "video" !== this.curType && "audio" !== this.curType || (i = this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish ? this.recordTime : this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish ? this.curTimeToFinish : Math.round(Math.max(this.seek, this.player.getCurrentTime())));
                            var s = {
                                recordId: n,
                                courseId: this.courseId,
                                sourceId: this.sourceId,
                                providerCorpCode: this.providerCorpCode,
                                chapterId: this.curChapterId,
                                resourceId: this.curId,
                                timeToFinish: this.curTimeToFinish,
                                currentPosition: i,
                                type: this.curType,
                                currentStudyTime: "video" === this.curType || "audio" == this.curType ? this.recordTimeTemp - this.curTime.currentStudyTime : this.recordTime,
                                pageIndex: "video" !== this.curType && "audio" !== this.curType && this.$refs.aliPreview ? this.$refs.aliPreview.currentCount : 0
                            };
                            this.canSaveRecord = !1, a["c"].APIupdateCourseRecord(s).then((function (e) {
                                t.getStudyRecordList((function () {
                                    A && (t.recordTimeId && clearInterval(t.recordTimeId), t.recordTime = 0, t.recordTimeId = setInterval((function () {
                                        t.recordTime++
                                    }), 1e3)), t.canSaveRecord = !0
                                })), t.getStudyRate()
                            }))
                        }
                    }
                }, getStudyRate: function () {
                    var A = this,
                        e = { courseId: this.courseId, sourceId: this.sourceId, providerCorpCode: this.providerCorpCode };
                    a["c"].APIgetStudyRate(e).then((function (e) {
                        A.studyRate = e.bizResult, localStorage.studyRate = A.studyRate
                    }))
                }, checkoutSection: function (A, e) {
                    var t = this, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                    arguments.length > 3 && arguments[3];
                    clearInterval(this.heartTimer), this.firstEnterStudyFlag && this.recordLearningStatus("QUIT_COURSE_ITEM");
                    var n = A.resourceId, i = A.resourceType, s = A.minStudyTime;
                    if (this.mustReplayCanFinish = !1, this.updateCourseRecord(), this.videoCheck = !1, "video" !== this.curType && "audio" !== this.curType || this.player.pause(), this.recordTimeId && clearInterval(this.recordTimeId), this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), A.pageIndex && (this.pageIndex = A.pageIndex), this.curType = i, "video" !== this.curType && "audio" !== this.curType && (this.isPlaying = !0), "video" === this.curType || "audio" === this.curType ? this.resetHandoutAndVideo() : (document.pictureInPictureElement && document.exitPictureInPicture(), this.handoutVideo = !1), "video" === this.curType || "audio" === this.curType) {
                        var o = this.recordList.find((function (A) {
                            return A.resourceId === n
                        }));
                        void 0 !== o && null !== o.currentPosition && 1 !== o.confirmFinish && o.currentPosition < o.timeToFinish ? (this.seeked = o.currentPosition, this.seek = o.currentPosition) : (this.seeked = 0, this.seek = 0), this.$refs.aliPlayer && (this.$refs.aliPlayer.seeked = this.seeked, this.player.seek(0))
                    }
                    this.preventCheatFlag && ("video" == this.curType || "audio" == this.curType ? this.$refs.preventCheat.resetPlayTime(this.preventCheatTime) : this.$refs.preventCheat.initPreventCheat(this.preventCheatTime)), this.recordTime = 0, this.recordTimeTemp = 0, this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), this.$nextTick((function () {
                        t.isVideo = !1, t.curId = n, t.minStudyTime = s, t.curIndex = [e, r], t.curVideoId = t.courseData[t.curIndex[0]] ? t.courseData[t.curIndex[0]].resourceDTOS[t.curIndex[1]].resourceRelId : "", t.noteId = t.courseData[t.curIndex[0]] ? t.courseData[t.curIndex[0]].resourceDTOS[t.curIndex[1]].noteId : "", console.log("noteId", t.noteId), t.resourceRelIdNoteId = t.courseData[t.curIndex[0]] ? (t.courseData[t.curIndex[0]].resourceDTOS[t.curIndex[1]].noteResource || {}).resourceRelId : "", t.curTime = {
                            minStudyTime: t.courseData[t.curIndex[0]] ? t.courseData[t.curIndex[0]].resourceDTOS[t.curIndex[1]].minStudyTime : "",
                            currentStudyTime: t.courseData[t.curIndex[0]] ? t.courseData[t.curIndex[0]].resourceDTOS[t.curIndex[1]].currentStudyTime : ""
                        }, t.recordTimeTemp = t.courseData[t.curIndex[0]] && t.courseData[t.curIndex[0]].resourceDTOS[t.curIndex[1]].currentStudyTime ? t.courseData[t.curIndex[0]].resourceDTOS[t.curIndex[1]].currentStudyTime : 0, "video" !== t.curType && "audio" != t.curType || (t.isVideo = !0, t.$refs.aliPlayer && t.$refs.aliPlayer.aliPlayer(t.curVideoId), t.recordTimeIdTemp = setInterval((function () {
                            t.recordTimeTemp++
                        }), 1e3)), ("video" !== t.curType && "audio" !== t.curType || ("video" === t.curType || "audio" === t.curType) && t.isEdge && t.excludeCorpCodeList.indexOf(t.corpCode) > -1) && ("video" !== t.curType && "audio" !== t.curType || t.allowDrag || t.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                            confirmButtonText: t.$t("v4.js.pc.ocmt.confirm"),
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }), t.recordTimeId = setInterval((function () {
                            t.recordTime++
                        }), 1e3)), t.recordLearningStatus("ENTER_COURSE_ITEM")
                    }))
                }, toggleCollapse: function (A, e) {
                    A.fold = !A.fold, this.$set(this.courseData, e, A)
                }, startRecord: function () {
                }, play: function () {
                    var A = this, e = this;
                    clearTimeout(this.pausecountTimer), this.pausecountTimer = setTimeout((function () {
                        e.pauseCountTime && e.recordLearningStatus("PLAY")
                    }), 1e3), ("video" === this.curType || "audio" === this.curType) && (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && (clearInterval(this.recordTimeId), this.recordTimeId = setInterval((function () {
                        A.recordTime++
                    }), 1e3)), "video" !== this.curType && "audio" !== this.curType || (clearInterval(this.recordTimeIdTemp), this.recordTimeIdTemp = setInterval((function () {
                        A.recordTimeTemp++
                    }), 1e3)), this.isPlaying = !0, this.videoCheck = !0
                }, pause: function () {
                    var A = this;
                    this.pauseCountTime = 0, clearTimeout(this.pausecountTimer), this.pausecountTimer = setTimeout((function () {
                        A.pauseCountTime++, A.recordLearningStatus("PAUSE")
                    }), 1e3), ("video" === this.curType || "audio" === this.curType) && (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && clearInterval(this.recordTimeId), "video" !== this.curType && "audio" !== this.curType || clearInterval(this.recordTimeIdTemp)
                }, ended: function () {
                    var A = this;
                    console.log("视频播放完成！章节结束时间"), this.recordLearningStatus("COMPLETE_COURSE_ITEM"), this.getStudyRecordList((function () {
                        A.canSaveRecord = !0
                    })), this.$nextTick((function () {
                        var e = A.recordList.find((function (e) {
                            return e.resourceId === A.curId
                        }));
                        !A.isIE11 && !A.isEdge || A.isIE11 && A.excludeCorpCodeList.indexOf(A.corpCode) > -1 && !A.allowDrag && A.recordTime >= A.noPreviewCurTimeToFinish ? (A.mustReplayCanFinish = !1, A.updateCourseRecord(), A.aliPlayer.resetPlayer()) : A.isIE11 && A.excludeCorpCodeList.indexOf(A.corpCode) > -1 && !A.allowDrag && A.recordTime < A.noPreviewCurTimeToFinish && (void 0 === e || 1 !== e.confirmFinish) ? (A.mustReplayCanFinish = !0, clearInterval(A.recordTimeId), A.updateCourseRecord()) : (A.mustReplayCanFinish = !1, A.aliPlayer.resetPlayer()), A.isPlaying = !1, A.isReplayBtn = !0, setTimeout((function () {
                            A.isPlaying || "preview" === A.$route.query.from || "unionpay" !== A.corpCode || A.playNextSection()
                        }), 1e3)
                    }))
                }, ready: function () {
                    this.curTimeToFinish = Math.round(this.player.getDuration() * this.courseData[this.curIndex[0]].finishPercent), this.noPreviewCurTimeToFinish = Math.round(.5 * this.player.getDuration());
                    var A = this;
                    "video" != this.curType && "audio" != this.curType || document.getElementsByClassName("rate-list").length && document.getElementsByClassName("rate-list")[0].addEventListener("click", (function (e) {
                        var t = e.target.innerText.replace("x", "");
                        A.studyLogData.studyLogVO.mark = t, A.recordLearningStatus("SPEED_CHANGE")
                    }))
                }, timeupdate: function () {
                    var A = this;
                    if (this.videoCheck && ("video" === this.curType || "audio" === this.curType)) {
                        var e = Math.floor(this.player.getCurrentTime()) + 1, t = this.recordList.find((function (e) {
                            return e.resourceId === A.curId
                        }));

                        /** NicolasLemon修改2 */
                        // 修改当前对象的seek时间，在 修改1 中已经将播放器的播放时间设置成需要观看的最小的学习时间
                        this.seek = Math.floor(this.player.getCurrentTime());

                        if (e > this.seek && e - this.seek > 3 && (void 0 === t || 1 !== t.confirmFinish) && !this.allowDrag && "preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) this.player.seek(this.seek); else {
                            var r = e > 2 ? e : 0;
                            this.seek = Math.max(this.seek, r)
                        }
                        (void 0 === t || 1 !== t.confirmFinish) && (e > this.curTimeToFinish || this.minStudyTime === this.recordTimeTemp) && (!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.allowDrag) && (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                            A.canRecord = !0
                        }), 1e3)), e !== this.curTimeToFinish && (0 === e || e % 180 !== 0 && this.minStudyTime !== this.recordTimeTemp) || !(!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.allowDrag) || (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                            A.canRecord = !0
                        }), 1e3))
                    }
                }, rePlay: function () {
                    this.resetHandoutAndVideo(), this.player.seek(0), this.isPlaying = !0, this.seek = 0, this.play(), this.isReplayBtn = !1, this.recordTime = 0, this.recordTimeTemp = 0
                }, playNextSection: function () {
                    var A = this;
                    this.resetHandoutAndVideo(), this.isPlaying = !0, this.updateCourseRecord(), this.$nextTick((function () {
                        A.curType = A.nextInfo.resourceType, A.minStudyTime = A.nextInfo.minStudyTime, A.curId = A.nextId, A.curIndex = A.nextIndex ? A.nextIndex.slice(0) : null;
                        var e = A.recordList.find((function (e) {
                            return e.resourceId === A.curId
                        }));
                        void 0 !== e && null !== e.currentPosition && 1 !== e.confirmFinish ? A.seek = e.currentPosition : A.seek = 0, "video" !== A.curType && "audio" !== A.curType || (A.isVideo = !0, A.$refs.aliPlayer.aliPlayer()), ("video" !== A.curType && "audio" !== A.curType || ("video" === A.curType || "audio" === A.curType) && A.isEdge && A.excludeCorpCodeList.indexOf(A.corpCode) > -1) && ("video" !== A.curType && "audio" !== A.curType || A.allowDrag || A.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                            confirmButtonText: A.$t("v4.js.pc.ocmt.confirm"),
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }), A.recordTime = 0, A.recordTimeId = setInterval((function () {
                            A.recordTime++
                        }), 1e3))
                    }))
                }, writeRecordWhileClose: function () {
                    var A = this;
                    if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                        this.recordLearningStatus("QUIT_STUDY");
                        var e = this.recordList.find((function (e) {
                            return e.resourceId === A.curId
                        })), t = void 0 !== e ? e.recordId : null;
                        this.endTime = Date.now(), this.continueTime = this.endTime - this.startTime;
                        var r = 0;
                        "video" !== this.curType && "audio" !== this.curType || ((this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish) && (r = this.recordTime), r = this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish ? this.curTimeToFinish : Math.round(Math.max(this.seek, this.player.getCurrentTime())));
                        var n = {
                            recordId: t,
                            courseId: this.courseId,
                            sourceId: this.sourceId,
                            providerCorpCode: this.providerCorpCode,
                            chapterId: this.curChapterId,
                            resourceId: this.curId,
                            timeToFinish: this.curTimeToFinish,
                            currentPosition: r,
                            type: this.curType,
                            currentStudyTime: "video" === this.curType || "audio" == this.curType ? this.recordTimeTemp - this.curTime.currentStudyTime : this.recordTime,
                            pageIndex: "video" !== this.curType && "audio" === this.curType && this.$refs.aliPreview ? this.$refs.aliPreview.currentCount : 0
                        };
                        if (navigator.sendBeacon) {
                            var i = { type: "text/plain; charset=UTF-8" }, s = new Blob([JSON.stringify(n)], i);
                            navigator.sendBeacon("/tbc-rms/record/writeRecordWhileClose", s)
                        } else {
                            var o = new XMLHttpRequest;
                            o.open("POST", "/tbc-rms/record/writeRecordWhileClose", !0), o.setRequestHeader("Content-Type", "application/json"), o.send(JSON.stringify(n))
                        }
                    }
                }, registerClosePageEvent: function () {
                    window.addEventListener("beforeunload", this.writeRecordWhileClose)
                }, handlePause: function (A) {
                    "Space" === A.code && this.checkoutStatus(!1)
                }, registerSpaceEvent: function () {
                    document.addEventListener("keyup", this.handlePause)
                }, checkoutStatus: function (A) {
                    "video" !== this.curType && "audio" !== this.curType || !this.player || (!A || "VIDEO" !== A.target.tagName) && A || document.querySelector(".prism-play-btn").click()
                }, checkBrowerIsEdgeAndIE11: function () {
                    var A = window.navigator.userAgent, e = function () {
                        return "ActiveXObject" in window
                    }();
                    e && (this.isIE11 = !0), A.indexOf("Edge/") > 0 && (this.isEdge = !0);
                    return e && this.excludeCorpCodeList.indexOf(this.corpCode) < 0 && (!localStorage.getItem("IETipsTime") || Object(N["getCurrentDateFormat"])(new Date, "yyyyMMdd") > localStorage.getItem("IETipsTime")) ? (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过IE浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                        confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                        showClose: !1,
                        showCancelButton: !0,
                        cancelButtonText: "今日不在提醒",
                        dangerouslyUseHTMLString: !0
                    }).then((function () {
                    })).catch((function () {
                        localStorage.setItem("IETipsTime", Object(N["getCurrentDateFormat"])(new Date, "yyyyMMdd"))
                    })), !0) : A.indexOf("Edge/") > 0 && this.excludeCorpCodeList.indexOf(this.corpCode) < 0 && (!localStorage.getItem("IETipsTime") || Object(N["getCurrentDateFormat"])(new Date, "yyyyMMdd") > localStorage.getItem("IETipsTime")) ? (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过Edge浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                        confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                        showClose: !1,
                        showCancelButton: !0,
                        cancelButtonText: "今日不在提醒",
                        dangerouslyUseHTMLString: !0
                    }).then((function () {
                    })).catch((function () {
                        localStorage.setItem("IETipsTime", Object(N["getCurrentDateFormat"])(new Date, "yyyyMMdd"))
                    })), !0) : A.indexOf("Safari") > -1 && A.indexOf("Chrome") < 0 && (!localStorage.getItem("IETipsTime") || Object(N["getCurrentDateFormat"])(new Date, "yyyyMMdd") > localStorage.getItem("IETipsTime")) && (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过Safari浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                        confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                        showClose: !1,
                        showCancelButton: !0,
                        cancelButtonText: "今日不在提醒",
                        dangerouslyUseHTMLString: !0
                    }).then((function () {
                    })).catch((function () {
                        localStorage.setItem("IETipsTime", Object(N["getCurrentDateFormat"])(new Date, "yyyyMMdd"))
                    })), !0)
                }, clickCloseSaveRecord: function () {
                    var A = this;
                    window.addEventListener("message", (function (e) {
                        try {
                            var t = JSON.parse(e.data)
                        } catch (r) {
                            return
                        }
                        switch (t.action) {
                            case "studyRecordWhileClose":
                                A.writeRecordWhileClose(), window.parent.postMessage(e.data, "*"), console.log("处理成功，返回消息！");
                                break
                        }
                    }), !1)
                }, getSystemSeting: function () {
                    var A = this, e = { courseId: this.courseId, eln_session_id: Object(N["getUrl"])("eln_session_id") };
                    a["c"].loadCourseSystemSeting(e).then((function (e) {
                        "1001" == e.code && (e.bizResult.checkType && (A.checkType = e.bizResult.checkType, A.maxTime = e.bizResult.preventCheatTimeTo, A.minTime = e.bizResult.preventCheatTime, A.preventCheatTime = (Math.random() * (e.bizResult.preventCheatTimeTo - e.bizResult.preventCheatTime) + e.bizResult.preventCheatTime).toFixed(1), A.verificationType = "preventCheat", A.preventCheatFlag = !0), e.bizResult.enablePreventHang && (A.verificationType = "hangUp", A.hangUpFlag = !0, A.preventHangTime = e.bizResult.preventHangTime), !e.bizResult.heartBeat || A.curInfo.finish && !e.bizResult.continueHeartBeat || (A.heartBeatFlag = !0, A.$refs.aliPlayer.addVideoClick()))
                    }))
                }, isReady: function () {
                    ("video" == this.curType || "audio" === this.curType) && this.addVideoClickFlag && this.$refs.preventCheat && this.$refs.preventCheat.addVideoClick(), "preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview ? (this.addVideoClickFlag = !0, this.getSystemSeting()) : this.$refs.aliPlayer && this.$refs.aliPlayer.addVideoClick()
                }, pauseOrPlay: function (A) {
                    this.isVideo && (!A && this.player ? this.player.pause() : this.player.play())
                }, saveStudyLog: function (A) {
                    this.recordLearningStatus(A)
                }, recordLearningStatus: function (A) {
                    if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                        "PREVENT_HANG_LOGOUT" == A && window.removeEventListener("beforeunload", this.writeRecordWhileClose), "ENTER_STUDY" == A && (this.firstEnterStudyFlag = !0), this.studyLogData.studyLogVO.minStudyTime = null == this.curInfo.minStudyTime ? "" : this.curInfo.minStudyTime, this.studyLogData.eventType = A, this.studyLogData.studyLogVO.courseItemId = this.curId, this.studyLogData.studyLogVO.courseItemName = this.curInfo.resourceName, this.studyLogData.studyLogVO.courseId = this.courseId, this.studyLogData.studyLogVO.courseTitle = parent.title;
                        try {
                            this.studyLogData.studyLogVO.videoDuration = "video" != this.curType && "audio" !== this.curType || !this.player ? "" : Math.floor(1e3 * this.player.getDuration())
                        } catch (t) {
                            console.log(t)
                        }
                        var e = JSON.parse(JSON.stringify(this.studyLogData));
                        a["c"].saveStudyLog(this.courseId, e).then((function (A) {
                        }))
                    }
                }, getCourseSetting: function () {
                    var A = this, e = { courseId: this.courseId };
                    a["b"].APIshowCourseSetting(e).then((function (e) {
                        A.allowDrag = 1 == e.bizResult.allowDrag, A.allowHighSpeed = 1 == e.bizResult.allowHighSpeed, A.allowMinStudyTime = 1 == e.bizResult.allowMinStudyTime
                    }))
                }, playOrPauseReordTime: function (A) {
                    var e = this;
                    A ? clearInterval(this.recordTimeId) : this.recordTimeId = setInterval((function () {
                        e.recordTime++
                    }), 1e3), A ? clearInterval(this.recordTimeIdTemp) : this.recordTimeIdTemp = setInterval((function () {
                        e.recordTimeTemp++
                    }), 1e3)
                }, handletabClick: function (A, e) {
                    var t = this;
                    this.$nextTick((function () {
                        t.navMsg = "myNote", t.isCreateNote = !1;
                        var r = document.querySelector("#el-tabsA .el-tabs__active-bar");
                        "preview" !== t.$route.query.from ? "contents" === A.name ? r.style = "transform:translateX(".concat(e.target.offsetLeft + (e.target.clientWidth - 16 - 20) / 2 + 10, "px)!important") : "note" === A.name ? r.style = "transform:translateX(".concat(e.target.offsetLeft + (e.target.clientWidth - 16) / 2, "px)!important") : "QA" === A.name && (r.style = "transform:translateX(".concat(e.target.offsetLeft + (e.target.clientWidth - 16 - 20) / 2 + 10, "px)!important")) : "contents" === A.name && (r.style = "transform:translateX(".concat(e.target.offsetLeft + e.target.clientWidth / 2 - 7, "px)!important"))
                    }))
                }, uploadImageFile: function (A) {
                    var e = this;
                    return Object(i["a"])(regeneratorRuntime.mark((function t() {
                        var r, n, i, s, o;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1) switch (t.prev = t.next) {
                                case 0:
                                    r = 0;
                                case 1:
                                    if (!(r <= A.length - 1)) {
                                        t.next = 11;
                                        break
                                    }
                                    return n = A[r], t.next = 5, e.uploadFileProcess(n);
                                case 5:
                                    i = t.sent, s = JSON.parse(i), o = s.bizResult, e.uploadList.push(UA(UA({}, o), {}, {
                                        name: n.name,
                                        size: n.size,
                                        type: n.type
                                    }));
                                case 8:
                                    r++, t.next = 1;
                                    break;
                                case 11:
                                    e.isUploadImage = !0;
                                case 12:
                                case "end":
                                    return t.stop()
                            }
                        }), t)
                    })))()
                }, uploadFileProcess: function (A) {
                    var e = window.$cookies.get("corpCode"), t = window.$cookies.get("eln_session_id"),
                        r = "text/plain", n = "bgImage", i = !0, s = "NO_OPT", o = "qa_wenda", a = "pic", c = 0;
                    return new Promise((function (l, u) {
                        var d = new XMLHttpRequest;
                        d.open("post", "".concat(origin, "/tbc-rms/video/uploadFileToProcess?corpCode=").concat(e, "&eln_session_id=").concat(t, "&responseFormat=").concat(r, "&processor=").concat(n, "&system=").concat(i, "&processType=").concat(s, "&uploadedFrom=").concat(o, "&resourceClass=").concat(a, "&categoryId=").concat(c));
                        var B = new FormData;
                        B.append("multipartFile", A), d.onreadystatechange = function () {
                            4 == d.readyState && 200 == d.status && l(d.responseText)
                        }, d.send(B)
                    }))
                }, saveQuestion: function () {
                    if (this.isUploadImage) if (this.QAformData.title) {
                        this.topicData.push(this.courseTitle);
                        var A = {
                            title: this.QAformData.title,
                            content: this.QAformData.content,
                            topic: this.topicData.join(",")
                        }, e = this, t = new FormData;
                        t.append("question.title", A.title), t.append("question.content", A.content), t.append("question.topic", A.topic), this.uploadList.forEach((function (A, e) {
                            t.append("question.attachmentList[".concat(e, "].storeFileId"), A.url || ""), t.append("question.attachmentList[".concat(e, "].storeFileName"), A.fileName || A.name || ""), t.append("question.attachmentList[".concat(e, "].resourceId"), A.resourceId || ""), t.append("question.attachmentList[".concat(e, "].attachmentType"), "PICTURE")
                        }));
                        var r = new XMLHttpRequest, n = window.location.origin;
                        r.open("post", "".concat(n, "/els/html/course/courseStudy.courseAskPublishJson.do")), r.send(t), r.onreadystatechange = function () {
                            4 == r.readyState && 200 == r.status && (e.$message({
                                message: e.$t("v4.js.pc.ocmt.Successful"),
                                type: "success"
                            }), e.QAformData = {}, e.topicData = [], e.uploadList = [], e.showChoiceVisible = !1)
                        }
                    } else this.$message({
                        message: this.$t("v4.js.pc.ocmt.QuestionEmpty"),
                        type: "error"
                    }); else this.$message.warning("图片上传中...请稍等！")
                }, inputFocus: function () {
                    this.showPlaceholder = !1
                }, inputBlur: function () {
                    this.showPlaceholder = !0, this.inputTopicText && (this.topicData.push(this.inputTopicText), this.inputTopicText = "")
                }, deleteTopicItem: function (A) {
                    this.topicData.splice(A, 1)
                }, getRelativeQuestion: function () {
                    var A, e = this, t = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>《》/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？ ]");
                    A = t.test(this.courseTitle) ? "" : this.courseTitle, a["c"].relativeQuestionJson(A).then((function (A) {
                        A && 1001 === A.code && (e.questionData = A.bizResult.rows || [])
                    }))
                }, goToQuestion: function (A) {
                    var e = window.location.origin, t = Object(N["getUrl"])("eln_session_id");
                    window.open("".concat(e, "/qa/html/question.do?elsSign=").concat(t, "&questionId=").concat(A))
                }, handleTabChange: function (A) {
                    this.QAactiveName = A, "relatedQuestion" === A && this.getRelativeQuestion()
                }, getMyNoteAndOtherNoteList: function (A, e) {
                    var t = this, r = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "init";
                    "init" === r && (this.myNoteCondition.pageNo = 1, this.otherNoteCondition.pageNo = 1, e.pageNo = 1);
                    var n = { courseId: this.courseId, processType: A, page: { pageNo: e.pageNo, pageSize: e.pageSize } };
                    H(n).then((function (e) {
                        var r = e.bizResult;
                        "me" === A ? t.myNotes = r || [] : "other" === A && (t.otherNotes = r || [])
                    }))
                }
            }, beforeDestroy: function () {
                clearInterval(this.heartTimer), document.removeEventListener("keyup", this.handlePause), this.timer && clearInterval(this.timer)
            }, destroyed: function () {
                window.removeEventListener("beforeunload", this.writeRecordWhileClose), this.timer && clearInterval(this.timer)
            }, created: function () {
                var A = this;
                this.getCourseSetting(), this.$nextTick((function () {
                    var e = document.querySelector("#el-tabsA .el-tabs__active-bar"),
                        t = document.querySelector(".el-tabs__item").clientWidth;
                    "preview" !== A.$route.query.from ? e.style = "transform:translateX(".concat(t / 2 - 17 + 10, "px)!important") : e.style = "transform:translateX(".concat(t / 2 - 7, "px)!important")
                }))
            }, mounted: function () {
                var A = this;
                this.coursePlayBoxHeight = document.getElementsByClassName("player-container")[0].offsetWidth / 1.777 + 128 + "px", window.addEventListener("resize", (function () {
                    document.getElementsByClassName("course-play-container")[0].style.height = document.getElementsByClassName("player-container")[0].offsetWidth / 1.777 + 128 + "px"
                })), this.corpCode = window.$cookies.get("corp_code") || window.$cookies.get("corpCode"), this.registerClosePageEvent(), this.registerSpaceEvent(), this.clickCloseSaveRecord(), this.$store.dispatch("nav1/fetchGetAuthCorpsAction", { type: 0 }).then((function (e) {
                    A.excludeCorpCodeList = e, A.pcEdgeBrowerPreview = A.checkBrowerIsEdgeAndIE11(), A.syncStudyRecord(), A.getCourseData(), A.getStudyRate(), A.getRelativeQuestion(), A.startTime = Date.now()
                })), this.getCourseInfo(), this.getCourseDiscuss("init"), c["a"].getUserInfo().then((function (e) {
                    A.userInfo = e.bizResult
                })), this.queryReferences(), this.getMyNoteAndOtherNoteList("me", this.myNoteCondition), L({ courseId: this.courseId }).then((function (e) {
                    var t = e.bizResult;
                    A.isbizResultShow = t
                }))
            }
        }, FA = vA, IA = (t("6e46"), Object(j["a"])(FA, r, n, !1, null, "21f83643", null));
        e["default"] = IA.exports
    }, df09: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("d8d69");

        function i(A, e, t, r) {
            n.call(this, A, e, t, r)
        }

        r(i, n), i.enabled = n.enabled && n.supportsCORS, A.exports = i
    }, dfcd: function (A, e) {
        A.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAARZJREFUOBHlkkFLAkEUgHdyDx3VDoKQ4E0Jb56DTCgKoYN4qR8R/Y7wFP0LIdglwpOHDt77A0t1SAxPHrqt3yxvhp1xQe8NfL5533sz485uEHgjTdMh3Hg6wN3Bpe8PfEGum7YacdfQB2cUbeA07EqcDfiLIQsasCpY+ItrSY8th4hzsp6YE2IVXiXPhwnJI8SsSaTwpk88hraIH+KTUupdchtwMxbeIwZwJIWSbfjHE8XFnPH85i0smL9wYd9Fd0JvF38FFalP9VtoQkfEBXFE4y2bfInLAu6UyRjWYA4oZ0XzQ1MD5vBgnIm4Z4jg0DgdnS+RUz9xCdTBHzXEBz1/+YKzQb6w71zfgT9ixNKX5BGYZ7flDQm0WV3DIlGvAAAAAElFTkSuQmCC"
    }, e2b3: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("7577"), i = t("1548"), s = t("df09"), o = t("73aa");

        function a(A) {
            if (!o.enabled && !s.enabled) throw new Error("Transport created when disabled");
            n.call(this, A, "/xhr", i, s)
        }

        r(a, n), a.enabled = function (A) {
            return !A.nullOrigin && (!(!o.enabled || !A.sameOrigin) || s.enabled)
        }, a.transportName = "xhr-polling", a.roundTrips = 2, A.exports = a
    }, e362: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("9a833");

        function i() {
            n.call(this), this.initEvent("close", !1, !1), this.wasClean = !1, this.code = 0, this.reason = ""
        }

        r(i, n), A.exports = i
    }, e556: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("7577"), i = t("b185"), s = t("1548"), o = t("9d7d");

        function a(A) {
            if (!o.enabled) throw new Error("Transport created when disabled");
            n.call(this, A, "/xhr", s, o)
        }

        r(a, n), a.enabled = i.enabled, a.transportName = "xdr-polling", a.roundTrips = 2, A.exports = a
    }, e998: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("ada0").EventEmitter, i = function () {
        };

        function s(A, e) {
            i(A), n.call(this), this.sendBuffer = [], this.sender = e, this.url = A
        }

        r(s, n), s.prototype.send = function (A) {
            i("send", A), this.sendBuffer.push(A), this.sendStop || this.sendSchedule()
        }, s.prototype.sendScheduleWait = function () {
            i("sendScheduleWait");
            var A, e = this;
            this.sendStop = function () {
                i("sendStop"), e.sendStop = null, clearTimeout(A)
            }, A = setTimeout((function () {
                i("timeout"), e.sendStop = null, e.sendSchedule()
            }), 25)
        }, s.prototype.sendSchedule = function () {
            i("sendSchedule", this.sendBuffer.length);
            var A = this;
            if (this.sendBuffer.length > 0) {
                var e = "[" + this.sendBuffer.join(",") + "]";
                this.sendStop = this.sender(this.url, e, (function (e) {
                    A.sendStop = null, e ? (i("error", e), A.emit("close", e.code || 1006, "Sending error: " + e), A.close()) : A.sendScheduleWait()
                })), this.sendBuffer = []
            }
        }, s.prototype._cleanup = function () {
            i("_cleanup"), this.removeAllListeners()
        }, s.prototype.close = function () {
            i("close"), this._cleanup(), this.sendStop && (this.sendStop(), this.sendStop = null)
        }, A.exports = s
    }, f1f8: function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("c282"), n = t("930c"), i = t("26a0"), s = function () {
            };
            A.exports = {
                WPrefix: "_jp", currentWindowId: null, polluteGlobalNamespace: function () {
                    A.exports.WPrefix in e || (e[A.exports.WPrefix] = {})
                }, postMessage: function (t, r) {
                    e.parent !== e ? e.parent.postMessage(n.stringify({
                        windowId: A.exports.currentWindowId,
                        type: t,
                        data: r || ""
                    }), "*") : s("Cannot postMessage, no parent window.", t, r)
                }, createIframe: function (A, t) {
                    var n, i, o = e.document.createElement("iframe"), a = function () {
                        s("unattach"), clearTimeout(n);
                        try {
                            o.onload = null
                        } catch (A) {
                        }
                        o.onerror = null
                    }, c = function () {
                        s("cleanup"), o && (a(), setTimeout((function () {
                            o && o.parentNode.removeChild(o), o = null
                        }), 0), r.unloadDel(i))
                    }, l = function (A) {
                        s("onerror", A), o && (c(), t(A))
                    }, u = function (A, e) {
                        s("post", A, e), setTimeout((function () {
                            try {
                                o && o.contentWindow && o.contentWindow.postMessage(A, e)
                            } catch (t) {
                            }
                        }), 0)
                    };
                    return o.src = A, o.style.display = "none", o.style.position = "absolute", o.onerror = function () {
                        l("onerror")
                    }, o.onload = function () {
                        s("onload"), clearTimeout(n), n = setTimeout((function () {
                            l("onload timeout")
                        }), 2e3)
                    }, e.document.body.appendChild(o), n = setTimeout((function () {
                        l("timeout")
                    }), 15e3), i = r.unloadAdd(c), { post: u, cleanup: c, loaded: a }
                }, createHtmlfile: function (t, n) {
                    var i, o, a, c = ["Active"].concat("Object").join("X"), l = new e[c]("htmlfile"), u = function () {
                        clearTimeout(i), a.onerror = null
                    }, d = function () {
                        l && (u(), r.unloadDel(o), a.parentNode.removeChild(a), a = l = null, CollectGarbage())
                    }, B = function (A) {
                        s("onerror", A), l && (d(), n(A))
                    }, h = function (A, e) {
                        try {
                            setTimeout((function () {
                                a && a.contentWindow && a.contentWindow.postMessage(A, e)
                            }), 0)
                        } catch (t) {
                        }
                    };
                    l.open(), l.write('<html><script>document.domain="' + e.document.domain + '";<\/script></html>'), l.close(), l.parentWindow[A.exports.WPrefix] = e[A.exports.WPrefix];
                    var g = l.createElement("div");
                    return l.body.appendChild(g), a = l.createElement("iframe"), g.appendChild(a), a.src = t, a.onerror = function () {
                        B("onerror")
                    }, i = setTimeout((function () {
                        B("timeout")
                    }), 15e3), o = r.unloadAdd(d), { post: h, cleanup: d, loaded: u }
                }
            }, A.exports.iframeEnabled = !1, e.document && (A.exports.iframeEnabled = ("function" === typeof e.postMessage || "object" === typeof e.postMessage) && !i.isKonqueror())
        }).call(this, t("c8ba"))
    }, f701: function (A, e, t) {
        "use strict";
        var r = t("ada0").EventEmitter, n = t("3fb5");

        function i() {
            var A = this;
            r.call(this), this.to = setTimeout((function () {
                A.emit("finish", 200, "{}")
            }), i.timeout)
        }

        n(i, r), i.prototype.close = function () {
            clearTimeout(this.to)
        }, i.timeout = 2e3, A.exports = i
    }, f7a9: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("621f"), i = t("e998"), s = t("0e88"), o = function () {
        };

        function a(A, e, t, r, a) {
            var c = n.addPath(A, e);
            o(c);
            var l = this;
            i.call(this, A, t), this.poll = new s(r, c, a), this.poll.on("message", (function (A) {
                o("poll message", A), l.emit("message", A)
            })), this.poll.once("close", (function (A, e) {
                o("poll close", A, e), l.poll = null, l.emit("close", A, e), l.close()
            }))
        }

        r(a, i), a.prototype.close = function () {
            i.prototype.close.call(this), o("close"), this.removeAllListeners(), this.poll && (this.poll.abort(), this.poll = null)
        }, A.exports = a
    }, f84c: function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("3fb5"), n = t("f7a9"), i = t("f9f5"), s = t("bf4a");

            function o(A) {
                if (!o.enabled()) throw new Error("Transport created when disabled");
                n.call(this, A, "/jsonp", s, i)
            }

            r(o, n), o.enabled = function () {
                return !!e.document
            }, o.transportName = "jsonp-polling", o.roundTrips = 1, o.needBody = !0, A.exports = o
        }).call(this, t("c8ba"))
    }, f91e: function (A, e, t) {
        "use strict";
        var r = t("3fb5"), n = t("ada0").EventEmitter, i = t("ca34"), s = function () {
        };

        function o(A) {
            s(A), n.call(this);
            var e = this, t = this.es = new i(A);
            t.onmessage = function (A) {
                s("message", A.data), e.emit("message", decodeURI(A.data))
            }, t.onerror = function (A) {
                s("error", t.readyState, A);
                var r = 2 !== t.readyState ? "network" : "permanent";
                e._cleanup(), e._close(r)
            }
        }

        r(o, n), o.prototype.abort = function () {
            s("abort"), this._cleanup(), this._close("user")
        }, o.prototype._cleanup = function () {
            s("cleanup");
            var A = this.es;
            A && (A.onmessage = A.onerror = null, A.close(), this.es = null)
        }, o.prototype._close = function (A) {
            s("close", A);
            var e = this;
            setTimeout((function () {
                e.emit("close", null, A), e.removeAllListeners()
            }), 200)
        }, A.exports = o
    }, f9f5: function (A, e, t) {
        "use strict";
        (function (e) {
            var r = t("f1f8"), n = t("2582"), i = t("26a0"), s = t("621f"), o = t("3fb5"), a = t("ada0").EventEmitter,
                c = function () {
                };

            function l(A) {
                c(A);
                var t = this;
                a.call(this), r.polluteGlobalNamespace(), this.id = "a" + n.string(6);
                var i = s.addQuery(A, "c=" + encodeURIComponent(r.WPrefix + "." + this.id));
                e[r.WPrefix][this.id] = this._callback.bind(this), this._createScript(i), this.timeoutId = setTimeout((function () {
                    c("timeout"), t._abort(new Error("JSONP script loaded abnormally (timeout)"))
                }), l.timeout)
            }

            o(l, a), l.prototype.abort = function () {
                if (c("abort"), e[r.WPrefix][this.id]) {
                    var A = new Error("JSONP user aborted read");
                    A.code = 1e3, this._abort(A)
                }
            }, l.timeout = 35e3, l.scriptErrorTimeout = 1e3, l.prototype._callback = function (A) {
                c("_callback", A), this._cleanup(), this.aborting || (A && (c("message", A), this.emit("message", A)), this.emit("close", null, "network"), this.removeAllListeners())
            }, l.prototype._abort = function (A) {
                c("_abort", A), this._cleanup(), this.aborting = !0, this.emit("close", A.code, A.message), this.removeAllListeners()
            }, l.prototype._cleanup = function () {
                if (c("_cleanup"), clearTimeout(this.timeoutId), this.script2 && (this.script2.parentNode.removeChild(this.script2), this.script2 = null), this.script) {
                    var A = this.script;
                    A.parentNode.removeChild(A), A.onreadystatechange = A.onerror = A.onload = A.onclick = null, this.script = null
                }
                delete e[r.WPrefix][this.id]
            }, l.prototype._scriptError = function () {
                c("_scriptError");
                var A = this;
                this.errorTimer || (this.errorTimer = setTimeout((function () {
                    A.loadedOkay || A._abort(new Error("JSONP script loaded abnormally (onerror)"))
                }), l.scriptErrorTimeout))
            }, l.prototype._createScript = function (A) {
                c("_createScript", A);
                var t, r = this, s = this.script = e.document.createElement("script");
                if (s.id = "a" + n.string(8), s.src = A, s.type = "text/javascript", s.charset = "UTF-8", s.onerror = this._scriptError.bind(this), s.onload = function () {
                    c("onload"), r._abort(new Error("JSONP script loaded abnormally (onload)"))
                }, s.onreadystatechange = function () {
                    if (c("onreadystatechange", s.readyState), /loaded|closed/.test(s.readyState)) {
                        if (s && s.htmlFor && s.onclick) {
                            r.loadedOkay = !0;
                            try {
                                s.onclick()
                            } catch (A) {
                            }
                        }
                        s && r._abort(new Error("JSONP script loaded abnormally (onreadystatechange)"))
                    }
                }, "undefined" === typeof s.async && e.document.attachEvent) if (i.isOpera()) t = this.script2 = e.document.createElement("script"), t.text = "try{var a = document.getElementById('" + s.id + "'); if(a)a.onerror();}catch(x){};", s.async = t.async = !1; else {
                    try {
                        s.htmlFor = s.id, s.event = "onclick"
                    } catch (a) {
                    }
                    s.async = !0
                }
                "undefined" !== typeof s.async && (s.async = !0);
                var o = e.document.getElementsByTagName("head")[0];
                o.insertBefore(s, o.firstChild), t && o.insertBefore(t, o.firstChild)
            }, A.exports = l
        }).call(this, t("c8ba"))
    }, ff5b: function (A, e, t) {
        "use strict";
        var r = t("103f"), n = t.n(r);
        n.a
    }
}]);
//# sourceMappingURL=coursePlay.60750241.js.map