(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["coursePlay"], {
    "12ef": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAACthJREFUeF7tnU/MHVUZh39vAmUBGmw0kZDoho1oAiwUFoALamADikGDKFBii0YCTdghW//sCEo0FirQoLEBBYUV2iZiuyC6ABJlxUYTgokEiMICMHnNaa7pZ22/O/e9c+/M3N8z6/OeOe/znuebb+bOnBPigAAETksgYAMBCJyeAIIwOyCwDQEEYXpAAEGYAxCoEeAKUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEEAQk0KTZo0AgtS4EWVCAEFMCk2aNQIIUuNGlAkBBDEpNGnWCCBIjRtRJgQQxKTQpFkjgCA1bkSZEECQNRc6MxvzCyVdIOnjkj4qaaekcyTtmA3nPUlvS3pD0muS/ibpFUkvR0SuecjWp0OQFZc/Mz8kaZekKyRdJukSSWcUT/tvSS9Iel7SHyQdiYg3i30R1oEAgnSAtGiTzPywpC9Lun4mx6JdLNL+sKSnJD0eEa8vEkjb+QQQZD6jzi0y8ypJeyTd2Dmo34aHJB2IiCP9duvbG4L0UPvMvEHSPkmX99BdH10clXR/RDzZR2fOfSDIEtXPzKsl3Tu7v1iip5WFPifpOxHR/g3jKBBAkAK0zDxf0vcl3VwIHyLkoKR7IqI9EeNYgACCLACrNc3Mr0u6T9IHFwwduvlbku6OiEeGHsiUzo8gHauVmWdJ2i/p1o4hY23WBPlGRLw/1gGOaVwI0qEamXmxpEclXdSh+RSavChpd0S8NIXBDjlGBJlDPzOvlfQLSWcPWagVnLv9Un9TRDyzgr43pksE2aaUmdn+nWpXjk0+2pWk3cRznIIAgpxmWmTmXkkPmsya2yPiIZNcF0oTQU6By+TKcXLmXEm4gsz/4zG753h6fsuNbHEd9yT/W1euIFt4ZGZ7SnVs9ur5RhowJ6l32usyEdGecnFIQpDZNMjMMyX9UVJ7pOt8tEe/l0bEu84Q/ps7gpwQ5GFJtzEpjhM4GBG7YcEV5PgcyMwmRhOE4wSBPRHxU3cg9leQzDyvfcoq6Vz3yXBS/v9snwZHxKvOXBAks/0QOPX3q1Y1hx+LiFtW1fkU+rUWJDPbt+K/m0KhBhzjNRHx7IDnH/TU7oL8XtJnB63A+E9+NCKuHP8wVzNCW0Ey84uSfrUarBvX65ci4pcbl1WHhJwFacvmtKV4OOYTOBYRlqwsBZmtPsJ32vPF2Npil+NqKa6CtO87hlqaZ7FpOZ7WhyLiK+MZznpGYifIbFG3f6wH78ad5SNui9M5CvItST/auKm7noTuiIgfr+dU4ziLoyDtd4/2+wfH4gQOR8TnFg+bboSVILOFpNuK6Rx1AjudFsx2E6QtEfpEfW4QKcnqNxE3QX4o6U6m+VIEHoiIu5bqYULBboK0D6I+PaH6jHGof4qIz4xxYKsYk40gs52d2s5N1c1rVsF/in22TXx2uOx05STIJyX9eYozcoRj/lRE/GWE4+p9SE6CfF7Sr3sn6NnhFyLiNw6pOwnSbs7bTTrH8gT2RYQFSydBvtf2yFh+btBD2xslIr7tQMJJkJ+0Zf8dirqGHPdHxDfXcJ7BT+EkyM8kfXVw4psxgJ9HxNc2I5Xts3AS5PH2K7BDUdeQ4xMR0ba53vgDQTa+xCtJEEFWgnXATjOTf7H648+/WP2xHEdPmclNen+l4Ca9P5bj6CkzeczbXyl4zNsfy3H0lJntDdQfjGM0kx/FXRHxwOSz6JCA0006r5p0mBAdm/CqSUdQk2mWmbys2F+1eFmxP5bj6InX3XurA6+794ZyZB1lJh9MLV8TPphanuE4e8hMPrldvjR8crs8w3H2kJntVZP2yglHnQCLNtTZjTuSZX96qQ/L/vSCcaSdZCYLx9Vrw8JxdXbTiMxMlh6tl4qlR+vsphHJ4tVL1YnFq5fCN5HgzGT7g8VrxfYHizObZgQb6JTqxgY6JWwTDcpMtmDrXju2YOvOajNasonnQnW0+u1jKxmbt3lPNR0yk22g53vCNtDzGW1mi8xsm8H8djOz6y2rayLi2d56m1hH1leQVqvMfFTSrROr27qG+1hE3LKuk43xPAiSeZ6klyWdO8YCDTimf0n6RES8OuAYBj+1vSCzq8htkh4evBrjGsDeiDgwriGtfzQIMmOemU2QJgqHdDAidgNCQpATgpwpqX1QdbH5xHhJ0qUR8a45h+PpI8iWWZCZF0k6Jukc08nxjqTLI+JF0/z/L20EOQlJZl4r6WnTCXJdRDxjmvsp00aQU2DJzPbYtz3+dTp2R8RBp4S75Iogp6GUmXslPdgF4ga0uT0iHtqAPHpPAUG2QWpyJeHKsc0cQJA5f3Nm9yTt+5Gze//zNGyHb0u6iXuO7YuAIB0maWa2R7/tnqQ95dqEoz2laleO9kiXgyvI8nMgM8+StH8D3tt6pO3VGBHvL09l83vgCrJgjTNzj6T7JH1gwdChm78l6e6IaIJwdCSAIB1BbW2Wmee3rZAl3VwIHyKkPb69JyJeG+LkUz4ngixRvcy8WtK9kq5YoptVhj4n6bsR0dYC4ygQQJACtJNDMvMGSfvaaxo9dNdHF0cl3R8RT/bRmXMfCNJj9WerpbR7lBt77HaRrg5JOhARRxYJou3pCSDICmbHbHG6to/49ZJ2reAUW7s8LOmptih3RLy+4nPZdY8gKy75bMHsqyRdKekySZdIOqN42rZ5zQuSnpfUli06EhFvFvsirAMBBOkAqc8ms52uLpR0gaSPSWqf/O6cvWK/Y3au9yS1X7rfkPR3SX+V9Er7NDgiss/x0Nf2BBCEGQKBbQggCNMDAgjCHIBAjQBXkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAghiUmjSrBFAkBo3okwIIIhJoUmzRgBBatyIMiGAICaFJs0aAQSpcSPKhACCmBSaNGsEEKTGjSgTAv8B2wLU2F3C5UUAAAAASUVORK5CYII="
    },
    "15ba": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACgAAAAoCAYAAACM/rhtAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAKKADAAQAAAABAAAAKAAAAABZLkSWAAAB+UlEQVRYCe2WvUrEQBDHLyKKhSAogoUnovgJvoDvoI2tja0IlloIgoJgLZaWvoCIT2CrnahY+FWI2lkoCsbf6F7IXXK3s6uJV2RhmM3szPz/mZkNKZWKVVTgfysQ2ODDMFzEZ9rmpzh/xGcnCIIrhW/k0hLt6m/+gpxk70VWeeHh+lDJE00F903YHvoumcJqmcNjMub1yn5LW8nWWKBte0vSS5tT7TkVezG2E3QZ6UGkkiqSmhab/L9Wz2TYQER3IKp250mwRAeeXEnmShBy9UgOyVnacpnBtHgX2yhzNx8LuGYv8yjtXkKWkcTKg+CHQR1Ai6Qt+QSlrjwIHoAsn7O2FAad2MZT7JEpc4JcjHvQdiPE2IaWj/C4HjMltrlfkgQDi6EgaCmQ9bjpK+h9SRjwGV5/ylqCaodTLs1htanxkxdByEnlZxH5yLqsQWKPIPmpDfIiKAAAbQMygVh/2QyZEH3uQk7ivAhKIEAXKJFMV9NfkqYn6N1iZlBmr92lv4zFm4u/+HoTJHYNGZMk2sVLnUFyU+svfl4tNtXrcgEyvt0mVh3qVUGqAE64AkqfGunH8UFiXWK8CAoAQO+oGxcwH1+vFvsA+cYUBH0rV4lzmcGy6w2sgDTQ/Q3Ovo9cCC7YkmVxrpnB4yyAa3LmgVEDWTwWFdBV4Av/IG+Sf2qUhwAAAABJRU5ErkJggg=="
    },
    "2d5a": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAAEiUlEQVRoBe2Z3WsVRxjGn2M+jEkTm5ho4hcVsSBeVArmxt6L+AdoL6zohWiroSoIQQrthaKFCvUqYMCPk96IoqipiOmFWgN6EaP0pihSiCClfiV+NG2Ss77PoZOz8Zw9O7M7exbKDExm8p7deX7z7Dtz9uzC87wFUquQUpkluh9IXSIQ9WkwEICFDnQIRJtUFct/kPSf98WaRHCxQNQlLazGfx+A8RqpiwSiRWpGHZhUWwpAaTVLh27UqkASbTkA6lGcCfphUm6EAahJz5POQoHg5bFadAEoysSkG0xUa8UEgKJMSi5VLtlqGxSmAEqTmxbdaFCBqG1UAOrx3HaBmC818jiRT/TNuFH6dGOOL6bdtQFAMeYDV0mrqRu2ANSM50qHm9dsFQhrbQNQj3sFIZqlhm7lSQCoSbdIh98pZbfyJAEIwktBN3hpSpakASjKy8DkZJIWbV6VAFAz5zLlcuUd2HSpJABFqcd7UH7V50ulAZQub3a4geWJVLDSLfOiKi0H1OQb0wQgREPaADVpA6SaA/mkT9uBVJehc8A54BxwDjgHnAPOAeeAc8Dcgf1XsSJ/lsU/2jelnT3oyt7D5fWnsMGivt5NKcVHRtEFD1XDf+KoTYhQB2j7yBi+mp61ZYhQgO/X4cGnHdgrzzmmkoAIBaBo/2b0B0FsyMbLCS0ABbF6QbETQ09wNA6ENgAhrmxBv20II4AkIIwBbENEArAJERnAFkQsABsQsQEIUVeDcdmmPfZVyXiYaqjBmPo/qI0NsPEMPrv9GMdEwP8ceLJzKbrObMLNIGEVjwXwxXms+fUP9Hhe/qm4GjO3uh37LnyOARUo1/qpyx1X9NmOi/hk4AGOi3jhRXcG3qo2dHPDKjohIBDJga9/xspLv+OEiM948v1xK74b2IpzAVolw8YOdF/D8rO/4WTOw4w3qMuacfj6NvSVVCkTNHLg0HUszQ4jO+WB75Kny5K5ODa4Hb3TAYOONsAPt9DRcwd9UznM94/f3ojjd3bkV4E/rN3XAugdQtuPg8hO5LDQP3JbA/rufokj/phpXwvgyA0cFPGP/IO31OPs/V341h+L0tcC2LMW39RW45ESaKrD5aHd6Fb/x2kz8tZiuc4APw2j5cAvOF1bhZHBndjVOtt3j6gzQMAx2gA8/+JDNK1sxviKefg3YDzjsBGA8egaJ2jlgMY4kQ9xAM4B54BzwDngHHAOOAecA86BtB3IpQ0wmTbA27QBxtIEeJnJZCbSAngrP6We8+eU8TOiyL/BCie+lO5zmX3+wWYlASZE+C8R/rvAUhkHONMXUnnNZzzOJUjSDnC2T0U48HlCUgC5/4RfcZblShIAFH0msy685itDYBOASUa7ucS0iy0AlWS03qjEBRgXNS6twCQLo4kKwJk+k/pKxIuWVpio//MoAG9kAF7rSf9AUfsmABSkMAGsFV2AUVHk/m2cZGGkYQD/yABMMraJlCAAJha/LkdFPFaShVGXAuBGwllbSTITAG6dTLLXYSfZ/Fw5wDec3L+tJ1korLwvKLz3Cz36f3jAO1LnaxkaiWUtAAAAAElFTkSuQmCC"
    },
    "2e5a": function (e, t, i) {
        e.exports = i.p + "static/img/nopass.a96f964c.png"
    },
    "324c": function (e, t, i) { },
    "3f0f": function (e, t, i) {
        "use strict";
        var s = i("9aba")
            , n = i.n(s);
        n.a
    },
    "3f4a": function (e, t, i) {
        "use strict";
        i.r(t);
        var s = function () {
            var e = this
                , t = e.$createElement
                , i = e._self._c || t;
            return i("div", {
                class: ["live-play-container", e.from ? "live-play-container__" + e.from : ""]
            }, [i("div", {
                staticClass: "topbar"
            }, [e._v("\n    预览\n  ")]), i("div", {
                staticClass: "player-content"
            }, [e.courseInfo.fileHref ? i("Player", {
                attrs: {
                    src: e.courseInfo.fileHref,
                    defaultSetting: {
                        speed: [.5, 1, 1.25, 1.5, 2, 2.5, 3],
                        autoPlay: !0
                    },
                    isDefaultHideControl: !0
                },
                on: {
                    init: e.initPlayer,
                    selectedImage: e.selectedImage,
                    timeUpdate: e.timeUpdate,
                    completeSeek: e.completeSeek,
                    changeScreen: e.changeScreen
                }
            }, [i("div", {
                staticClass: "right",
                attrs: {
                    slot: "right"
                },
                slot: "right"
            }, [i("div", {
                staticClass: "title"
            }, [e._v("\n          课程片段\n        ")]), i("div", {
                staticClass: "content"
            }, [i("vue-custom-scrollbar", {
                staticClass: "scroll-area",
                attrs: {
                    settings: {
                        suppressScrollX: !0
                    }
                }
            }, e._l(e.list, (function (t, s) {
                return i("div", {
                    key: t.id,
                    class: ["content-item", !e.player && "disabled", e.activeId === t.id && "active"],
                    on: {
                        click: function (i) {
                            return e.seekPlay(t)
                        }
                    }
                }, [i("span", {
                    staticClass: "index"
                }, [e._v("\n                " + e._s(s + 1) + "\n              ")]), i("div", {
                    staticClass: "imgWrap",
                    style: {
                        "background-image": "url(" + t.url + ")"
                    }
                }), i("span", {
                    staticClass: "time"
                }, [e._v("\n                " + e._s(e.getTime(t.time)) + " - " + e._s(e.getTime(t.endTime)) + "\n              ")])])
            }
            )), 0)], 1)]), e._l(Object.entries(e.$slots), (function (t) {
                return i("template", {
                    slot: t[0]
                }, [e._t(t[0])], 2)
            }
            ))], 2) : e._e()], 1)])
        }
            , n = []
            , a = (i("8e6e"),
                i("2fdb"),
                i("6762"),
                i("456d"),
                i("bd86"))
            , o = i("75fc")
            , r = (i("ac6a"),
                i("c5f6"),
                i("96cf"),
                i("3b8d"))
            , c = (i("28a5"),
                i("c1df"))
            , l = i.n(c)
            , u = i("b31b")
            , d = i("4b70")
            , h = i.n(d)
            , m = i("5e99")
            , p = i("8e44")
            , v = i("bc3a")
            , f = i.n(v);
        function g(e, t) {
            var i = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var s = Object.getOwnPropertySymbols(e);
                t && (s = s.filter((function (t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }
                ))),
                    i.push.apply(i, s)
            }
            return i
        }
        function A(e) {
            for (var t = 1; t < arguments.length; t++) {
                var i = null != arguments[t] ? arguments[t] : {};
                t % 2 ? g(Object(i), !0).forEach((function (t) {
                    Object(a["a"])(e, t, i[t])
                }
                )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : g(Object(i)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                }
                ))
            }
            return e
        }
        var y = m["b"].uuid
            , C = m["b"].getImageSize
            , I = m["a"].Canvas
            , T = {
                components: {
                    Player: u["a"],
                    vueCustomScrollbar: h.a
                },
                data: function () {
                    return {
                        originList: [],
                        list: [],
                        player: null,
                        activeId: 0,
                        canvasId: "canvas-".concat(y()),
                        paper: null,
                        timeMap: {},
                        courseInfo: {},
                        pageType: "yunkai",
                        from: ""
                    }
                },
                beforeDestroy: function () {
                    I.destory()
                },
                mounted: function () {
                    var e = this.$route.query
                        , t = e.pageType
                        , i = e.from;
                    this.pageType = t,
                        this.from = i,
                        this.init()
                },
                computed: {
                    courseParams: function () {
                        return decodeURIComponent(this.$route.params.courseInfo).split("&")
                    },
                    courseId: function () {
                        return this.courseParams[0]
                    }
                },
                methods: {
                    timeUpdate: function (e) {
                        var t = this.timeMap[e] || {}
                            , i = t.content;
                        if (i) {
                            var s = JSON.parse(i)
                                , n = s.type;
                            "stroke" === n && "path" === s[n].type && I.addPath(s[n]),
                                "clear" === n && I.clear()
                        }
                    },
                    changeScreen: function () {
                        I.resetSize()
                    },
                    initPlayer: function (e) {
                        var t = this;
                        return Object(r["a"])(regeneratorRuntime.mark((function i() {
                            var s, n, a, o, r, c, l;
                            return regeneratorRuntime.wrap((function (i) {
                                while (1)
                                    switch (i.prev = i.next) {
                                        case 0:
                                            s = e.player,
                                                n = e.playerRef,
                                                a = t.list[0],
                                                o = a.id,
                                                r = void 0 === o ? 0 : o,
                                                c = a.width,
                                                l = a.height,
                                                t.player = s,
                                                t.activeId = r,
                                                n.setSplitScreen({
                                                    twoScreenType: "IMAGE",
                                                    splitImageList: t.list,
                                                    canvasId: t.canvasId
                                                }),
                                                I.init({
                                                    canvasId: t.canvasId,
                                                    width: c,
                                                    height: l
                                                });
                                        case 6:
                                        case "end":
                                            return i.stop()
                                    }
                            }
                            ), i)
                        }
                        )))()
                    },
                    seekPlay: function (e) {
                        this.activeId = e.id,
                            this.player.seek(e.time),
                            this.player.play(),
                            this.updateCanvas(e)
                    },
                    completeSeek: function (e) {
                        var t = e.paramData;
                        for (var i in this.updateCanvas(),
                            this.timeMap)
                            Object.hasOwnProperty.call(this.timeMap, i) && Number(i) < Math.floor(10 * t) / 10 && this.timeUpdate(Number(i))
                    },
                    updateCanvas: function (e) {
                        var t = e || {}
                            , i = t.width
                            , s = t.height;
                        I.clear(),
                            i && s && I.setSize({
                                width: i,
                                height: s
                            })
                    },
                    selectedImage: function (e) {
                        this.activeId = e.id,
                            this.timeUpdate(e.time.toFixed(1)),
                            this.updateCanvas(e)
                    },
                    getTime: function (e) {
                        var t = l.a.duration(e, "seconds");
                        return l()({
                            h: t.hours(),
                            m: t.minutes(),
                            s: t.seconds()
                        }).format("HH:mm:ss")
                    },
                    init: function () {
                        var e = this;
                        return Object(r["a"])(regeneratorRuntime.mark((function t() {
                            var i, s, n, a, o, r, c, l;
                            return regeneratorRuntime.wrap((function (t) {
                                while (1)
                                    switch (t.prev = t.next) {
                                        case 0:
                                            return t.prev = 0,
                                                i = {},
                                                "yunkai" === e.pageType && (i = {
                                                    fromId: e.courseId,
                                                    fromPage: "ELS_PREVIEW"
                                                }),
                                                "live" === e.pageType && (i = {
                                                    fromId: e.courseId,
                                                    fromPage: "LIVE_PREVIEW"
                                                }),
                                                t.next = 6,
                                                p["c"].getYunKaiCourseInfo(i);
                                        case 6:
                                            if (s = t.sent,
                                                n = s.jsonObj,
                                                a = n.imagePrefix,
                                                o = n.operatorJson,
                                                r = n.imageOrderList,
                                                !/^(http|https):/g.test(o)) {
                                                t.next = 15;
                                                break
                                            }
                                            return t.next = 11,
                                                f.a.get(o);
                                        case 11:
                                            l = t.sent,
                                                o = (null === l || void 0 === l || null === (c = l.data) || void 0 === c ? void 0 : c.operates) || [],
                                                t.next = 16;
                                            break;
                                        case 15:
                                            o = JSON.parse(o);
                                        case 16:
                                            if (!o) {
                                                t.next = 19;
                                                break
                                            }
                                            return t.next = 19,
                                                e.dealList(o, a, r.split(","));
                                        case 19:
                                            e.courseInfo = s.jsonObj,
                                                t.next = 26;
                                            break;
                                        case 22:
                                            t.prev = 22,
                                                t.t0 = t["catch"](0),
                                                e.courseInfo = {
                                                    fileHref: ""
                                                },
                                                e.$message.error("获取课程数据出错");
                                        case 26:
                                        case "end":
                                            return t.stop()
                                    }
                            }
                            ), t, null, [[0, 22]])
                        }
                        )))()
                    },
                    filterList: function (e) {
                        var t = this;
                        if (!(null === e || void 0 === e ? void 0 : e.length))
                            return [];
                        var i = {}
                            , s = e.length - 1
                            , n = Object.assign([], e);
                        return e.forEach((function (e, n) {
                            var a = e.slider
                                , r = e.time
                                , c = e.content
                                , l = "".concat(a, "--").concat(r);
                            n !== s && (i[l] ? i[l] = [].concat(Object(o["a"])(i[l]), [n]) : i[l] = [n]),
                                c && (t.timeMap[Math.floor(10 * r) / 10] = A({}, e))
                        }
                        )),
                            Object.keys(i).forEach((function (e) {
                                i[e].length > 1 && i[e].forEach((function (e) {
                                    n[e] = null
                                }
                                ))
                            }
                            )),
                            n.filter((function (e) {
                                return e
                            }
                            ))
                    },
                    dealList: function (e, t, i) {
                        var s = this;
                        return Object(r["a"])(regeneratorRuntime.mark((function n() {
                            var a, o, r, c, l, u;
                            return regeneratorRuntime.wrap((function (n) {
                                while (1)
                                    switch (n.prev = n.next) {
                                        case 0:
                                            n.prev = 0,
                                                a = [],
                                                e = s.filterList(e),
                                                e.forEach((function (e, s) {
                                                    var n = e.slider
                                                        , o = e.time
                                                        , r = s - 1;
                                                    (r < 0 || n !== a[a.length - 1].slider) && (0 !== s && (a[a.length - 1].endTime = o),
                                                        a.push(A(A({}, e), {}, {
                                                            startTime: o,
                                                            url: "".concat(t, "/res/image/slide-rId").concat(i[n], ".jpg")
                                                        })))
                                                }
                                                )),
                                                s.originList = e,
                                                a[a.length - 1].endTime = e[e.length - 1].time,
                                                o = 0;
                                        case 7:
                                            if (!(o < a.length)) {
                                                n.next = 18;
                                                break
                                            }
                                            return r = a[o].url,
                                                n.next = 11,
                                                C(r);
                                        case 11:
                                            c = n.sent,
                                                l = c.width,
                                                u = c.height,
                                                a[o] = A(A({}, a[o]), {}, {
                                                    width: l,
                                                    height: u,
                                                    scale: l / u,
                                                    id: y()
                                                });
                                        case 15:
                                            o++,
                                                n.next = 7;
                                            break;
                                        case 18:
                                            s.list = a,
                                                a.includes,
                                                n.next = 25;
                                            break;
                                        case 22:
                                            n.prev = 22,
                                                n.t0 = n["catch"](0),
                                                s.$message.error(n.t0 || "处理出错");
                                        case 25:
                                        case "end":
                                            return n.stop()
                                    }
                            }
                            ), n, null, [[0, 22]])
                        }
                        )))()
                    }
                }
            }
            , S = T
            , w = (i("d3f6"),
                i("2877"))
            , b = Object(w["a"])(S, s, n, !1, null, "2b9ad8cf", null);
        t["default"] = b.exports
    },
    4812: function (e, t, i) {
        "use strict";
        var s = i("cc93")
            , n = i.n(s);
        n.a
    },
    "49fb": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAHKADAAQAAAABAAAAHAAAAABHddaYAAAB00lEQVRIDe1WPUsDQRB9ezEYvyAWgjEoIoqFgoK9nZVWgj/AJo0oKIqWllGDgiKICFpba59CsFXQRiUERJEUaqGQcObG2SMre64hl5A0koUws2/fm3fMXdgRKGN1xmmZ6UsFyfbLmkiUIXepwq8gGqfJPHCm8wPA1NOaONexUrlViqDOHWBC5Sr+hamzYtG3IQSajCJ/YQbJC/g39Ooq3v1/wwbZm5lTClym0dfQgcf0rMhW3C8fQiu6SaMXKaS+HNxlM8hENmjah65iipV3cEBAj1uB0Mb5Se8xhSquWEIoP5oxD4dN7VcMerAqbuQ7dN+jXtMhE9PP/eTdG9RlCwyEgrhOL4p3panJ3yKySTEbSMNBMpdDKpKg8ZoZDu1TKwi7/AtKE/4m2imPvZoZvn+inwiNysCNhGG1r3pLHQt8iRjrx+cnMSg1AuqGVW9svaX/o6U8fHmX5YAnQmMZPGYYWCmtxdPYjV5aCOTCLXjQMZkz7uEVw6RW1vDoNa0lApjnafjNJQjY/AALt3PiwyPgTXMIRxySGp4sYBoEuFquwXX4wuAH5drSQ5Hcybt3h8JZGyNBwv3jqnhWh7/jOpF1uIVRicdWcLUuhNFSpSl2H34DBDR9yphIIqoAAAAASUVORK5CYII="
    },
    "4eef": function (e, t, i) { },
    "52db": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADIAAAAyCAIAAACRXR/mAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjE5RTQ2QzZCRjNEMzExRTBCNzM0RkZBNEEwMDU0Njk0IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjE5RTQ2QzZDRjNEMzExRTBCNzM0RkZBNEEwMDU0Njk0Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6MTlFNDZDNjlGM0QzMTFFMEI3MzRGRkE0QTAwNTQ2OTQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6MTlFNDZDNkFGM0QzMTFFMEI3MzRGRkE0QTAwNTQ2OTQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz76PDNBAAAGuUlEQVR42oyZ209TWxDGadkqihcusUGimMrtkPAgIdH4/7/6AGosFqxNjSAE5Y7cjj2/dsp0mFl7c9ZDsy9rz5rLNzPfWi19+/ZtYGCg3W4P5A95WyqV9DZ5nZycnOPmO2mMrN0dyVWdrjqNIXPsTLmVmXqtF+62QL78ZqqNflMul90C0dbS9bBmWFFWmsyJVjmZui6vytEZVqe4mLMhRl9eJZ+7aFhpLvqZs9jBwinqdE0a7VZNQs2JcnI62MozRcffv3/dx+onlWs/kfm6dsSfA5bKt3Myp7L7TSJGPxkcHOQXuf92R8/QLOM503hujRTo6PKCueizXhCdTgWBE8TINUK5ODw83NnZOTg4OD09vby85PmdO3fu3bv3+PHjSqUyMjKCfldXV842u3wy6zvvWq2Wg6fTKeYB/tjf3280GuiENq5kSFyYMz4+Xq1Wnz59iiOtQHVVXrHoiPv+/XteLXU4E3GMZrNZr9fPz88Hu8NJ10xEG96+fPlybm6OC4lyMqtizmWx9OVVZBRCeq1WW19fxxl37961H0YhBJTrjY2NP3/+vH79mk8UfwWtogcSG2k7z9bMXkPIso3uYD2JgsvqZPKj/ebm5qdPnxyM0rHTImzrtRZlq6jMQxWQROxQTpPISZQ80AsViGZAhdCLPdGYUhhl1UBw4xbQ2JFQxA4VpSjYOVYPFaLZKhcYAyc4Pj6Wz8vXIy7XV8vGUR1mjUDoz58/yT7MTdrnPO28LhUOhOEzUcu5ObbasprlyrH1Fk+2trZcbcvjP67K63ooBAwuLi5cfU72Rx8IuXDqYyiVE58VpEXyWmdK9E9OTqi9gs64yg0dnL4RfYijiGOlYiUufAOtBnPuIcphXsFMFZUVN3N5eHZ2ZjGXRzTiw+gSirDtCnmo6LXVPI4loqXp2oIZJeYRTjdN+UJB9e55K5Jmt4ygKjb1pMTYsux8vCB2FrOpzFVO29s1Cvfv31fNlJ8kuX/kxNb9aPPgwQNHHyIH7Kml/TzSYrl9+PAhlVpz2/b/JLdO+k86PWzHTbMUvk+cYgmJcMFExNFoI/HKq17xFlcNDw9DxRyrLqVGuXTbEIOeP39uIRIl5tUwfYJVz549Aw+2XMcW3Cc2BWRGLUbi2NjY3t6e0JWC3WxsKeIqFIJ7JRMi5k05EoEYVoSCrYWFBYAvEImlUoFie7AOXAUZJIKISrZn91t2M6L/5S1yJycn5+fnoRJ2g5AMgbOeXJmampqZmbFFq+eV6y7k+EjZQcG+7ru0+yWa/dMdaJZXeOJ5BDqBy6WlpSSzUB/7dKZJuWLtCqC9EOO+fv26trZGRxJalzwZQG+0p3hOT08TfaZFLp93ZlGSTVUBhU/2LLQB+7DC7e1tKWa2QsoOESyOjo7Ozs5OTEzInixuaPMqamfdo6Oj2N1upVa4gV9Mgh7+/v0b5iOYIyfYJ1LkyFzUwkmiU4x1dNWNbXpSrYKNpX0lfJrosLbESPixKM0TybuC05e8kVnIR46Qd+oiQ/alsr2xJUpUFCxaDfTWta8IzSz2sgIiJYKEBWjtxlXsrYX8SE6IwxT7yY1rHpRvVPl4CpLc9QJ2rlHioDvAFjxYgaX7IuBFG3306NGT7hgaGpJMlLJy68llJ0wQ4oJDEXvugNxfv36x12CnIDQ6tkUFr6AKbdCJrkUGVCoV+o91nvPIDRBja0xRPlZeJaBmZ8xGj6TDMRJBjWNMDhUlkRUnQR+o9bRFvKgFOfdwj6qYpJSCIR7ini9fvuAnfVKcRPGYUzdqmIfDXr16RY3Fi+rvWI86nD8pHRiBm8+fP7daLSTKxjV5KOcOiRzVtCqK83AVJW1xcZHICigTk0Vll64kPHVyZWVFtof2IC/S81trb7SHpMHxNH46rPAA14L6aulnfNBoNFZXV5mt7Op/hiwZvuRXeA7lXrx4sby8zCo2DzpqyOGi3ZLThj9+/GiP1GIztgVFz7finxHxvwg3gBBN8+3bt0BNDhb73rJHtKD7w4cP7rQobgFu7R55cVQaqBJQgNrx7t07kNP3GaCTSejUbDbfv38vfkoeqcdykMyAW7uesw2fwcnevHnT706qEyUAPKlO8Yw/trDkljDJv5NdVeswXeHHjx+1Wq1/JCaNE33JOyFu7euRp5ACLvk3U/w/IelyJwTYQOBQrlerRV8gBbOTHUQBZchbuG1GnBCfR6skRKQaXafH5Xd3d6kIup1PNqxkKjnGHA+3Cv5ai/9DocDx8XG9Xu84j3u4uavjMc+L/9CKFMjVsGRlidGXw99qtfqfAAMAVXB5lHUIUuQAAAAASUVORK5CYII="
    },
    "5add": function (e, t, i) {
        e.exports = i.p + "static/img/pass.c4a29920.png"
    },
    "5c44": function (e, t, i) {
        "use strict";
        var s = i("75fc")
            , n = (i("ac6a"),
                i("5df3"),
                i("f400"),
                i("55dd"),
                i("d225"))
            , a = i("b0b4")
            , o = i("bd86")
            , r = i("2ef0")
            , c = i.n(r)
            , l = function () {
                function e() {
                    Object(n["a"])(this, e),
                        Object(o["a"])(this, "on", function () {
                            return function (e, t, i) {
                                e && t && i && e.addEventListener(t, i, !1)
                            }
                        }()),
                        Object(o["a"])(this, "off", function () {
                            return function (e, t, i) {
                                e && t && e.removeEventListener(t, i, !1)
                            }
                        }())
                }
                return Object(a["a"])(e, [{
                    key: "bindPlayer",
                    value: function (e) {
                        this.player = e,
                            this.addPlayerEvent()
                    }
                }, {
                    key: "initTags",
                    value: function (e) {
                        this.generalTestList(e),
                            this.defineConstants(),
                            this.generateEventList(),
                            this.setPrismTag()
                    }
                }, {
                    key: "generalTestList",
                    value: function (e) {
                        this.courseTestList = e.map((function (e) {
                            return {
                                offset: e.popupTime,
                                text: "课中测试".concat(e.userState),
                                data: e
                            }
                        }
                        )).sort((function (e, t) {
                            return e.offset - t.offset
                        }
                        ))
                    }
                }, {
                    key: "defineConstants",
                    value: function () {
                        this.isShowTagTimer = null,
                            this.startSeekTime = 0,
                            this.currentTime = 0,
                            this.inSeeking = !1,
                            this.progressMarkerContainer = null,
                            this.tagsPosition = {
                                left: {},
                                right: {}
                            }
                    }
                }, {
                    key: "generateEventList",
                    value: function () {
                        this.eventList = new Map
                    }
                }, {
                    key: "destroyEventList",
                    value: function () {
                        this.eventList = new Map
                    }
                }, {
                    key: "dispose",
                    value: function () {
                        this.removePlayerEvent(),
                            this.removeElementEvent(),
                            this.destroyEventList()
                    }
                }, {
                    key: "replay",
                    value: function () {
                        this.player.seek(0)
                    }
                }, {
                    key: "seek",
                    value: function (e) {
                        this.player.seek(e),
                            this.completeSeekCallback(e)
                    }
                }, {
                    key: "getPlayTime",
                    value: function () {
                        var e = Math.floor(this.player.getCurrentTime() + .1);
                        return e
                    }
                }, {
                    key: "timeUpdate",
                    value: function () {
                        // console.log('@@@this', this)
                        var e = this.getPlayTime();
                        e !== this.currentTime && (this.currentTime = e,
                            this.matchCourseTest())
                    }
                }, {
                    key: "matchCourseTest",
                    value: function () {
                        var e = this;
                        this.courseTestList.forEach((function (t) {
                            t.offset === e.currentTime && (console.log("courseTest: ", t),
                                (e.eventList.get("onTimeMatch") || []).forEach((function (e) {
                                    e(t)
                                }
                                )))
                        }
                        ))
                    }
                }, {
                    key: "addPlayerEvent",
                    value: function () {
                        this.removeElementEvent(),
                            this.onPlayerEvent("markerDotOver", this.onMarkerDotOverCallback.bind(this)),
                            this.onPlayerEvent("startSeek", this.startSeekCallback.bind(this)),
                            this.onPlayerEvent("completeSeek", this.completeSeekCallback.bind(this)),
                            this.onPlayerEvent("seeking", this.onSeeking.bind(this)),
                            this.onPlayerEvent("timeupdate", this.timeUpdate.bind(this))
                    }
                }, {
                    key: "removePlayerEvent",
                    value: function () {
                        this.offPlayerEvent("markerDotOver", this.onMarkerDotOverCallback.bind(this)),
                            this.offPlayerEvent("startSeek", this.startSeekCallback.bind(this)),
                            this.offPlayerEvent("completeSeek", this.completeSeekCallback.bind(this)),
                            this.offPlayerEvent("seeking", this.onSeeking.bind(this)),
                            this.onPlayerEvent("timeupdate", this.timeUpdate.bind(this))
                    }
                }, {
                    key: "startSeekCallback",
                    value: function (e) {
                        console.log("startSeek: ", e.paramData),
                            this.inSeeking || (this.startSeekTime = e.paramData)
                    }
                }, {
                    key: "onSeeking",
                    value: function () {
                        this.inSeeking = !0
                    }
                }, {
                    key: "completeSeekCallback",
                    value: function (e) {
                        this.inSeeking = !1;
                        var t = e.paramData || this.player.getCurrentTime();
                        console.log("completeSeek: ", t, e),
                            this.startSeekTime >= t ? this.seekMatchCourseTest(-1) : this.seekMatchCourseTest(t)
                    }
                }, {
                    key: "seekMatchCourseTest",
                    value: function (e) {
                        var t = this
                            , i = [];
                        this.courseTestList.forEach((function (s) {
                            Math.floor(t.startSeekTime) <= s.offset && e >= s.offset && i.push(s)
                        }
                        )),
                            (this.eventList.get("onCompleteSeek") || []).forEach((function (e) {
                                e(i)
                            }
                            ))
                    }
                }, {
                    key: "setPrismTag",
                    value: function () {
                        this.player && (this.player.setProgressMarkers(this.courseTestList),
                            this.progressMarkerContainer && this.progressMarkerContainer.remove(),
                            this.setPrismTagText())
                    }
                }, {
                    key: "setTagPositionStyle",
                    value: function (e, t) {
                        var i = e;
                        if (i > 3 && i < 95) {
                            this.tagsPosition.left[i] = (this.tagsPosition.left[i] || 0) + 1,
                                t.style.left = "".concat(i, "%"),
                                t.style.transform = "translate(-50%,-100%)";
                            var s = 2 * this.tagsPosition.left[i];
                            t.style.margin = "0px 0px ".concat(s, "px ").concat(s, "px"),
                                t.style.whiteSpace = "nowrap"
                        } else {
                            if (i >= 95) {
                                var n = 100 - i;
                                this.tagsPosition.right[n] = (this.tagsPosition.right[n] || 0) + 1,
                                    t.style.right = "".concat(n, "%");
                                var a = 2 * this.tagsPosition.right[n];
                                t.style.margin = "0px ".concat(a, "px ").concat(a, "px 0")
                            } else {
                                this.tagsPosition.left[i] = (this.tagsPosition.left[i] || 0) + 1,
                                    t.style.left = "".concat(i, "%");
                                var o = 2 * this.tagsPosition.left[i];
                                t.style.margin = "0px 0px ".concat(o, "px ").concat(o, "px")
                            }
                            t.style.transform = "translateY(-100%)"
                        }
                    }
                }, {
                    key: "setPrismTagText",
                    value: function () {
                        var e = this
                            , t = document.querySelector(".prism-controlbar")
                            , i = document.createElement("div");
                        this.progressMarkerContainer = i,
                            t.append(i),
                            i.style.position = "absolute",
                            i.style.width = "100%",
                            i.style.fontSize = "12px";
                        var s = this.player.getDuration()
                            , n = this.courseTestList.length;
                        this.courseTestList.forEach((function (t, a) {
                            var o = document.createElement("div");
                            o.style.position = "absolute";
                            var r = n - a;
                            o.style.zIndex = r,
                                o.style.dataZindex = r,
                                e.setTagPositionStyle(100 * c.a.divide(t.offset, s), o),
                                o.style.padding = "2px 8px",
                                o.style.backgroundColor = "rgba(0,0,0,0.8)",
                                o.style.borderRadius = "4px",
                                o.style.userSelect = "none",
                                o.style.cursor = "pointer",
                                o.dataIndex = t,
                                o.classList = ["progress-marker-item"],
                                o.innerHTML = '<div>\n                                        <span style="color:'.concat(t.data.userStateColor, '">').concat(t.data.userStateText, "</span>\n                                      </div>"),
                                i.append(o),
                                e.on(o, "click", e.onProgressMarkerItemClick.bind(e))
                        }
                        ))
                    }
                }, {
                    key: "onProgressMarkerItemClick",
                    value: function (e) {
                        var t = e.currentTarget.dataIndex
                            , i = this.getPlayTime()
                            , s = t.offset
                            , n = [];
                        this.courseTestList.forEach((function (e) {
                            i <= e.offset && s >= e.offset && n.push(e)
                        }
                        )),
                            (this.eventList.get("onTagClick") || []).forEach((function (e) {
                                e(t, n, i)
                            }
                            ))
                    }
                }, {
                    key: "onMarkerDotOverCallback",
                    value: function () {
                        var e = document.querySelector(".prism-marker-text");
                        e.style.display = "none",
                            e.style.opacity = "0",
                            e.style.zIndex = "-100"
                    }
                }, {
                    key: "removeElementEvent",
                    value: function () {
                        var e = this
                            , t = document.querySelectorAll(".progress-marker-item");
                        t.forEach((function (t) {
                            e.off(t, "click", e.onProgressMarkerItemClick.bind(e))
                        }
                        ))
                    }
                }, {
                    key: "onEvents",
                    value: function (e, t) {
                        this.eventList.set(e, [].concat(Object(s["a"])(this.eventList.get(e) || []), [t]))
                    }
                }, {
                    key: "offEvents",
                    value: function (e) {
                        this.eventList.delete(e)
                    }
                }, {
                    key: "onPlayerEvent",
                    value: function (e, t) {
                        this.player && this.player.on(e, t)
                    }
                }, {
                    key: "offPlayerEvent",
                    value: function (e, t) {
                        this.player && this.player && this.player.off(e, t)
                    }
                }], [{
                    key: "getInstance",
                    value: function () {
                        return e.instance || (e.instance = new e),
                            e.instance
                    }
                }]),
                    e
            }();
        Object(o["a"])(l, "instance", null),
            t["a"] = l.getInstance()
    },
    6710: function (e, t, i) { },
    6846: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABwAAAAcCAYAAAByDd+UAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAHKADAAQAAAABAAAAHAAAAABHddaYAAABk0lEQVRIDe3UP0vDUBAA8LtXxKG7k7VgimN3qYPQOjiqq4N/Ojn5CSRfwkWsHSx+AsdEHOwqCC5iVdqKWBG6SIUgOXMpfU1rkyZpAg590NC83Ltf7rXvAKZjugP/fQcw7hdc0JYKBD8bgqBaX3u+iBVM65miSeYJENiOELiZiKvCYcx2CF5iqXAUhoAGClwWUVfohgGKrXq+dhtphV5Yo/B4ycVFBvrBGJRbmr3LJpWqMseTQYdfjPPaYFpX1tsfXy3jm95T2uKxSqp8kXF4EEyCpglH1k3SPi8EB2f6eckPGhSTICK0nJUQ0U5Jq5x6oWEwCYrEzCEgvjpRAHPXDQ2LcX75L03pGQWIrq3P/CAsyvuF7aKKqsnzk2C8XoJ8Mw4tX1X2nL2xmwANPtS9c8ZzXmMA5EA31Aq8IYRcrxFzLLerIFh3DV+HhhvqDAuD8fo/FfaSeqFhMU+QH45CJ8E4p2dHaeZrT9ZxWbXiGhxsjU7Q36y7rH913dJ+CAD32fZnJwezifvmysOb89n0+/AO/AKJBfgZykzlOgAAAABJRU5ErkJggg=="
    },
    "7bd1": function (e, t, i) { },
    "7ff9": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAIAAAAACPTkDJAAAFWUlEQVRYCeWXe2zURRDHZ67XFkuRChHpAaWIiEoQExVRUIHgo1DBRzRiwEhMQCBRVNrDqAl/aNKKBCSRh8QQAmoUhCBBSEhFkRiswQQSRbHSUui1aigPa/H6uPUzv95d78q12mD9x01/ndnZeXx3Z3d2T+T/3rSzBRhZ6vr8rlIYcfKgOhnhRAKiko1+Jd+ujAx5p/p5Pd6Z/cASV4D+q9jmiU/W1hbra6l0LwIQWO6GRJolyMDTBO2Vyigqa1GVjRk+ef1EkRoor+Wtdlc0n5dV2M6KyYz602TcqSL9OlFmfBKAQKmb7px82CFwBUrlTuUYAVslIrfATxUn6VFnLXjZw0yPQK/D9h7G+nhjKiFoLn2Ls6Buia6J2sSJP87BRERMwWbdwrfZr7LmVFDL4ZNa7ptuKFBeJthTHhAnhfCF8O1NZUtab5nf2iB1CP3qk4z2wXYuvgI3r3PpNWclbGh9Ii+FlmhJu1pqzoC4iCzAZhrfYOZZj+1+nK6tCepBs2IvNEMMwCL2wVsdPcVX4NA8bc4tcUeYxBiW+G4U/xZA7WI9gV4w+nX0/Y/6AG5v5PiTaG/SqLed7fgeb0kAmL0HgI2YWf+H3Nfj0QmQBCBULIfIo+1c25HTPdrD/5IAqKojDTujMac9+pFL6+H4yStgwdjVOzwq0v9AtYz/zwFkZ8lnBG3wArfKjEsGoF4R6tRNUgpMq+JZDZOGPcazKR8yai1/hcsZvswN6E5ahq5wVgW9NBLoXJun5P/xQpQoDpS4J6iK75kMMJ9C7uBk5Hh9kSbqxLc43OZLl/dPvaA1Jk9s16xymRcaZUaryCvIR7MGzp8u16JbkahnfEoANts/w/Ib4/FC1dEw2o8AcC9e9vNVa6sEAHcTYwUxwKbnU1kdCurCqE0SSQnANCihZZDJOG5GaSPfV6wKf5LHxTOF9EyAvyiFyBJbBSV4WahI1tsJSxyI8Z0CyH3DPceJWAkAx7U3+GRQ2+pD1JI05UVU5uB2GqJReM+Kgq2iX4bjbXOLpWypqoHufiMN+ayCs487Yl5XHpY65xu20l1ltCu9VGOdroApDyx1h9nFN5Ln3bVBnZrKwaXKukTM8sYup8k9dTl1CYCctlXFHrycukyBc04DpXKSDTaINGwiDU/aklsx+rJS9rJCtzMWRtTI+Hnoab5fSdsJzkclzo/6s+Wb6gV6BnnKFgcwuMSNbvHJLJw+gGa2psm9ocX6Q26pW8OZfoYA9ROGyYAtj2mrbbgLYamJVbmUnmNCThFBjtHdis/N5jM2ZFQD61yWOyPr0ZqJwzgglB+uLdLtHMf7OY67PSOfTKwr1i+M5zl2F+/C8dilc9AyAZjDeeuHg1xWJQ+VvFQA0fugX7bM/W6heveNP3JW3kX5cZSt7F6A3wXdGiI4vPTuJfsaGr3LKZsydCsiDwDPsf3w9qVs+Rtcr6Z6ud61yG34noJSASGyWM2Z9Q2SSf8RM1TO+VloX+ZeSb2+M1Vt57luvxFmozeffXDUDLvbhpS6AK/TA4AZhm0DT3Tv6a6c9R0IY6+f88x+J8tYRsCDI8fKT59PUnuid7tN3Of8P5bLCHyNY9ZWugtxcrnniLdnXVC9q16vLnF9WfcNKMSv3lg0jJtYmZ8BaCchBLh6cn7O5yQMbTI9Nm0GJTkT2pdAtgfsJ9wQbIZjc9FvAca3XyYy5/gS9a5n+m1t0HI3hnzN5reg5SY/Kv63SBU34sfql001L+rhRKdxAIlCO2bhZhnLpruBWeQzls+MroTvj4Htl6zY7Og3MdZI/xz8acbsGq+Cr6IWfJ+ZLuWVi/SXRP+J/F+XK9H/d2hQCQAAAABJRU5ErkJggg=="
    },
    8170: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAADtklEQVRoBe2aW08UMRiGWRE8ICooHlCvjN4aY4x647/30niMJiYajcZoEOSgeABZ32egZCy728O028S0ybftdqZ9n37ztbPT2Yl+v39eNjlRKB2S7gnZFUEcL8EAAAkPXBTEgszUNQdyf9hiJyV4WRBHcwub/m0A6qdklwQxL+uZE3PlgwCM1pwKeGPaVOTIRwGghzgBejqXN1wAZtBnVFgUBJcnafIFQJTAxBsEarIUAoAoQclUZcoeTkERCmA0WbTwxoypiM1jAdCj7QVBnJNF9xPdsDXiWZXxxrFWnXcxBQBixAOz5GyoN1IBmBGfUoHF64ipcOWpAdBjrQBiTuZcynMAmEHPq8A9ZeRSnhMAEC4F3uDSDEy5ARDlMhCcBOmBxWscAGbkTFOmK7/A9tM4ARBFj9+g3OqbNG4Ao8uPHRawhshUjjsnLiZLecAMfrYkABAzpQGmSgMUjYEm6Et7oOg0rB6oHqgeqB6oHqgeqB6oHqgeiPJA8zjVtEz0EfKj9Lo078sWE2k33Rx4Xh/SOeIY6eZuNvFxL++U+XgAt19rqbDhAEQST/gAbEjskawvMykZhA8Aorg7C4QvQDaIEIAsEKEAySFiAJJCxAIkg+gCkASiK0BniBQAQOzwMSBtDaj7pyoFwIJ6vCVrb82zaj6ULclGpq4AbMnflrXFEWTV/ETBlboAsN97R2b38UR13ndKu7EL2Bzn5SXi9h8fnqvuvTnJJ48BYLv9rsz+LfFSdW9lQSkUgBeV92TTlsorfX9t1Xl9DQHghQPi9huxN6oDICr5AiCKuP3PineqexGlvNfIF+CGzrf/5PJBdc+6iNPWF+Cpzv3eEmOaPW59jy76AvyUwgPZuuyzjIUmSerptcnVgJ54K/pHNmztD+hq91R7Lrs6cN5cXB3Yx30vgd0u2fcKUD1QPVA9UD1QPVA9UD1QPVA9UNoDO6UBtksDbJYGWC8JsNrr9bZKAWzq0WqFx6vQZ8MUj2SriGv0zRuYcQLwYLsk4R/tUYwDgJF+lXHN2++dGo7cAIz2i4R/N2oDPnIBsIGBMG/cRqYcAIguS5ydFGdKCUCQMWqmmHdKBWCCLHjvqCsAu2dMraFB5nJFLAAjXZZtSPzA1HKJto/HALBhybXebncUWw4BQBDh9o5prO5+O1+ANbVg/Q4Osn2lIQUXwC+1I8jIs6RhAAQWt8s1iXcKMhf1IAAWEkadJMhCAFg6CbJvrkYpjxsPsA3P+p08yJyw2q63X8M42/xXJ/wFwHnm7/JFNS4AAAAASUVORK5CYII="
    },
    "948c": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAANxJREFUOBHdky0OwkAQhTsbDArFCXoEDEGQIEkQBIVA4MpFOEQvQRAkBIUjNT1CT4BCIZfvkQkJblsck7zuT9836XZnLCNijCOGFRpqic5mdmT8BJ4Ni6lv3BkPeOrgcMnG2F+mDPKWYo3H3uEFGZ8pNEwf3wlVgYc+u0mF8WbubcQqwU/Rg751zHDpyP0dpjqY6VRczbXN6eDm8usW1g62SgCzFKcEpkmHeHMqJDVG7uWZlMe9uVj9A3WimumBVJ7qRnXaV6Hg27I/QQrBA1QEjDWTHapQashbiH0BjwFD/NVolbwAAAAASUVORK5CYII="
    },
    "9a48": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAMgAAADICAYAAACtWK6eAAAAAXNSR0IArs4c6QAADvdJREFUeF7tnXnIblUVxp+HqCgLymzULJs0lKJMNBrIqIzU1MxCK1PMKBxKqUg0HDJRLDQNyww1J8zMTJts1CIzqRC1HBqUSMsGMtEGK1YsOfd6u937feecd631neE54F/uvdbZv71/d73f++6zD6FLBERgvQQoNiIgAusnIEG0OkRgCQISRMtDBCSI1oAI9COgCtKPm3rNhIAEmclEa5j9CEiQftzUayYEJMhMJlrD7EdAgvTjpl4zISBBZjLRGmY/AhKkHzf1mgkBCTKTidYw+xGQIP24qddMCEiQmUy0htmPgATpx029ZkJAgsxkojXMfgQkSD9u6jUTAhJkBSbazHYCsAOArQBsDeAPAK4H8AsAnyR5+wrcllKug4AEKV4WZnYZgJ2XSHsfgANJnl18a0onQVZ2DZjZjQC2bHkX25O8smVbNUsioAqSBHbtsGa2F4DzO6bbhOQdHfuoeSABCRIIc32hzGwDADcA2KxjuktI7t6xj5oHEpAggTCXEGQbANf2SHUXySf16KcuQQQkSBDIpcKY2T4AzuqZajN9q9WTXEA3CRIAcbkQZnYUgCOXa7ee/68/1nuCi+gmQSIoLhNDghRATkohQZLArhlWghRATkohQZLASpACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBJYVZACsAUpJEgBZFWQAshJKSRIElhVkAKwBSkkSAFkVZACyEkpJEgSWFWQArAFKSRIAWRVkALISSkkSBLYtSrIkQCO6plqe5JX9uyrbgsSkCALAmzT3cwkSBtQA2wjQQomRYIUQE5KIUGSwOojVgHYghQSpACyKkgB5KQUEiQJrCpIAdiCFBKkALIqSAHkpBQSJAmsKkgB2IIUEqQAsipIAeSkFBIkCawqSAHYghQSpACyKkgB5KQUEiQJrCpIAdiCFBKkALI2KxZATkohQZLAqoIUgC1IIUEKIOtvkALISSkkSBLYtSqIb3X3Hb19Lm1370MtqM/kBDGznQC8BsDmAJ4P4K8AvgLghyQ/H8StU5gxVhAz2wPAiwHsCOBRAH4C4CYA55G8oROAETeelCBmdhmAnZeYj0tJ7lY9X2MSxMyeA+BYAC7I+q7jSR5WzXEl8k1GEDO7DcDTW0C8m+RjW7QLazKWb7HMbHcAJwPYpMXgTyZ5SIt2o24yCUHM7AMATugwE38huWGH9gs1HUMFMbNXAfgygId3GOzrSH6tQ/vRNR29IGb2WgB9Julmks+tmLGhC2Jm2zRyPKEjj18C2Ibk3R37jab5FAQ5EcD7ehK/iuQrevZt3W3IH7HMzL/MuBzAs1sP6H8b7kby0p59B99tCoL4tysvXID0RSTfvED/ZbsOtYKY2RObb/i2XnYQ628w6b9FpiDIPQAevcAEe9dTSR68YIz1dh+iIGb2sOaj6SsXHPflJF+/YIzBdp+CIN8FEPEx6QiSH8mYqSF+xDKzLwLYNWC8R5Pse+ZXQPrcEFMQ5FQABwZh2p/kZ4JirQ4ztApiZmcDeHvQOPckeWFQrMGFmYIgrwbwjUCyu5D0HxzDriEJYmYfBxD1cfIWAC8l+acwWAMLNHpBnKeZRVYRD+mT/oOouRrKRywz+zCAI6LGBWA/kmcGxhtcqKkI8tSmimwRSPh5UXuOhlBBzMy/CvevxKOui0kutR0lKs+KxpmEIE0V2RaA/+H55ECiTyP5m0XjrbQgZvZOAKcvOo41+n8LgP/+cW9gzEGGmowgjSS+i/cSABsE0f4PgI0W/aV4JT9imdmbAHwuiIeH+XEjx28DYw421KQEaSR5I4DIbe13+uY9ktZ3FleqgpiZf4Hh23Ae0vfe1+rnW0t2JfmzoHiDDzM5QRpJ9gMQ+XXtdSRf0Hc2V0IQM3sRgCsARG3K/GNTOcK+vOjLs7LfJAVpJDkUwMcCYV5B0jdGdr6qP2KZ2TMB+N8Jbbb/txnPvxo5/MGzWV2TFaSRZJFHXde1EM4h2fkHtsoKYmZeMb7TPE0ZtZjfSvL8qGBjijNpQRpJTgLw3sBJOZGkP3/S+qoSxMx8Pq8C8LLWN7d8wwNInrZ8s2m2mLwgjST+Y9a+gVPYad9W1UcsM/Nt6/5MftR1OMnjooKNMc4sBGkk+QKANwRO0kEkP9EmXkUFMbPzALylzf20bNO5UraMO6pmcxLEfxvxB3v80dKoa2+S5y4XLFsQM3NRD1juPjr8/zNI+o+Ls79mI0hTRZ7SSOKPmEZd/rvAl5YKlvkRK2F/VfoDZFHgK+LMSpBGEn8O3SuJH28TdS15uFtWBTGz6K+yfVe072b+RxSYsceZnSCNJNs1kvgjp1HX1iR/uq5gGYKYmX/pELmT9tpGjt9HAZlCnFkK0kiyQ7O58RFBE3mf//ZA8ldrx4v+iGVm/iSgb8yMum5t5Lg5KuBU4sxWkEaS6I18vwawHUnflrH6iqwgZuaPF/tjxlHXXc3+qmuiAk4pzqwFaSTZH8CnAyf1RwBeTvL+VTGjBDEzP2v4+wGHVKy6tX82cnw9cPyTClUiiJk9A8D9JAe5RTrhYaJvkvSt9w9cEYKY2aYAfKNgm2NB2y7SUT5PbmaPAbApyevbDrRvuzRBzMz/EPbv0n3bw7OaG/QzrL4H4BSSt/e96Yx+ZnYMgA8Fxl79xN2igjQnq18NYKvA+3s3yU8FxksP1fwt58cUrdpK4x8P/ePmtzMO2/ABpQhiZu8AcMYSxPwP2gNJ+ukag7mCDzTwcZ1Jcr8AQVzeyP1Vh5E8fjDgl7mRZuu+r5Utl2jqkkT+CPxAqnBBzOyiZY7OX3OMO5P0A5MHcwUfiePj8s2S/o6SvmdH+QkrkQeznUDyg4MBvrwc+wA4q+X93kly45ZtWzULFcTM/HwqP2Gky7UtSf8OfjBX4KFqq8Z09AJvmIrkcjrJd0UGzIxlZv48y40dH6E+iaT/gBpyhQliZo8E4N+j+wkjXa6rSb6kS4fstmbm+7b8X+5Fj+XMvtUu8S8kuWeXDivd1sz8lRadHi1o7jnsQO1IQfyR1HX+krwM6PIX2rSZeDPzfVsuySIHO7dJVdHGv8b1j7P/rkgWlcPM/ACOPm8EC9umHymI/+t0QU84zyTpP7IN6jIz37flkqz6Fm5Q99fyZvwHQJdjdKcfmpkfEuGPD3e9ziW5d9dO62ofKcgij7cO9k2uzdfVLsnjI4AXx/CPvC6HL7TRXWbW9ySZK0luHzFgCdKCopn5vi3f0t7l9WQtIqc2+Z1/+0XSz7Ea5SVBHpy2wVaQVbeYcABb5qL9eyOHn2wy2kuCjEgQv1Uzi963lbV49yB5cVbwqrgSZGSCNJJEHwIdvd5S3nESfZNt4kmQEQrSSBL9GoE266VNm/eT/GibhmNoI0FGKkgjySkADhrQQjuO5OEDup+Fb0WCjFiQRpLPAgj5vn3B1XQaychTTRa8nZjuEmTkgjSS+AEQu8QsiV5RLiAZeR5Wr5vI6CRBpiGI79vyHckRb9rtus6+SnLHrp3G0l6CTECQpor4vi2XpPcrEnosWn+AasdFX+7TI29ZFwkyEUEaSXzflkvijxdnXz9v5BjUU5nRg5YgExKkkcQfM3ZJHhe9WNaId4cfUE3yusQcgwgtQSYmSCOJ79vyU9YfmrDK/FFll+PKhNiDCylBJihII0n0eVurSIU9CDQ4G9ZxQxJkooI0kkTv29p3aIdcZEsmQSYsSCNJ1L6tQ0ienL0ghxZfgkxckEaSRfdtHUPyyKEt3or7kSAzEKSRpO++LT9g7z0Vi3GIOSTITARpJOm6b6vXG3WHuND73pMEmZEgHSvJqSQP7ruwptJPgsxMkEaSvQAcC2CzdSzk2wD4G3T7ng4zFTceGIcEmaEgzcT7IXubN/9t0Ry4dwuAW0j+bVKrfIHBSJCZCrLAmplVVwkiQWa14LsOVoJIkK5rZlbtJYgEmdWC7zpYCSJBuq6ZWbWXIBJkVgu+62AliATpumZm1V6CSJBZLfiug5UgEqTrmplVewkiQWa14LsOVoJIkK5rZlbtJYgEmdWC7zpYCSJBuq6ZWbWXIBJkVgu+62AlyIPEZnHOU9cFova9zzue3Es8tRZEIJKABImkqViTIyBBJjelGlAkAQkSSVOxJkdAgkxuSjWgSAISJJKmYk2OgASZ3JRqQJEEBinI2wCcEzlKxRKBngTOJRny9mH2vIH/62Zm2wK4Jiqe4ojAAgQOJ3ncAv1Xd40UZEMAf464KcUQgQUJhL1oKEwQH5CZHQVglkf1Lzih6h5H4CSSh0aFCxWkkcRfYjnZd3dHgVecFAJ3ktw4MnK4IKokkdOjWB0IXEcy/D31KYI0kvi3Wl7qtkx642sHdmo6YQI3AbiC5CEZY0wTZNXNmpm/DtlPMt8oYwCKOVsC9wK4leQ9mQTSBcm8ecUWgWwCEiSbsOKPmoAEGfX06eazCUiQbMKKP2oCEmTU06ebzyYgQbIJK/6oCUiQUU+fbj6bgATJJqz4oyYgQUY9fbr5bAISJJuw4o+agAQZ9fTp5rMJSJBswoo/agISZNTTp5vPJiBBsgkr/qgJSJBRT59uPpuABMkmrPijJiBBRj19uvlsAhIkm7Dij5rAfwFHMhojAvdxjgAAAABJRU5ErkJggg=="
    },
    "9aba": function (e, t, i) { },
    a1b9: function (e, t, i) { },
    aef4: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAAEw0lEQVRoBe2bW2gVRxjH/3uOGm/xEqPxjlTBhxYjhrZUoUKliAqKUBBvqbUBbX1QrL4IpSgtSPFFpILaUrT6Kqigrb604kNRVIT2xaqgVIuXxGjSJJo0x++/ZY5zTvac2d0ze/ZlBvbM7Lc78//Nt9/M7s4myOVyDbJlkVLKiO5I2aYJxPA0GAjARA9MEojxsimbfyDpn2KxUSI4VSCGJi2s2i8GoH2wbFMEok42T52YVB4EoLTGSoHeGKIMSeTlAKhHcQbomKS8YQJQnR4nhckCwctjNYUFoCgDk95goFpLUQAoyqDkUOWQHWSDIiqA0uSkRW+MUIa4eVwA6rHuRIGYIFvsdmJX1HpcK2V6Y5hmC120AUAxxgNHSX1Ub9gCUD0eLQVOXjXKYMptA1CPcwUhxspmnMqTAFCdrpMC7yllp/IkAQjCS0Fv8NIEpqQBKMrLwOBkkA6YvKoBoHrOYcrhyiewfKomAEWpx2dQ3ur9VG0ApcuHHU5gPpEyVjtnXGTT8oDqfG2aAIQYkTbA4LQBUo0BP+jT9kCqw9B5wHnAecB5wHnAecB5wHnAeSAZDxy6jAmnbyH0WuKA12UfK+bPwSto2PsbTgzKoBMr0Lx8Fp6bmrL2VOyL/4oTvf2Y0d2Ht7adwrEwnrACoIurHhNi93m0qP1SecUAQeIUGz0UP//yKfaXElb2igDKiV/ajK31NfhPCZXKYwPYECdULABb4rEAbIpHBrAtHgkgCfHQAEmJE8A4FXNu5/TKGY4VVOI4DzvUVJ2g3DgKJtWhJ5NBT3FlWX99WVuD/mJ71H0jAG8o3yxC85AsbuuNt/dgedMBfK3b4pSNAGx07Vy07Xof6+Uud08Xae3Cqsbv8KVui1oOBcBGN72DR9sW+BAPdJFHnfh43kHs0G1RyqEB2OgX83G/pQnrZW3tsS7yTwc2v30In+u2sOVIAGz0qw9wd80cNGc9PNVF/m7H9gWHsVG3hSlHBmCj3y7GXyvfxIaMhw5d5M5T7Fr4A1brNlM5FgAbPbAMfy6djY2eh391kZut2PPhUazUbeXKsQHY6JEVuL7oDWwST7zIi+Tg/fEQe5cex5K8rUyhIgC2+9NH+P3dafiME1NeJ4fsjQfY9/01jM/bShQqBmC7J1fjYtNUbJVin6/jobdxMna0zCscLf6xoh8rAGzzzFpcaGzATrkc3e9Nx5az63CuSCtw15PPJjMDj8Q0/ngV9Z804UnY6tYBwgqr86xdAtVg1NwBOA84DzgPOA84DzgPOA84DzgPpO2B/rQB+tIG6Eob4HmaAO2e5/WmBdAlb1BtfIsyrpRGfdUKcX67nNMmvc/x3GoC9IreYxHuprBK1QBgT7mixmvu91qJM08agL19IsKvl2909QQBuIhN4YJlvCJtfzcJD1C0VcSNX8xIYBOAQcZec4iFTrYAVJBF/n5QKQA/ZHBolQwykyviArCnrbJ1iPiAoWUS1Y/HAeDaMK/1/4uSemsxylEAKEjhgsXpGJoFVcICPJNanL8jB1mBWsCOCYCr4Ayy16vhAY1UYioFwMDi7fKZiFcUZCa4IABOJOy1lSCLAsCpk0HWaapk87jyAP/ahfO39SAzwspyfdX+wdUIk8YJrwDREG917sSAdgAAAABJRU5ErkJggg=="
    },
    bf68: function (e, t, i) {
        "use strict";
        var s = i("7bd1")
            , n = i.n(s);
        n.a
    },
    c206: function (e, t, i) {
        "use strict";
        var s = i("a1b9")
            , n = i.n(s);
        n.a
    },
    cc93: function (e, t, i) { },
    ccf6: function (e, t, i) {
        e.exports = i.p + "static/img/audio@2x.221e7c1f.png"
    },
    d26f: function (e, t, i) {
        "use strict";
        var s = i("4eef")
            , n = i.n(s);
        n.a
    },
    d3f6: function (e, t, i) {
        "use strict";
        var s = i("324c")
            , n = i.n(s);
        n.a
    },
    d46a: function (e, t, i) {
        e.exports = i.p + "static/img/xsz-no.828b8a52.png"
    },
    da9d: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAB6CAYAAADeb1FlAAAABGdBTUEAALGPC/xhBQAAADhlWElmTU0AKgAAAAgAAYdpAAQAAAABAAAAGgAAAAAAAqACAAQAAAABAAAAIKADAAQAAAABAAAAegAAAAD97ZejAAADuUlEQVRoBe2aW28TMRBGG0opUAq0XFtagUAIgUBIvMH/l7gjXvkFIKClFyiXlobvhBi5m83a3rXXD3ikYW0n6+94duykE2aGw+EV+exMJjsm3TPydUGczsEAAEYEVgRxSW7GRi+k/qcqdlaCa4I4mVrYzF8FYHxOfk0Qy/KBeWOqax2A0VpSg2icMAMprk0A6CFOgp5PFQ0XgFn0BTVWBcHjiWq+AIiSmESDRI1mIQCIkpRsVbbs8RgUoQBGk0OLaCyYgbbXtgDoce9VQVyWt56n9Y3WihfVJhqnrDHvZgwAxMgHdsnF0GjEAjArPqcGh9e8GXBdYwOgx1kBxJLceZSnADCLXlaDz5TGozwlACA8CqLBo6m11ACI8hhITpJ04vDqA8CsnG3KduUb2D/rEwBR9PgOykf9yPoGMLp82eEAGxGZwb6v5MVsrgiYxS/mBABiITfAXG6ArDkwSvrcEci6DUsESgRKBEoESgRKBEoESgRKBJJFgHqid0Ez9pdSxJ/IH/tCxAQw4tQQqaZ6QcQCsMWlPTIgbo3bUy8xAOrEEfwgfzdVefxCV4Am8dfSGKYE6CwOXNsIRBFvCxBNvA1AVPFQgOjiIQBJxH0Bkon7AvzWGw94c8UO1Xfu88o9E12fbbivu57Jv1XuXlX/YWUsuOsDwKS/5E/l3+lYtq72fasf3PQFYOIfciC42nZDnbv2QEg7BIB59+RA/KRjGZ96t62+dzMUgInJBXKC3LDtjjo37QGfdhsA5t2VA1HdHfc0dl3ubW0BENiWP5ezTW17oM6aPdDU7gLAvF/kL+TV84DtuSJ3WlcABDbkL+U2BL8TPZLPyxstBgACH+Vv5AaCK/3qbtHQUYsFwKzv5W/lHNGvxn1dmm2gn02c31ybp5h4lbA7V27uihkBM6e3ODekADAgXtcCUCJQIlAiUCJQIlAiUCJQIlAikDsCh7kBDnID7OUG2MkJsDUYDPZzAVBr2uRPp4n/4+n191S3N23p9k2tfvSnfJ8AFLU+SfhIrbEPAFZKKYdnbgoY6v611ACs9rOEqbTWWioAqiQIU85rtBQAiG5IvFq+qwWJCUCSsWq2mLfFAjBJRuiDrCsAlXO21tQkc9G0BWClFCh3JT6xtVyi9uttAKiW86yrhWp7Xu92CACCCFd/uvEWq3ujLwCVcc7v4CSrE7XHXAAUHUmyoOKjLeBqTwMgsfi43JZ4pyRrA8BBwqqjJFkIAEcnSfbVdVPM180j2NGknN/Rk8wJq3I9vw3/v/YHErbwICLhC4UAAAAASUVORK5CYII="
    },
    dd49: function (e, t, i) {
        "use strict";
        i.r(t);
        var s = function () {
            var e = this
                , t = e.$createElement
                , s = e._self._c || t;
            return s("div", {
                staticClass: "course-play-main"
            }, [s("Test", {
                ref: "courseTest",
                attrs: {
                    allInFixTest: e.infixTests
                },
                on: {
                    updateInFixTest: e.updateInFixTest
                }
            }), s("div", {
                staticClass: "course-play-container",
                style: {
                    height: "preview" === e.$route.query.from ? "100%" : e.coursePlayBoxHeight
                }
            }, [s("div", {
                staticClass: "player-container",
                on: {
                    click: function (t) {
                        return t.stopPropagation(),
                            e.checkoutStatus.apply(null, arguments)
                    }
                }
            }, [s("div", [e.hangUpFlag ? s("hangUp", {
                attrs: {
                    preventHangTime: e.preventHangTime,
                    maxTime: e.maxTime,
                    minTime: e.minTime
                },
                on: {
                    pauseOrPlay: e.pauseOrPlay,
                    saveStudyLog: e.saveStudyLog
                }
            }) : e._e(), e.preventCheatFlag ? s("preventCheat", {
                ref: "preventCheat",
                attrs: {
                    preventCheatTime: e.preventCheatTime,
                    maxTime: e.maxTime,
                    minTime: e.minTime,
                    checkType: e.checkType
                },
                on: {
                    pauseOrPlay: e.pauseOrPlay,
                    saveStudyLog: e.saveStudyLog
                }
            }) : e._e()], 1), e.handoutVideo ? s("div", {
                staticClass: "handout-iframe-content"
            }, ["video" !== e.curType && "url" !== e.curType && "audio" !== e.curType && "" !== e.curType ? s("div", {
                staticStyle: {
                    height: "100%"
                }
            }, [s("div", {
                staticStyle: {
                    height: "calc(100% - 50px)"
                }
            }, [s("iframe", {
                staticClass: "handout-iframe",
                attrs: {
                    src: e.handoutVideoNoteId
                }
            })]), s("div", {
                staticClass: "tips_area"
            }, [e.currentStudyTime > 0 && "preview" !== e.$route.query.from ? s("span", {
                staticClass: "tips"
            }, [e._v("\n              需要 "), s("span", {
                staticClass: "tips-content"
            }, [e._v(e._s(e._f("TimeToString")(e.currentStudyTime)))]), e._v(" \n              完成学习  \n            ")]) : e._e(), "preview" === e.$route.query.from ? s("span", {
                staticClass: "tips"
            }, [e._v(e._s(e.$t("v4.js.pc.ocmt.preview")))]) : e._e(), s("span", {
                staticClass: "handout_span",
                on: {
                    click: function (t) {
                        return e.openHandoutOperate(e.noteId)
                    }
                }
            }, [e._v("关闭讲义")])])]) : s("iframe", {
                staticClass: "handout-iframe",
                attrs: {
                    src: e.handoutVideoNoteId
                }
            })]) : e._e(), !e.isVideo || "video" !== e.curType && "audio" !== e.curType ? e._e() : s("div", {
                staticClass: "aliPlayer-content"
            }, [s("div", {
                staticClass: "ac-main"
            }, [s("aliPlayer", {
                ref: "aliPlayer",
                attrs: {
                    resetHandoutAndVideoProps: e.resetHandoutAndVideoProps,
                    id: "aliPlayer",
                    type: e.curType,
                    isDefaultHideControl: e.isDefaultHideControl,
                    allowHighSpeed: e.allowHighSpeed,
                    allowMinStudyTime: e.allowMinStudyTime,
                    videoId: e.curVideoId,
                    curTime: e.curTime,
                    recordTime: e.recordTimeTemp,
                    noteId: e.noteId,
                    resourceRelId: e.resourceRelIdNoteId,
                    settingBtn: e.settingBtn,
                    seek: e.seek,
                    heartBeatFlag: e.heartBeatFlag,
                    courseId: e.courseId,
                    isNewPlay: !0,
                    infixTests: e.infixTests
                },
                on: {
                    seeking: e.videoSeeking,
                    openAndCloseVideoParent: e.openAndCloseVideo,
                    play: e.play,
                    pause: e.pause,
                    ended: e.ended,
                    ready: e.ready,
                    timeupdate: e.timeupdate,
                    isReady: e.isReady,
                    updateAndClear: e.updateCourseRecord,
                    "update:infixTests": function (t) {
                        e.infixTests = t
                    },
                    "update:infix-tests": function (t) {
                        e.infixTests = t
                    },
                    onTagClick: e.onTagClick,
                    onTimeMatch: e.onTimeMatch,
                    onCompleteSeek: e.onCompleteSeek
                }
            })], 1), s("div", {
                staticClass: "additional"
            }, [s("div", {
                staticClass: "additional-item",
                on: {
                    click: function (t) {
                        return e.toggleCollection(e.courseInfo.hasCollected)
                    }
                }
            }, [s("div", {
                staticClass: "ai-item ai-collection",
                class: {
                    "ai-collection_active": e.courseInfo.hasCollected
                }
            }), s("span", {
                class: {
                    span_active: e.courseInfo.hasCollected
                }
            }, [e._v(e._s(e.courseInfo.collectionCount || 0))])]), s("div", {
                staticClass: "additional-item",
                on: {
                    click: function (t) {
                        return e.toggleThumbsUp(e.courseInfo.hasPraised)
                    }
                }
            }, [s("div", {
                staticClass: "ai-item ai-thumbs-up",
                class: {
                    "ai-thumbs-up_active": e.courseInfo.hasPraised
                }
            }), s("span", {
                class: {
                    span_active: e.courseInfo.hasPraised
                }
            }, [e._v(e._s(e.courseInfo.praiseCount || 0))])]), s("div", {
                staticClass: "additional-item",
                on: {
                    click: e.shareCourse
                }
            }, [s("div", {
                staticClass: "ai-item ai-share"
            }), s("span", [e._v("分享")])]), e.campData.trainingCampId ? s("div", {
                staticClass: "additional-item"
            }, [s("el-popover", {
                attrs: {
                    placement: "top-start",
                    "popper-class": "pop-camp",
                    trigger: "click"
                },
                model: {
                    value: e.showCamp,
                    callback: function (t) {
                        e.showCamp = t
                    },
                    expression: "showCamp"
                }
            }, [e._v("\n              点击查看精彩训练营 "), s("i", {
                staticClass: "el-icon-close camp-pop-close",
                on: {
                    click: function (t) {
                        e.showCamp = !1
                    }
                }
            }), s("div", {
                staticClass: "ai-item ai-share campIcon",
                attrs: {
                    slot: "reference"
                },
                on: {
                    click: e.goTrainingCamp
                },
                slot: "reference"
            })]), s("span", {
                on: {
                    click: e.goTrainingCamp
                }
            }, [e._v("训练营")])], 1) : e._e()])]), "url" === e.curType ? [s("div", {
                staticClass: "aliPlayer-content"
            }, [s("div", {
                staticClass: "ac-main",
                staticStyle: {
                    position: "relative"
                }
            }, [e.urlJson && e.urlJson.content ? s("iframe", {
                ref: "urlContent",
                class: ["iframe-content", e.urlIframeHasControl ? "iframe-content__small" : ""],
                attrs: {
                    src: e.urlJson.content,
                    allowfullscreen: "true",
                    webkitallowfullscreen: "true",
                    mozallowfullscreen: "true"
                }
            }) : s("div", {
                ref: "urlContent",
                class: ["iframe-content", e.urlIframeHasControl ? "iframe-content__small" : ""],
                domProps: {
                    innerHTML: e._s(e.urlJson && e.urlJson.code)
                }
            }), "preview" !== e.$route.query.from && e.currentStudyTime > 0 && e.urlJson && e.urlJson.minStudyTime ? s("span", {
                staticClass: "min-study"
            }, [s("span", [e._v("\n              需要 " + e._s(e._f("TimeToString")(e.currentStudyTime)) + "\n              完成学习  \n             ")]), s("span", {
                staticClass: "icon iconfont icon-quanping full-screen",
                on: {
                    click: function (t) {
                        return e.toFullVideo(e.$refs.urlContent)
                    }
                }
            })]) : e._e(), "preview" !== e.$route.query.from && e.urlJson && (0 === e.currentStudyTime || e.urlJson.confirmFinish) && e.urlJson.minStudyTime ? s("span", {
                staticClass: "min-study"
            }, [s("span", [e._v("\n                " + e._s(e.$t("v4.js.pc.ocmt.completedLearning")) + "\n              ")]), s("span", {
                staticClass: "icon iconfont icon-quanping full-screen",
                on: {
                    click: function (t) {
                        return e.toFullVideo(e.$refs.urlContent)
                    }
                }
            })]) : e._e(), "preview" === e.$route.query.from ? s("span", {
                staticClass: "min-study"
            }, [e._v(e._s(e.$t("v4.js.pc.ocmt.preview")) + "\n        "), s("span", {
                staticClass: "icon iconfont icon-quanping full-screen",
                on: {
                    click: function (t) {
                        return e.toFullVideo(e.$refs.urlContent)
                    }
                }
            })]) : e._e()]), s("div", {
                staticClass: "additional"
            }, [s("div", {
                staticClass: "additional-item",
                on: {
                    click: function (t) {
                        return e.toggleCollection(e.courseInfo.hasCollected)
                    }
                }
            }, [s("div", {
                staticClass: "ai-item ai-collection",
                class: {
                    "ai-collection_active": e.courseInfo.hasCollected
                }
            }), s("span", {
                class: {
                    span_active: e.courseInfo.hasCollected
                }
            }, [e._v(e._s(e.courseInfo.collectionCount || 0))])]), s("div", {
                staticClass: "additional-item",
                on: {
                    click: function (t) {
                        return e.toggleThumbsUp(e.courseInfo.hasPraised)
                    }
                }
            }, [s("div", {
                staticClass: "ai-item ai-thumbs-up",
                class: {
                    "ai-thumbs-up_active": e.courseInfo.hasPraised
                }
            }), s("span", {
                class: {
                    span_active: e.courseInfo.hasPraised
                }
            }, [e._v(e._s(e.courseInfo.praiseCount || 0))])]), s("div", {
                staticClass: "additional-item",
                on: {
                    click: e.shareCourse
                }
            }, [s("div", {
                staticClass: "ai-item ai-share"
            }), s("span", [e._v("分享")])]), e.campData.trainingCampId ? s("div", {
                staticClass: "additional-item"
            }, [s("el-popover", {
                attrs: {
                    placement: "top-start",
                    trigger: "click"
                },
                model: {
                    value: e.showCamp,
                    callback: function (t) {
                        e.showCamp = t
                    },
                    expression: "showCamp"
                }
            }, [e._v("\n                点击查看精彩训练营 "), s("i", {
                staticClass: "el-icon-close camp-pop-close",
                on: {
                    click: function (t) {
                        e.showCamp = !1
                    }
                }
            }), s("div", {
                staticClass: "ai-item ai-share campIcon",
                attrs: {
                    slot: "reference"
                },
                on: {
                    click: e.goTrainingCamp
                },
                slot: "reference"
            })]), s("span", {
                on: {
                    click: e.goTrainingCamp
                }
            }, [e._v("训练营")])], 1) : e._e()])])] : e._e(), "video" !== e.curType && "url" !== e.curType && "audio" !== e.curType && "" !== e.curType ? s("div", {
                staticClass: "aliPlayer-content"
            }, [s("div", {
                staticClass: "ac-main"
            }, [e.handoutVideo ? e._e() : s("aliyun-preview", {
                ref: "aliPreview",
                attrs: {
                    allowDrag: e.allowDrag,
                    noteId: e.noteId,
                    resourceRelId: e.curVideoId,
                    pageIndex: e.pageIndex,
                    isFinish: e.curInfo.finish
                },
                on: {
                    isReady: e.isReady
                },
                scopedSlots: e._u([{
                    key: "handoutSpan",
                    fn: function () {
                        return [s("span", {
                            staticClass: "handout_span",
                            on: {
                                click: function (t) {
                                    return e.openHandoutOperate(e.noteId)
                                }
                            }
                        }, [e._v("讲义")])]
                    },
                    proxy: !0
                }], null, !1, 3578998395)
            }, [(e.currentStudyTime > 0 || e.infixTests.length) && "preview" !== e.$route.query.from ? s("span", {
                staticClass: "tips"
            }, [e._v("\n              还需观看 "), s("span", {
                staticClass: "tips-content"
            }, [e._v(e._s(e._f("TimeToString")(e.currentStudyTime)))]), e.infixTests.length ? s("span", [e._v(" 并完成随堂测试后")]) : e._e(), e._v(" \n              完成学习 \n              "), e.infixTests.length ? s("a-button", {
                class: ["course-test__button", e.currentStudyTime > 0 ? "course-test__button__disabled" : ""],
                attrs: {
                    type: "primary"
                },
                on: {
                    click: e.onStartDocumentTest
                }
            }, [e._v("\n                        开始随堂测试\n              ")]) : e._e()], 1) : e._e(), e.isPreview ? s("span", {
                staticClass: "tips"
            }, [e._v("\n              " + e._s(e.$t("v4.js.pc.ocmt.preview")) + "\n              "), e.infixTests.length ? s("a-button", {
                staticClass: "course-test__button",
                attrs: {
                    type: "primary"
                },
                on: {
                    click: e.onStartDocumentTest
                }
            }, [e._v("\n                        预览随堂测试\n              ")]) : e._e()], 1) : e._e()])], 1), s("div", {
                staticClass: "additional"
            }, [s("div", {
                staticClass: "additional-item",
                on: {
                    click: function (t) {
                        return e.toggleCollection(e.courseInfo.hasCollected)
                    }
                }
            }, [s("div", {
                staticClass: "ai-item ai-collection",
                class: {
                    "ai-collection_active": e.courseInfo.hasCollected
                }
            }), s("span", {
                class: {
                    span_active: e.courseInfo.hasCollected
                }
            }, [e._v(e._s(e.courseInfo.collectionCount || 0))])]), s("div", {
                staticClass: "additional-item",
                on: {
                    click: function (t) {
                        return e.toggleThumbsUp(e.courseInfo.hasPraised)
                    }
                }
            }, [s("div", {
                staticClass: "ai-item ai-thumbs-up",
                class: {
                    "ai-thumbs-up_active": e.courseInfo.hasPraised
                }
            }), s("span", {
                class: {
                    span_active: e.courseInfo.hasPraised
                }
            }, [e._v(e._s(e.courseInfo.praiseCount || 0))])]), s("div", {
                staticClass: "additional-item",
                on: {
                    click: e.shareCourse
                }
            }, [s("div", {
                staticClass: "ai-item ai-share"
            }), s("span", [e._v("分享")])]), e.campData.trainingCampId ? s("div", {
                staticClass: "additional-item"
            }, [s("el-popover", {
                attrs: {
                    placement: "top-start"
                },
                model: {
                    value: e.showCamp,
                    callback: function (t) {
                        e.showCamp = t
                    },
                    expression: "showCamp"
                }
            }, [e._v("\n              点击查看精彩训练营 "), s("i", {
                staticClass: "el-icon-close camp-pop-close",
                on: {
                    click: function (t) {
                        e.showCamp = !1
                    }
                }
            }), s("div", {
                staticClass: "ai-item ai-share campIcon",
                attrs: {
                    slot: "reference"
                },
                on: {
                    click: e.goTrainingCamp
                },
                slot: "reference"
            })]), s("span", {
                on: {
                    click: e.goTrainingCamp
                }
            }, [e._v("训练营")])], 1) : e._e()])]) : e._e(), s("el-dialog", {
                staticClass: "share-window",
                attrs: {
                    width: "404px",
                    visible: e.shareVisible,
                    "append-to-body": "",
                    "show-close": !1
                },
                on: {
                    "update:visible": function (t) {
                        e.shareVisible = t
                    }
                }
            }, [s("div", {
                staticClass: "sw-main"
            }, [s("div", {
                staticStyle: {
                    "background-color": "#FFFFFF",
                    "border-radius": "15px"
                }
            }, [s("img", {
                attrs: {
                    src: e.courseInfo.courseImage || "",
                    alt: ""
                }
            }), s("i", {
                staticClass: "el-icon-close",
                on: {
                    click: e.closeDialog
                }
            }), s("div", {
                staticClass: "swm-content"
            }, [s("div", {
                staticClass: "sc-top"
            }, [s("div", {
                staticClass: "top-line"
            }), s("p", {
                staticClass: "rate-title"
            }, [e._v(e._s(e.courseInfo.courseTitle || ""))]), s("div", {
                staticClass: "rate-area"
            }, [e.courseInfo && e.courseInfo.teacherList && e.courseInfo.teacherList.length ? s("div", {
                staticClass: "rate-area-span"
            }, [s("div", {
                staticStyle: {
                    width: "38px"
                }
            }, [e._v("讲师：")]), s("div", {
                staticStyle: {
                    width: "80px",
                    "text-overflow": "ellipsis",
                    "overflow-x": "hidden",
                    "white-space": "nowrap"
                }
            }, [e._v("\n                      " + e._s(e.ellipsisSpan) + "\n                    ")]), e.ellipsisSpan.length > 8 || e.courseInfo.teacherList.length > 1 ? s("span", [e._v("等" + e._s(e.courseInfo.teacherList.length) + "人")]) : e._e()]) : e._e(), s("el-rate", {
                attrs: {
                    disabled: "",
                    "show-score": "",
                    "text-color": "rgba(0,0,0,0.65)",
                    "score-template": "{value}"
                },
                model: {
                    value: e.courseInfo.avgPoint,
                    callback: function (t) {
                        e.$set(e.courseInfo, "avgPoint", t)
                    },
                    expression: "courseInfo.avgPoint"
                }
            }), s("span", {
                staticStyle: {
                    color: "rgba(0,0,0,0.65)"
                }
            }, [e._v("分")])], 1)]), s("div", {
                staticClass: "sc-bottom"
            }, [s("div", {
                staticClass: "scb-href-area"
            }, [s("div", {
                staticClass: "area-item"
            }, [s("div", {
                staticClass: "ai-l"
            }, [s("span", [e._v("PC端：")]), s("span", {
                attrs: {
                    title: e.courseInfo.courseInfoShortUrl || ""
                }
            }, [e._v(e._s(e.courseInfo.courseInfoShortUrl || ""))])]), s("div", {
                staticClass: "ai-r",
                on: {
                    click: function (t) {
                        return e.copyText(e.courseInfo.courseInfoShortUrl || "")
                    }
                }
            }, [e._v("复制")])]), s("div", {
                staticClass: "area-item"
            }, [s("div", {
                staticClass: "ai-l"
            }, [s("span", [e._v("移动端：")]), s("span", {
                attrs: {
                    title: e.courseInfo.qrCodePath || ""
                }
            }, [e._v(e._s(e.courseInfo.qrCodePath || ""))])]), s("div", {
                staticClass: "ai-r",
                on: {
                    click: function (t) {
                        return e.copyText(e.courseInfo.qrCodePath || "")
                    }
                }
            }, [e._v("复制")])])]), s("div", {
                staticClass: "qrcode-area"
            }, [s("el-image", {
                ref: "myImg",
                staticClass: "my-img",
                attrs: {
                    src: "/els/html/courseInfo/courseinfo.createQRCodeForGeneral.do?courseId=" + e.courseId,
                    "preview-src-list": ["/els/html/courseInfo/courseinfo.createQRCodeForGeneral.do?courseId=" + e.courseId]
                }
            })], 1)])])]), s("div", {
                staticClass: "swm-download"
            }, [s("div", {
                staticClass: "swm-download-btn",
                on: {
                    click: function (t) {
                        return e.saveDownload("sw-main")
                    }
                }
            }, [s("img", {
                attrs: {
                    src: e.icon_download,
                    alt: ""
                }
            }), s("span", [e._v("下载到本地")])])])])]), s("el-dialog", {
                attrs: {
                    title: e.campData.trainingCampName,
                    visible: e.campVisible,
                    width: "50%",
                    "append-to-body": "",
                    "close-on-click-modal": !1,
                    "custom-class": "camp-dialog"
                },
                on: {
                    "update:visible": function (t) {
                        e.campVisible = t
                    }
                }
            }, [s("div", {
                staticClass: "camp-dia"
            }, [s("p", {
                domProps: {
                    innerHTML: e._s(e.campData.trainingCampIntroduction)
                }
            }), s("img", {
                staticClass: "camp-img",
                attrs: {
                    src: e.campData.trainingCampPicture || "",
                    alt: ""
                }
            })]), s("span", {
                staticClass: "dialog-footer",
                attrs: {
                    slot: "footer"
                },
                slot: "footer"
            }, [s("el-checkbox", {
                model: {
                    value: e.notShowCampAd,
                    callback: function (t) {
                        e.notShowCampAd = t
                    },
                    expression: "notShowCampAd"
                }
            }, [e._v("今日不再弹出")]), s("el-button", {
                attrs: {
                    size: "small"
                },
                on: {
                    click: e.closeCampAd
                }
            }, [e._v("关 闭")]), s("el-button", {
                attrs: {
                    size: "small",
                    type: e.campData.hasInterest ? "default" : "primary"
                },
                on: {
                    click: e.toggleInterest
                }
            }, [e._v(e._s(e.campData.hasInterest ? "已感兴趣" : "感兴趣"))])], 1)]), s("div", {
                staticClass: "share-window",
                staticStyle: {
                    display: "none"
                },
                attrs: {
                    id: "sw-main-content"
                }
            }, [s("div", {
                staticClass: "sw-main",
                attrs: {
                    id: "sw-main"
                }
            }, [s("div", {
                staticStyle: {
                    "background-color": "#FFFFFF",
                    "border-radius": "15px"
                }
            }, [s("img", {
                attrs: {
                    crossOrigin: "anonymous",
                    id: "sw-main-img",
                    src: e.courseInfo.courseImage || "",
                    alt: ""
                }
            }), s("div", {
                staticClass: "swm-content"
            }, [s("div", {
                staticClass: "sc-top"
            }, [s("div", {
                staticClass: "top-line"
            }), s("p", {
                staticClass: "rate-title"
            }, [e._v(e._s(e.courseInfo.courseTitle || ""))]), s("div", {
                staticClass: "rate-area"
            }, [e.courseInfo && e.courseInfo.teacherList && e.courseInfo.teacherList.length ? s("div", {
                staticClass: "rate-area-span"
            }, [s("div", {
                staticStyle: {
                    width: "38px"
                }
            }, [e._v("讲师：")]), s("div", {
                staticStyle: {
                    width: "80px",
                    "text-overflow": "ellipsis",
                    "overflow-x": "hidden",
                    "white-space": "nowrap"
                }
            }, [e._v("\n                    " + e._s(e.ellipsisSpan) + "\n")]), s("span", [e._v("等" + e._s(e.courseInfo.teacherList.length) + "人")])]) : e._e(), s("el-rate", {
                attrs: {
                    disabled: "",
                    "show-score": "",
                    "text-color": "rgba(0,0,0,0.65)",
                    "score-template": "{value}"
                },
                model: {
                    value: e.courseInfo.avgPoint,
                    callback: function (t) {
                        e.$set(e.courseInfo, "avgPoint", t)
                    },
                    expression: "courseInfo.avgPoint"
                }
            }), s("span", {
                staticStyle: {
                    color: "rgba(0,0,0,0.65)"
                }
            }, [e._v("分")])], 1)]), s("div", {
                staticClass: "sc-bottom"
            }, [e._m(0), s("div", {
                staticClass: "qrcode-area-download"
            }, [s("img", {
                attrs: {
                    src: "/els/html/courseInfo/courseinfo.createQRCodeForGeneral.do?courseId=" + e.courseId,
                    alt: ""
                }
            })])])])])])]), !e.isPlaying && e.isReplayBtn ? s("div", {
                staticClass: "player-endInfo",
                class: {
                    "has-replay-btn": e.mustReplayCanFinish
                }
            }, [e.mustReplayCanFinish ? s("div", {
                staticClass: "player-replay-tip"
            }, [s("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.replayTips1")))]), s("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.replayTips2")))])]) : e._e(), s("div", {
                staticClass: "player-opt-btn"
            }, [e.mustReplayCanFinish ? s("button", {
                staticClass: "replay-btn",
                on: {
                    click: e.rePlay
                }
            }, [e._v(e._s(e.$t("v4.js.pc.ocmt.reView")))]) : e._e(), "unionpay" === e.corpCode ? [e.nextIndex ? e._e() : s("p", ["zh" === e.language ? s("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.Islastsection")))]) : s("span", [e._v("This is the last section")])])] : [e.nextIndex ? s("button", {
                staticClass: "next-button",
                on: {
                    click: e.playNextSection
                }
            }, [e._v(e._s(e.$t("v4.js.pc.ocmt.nextSection")))]) : s("p", ["zh" === e.language ? s("span", [e._v("已是最后一节")]) : s("span", [e._v("This is the last section")])])]], 2)]) : e._e()], 2), s("div", {
                staticClass: "rightList-container",
                style: e.open ? "" : "width:0;"
            }, [s("div", {
                style: e.open ? "width: 100%;border-bottom: 1px solid rgba(255,255,255,0.14);" : "width: 100%;"
            }, [s("el-tabs", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.open,
                    expression: "open"
                }],
                staticClass: "el-tabs",
                attrs: {
                    id: "el-tabsA",
                    stretch: ""
                },
                on: {
                    "tab-click": e.handletabClick
                },
                model: {
                    value: e.activeName,
                    callback: function (t) {
                        e.activeName = t
                    },
                    expression: "activeName"
                }
            }, [s("el-tab-pane", {
                attrs: {
                    label: e.$t("v4.js.pc.ocmt.contents"),
                    name: "contents"
                }
            }), "preview" !== e.$route.query.from ? s("el-tab-pane", {
                attrs: {
                    label: e.$t("v4.js.pc.ocmt.note"),
                    name: "note"
                }
            }) : e._e(), "preview" !== e.$route.query.from ? s("el-tab-pane", {
                attrs: {
                    label: e.$t("v4.js.pc.ocmt.QA"),
                    name: "QA"
                }
            }) : e._e()], 1)], 1), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "contents" === e.activeName,
                    expression: 'activeName ==="contents"'
                }],
                staticClass: "chapter-container",
                class: {
                    "bg-black": !e.open
                },
                style: {
                    height: e.open ? "calc(100% - 104px)" : "calc(100% - 48px)"
                }
            }, [s("div", {
                staticClass: "collapse-box-btn",
                on: {
                    mouseenter: e.enterDefault,
                    mouseleave: e.leaveDefault
                }
            }, [s("img", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.open,
                    expression: "open"
                }],
                staticStyle: {
                    transform: "scale(0.5)"
                },
                attrs: {
                    src: e.isHoverActive ? e.btnRightActive : e.btnRightDefault,
                    alt: ""
                },
                on: {
                    click: function (t) {
                        e.open = !e.open
                    }
                }
            }), s("img", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !e.open,
                    expression: "!open"
                }],
                staticStyle: {
                    transform: "scale(0.5)"
                },
                attrs: {
                    src: e.isHoverActive ? e.btnLeftActive : e.btnLeftDefault,
                    alt: ""
                },
                on: {
                    click: function (t) {
                        e.open = !e.open
                    }
                }
            })]), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.open,
                    expression: "open"
                }],
                staticClass: "chapter-section-box"
            }, [s("div", {
                staticClass: "chapter-box"
            }, e._l(e.courseData, (function (t, i) {
                return s("ul", {
                    key: i
                }, [e.courseData && e.courseData.length > 1 ? s("li", {
                    staticClass: "chapter",
                    attrs: {
                        title: t.chapterName
                    },
                    on: {
                        click: function (s) {
                            return e.toggleCollapse(t, i)
                        }
                    }
                }, ["zh_CN" === e.language ? s("span", [e._v("\n                  " + e._s(t.chapterName))]) : s("span", [e._v("Chapter " + e._s(i + 1))])]) : e._e(), s("div", {
                    staticClass: "section"
                }, e._l(t.resourceDTOS, (function (t, n) {
                    return s("li", {
                        key: n,
                        staticClass: "section-item",
                        class: {
                            finish: t.finish
                        },
                        on: {
                            click: function (s) {
                                return e.checkoutSection(t, i, n)
                            }
                        }
                    }, [s("div", {
                        class: {
                            "first-line": !0,
                            active: e.curId === t.resourceId
                        }
                    }, [s("span", {
                        staticClass: "icon-box",
                        attrs: {
                            title: t.resourceName
                        }
                    }, ["video" === t.resourceType ? s("div", {
                        staticClass: "icon-span-block"
                    }, [e._v(e._s(e.$t("v4.js.pc.ocmt.icon_video")))]) : e._e(), "audio" === t.resourceType ? s("div", {
                        staticClass: "icon-span-block"
                    }, [e._v(e._s(e.$t("v4.js.pc.ocmt.icon_audio")))]) : e._e(), "document" === t.resourceType ? s("div", {
                        staticClass: "icon-span-block"
                    }, [e._v(e._s(e.$t("v4.js.pc.ocmt.icon_document")))]) : e._e(), "url" === t.resourceType ? s("div", {
                        staticClass: "icon-span-block"
                    }, [e._v(e._s(e.$t("v4.js.pc.ocmt.icon_url")))]) : e._e(), s("span", {
                        staticClass: "section-title",
                        style: {
                            maxWidth: t.finish || !t.finish && e.curId === t.resourceId ? "140px" : "240px"
                        }
                    }, [e._v(e._s(t.resourceName))])]), t.finish ? s("span", {
                        staticClass: "finish-tig finish-tig-item"
                    }, [s("img", {
                        staticStyle: {
                            transform: "scale(0.5,0.5)",
                            "margin-right": "4px"
                        },
                        attrs: {
                            src: e.icon_completed,
                            alt: ""
                        }
                    }), e._v("\n                      " + e._s(e.$t("v4.js.pc.ocmt.completed")) + "\n                    ")]) : e._e(), t.finish || e.curId !== t.resourceId ? e._e() : s("span", {
                        staticClass: "finish-tig-item"
                    }, [s("img", {
                        staticStyle: {
                            transform: "scale(0.5,0.5)",
                            "margin-right": "4px"
                        },
                        attrs: {
                            src: e.icon_learning,
                            alt: ""
                        }
                    }), "zh_CN" === e.language ? s("span", [e._v("学习中")]) : s("span", [e._v("learning")])])]), s("div", {
                        staticClass: "second-line"
                    }, ["video" !== t.resourceType && "audio" !== t.resourceType && t.minStudyTime ? s("span", [e._v("\n                      " + e._s(e.$t("v4.js.pc.ocmt.minStudyTime")) + ": " + e._s(e._f("TimeToString")(t.minStudyTime)) + "\n                    ")]) : e._e(), "video" === t.resourceType || "audio" === t.resourceType ? [e.allowMinStudyTime && t.minStudyTime ? s("span", [e._v("\n                          " + e._s(e.$t("v4.js.pc.ocmt.minStudyTime")) + ": " + e._s(e._f("TimeToString")(t.minStudyTime)) + "\n                        ")]) : s("span", [e._v("\n                            " + e._s("video" === t.resourceType ? "zh_CN" === e.language ? "视频时长:" : "Video Duration: " : "zh_CN" === e.language ? "音频时长: " : "Audio Duration: ") + e._s(e._f("TimeToString")(t.playTime)) + "\n                        ")])] : e._e()], 2)])
                }
                )), 0)])
            }
            )), 0)])]), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "note" === e.activeName,
                    expression: 'activeName ==="note"'
                }],
                staticClass: "QA-container",
                class: {
                    "bg-black": !e.open
                },
                style: {
                    height: e.open ? "calc(100% - 104px)" : "calc(100% - 48px)"
                }
            }, [s("div", {
                staticClass: "QA-box-btn",
                on: {
                    mouseenter: e.enterDefault,
                    mouseleave: e.leaveDefault
                }
            }, [s("img", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.open,
                    expression: "open"
                }],
                staticStyle: {
                    transform: "scale(0.5)"
                },
                attrs: {
                    src: e.isHoverActive ? e.btnRightActive : e.btnRightDefault,
                    alt: ""
                },
                on: {
                    click: function (t) {
                        e.open = !e.open
                    }
                }
            }), s("img", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !e.open,
                    expression: "!open"
                }],
                staticStyle: {
                    transform: "scale(0.5)"
                },
                attrs: {
                    src: e.isHoverActive ? e.btnLeftActive : e.btnLeftDefault,
                    alt: ""
                },
                on: {
                    click: function (t) {
                        e.open = !e.open
                    }
                }
            })]), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.open,
                    expression: "open"
                }],
                staticClass: "QA-section-box"
            }, [s("div", {
                staticClass: "note-nav"
            }, [s("span", {
                style: {
                    color: "myNote" === e.navMsg ? "#1888FF" : ""
                },
                on: {
                    click: function (t) {
                        return e.navToggle("myNote")
                    }
                }
            }, [e._v("我的笔记")]), s("span", {
                style: {
                    color: "otherNote" === e.navMsg ? "#1888FF" : ""
                },
                on: {
                    click: function (t) {
                        return e.navToggle("otherNote")
                    }
                }
            }, [e._v("他人笔记")])]), e.isCreateNote || "myNote" !== e.navMsg ? e._e() : s("div", {
                staticClass: "note-list"
            }, [s("div", {
                staticClass: "note-list-content"
            }, [e._l(e.myNotes, (function (t, n) {
                return s("div", {
                    key: n,
                    staticClass: "nlc-item",
                    on: {
                        mouseenter: function (t) {
                            return e.noteEnter("note-item-s" + n)
                        },
                        mouseleave: function (t) {
                            return e.noteLeave("note-item-s" + n)
                        }
                    }
                }, [s("img", {
                    staticClass: "nlc-item-title",
                    attrs: {
                        src: i("15ba"),
                        alt: ""
                    }
                }), s("div", {
                    staticClass: "nlc-item-text",
                    style: {
                        width: e.noteMsg === "note-item-s" + n + "-enter" ? "120px" : "254px"
                    },
                    on: {
                        click: function (i) {
                            return e.showDownLoadDialog(t)
                        }
                    }
                }, [e._v("\n                  " + e._s(t.noteName || t.content || "") + "\n                ")]), e.noteMsg === "note-item-s" + n + "-enter" ? s("div", {
                    staticClass: "icon-area"
                }, [t.isSecret ? e._e() : s("div", {
                    staticClass: "icon_open_item",
                    attrs: {
                        title: "已公开"
                    },
                    on: {
                        click: function (i) {
                            return e.sendNote("toggle", t, "close")
                        }
                    }
                }), t.isSecret ? s("div", {
                    staticClass: "icon_close_item",
                    attrs: {
                        title: "已保密"
                    },
                    on: {
                        click: function (i) {
                            return e.sendNote("toggle", t, "open")
                        }
                    }
                }) : e._e(), e.isShowJumpPeriod(t) ? s("div", {
                    staticClass: "icon_href_item",
                    attrs: {
                        title: "跳转"
                    },
                    on: {
                        click: function (i) {
                            return e.jumpPeriod(t)
                        }
                    }
                }) : e._e(), s("div", {
                    staticClass: "icon_edit_item",
                    attrs: {
                        title: "编辑"
                    },
                    on: {
                        click: function (i) {
                            return e.editPeriod(t)
                        }
                    }
                }), s("div", {
                    staticClass: "icon_delete_item",
                    attrs: {
                        title: "删除"
                    },
                    on: {
                        click: function (i) {
                            return e.delMyNote(t)
                        }
                    }
                })]) : e._e()])
            }
            )), e.myNotes.length ? e._e() : s("div", {
                staticStyle: {
                    width: "100%",
                    "text-align": "center",
                    "font-size": "14px"
                }
            }, [e._v("\n                暂无笔记~~\n              ")])], 2), s("div", {
                staticClass: "note-toggle-btn"
            }, [s("div", {
                staticClass: "note-toggle-btn__block",
                on: {
                    click: e.toggleCreateNote
                }
            }, [s("i", {
                staticClass: "el-icon-notebook-2"
            }), s("span", [e._v("添加笔记")])])])]), "otherNote" === e.navMsg ? s("div", {
                staticClass: "note-list other-note-list"
            }, [e.otherNotes.length ? s("div", {
                staticStyle: {
                    width: "100%"
                }
            }, [s("div", {
                staticStyle: {
                    width: "100%",
                    height: "326px",
                    "overflow-y": "auto"
                }
            }, e._l(e.otherNotes, (function (t, n) {
                return s("div", {
                    key: n,
                    staticClass: "nlh-content nlh-content-new"
                }, [s("div", {
                    staticClass: "nc-left",
                    on: {
                        click: function (i) {
                            return e.showDownLoadDialog(t)
                        }
                    }
                }, [s("img", {
                    attrs: {
                        src: i("15ba"),
                        alt: ""
                    }
                })]), s("div", {
                    staticClass: "nc-right",
                    staticStyle: {
                        cursor: "pointer"
                    }
                }, [s("div", {
                    staticClass: "nlh-content-title nlh-content-dir",
                    on: {
                        click: function (i) {
                            return e.showDownLoadDialog(t)
                        }
                    }
                }, [s("span", {
                    staticClass: "note-name"
                }, [e._v(e._s(t.noteName || ""))])]), s("div", {
                    staticClass: "nlh-content-info"
                }, [s("div", {
                    staticClass: "info-time",
                    on: {
                        click: function (i) {
                            return e.showDownLoadDialog(t)
                        }
                    }
                }, [e._v(e._s(t.lastModifyTime || t.createTime || ""))]), s("div", {
                    staticClass: "info-icons"
                }, [e.isShowJumpPeriod(t) ? s("div", {
                    staticClass: "info-icons-item jump",
                    attrs: {
                        title: "跳转"
                    },
                    on: {
                        click: function (i) {
                            return e.jumpPeriod(t)
                        }
                    }
                }, [s("div")]) : e._e()])])])])
            }
            )), 0)]) : e._e(), e.otherNotes.length ? e._e() : s("div", {
                staticStyle: {
                    width: "100%",
                    "text-align": "center",
                    "font-size": "14px",
                    "padding-left": "18px"
                }
            }, [e._v("\n                暂无笔记~~\n            ")])]) : e._e(), e.isCreateNote ? s("div", {
                staticClass: "note-create"
            }, [s("el-input", {
                staticClass: "note-create-textarea-1",
                staticStyle: {
                    height: "64px"
                },
                attrs: {
                    type: "textarea",
                    placeholder: "请输入你的笔记标题",
                    maxlength: "50",
                    "show-word-limit": "",
                    resize: "none"
                },
                model: {
                    value: e.createNote.note_title,
                    callback: function (t) {
                        e.$set(e.createNote, "note_title", t)
                    },
                    expression: "createNote.note_title"
                }
            }), s("el-input", {
                staticClass: "note-create-textarea-2",
                attrs: {
                    type: "textarea",
                    placeholder: "请输入你的笔记内容（必填）",
                    resize: "none",
                    maxlength: "1300",
                    "show-word-limit": ""
                },
                model: {
                    value: e.createNote.note_content,
                    callback: function (t) {
                        e.$set(e.createNote, "note_content", t)
                    },
                    expression: "createNote.note_content"
                }
            }), s("div", {
                staticClass: "secrecy_submit_footer"
            }, [s("div", {
                staticClass: "ssf-l"
            }, [s("el-checkbox", {
                class: {
                    "secrecy-create": !e.createNote.secrecy
                },
                model: {
                    value: e.createNote.secrecy,
                    callback: function (t) {
                        e.$set(e.createNote, "secrecy", t)
                    },
                    expression: "createNote.secrecy"
                }
            }), e._m(1)], 1), s("div", {
                staticClass: "ssf-r"
            }, [s("el-button", {
                attrs: {
                    type: "primary",
                    size: "mini",
                    disabled: e.createNote.isSendShow
                },
                on: {
                    click: e.sendNote
                }
            }, [e._v(e._s("create" === e.noteStatus ? "发布" : "保存"))])], 1)])], 1) : e._e()])]), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "QA" === e.activeName,
                    expression: 'activeName ==="QA"'
                }],
                staticClass: "QA-container",
                class: {
                    "bg-black": !e.open
                },
                style: {
                    height: e.open ? "calc(100% - 104px)" : "calc(100% - 48px)"
                }
            }, [s("div", {
                staticClass: "QA-box-btn",
                on: {
                    mouseenter: e.enterDefault,
                    mouseleave: e.leaveDefault
                }
            }, [s("img", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.open,
                    expression: "open"
                }],
                staticStyle: {
                    transform: "scale(0.5)"
                },
                attrs: {
                    src: e.isHoverActive ? e.btnRightActive : e.btnRightDefault,
                    alt: ""
                },
                on: {
                    click: function (t) {
                        e.open = !e.open
                    }
                }
            }), s("img", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !e.open,
                    expression: "!open"
                }],
                staticStyle: {
                    transform: "scale(0.5)"
                },
                attrs: {
                    src: e.isHoverActive ? e.btnLeftActive : e.btnLeftDefault,
                    alt: ""
                },
                on: {
                    click: function (t) {
                        e.open = !e.open
                    }
                }
            })]), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.open,
                    expression: "open"
                }],
                staticClass: "QA-section-box"
            }, [s("div", {
                staticClass: "QA-box"
            }, [s("div", {
                staticClass: "QA-tabs"
            }, [s("div", {
                staticClass: "quiz",
                class: {
                    isActive: "quiz" === e.QAactiveName
                },
                on: {
                    click: function (t) {
                        return e.handleTabChange("quiz")
                    }
                }
            }, [e._v(e._s(e.$t("v4.js.pc.ocmt.quiz")))]), s("div", {
                staticClass: "relatedQuestion",
                class: {
                    isActive: "relatedQuestion" === e.QAactiveName
                },
                on: {
                    click: function (t) {
                        return e.handleTabChange("relatedQuestion")
                    }
                }
            }, [e._v(e._s(e.$t("v4.js.pc.ocmt.relatedQuestion")))])]), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "quiz" === e.QAactiveName,
                    expression: 'QAactiveName === "quiz"'
                }],
                staticClass: "quiz-box"
            }, [s("el-form", {
                ref: "form",
                staticClass: "que-form note-create",
                attrs: {
                    model: e.QAformData,
                    "label-width": "13px"
                },
                nativeOn: {
                    submit: function (e) {
                        e.preventDefault()
                    }
                }
            }, [s("el-form-item", {
                staticStyle: {
                    "margin-bottom": "16px"
                }
            }, [s("el-input", {
                staticStyle: {
                    "min-height": "80px"
                },
                attrs: {
                    type: "textarea",
                    maxlength: "140",
                    placeholder: "请输入你的问题",
                    "show-word-limit": "",
                    resize: "none"
                },
                model: {
                    value: e.QAformData.title,
                    callback: function (t) {
                        e.$set(e.QAformData, "title", t)
                    },
                    expression: "QAformData.title"
                }
            })], 1), s("el-form-item", {
                staticStyle: {
                    "margin-bottom": "16px"
                }
            }, [s("el-input", {
                staticStyle: {
                    "min-height": "80px"
                },
                attrs: {
                    type: "textarea",
                    maxlength: "140",
                    placeholder: "请输入你的问题补充",
                    "show-word-limit": "",
                    resize: "none"
                },
                model: {
                    value: e.QAformData.content,
                    callback: function (t) {
                        e.$set(e.QAformData, "content", t)
                    },
                    expression: "QAformData.content"
                }
            })], 1), s("el-form-item", {
                staticStyle: {
                    "margin-bottom": "5px"
                }
            }, [s("div", {
                staticClass: "quiz-topic",
                staticStyle: {
                    "border-radius": "4px"
                }
            }, [e._l(e.topicData, (function (t, i) {
                return s("span", {
                    staticClass: "topic-item"
                }, [e._v("\n                    " + e._s(t) + "\n                    "), s("span", {
                    staticClass: "deleteItem",
                    on: {
                        click: function (t) {
                            return e.deleteTopicItem(i)
                        }
                    }
                }, [e._v("x")])])
            }
            )), s("input", {
                directives: [{
                    name: "model",
                    rawName: "v-model",
                    value: e.inputTopicText,
                    expression: "inputTopicText"
                }, {
                    name: "show",
                    rawName: "v-show",
                    value: e.topicData.length <= 3,
                    expression: "topicData.length <= 3"
                }],
                attrs: {
                    type: "text",
                    maxlength: "10"
                },
                domProps: {
                    value: e.inputTopicText
                },
                on: {
                    focus: e.inputFocus,
                    blur: e.inputBlur,
                    input: function (t) {
                        t.target.composing || (e.inputTopicText = t.target.value)
                    }
                }
            }), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.showPlaceholder && 0 === e.topicData.length,
                    expression: "showPlaceholder && topicData.length === 0"
                }],
                staticClass: "placeholder"
            }, [e._v("请输入话题，每个话题长度10个")])], 2)]), s("el-form-item", {
                staticStyle: {
                    "margin-bottom": "20px"
                }
            }, [s("div", {
                staticClass: "choice_img"
            }, [s("div", {
                staticClass: "img_bg",
                on: {
                    click: function (t) {
                        e.showChoiceVisible = !e.showChoiceVisible
                    }
                }
            }), s("span", {
                on: {
                    click: function (t) {
                        e.showChoiceVisible = !e.showChoiceVisible
                    }
                }
            }, [e._v("图片")]), e.showChoiceVisible ? s("div", {
                staticClass: "choice_img_area"
            }, [s("div", [s("div", {
                staticClass: "choice-header"
            }, [s("span", [e._v("上传图片")]), s("i", {
                staticClass: "el-icon-close",
                on: {
                    click: function (t) {
                        e.showChoiceVisible = !1
                    }
                }
            })]), s("div", {
                staticClass: "choice-item-container"
            }, [e._l(e.uploadList, (function (t, i) {
                return s("div", {
                    key: i,
                    staticClass: "cic-item"
                }, [s("div", {
                    staticClass: "ci-content"
                }, [s("img", {
                    attrs: {
                        src: t.url || "",
                        alt: ""
                    }
                }), s("div", [s("i", {
                    staticClass: "el-icon-close",
                    on: {
                        click: function (t) {
                            return e.deleteItem(i)
                        }
                    }
                })])])])
            }
            )), e.uploadList.length < 9 ? s("div", {
                staticClass: "cic-item"
            }, [s("div", {
                staticClass: "ci-content-add"
            }, [s("input", {
                ref: "uploadFile",
                staticClass: "add-file",
                attrs: {
                    type: "file",
                    accept: "image/gif, image/jpeg, image/png, image/jpg",
                    multiple: ""
                },
                on: {
                    click: e.clickUpLoad,
                    change: e.changeUpLoad
                }
            }), s("i", {
                staticClass: "el-icon-plus"
            }), s("span", [e._v("还可上传" + e._s(9 - e.uploadList.length) + "张")])])]) : e._e()], 2), s("div", {
                staticClass: "choice-triangle"
            })])]) : e._e()])]), s("span", {
                staticClass: "course_area",
                staticStyle: {
                    "margin-bottom": "20px"
                }
            }, [e._v("\n                # " + e._s(e.courseInfo.courseTitle || "") + "\n              ")]), s("el-form-item", [s("div", {
                staticClass: "QA-saveBtn"
            }, [s("div", {
                staticClass: "note-toggle-btn__block_save",
                on: {
                    click: e.saveQuestion
                }
            }, [s("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.release")))])])])])], 1)], 1), s("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: "relatedQuestion" === e.QAactiveName,
                    expression: 'QAactiveName === "relatedQuestion"'
                }],
                staticClass: "question-box"
            }, [e._l(e.questionData, (function (t, n) {
                return e.questionData.length ? s("div", {
                    staticClass: "qusetion-item"
                }, [s("div", {
                    staticClass: "qusetion-item-header"
                }, [t.userFaceUrl ? s("img", {
                    attrs: {
                        src: t.userFaceUrl,
                        alt: ""
                    }
                }) : s("img", {
                    attrs: {
                        src: e.defaultAvatar,
                        alt: ""
                    }
                }), s("div", {
                    staticClass: "header-detail"
                }, [s("div", {
                    staticClass: "hd-content"
                }, [s("span", [e._v(e._s(t.nickName))]), s("img", {
                    staticClass: "dot-span",
                    attrs: {
                        src: i("12ef")
                    }
                }), s("span", {
                    staticClass: "answer",
                    on: {
                        click: function (i) {
                            return e.goToQuestion(t.questionId)
                        }
                    }
                }, [e._v(e._s(t.answerCount) + "个答案")])]), s("p", {
                    staticClass: "qusetion-title",
                    on: {
                        click: function (i) {
                            return e.goToQuestion(t.questionId)
                        }
                    }
                }, [e._v(e._s(t.title))]), s("p", {
                    staticClass: "time"
                }, [e._v(e._s(t.lastModifyTime))])])])]) : e._e()
            }
            )), e.questionData.length ? e._e() : s("div", {
                staticStyle: {
                    width: "100%",
                    "font-size": "14px",
                    "text-align": "center",
                    "margin-top": "15px"
                }
            }, [e._v("\n                暂无相关问题~~\n              ")])], 2)])])])]), s("el-dialog", {
                staticClass: "note-download-dialog",
                staticStyle: {
                    "border-radius": "15px"
                },
                attrs: {
                    width: "400px",
                    visible: e.noteDownLoadVisible,
                    "append-to-body": "",
                    "show-close": !1
                },
                on: {
                    "update:visible": function (t) {
                        e.noteDownLoadVisible = t
                    }
                }
            }, [e.otherNoteDownloadItem ? s("div", {
                staticClass: "note-download-dialog__container",
                staticStyle: {
                    "border-radius": "15px!important"
                }
            }, [s("i", {
                staticClass: "el-icon-close",
                on: {
                    click: function (t) {
                        e.noteDownLoadVisible = !1
                    }
                }
            }), s("div", {
                staticClass: "ndc_userInfo"
            }, [e.otherNoteDownloadItem && e.otherNoteDownloadItem.faceUrl ? s("img", {
                attrs: {
                    src: e.hostName + e.otherNoteDownloadItem.faceUrl,
                    alt: ""
                }
            }) : s("img", {
                attrs: {
                    src: e.defaultAvatar || "",
                    alt: ""
                }
            }), s("div", {
                staticClass: "ndc_userInfo__msg"
            }, [s("span", [e._v(e._s(e.otherNoteDownloadItem.createByName ? e.otherNoteDownloadItem.createByName : ""))]), s("span", [e._v(e._s(e.otherNoteDownloadItem.lastModifyTime || ""))])])]), s("div", {
                staticClass: "ndc_note_title"
            }, [e._v(e._s(e.otherNoteDownloadItem.noteName || ""))]), s("div", {
                staticClass: "ndc_note_content",
                staticStyle: {
                    "min-height": "132px"
                }
            }, [e._v("\n          " + e._s(e.otherNoteDownloadItem.content || "") + "\n        ")]), s("div", {
                staticClass: "ndc_form"
            }, [e._v("摘自《" + e._s(e.chapterInfo && e.chapterInfo.resourceName ? e.chapterInfo.resourceName : "") + "》")]), e.chapterInfo ? s("div", {
                staticClass: "ndc_chapter"
            }, [e._v("第" + e._s(e._f("convertToChinaNum")(e.chapterInfo.mIndex + 1)) + "章 " + e._s(e.chapterInfo ? e.chapterInfo.chapterName : ""))]) : e._e(), !e.chapterInfo || "video" !== e.chapterInfo.resourceClass && "audio" !== e.chapterInfo.resourceClass && "video" !== e.chapterInfo.resourceType && "audio" !== e.chapterInfo.resourceType ? e._e() : s("div", {
                staticClass: "ndc_time"
            }, [e._v("笔记所在时段:  "), s("img", {
                attrs: {
                    src: i("7ff9"),
                    alt: ""
                },
                on: {
                    click: function (t) {
                        return e.jumpPeriod(e.otherNoteDownloadItem, "window")
                    }
                }
            }), s("span", {
                on: {
                    click: function (t) {
                        return e.jumpPeriod(e.otherNoteDownloadItem, "window")
                    }
                }
            }, [e._v(e._s(e.jumpPeriodTime))])]), s("div", {
                staticClass: "ndc_btns"
            }, [s("el-button", {
                staticStyle: {
                    "margin-right": "20px"
                },
                attrs: {
                    type: "primary"
                },
                on: {
                    click: function (t) {
                        return e.downLoadTxt(e.otherNoteDownloadItem.noteName, e.otherNoteDownloadItem.content)
                    }
                }
            }, [e._v("下载")]), s("el-button", {
                on: {
                    click: function (t) {
                        e.noteDownLoadVisible = !1
                    }
                }
            }, [e._v("取消")])], 1)]) : e._e()]), s("el-dialog", {
                staticClass: "note-jumpPeriod-dialog",
                staticStyle: {
                    "border-radius": "15px"
                },
                attrs: {
                    width: "480px",
                    visible: e.noteJumpPeriodVisible,
                    "append-to-body": "",
                    "show-close": !1
                },
                on: {
                    "update:visible": function (t) {
                        e.noteJumpPeriodVisible = t
                    }
                }
            }, [s("div", {
                staticClass: "njd-header"
            }, [s("span", [e._v("提示")]), s("i", {
                staticClass: "el-icon-close",
                on: {
                    click: e.closePositionPlay
                }
            })]), s("div", {
                staticClass: "njd-main"
            }, [e.isRead() || e.userInfo && e.notejumpPeriod && e.userInfo.userId === e.notejumpPeriod.createBy || e.userInfo && e.notejumpPeriod && e.userInfo.userId !== e.notejumpPeriod.createBy && e.notejumpPeriodInfo && e.notejumpPeriodInfo.currentPosition && e.notejumpPeriodInfo.currentPosition >= e.jumpPeriodSecond ? s("p", [e._v("是否要跳转至笔记所在时段：" + e._s(e.jumpPeriodTime) + "?")]) : s("p", [e._v("笔记所在时段尚未学习，请先完成学习哦～")]), s("div", {
                staticClass: "njd-main-body"
            }, [s("el-button", {
                staticStyle: {
                    "margin-right": "24px"
                },
                attrs: {
                    type: "primary"
                },
                on: {
                    click: e.confirmPositionPlay
                }
            }, [e._v("确定")]), s("el-button", {
                on: {
                    click: e.closePositionPlay
                }
            }, [e._v("取消")])], 1)])])], 1), "preview" !== e.$route.query.from ? s("div", {
                staticClass: "course-play-footer"
            }, [s("div", {
                staticClass: "cpf-left"
            }, [s("div", {
                staticClass: "cpf-left-header"
            }, [s("div", {
                staticClass: "clh-item",
                class: {
                    "clh-item-active": "1" === e.navActive
                },
                on: {
                    click: function (t) {
                        return e.toggleNavItem("1")
                    }
                }
            }, [e._v("课程简介 "), s("span")]), e.courseInfo && e.courseInfo.openDsc ? s("div", {
                staticClass: "clh-item",
                class: {
                    "clh-item-active": "2" === e.navActive
                },
                on: {
                    click: function (t) {
                        return e.toggleNavItem("2")
                    }
                }
            }, [e._v("讨论区 "), s("span")]) : e._e(), s("div", {
                staticClass: "clh-item",
                class: {
                    "clh-item-active": "3" === e.navActive
                },
                on: {
                    click: function (t) {
                        return e.toggleNavItem("3")
                    }
                }
            }, [e._v("参考资料 "), s("span")]), e.campData.trainingCampId ? s("div", {
                staticClass: "clh-item",
                class: {
                    "clh-item-active": "4" === e.navActive
                },
                on: {
                    click: function (t) {
                        return e.toggleNavItem("4")
                    }
                }
            }, [e._v("训练营 "), s("span")]) : e._e()]), "1" === e.navActive ? s("div", {
                staticClass: "cpf-left-main course_introduction"
            }, [s("div", {
                staticClass: "ci-item"
            }, [e._m(2), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e._v(e._s(e.courseInfo.selectCount || 0) + "人")])]), s("div", {
                staticClass: "ci-item"
            }, [e._m(3), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r",
                staticStyle: {
                    display: "flex",
                    "flex-direction": "row",
                    "justify-content": "flex-start",
                    "align-items": "center"
                }
            }, [s("el-rate", {
                attrs: {
                    disabled: "",
                    "show-score": "",
                    "text-color": "#ff9900",
                    "score-template": "{value}"
                },
                model: {
                    value: e.courseInfo.avgPoint || 0,
                    callback: function (t) {
                        e.$set(e.courseInfo, "avgPoint || 0", t)
                    },
                    expression: "courseInfo.avgPoint || 0"
                }
            }), s("span", [e._v("分")])], 1)]), s("div", {
                staticClass: "ci-item"
            }, [e._m(4), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e._v("\n            " + e._s(e.courseInfo.coursePeriod || 0) + "\n          ")])]), s("div", {
                staticClass: "ci-item"
            }, [e._m(5), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e._v("\n            " + e._s(e.courseInfo.courseScore || 0) + "\n          ")])]), s("div", {
                staticClass: "ci-item"
            }, [e._m(6), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e._v("\n            " + e._s(e.courseInfo.categoryNamePath || "") + "\n          ")])]), s("div", {
                staticClass: "ci-item"
            }, [e._m(7), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e._v("\n            " + e._s(e.gWay) + "\n          ")])]), s("div", {
                staticClass: "ci-item"
            }, [e._m(8), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e._v("\n            " + e._s(e.courseInfo.publishDate ? e.moment(e.courseInfo.publishDate).format("YYYY-MM-DD") : "") + "\n          ")])]), e.courseInfo && e.courseInfo.teacherList && e.courseInfo.teacherList.length && e.courseInfo.teacherList[0].teacherName ? s("div", {
                staticClass: "ci-item"
            }, [e._m(9), e._v("\n          :\n          "), e.courseInfo.teacherList && e.courseInfo.teacherList.length ? s("div", {
                staticClass: "ci-item-r"
            }, e._l(e.courseInfo.teacherList, (function (t, i) {
                return s("span", [s("span", [e._v(e._s(t.teacherName))]), i !== e.courseInfo.teacherList.length - 1 ? s("span", [e._v(", ")]) : e._e()])
            }
            )), 0) : e._e()]) : e._e(), e.courseInfo && e.courseInfo.meaning ? s("div", {
                staticClass: "ci-item"
            }, [e._m(10), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e.courseInfo.meaning ? s("div", {
                domProps: {
                    innerHTML: e._s(e.courseInfo.meaning)
                }
            }) : e._e()])]) : e._e(), e.courseInfo && e.courseInfo.orientObj ? s("div", {
                staticClass: "ci-item"
            }, [e._m(11), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e.courseInfo.orientObj ? s("div", {
                domProps: {
                    innerHTML: e._s(e.courseInfo.orientObj)
                }
            }) : e._e()])]) : e._e(), e.courseInfo && e.courseInfo.objectives ? s("div", {
                staticClass: "ci-item"
            }, [e._m(12), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e.courseInfo.objectives ? s("div", {
                domProps: {
                    innerHTML: e._s(e.courseInfo.objectives)
                }
            }) : e._e()])]) : e._e(), e.courseInfo && e.courseInfo.outline ? s("div", {
                staticClass: "ci-item"
            }, [e._m(13), e._v("\n          :\n          "), s("div", {
                staticClass: "ci-item-r"
            }, [e.courseInfo.outline ? s("div", {
                domProps: {
                    innerHTML: e._s(e.courseInfo.outline)
                }
            }) : e._e()])]) : e._e()]) : e._e(), "2" === e.navActive ? s("div", {
                staticClass: "cpf-left-main discussion_area"
            }, [s("el-input", {
                attrs: {
                    type: "textarea",
                    placeholder: "发布一条友善的评论",
                    maxlength: "140",
                    "show-word-limit": "",
                    rows: "6"
                },
                model: {
                    value: e.discussionValue,
                    callback: function (t) {
                        e.discussionValue = t
                    },
                    expression: "discussionValue"
                }
            }), s("div", {
                staticClass: "comment-block"
            }, [s("el-button", {
                staticClass: "comment-btn",
                attrs: {
                    type: "primary",
                    size: "mini",
                    disabled: e.sendCommentIsShow
                },
                on: {
                    click: e.sendDiscuss
                }
            }, [e._v("发表评论")])], 1), s("div", {
                staticClass: "infinite-list-wrapper",
                staticStyle: {
                    overflow: "auto",
                    height: "800px"
                }
            }, [s("div", {
                directives: [{
                    name: "infinite-scroll",
                    rawName: "v-infinite-scroll",
                    value: e.load,
                    expression: "load"
                }],
                staticClass: "comment-list",
                attrs: {
                    "infinite-scroll-disabled": e.disabled
                }
            }, e._l(e.commentList, (function (t, i) {
                return s("div", {
                    key: i,
                    staticClass: "comment-list-item"
                }, [s("div", {
                    staticClass: "cli-l"
                }, [s("img", {
                    attrs: {
                        src: t.faceUrl || e.defaultAvatar || "",
                        alt: ""
                    }
                })]), s("div", {
                    staticClass: "cli-r"
                }, [s("div", [s("span", {
                    staticClass: "cli-r-title"
                }, [e._v(e._s(t.userName || ""))])]), s("div", {
                    staticStyle: {
                        "white-space": "normal",
                        "word-break": "break-all"
                    }
                }, [e._v("\n                  " + e._s(t.contentPreview || "") + "\n                ")]), s("div", [s("div", {
                    staticClass: "comment-time"
                }, [e._v(e._s(t.createTime ? e.moment(t.createTime).format("YYYY-MM-DD HH:mm") : ""))]), s("div", {
                    staticClass: "comment-priview"
                }, [s("div", {
                    staticClass: "cp-item cp-reply",
                    on: {
                        click: function (s) {
                            return e.choiceReply(t, i)
                        }
                    }
                }, [s("div", {
                    staticClass: "cpr-block"
                }), s("span", [e._v("回复")])]), e.userInfo && e.userInfo.userId === t.createBy && !e.isbizResultShow || e.isbizResultShow ? s("div", {
                    staticClass: "cp-item cp-delete",
                    on: {
                        click: function (s) {
                            return e.delComment(t, i)
                        }
                    }
                }, [s("div", {
                    staticClass: "cpd-block"
                }), s("span", [e._v("删除")])]) : e._e()])]), t.isReplyShow ? s("div", {
                    staticClass: "child_item reply_area",
                    staticStyle: {
                        "margin-bottom": "32px"
                    }
                }, [s("el-input", {
                    attrs: {
                        type: "textarea",
                        placeholder: "请输入回复信息",
                        maxlength: "140",
                        "show-word-limit": "",
                        rows: "4",
                        resize: "none"
                    },
                    model: {
                        value: e.replyValue,
                        callback: function (t) {
                            e.replyValue = t
                        },
                        expression: "replyValue"
                    }
                }), s("div", {
                    staticClass: "reply-block"
                }, [s("el-button", {
                    staticClass: "reply-btn-send",
                    attrs: {
                        type: "primary",
                        size: "mini",
                        disabled: e.sendReplyIsShow
                    },
                    on: {
                        click: function (i) {
                            return e.sendReply(t)
                        }
                    }
                }, [e._v("回复")])], 1)], 1) : e._e(), e._l(t.discussList, (function (i, n) {
                    return s("div", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: t.discussList.length,
                            expression: "item.discussList.length"
                        }],
                        key: n,
                        staticClass: "child_item",
                        staticStyle: {
                            "margin-bottom": "32px"
                        }
                    }, [s("div", {
                        staticClass: "comment-list-item",
                        staticStyle: {
                            "border-bottom": "none",
                            "margin-bottom": "0",
                            padding: "0 0"
                        }
                    }, [s("div", {
                        staticClass: "cli-l"
                    }, [s("img", {
                        attrs: {
                            src: i.faceUrl || e.defaultAvatar || "",
                            alt: ""
                        }
                    })]), s("div", {
                        staticClass: "cli-r"
                    }, [s("div", {
                        staticClass: "cli-r-child"
                    }, [s("span", {
                        staticClass: "cli-r-title"
                    }, [e._v(e._s(i.userName))]), e.userInfo && e.userInfo.userId === i.createBy && !e.isbizResultShow || e.isbizResultShow ? s("div", {
                        staticClass: "cp-item cp-delete",
                        on: {
                            click: function (t) {
                                return e.delComment(i, n)
                            }
                        }
                    }, [s("div", {
                        staticClass: "cpd-block"
                    }), s("span", [e._v("删除")])]) : e._e()]), s("div", {
                        staticStyle: {
                            "white-space": "normal",
                            "word-break": "break-all"
                        }
                    }, [e._v("\n                        " + e._s(i.contentPreview || "") + "\n                      ")]), s("div", {
                        staticStyle: {
                            "margin-bottom": "0"
                        }
                    }, [s("div", {
                        staticClass: "comment-time"
                    }, [e._v(e._s(i.createTime ? e.moment(i.createTime).format("YYYY-MM-DD HH:mm") : ""))]), s("div", {
                        staticClass: "comment-priview"
                    })])])])])
                }
                ))], 2)])
            }
            )), 0), e.loading ? s("p", {
                staticStyle: {
                    "margin-top": "15px",
                    "margin-bottom": "30px",
                    "text-align": "center",
                    "font-size": "12px",
                    color: "rgba(0,0,0,0.25)"
                }
            }, [e._v("加载中...")]) : e._e(), e.noMore ? s("p", {
                staticStyle: {
                    "margin-top": "15px",
                    "margin-bottom": "30px",
                    "text-align": "center",
                    "font-size": "12px",
                    color: "rgba(0,0,0,0.25)"
                }
            }, [e._v("到底了~")]) : e._e()])], 1) : e._e(), "3" === e.navActive ? s("div", {
                staticClass: "cpf-left-main reference_material"
            }, [e.referenceMaterial.length > 0 ? s("div", [s("div", {
                staticClass: "reference_material_header"
            }, [e._v("共有" + e._s(e.referenceMaterial.length) + "份资料")]), e._l(e.referenceMaterial, (function (t, i) {
                return s("div", {
                    key: i,
                    staticClass: "rmh-data-item"
                }, [s("span", [e._v(e._s(t.refName))]), "RESOURSESTATION" === t.refSource ? s("span", {
                    on: {
                        click: function (i) {
                            return e.showRefer(t)
                        }
                    }
                }, [e._v("查看")]) : s("span", {
                    on: {
                        click: function (i) {
                            return e.downLoadRefer(t)
                        }
                    }
                }, [e._v("下载")])])
            }
            ))], 2) : s("div", {
                staticClass: "no-area"
            }, [s("img", {
                attrs: {
                    src: i("d46a"),
                    alt: ""
                }
            }), s("span", [e._v("暂无参考资料")])])]) : e._e(), "4" === e.navActive ? s("div", {
                staticClass: "cpf-left-main reference_material"
            }, [s("div", {
                staticClass: "camp-title"
            }, [s("h3", [e._v(e._s(e.campData.trainingCampName))]), s("el-button", {
                attrs: {
                    size: "small",
                    type: e.campData.hasInterest ? "default" : "primary"
                },
                on: {
                    click: e.toggleInterest
                }
            }, [e._v(e._s(e.campData.hasInterest ? "已感兴趣" : "感兴趣"))])], 1), e.campData.startTime ? s("p", {
                staticClass: "time-line"
            }, [e._v("计划期限："), s("span", [e._v(e._s(e.campData.startTime) + " ~ " + e._s(e.campData.endTime))])]) : e._e(), e.campData.trainingCampIntroduction ? s("div", {
                staticClass: "camp-desc",
                domProps: {
                    innerHTML: e._s("训练营简介：" + e.campData.trainingCampIntroduction)
                }
            }) : e._e(), s("img", {
                staticClass: "camp-img",
                attrs: {
                    src: e.campData.trainingCampPicture || "",
                    alt: ""
                }
            })]) : e._e()]), e._m(14)]) : e._e()], 1)
        }
            , n = [function () {
                var e = this
                    , t = e.$createElement
                    , i = e._self._c || t;
                return i("div", {
                    staticClass: "qrcode-area-title"
                }, [i("span", [e._v("扫一扫，观看精彩课程")]), i("span", [e._v("学习成就卓越")])])
            }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("span", [e._v("保密"), i("span", [e._v("（只有本人可以查看）")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("学")]), i("span", [e._v("习")]), i("span", [e._v("人")]), i("span", [e._v("次")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("评")]), i("span", [e._v("分")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("学")]), i("span", [e._v("时")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("学")]), i("span", [e._v("分")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("课")]), i("span", [e._v("程")]), i("span", [e._v("分")]), i("span", [e._v("类")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("学")]), i("span", [e._v("习")]), i("span", [e._v("来")]), i("span", [e._v("源")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("发")]), i("span", [e._v("布")]), i("span", [e._v("日")]), i("span", [e._v("期")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("讲")]), i("span", [e._v("师")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("课")]), i("span", [e._v("程")]), i("span", [e._v("意")]), i("span", [e._v("义")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("课")]), i("span", [e._v("程")]), i("span", [e._v("对")]), i("span", [e._v("象")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("课")]), i("span", [e._v("程")]), i("span", [e._v("目")]), i("span", [e._v("标")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , i = e._self._c || t;
                    return i("div", {
                        staticClass: "ci-item-l"
                    }, [i("span", [e._v("课")]), i("span", [e._v("程")]), i("span", [e._v("提")]), i("span", [e._v("纲")])])
                }
                , function () {
                    var e = this
                        , t = e.$createElement
                        , s = e._self._c || t;
                    return s("div", {
                        staticClass: "cpf-right"
                    }, [s("span", {
                        staticClass: "cpf-right-title"
                    }, [e._v("大家都在看")]), s("div", {
                        staticClass: "no-area",
                        staticStyle: {
                            width: "100%",
                            "padding-top": "10px"
                        }
                    }, [s("img", {
                        attrs: {
                            src: i("d46a"),
                            alt: ""
                        }
                    }), s("span", [e._v("敬请期待")])])])
                }
            ]
            , a = (i("8e6e"),
                i("456d"),
                i("55dd"),
                i("3b2b"),
                i("96cf"),
                i("3b8d"))
            , o = (i("7f7f"),
                i("a481"),
                i("20d6"),
                i("34ef"),
                i("6762"),
                i("2fdb"),
                i("5df3"),
                i("1c4c"),
                i("bd86"))
            , r = i("75fc")
            , c = (i("7514"),
                i("28a5"),
                i("ac6a"),
                i("8e44"))
            , l = i("527b")
            , u = i("b775")
            , d = i("bc3a")
            , h = i.n(d)
            , m = i("5c96")
            , p = i("4360")
            , v = i("4328")
            , f = i.n(v)
            , g = h.a.create({
                baseURL: Object({
                    NODE_ENV: "production",
                    BASE_URL: "/courseSetting/"
                }).VUE_APP_BASE_API,
                timeout: 5e3,
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded"
                }
            });
        g.interceptors.request.use((function (e) {
            return p["a"].getters.token,
                e.data = f.a.stringify(e.data),
                e
        }
        ), (function (e) {
            return console.log(e),
                Promise.reject(e)
        }
        )),
            g.interceptors.response.use((function (e) {
                var t = e.data;
                return 0 !== t.code && 1001 !== t.code || 200 !== e.status ? (Object(m["Message"])({
                    message: t.message || t.msg || "Error",
                    type: "error",
                    duration: 5e3
                }),
                    50008 !== t.code && 50012 !== t.code && 50014 !== t.code || m["MessageBox"].confirm("You have been logged out, you can cancel to stay on this page, or log in again", "Confirm logout", {
                        confirmButtonText: "Re-Login",
                        cancelButtonText: "Cancel",
                        type: "warning"
                    }).then((function () {
                        p["a"].dispatch("user/resetToken").then((function () {
                            location.reload()
                        }
                        ))
                    }
                    )),
                    Promise.reject(new Error(t.message || t.msg || "Error"))) : t
            }
            ), (function (e) {
                console.log("err" + e),
                    console.log(e.response.status),
                    Object(m["Message"])({
                        message: e.response.data.message,
                        type: "error",
                        duration: 5e3
                    });
                var t = window.vm.$route.path
                    , i = {};
                return "/login" !== t && (i.redirect = t),
                    401 === e.response.status && window.vm.$router.push({
                        path: "/login",
                        query: i
                    }),
                    Promise.reject(e)
            }
            ));
        var A = g;
        function y(e) {
            return Object(u["a"])({
                url: "/els/html/course/course.getCourseReferenceJson.do?courseId=".concat(e.courseId),
                method: "get"
            })
        }
        function C(e) {
            return Object(u["a"])({
                url: "/els/html/discussAndNote/discussAndNote.batchDeleteDiscussJson.do?discussIds=".concat(e.discussIds, "&csrfToken=").concat(e.csrfToken),
                method: "get"
            })
        }
        function I(e) {
            return Object(u["a"])({
                url: "/els/html/coursebasic/coursebasic.saveDiscuss.do?discuss.idPath=".concat(e.discuss.idPath, "&discuss.objectId=").concat(e.discuss.objectId, "&discuss.contentPreview=").concat(e.discuss.contentPreview),
                method: "get"
            })
        }
        function T(e) {
            return Object(u["a"])({
                url: "/els/html/coursebasic/coursebasic.saveDiscuss.do?discuss.objectId=".concat(e.discuss.objectId, "&discuss.contentPreview=").concat(e.discuss.contentPreview, "&isShare=").concat(e.isShare),
                method: "get"
            })
        }
        function S(e) {
            return Object(u["a"])({
                url: "/els/html/coursebasic/coursebasic.getCourseDiscussJson.do?courseType=".concat(e.courseType, "&courseId=").concat(e.courseId, "&page.pageNo=").concat(e.page.pageNo, "&page.pageSize=").concat(e.page.pageSize),
                method: "get"
            })
        }
        function w(e) {
            return Object(u["a"])({
                url: "/els/html/course/course.getCourseInfoJson.do",
                method: "get",
                params: e
            })
        }
        function b(e) {
            return A({
                url: "/els/html/course/courseStudy.saveOrUpdateCourseNoteJson.do",
                method: "post",
                data: e
            })
        }
        function x(e) {
            var t = e.courseId
                , i = e.processType
                , s = e.page
                , n = s.pageNo
                , a = s.pageSize
                , o = "?courseId=".concat(t, "&processType=").concat(i, "&page.pageNo=").concat(n, "&page.pageSize=").concat(a);
            return Object(u["a"])({
                url: "/els/html/course/courseStudy.courseNoteListJson.do".concat(o),
                method: "get"
            })
        }
        function k(e) {
            var t = e.noteId
                , i = "?noteId=".concat(t);
            return Object(u["a"])({
                url: "/els/html/course/courseStudy.deleteCourseNoteJson.do".concat(i),
                method: "get"
            })
        }
        function E(e) {
            return Object(u["a"])({
                url: "/els/html/collection/collection.collectionCourseJson.do?courseId=".concat(e.courseId),
                method: "get"
            })
        }
        function _(e) {
            return Object(u["a"])({
                url: "/els/html/collection/collection.cancelCollectionJson.do?courseId=".concat(e.courseId),
                method: "get"
            })
        }
        function P(e) {
            return Object(u["a"])({
                url: "/els/html/coursePraise/coursePraise.getCountPraiseAndUserJson.do?coursePraise.courseId=".concat(e.coursePraise.courseId, "&coursePraise.praiseStatus=").concat(e.coursePraise.praiseStatus),
                method: "get"
            })
        }
        function D(e) {
            return Object(u["a"])({
                url: "/els/html/discussAndNote/discussAndNote.checkAllowDeleteDiscuss.do?courseId=".concat(e.courseId),
                method: "get"
            })
        }
        function R(e) {
            return Object(u["a"])({
                url: "/els/html/trainCamp/trainingCamp.courseShow.do?courseId=" + e,
                method: "get"
            })
        }
        function N(e) {
            return Object(u["a"])({
                url: "/els/html/trainCamp/trainingCamp.isPrompt.do",
                method: "post",
                data: e
            })
        }
        function O(e) {
            return Object(u["a"])({
                url: "/els/html/trainCamp/trainingCamp.setUpPrompt.do",
                method: "post",
                data: e
            })
        }
        function B(e) {
            return Object(u["a"])({
                url: "/els/html/trainCamp/trainingCamp.addInterest.do",
                method: "post",
                data: e
            })
        }
        function j(e) {
            return Object(u["a"])({
                url: "/els/html/trainCamp/trainingCamp.reduceInterest.do",
                method: "post",
                data: e
            })
        }
        function F(e) {
            return Object(u["a"])({
                url: "/els/html/trainCamp/trainingCamp.addHits.do",
                method: "post",
                data: e
            })
        }
        var L = i("704d")
            , Q = i("9ff8")
            , U = function () {
                var e = this
                    , t = e.$createElement
                    , i = e._self._c || t;
                return i("div", [e.preventCheatFlag && 2 == e.checkType ? i("div", {
                    staticClass: "pCheat-box",
                    staticStyle: {
                        width: "100%",
                        height: "100%"
                    }
                }, [i("div", {
                    staticClass: "pCheat-wrap"
                }, [i("div", {
                    staticClass: "header-tips"
                }, [e._v("\n               " + e._s(e.$t("v4.js.pc.ocmt.systemHint")) + "\n            ")]), i("div", {
                    staticStyle: {
                        padding: "20px"
                    }
                }, [i("div", {
                    staticClass: "pCheat-title"
                }, [e._v("请完成下方的题目，"), i("span", {
                    staticClass: "pCheat-title-count",
                    staticStyle: {
                        color: "#14ABEF"
                    }
                }, [e._v(e._s(e.timeCount))]), e._v(" 秒内未完成将退出课程学习")]), i("div", {
                    staticClass: "pCheat-img-box"
                }, [i("img", {
                    staticClass: "pCheat-img",
                    staticStyle: {
                        cursor: "pointer"
                    },
                    attrs: {
                        id: "identifyCode",
                        src: e.imgUrl
                    }
                }), i("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: e.imgTime,
                        expression: "imgTime"
                    }],
                    attrs: {
                        id: "imgTime",
                        type: "hidden"
                    },
                    domProps: {
                        value: e.imgTime
                    },
                    on: {
                        input: function (t) {
                            t.target.composing || (e.imgTime = t.target.value)
                        }
                    }
                }), i("a", {
                    staticClass: "pCheat-img-link",
                    attrs: {
                        href: "javascript:;",
                        id: "changeNext"
                    },
                    on: {
                        click: e.changeNext
                    }
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.changeOne")))])]), i("div", {
                    staticClass: "vld-row",
                    staticStyle: {
                        "text-align": "center",
                        "margin-top": "20px"
                    }
                }, [i("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: e.answerVal,
                        expression: "answerVal"
                    }],
                    staticClass: "pCheat-input-text",
                    attrs: {
                        type: "text",
                        id: "answer",
                        placeholder: "",
                        maxlength: "10"
                    },
                    domProps: {
                        value: e.answerVal
                    },
                    on: {
                        blur: e.validate,
                        input: function (t) {
                            t.target.composing || (e.answerVal = t.target.value)
                        }
                    }
                }), i("span", {
                    staticStyle: {
                        color: "#000"
                    },
                    attrs: {
                        id: "tip"
                    }
                }, [e._v(e._s(e.tips))])])]), i("div", {
                    staticClass: "confirmBtn"
                }, [i("div", {
                    staticClass: "btn",
                    on: {
                        click: e.submitAnswer
                    }
                }, [e._v("\n                    " + e._s(e.$t("v4.js.pc.ocmt.confirm")) + "\n                ")])])])]) : e._e(), e.preventCheatFlag && 1 == e.checkType ? i("div", {
                    staticClass: "pCheat-box"
                }, [i("div", {
                    staticClass: "erweima-wrap"
                }, [i("p", [e._v(e._s(e.$t("v4.js.pc.ocmt.systemHint")))]), i("div", {
                    attrs: {
                        id: "erweima-img"
                    }
                }), i("p", {
                    staticStyle: {
                        "text-align": "center"
                    }
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.APPScanIt")))]), i("p", {
                    staticStyle: {
                        "text-align": "center"
                    }
                }, [i("span", [e._v(e._s(e.minute))]), e._v("分"), i("span", [e._v(e._s(e.second))]), e._v("秒内未完成将退出课程学习")])])]) : e._e()])
            }
            , V = []
            , M = (i("c5f6"),
                i("fa7d"))
            , J = i("d044")
            , H = i.n(J)
            , z = i("cc7d")
            , q = i.n(z)
            , G = {
                data: function () {
                    return {
                        preventCheatFlag: !1,
                        timeCount: 60,
                        preventCheatInterval: null,
                        countTimer: null,
                        preventCheatTime: 0,
                        imgUrl: "",
                        answerVal: "",
                        tips: "",
                        playTime: 0,
                        playTimer: null,
                        lastTimer: null,
                        nextPlayTime: 0,
                        qrcode: null,
                        minute: 2,
                        second: 59,
                        faceTimer: null,
                        userId: ""
                    }
                },
                props: {
                    maxTime: {
                        type: Number,
                        default: 0
                    },
                    minTime: {
                        type: Number,
                        default: 0
                    },
                    checkType: {
                        type: Number,
                        default: 2
                    }
                },
                computed: {},
                watch: {},
                methods: {
                    initPreventCheat: function (e) {
                        var t = this;
                        if ("video" == e)
                            t.exitfullscreen(),
                                t.$emit("saveStudyLog", "PREVENT_CHEAT_POPUP"),
                                t.preventCheatFlag = !0,
                                clearInterval(t.countTimer),
                                t.$emit("pauseOrPlay", !1),
                                "1" == t.checkType ? setTimeout((function () {
                                    t.initErWeima()
                                }
                                ), 100) : "2" == t.checkType && (t.preventCheat(),
                                    t.timeCount = 60,
                                    t.countTimer = setInterval((function () {
                                        t.timeCount--,
                                            t.timeCount <= 0 && (t.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"),
                                                t.timeCount = 0,
                                                console.log("退出登录"),
                                                setTimeout((function () {
                                                    top.open("about:blank", "_self").close()
                                                }
                                                ), 1e3),
                                                clearInterval(t.countTimer))
                                    }
                                    ), 1e3));
                        else {
                            clearInterval(this.preventCheatInterval);
                            var i = e ? 60 * e * 1e3 : 60 * t.preventCheatTime * 1e3;
                            console.log("自动验证的时间：" + i),
                                this.preventCheatInterval = setTimeout((function () {
                                    t.exitfullscreen(),
                                        t.$emit("saveStudyLog", "PREVENT_CHEAT_POPUP"),
                                        t.preventCheatFlag = !0,
                                        t.$emit("pauseOrPlay", !1),
                                        "1" == t.checkType ? setTimeout((function () {
                                            t.initErWeima()
                                        }
                                        ), 100) : (t.preventCheat(),
                                            t.timeCount = 60,
                                            clearInterval(t.countTimer),
                                            t.countTimer = setInterval((function () {
                                                t.timeCount--,
                                                    t.timeCount <= 0 && (t.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"),
                                                        t.timeCount = 0,
                                                        console.log("退出登录"),
                                                        setTimeout((function () {
                                                            top.open("about:blank", "_self").close()
                                                        }
                                                        ), 1e3),
                                                        clearInterval(t.countTimer))
                                            }
                                            ), 1e3))
                                }
                                ), i)
                        }
                    },
                    randomWord: function (e, t, i) {
                        var s = ""
                            , n = t
                            , a = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
                        e && (n = Math.round(Math.random() * (i - t)) + t);
                        for (var o = 0; o < n; o++) {
                            var r = Math.round(Math.random() * (a.length - 1));
                            s += a[r]
                        }
                        return s
                    },
                    initErWeima: function () {
                        var e = this
                            , t = this;
                        clearInterval(this.faceTimer),
                            t.minute = 2,
                            t.second = 59,
                            this.faceTimer = setInterval((function () {
                                t.second--,
                                    t.second < 0 && (t.second = 59,
                                        t.minute--,
                                        t.minute < 0 && (t.second = 0,
                                            t.minute = 0,
                                            t.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"),
                                            setTimeout((function () {
                                                top.open("about:blank", "_self").close()
                                            }
                                            ), 1e3),
                                            clearInterval(e.faceTimer)))
                            }
                            ), 1e3),
                            this.qrcode = new H.a(document.getElementById("erweima-img"), {
                                text: "",
                                width: 200,
                                height: 200
                            }),
                            this.webSK()
                    },
                    webSK: function () {
                        var e, t, i = this, s = this.randomWord(!1, 10), n = window.location.origin, a = this.randomWord(!1, 32);
                        e = new q.a(n + "/biz-oim/webSocket/handler?deviceId=" + a);
                        var o = window.$cookies.get("_local");
                        e.onopen = function (t) {
                            var n = '{"code" : 1, "params" : {"qrCode" : "' + s + '", "oldQrCode" : "", "local" : "' + o + '", "type" : "QR_STUDYCOURSE_SIGN", "userId" :"' + i.userId + '" }}';
                            e.send(n)
                        }
                            ,
                            e.onmessage = function (e) {
                                var s = JSON.parse(e.data);
                                1 == s.code ? (t = s.bizResult + "&userId=" + i.userId,
                                    i.qrcode.makeCode(t),
                                    document.getElementById("erweima-img").setAttribute("title", "")) : 2 == s.code || (6 == s.code ? (clearInterval(this.faceTimer),
                                        i.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"),
                                        setTimeout((function () {
                                            top.open("about:blank", "_self").close()
                                        }
                                        ), 1e3)) : 7 == s.code ? (console.log("用户扫码确认"),
                                            clearInterval(i.faceTimer),
                                            i.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_SUCCESS"),
                                            clearInterval(i.countTimer),
                                            clearInterval(i.playTimer),
                                            clearTimeout(i.lastTimer),
                                            clearInterval(i.preventCheatInterval),
                                            i.preventCheatFlag = !1,
                                            i.playTime = 0,
                                            i.answerVal = "",
                                            console.log("上次执行的时间:" + i.preventCheatTime),
                                            i.nextPlayTime = i.maxTime - i.preventCheatTime,
                                            console.log("上次剩余的时间：" + i.nextPlayTime),
                                            i.preventCheatTime = (Math.random() * (i.maxTime - i.minTime) + i.minTime).toFixed(1),
                                            console.log("这次摇到的时间:" + i.preventCheatTime),
                                            i.nextPlayTime = Number(i.nextPlayTime) + Number(i.preventCheatTime),
                                            console.log("下次执行的时间:" + i.nextPlayTime),
                                            document.getElementsByTagName("video")[0] ? i.addVideoClick(i.nextPlayTime) : i.initPreventCheat(i.nextPlayTime)) : 4 == s.code && !0)
                            }
                            ,
                            e.onclose = function (e) { }
                            ,
                            e.onerror = function (e) {
                                alert("WebSocket连接发生错误，请刷新页面！")
                            }
                    },
                    exitfullscreen: function () {
                        try {
                            document.exitFullscreen ? document.exitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen()
                        } catch (e) { }
                    },
                    preventCheat: function () {
                        var e = document.getElementsByTagName("head")[0]
                            , t = document.createElement("script");
                        t.type = "text/javascript",
                            e.appendChild(t),
                            t.onload = t.onreadystatechange = function () {
                                !this.readyState || "loaded" === this.readyState || this.readyState
                            }
                            ;
                        var i = parent.location.origin + "/els"
                            , s = Object(M["getUrl"])("eln_session_id")
                            , n = "".concat(i, "/html/preventCheat/preventCheat.loadIdentifyCode.do?eln_session_id=").concat(s, "&imgTime=")
                            , a = (new Date).getTime();
                        this.imgUrl = n + a,
                            this.imgTime = a
                    },
                    changeNext: function () {
                        var e = parent.location.origin + "/els"
                            , t = Object(M["getUrl"])("eln_session_id")
                            , i = "".concat(e, "/html/preventCheat/preventCheat.loadIdentifyCode.do?eln_session_id=").concat(t, "&imgTime=")
                            , s = (new Date).getTime();
                        this.imgUrl = i + s,
                            this.imgTime = s
                    },
                    validate: function () {
                        var e = new RegExp("^[0-9]*$")
                            , t = new RegExp("^-[1-9][0-9]*$");
                        return "" == this.answerVal ? (this.tips = this.$t("v4.js.pc.ocmt.PleaseEnterTheCorrectAnswer"),
                            !1) : e.test(this.answerVal) || t.test(this.answerVal) ? (this.tips = "",
                                !0) : (this.answerVal = "",
                                    this.tips = this.$t("v4.js.pc.ocmt.numPlease"),
                                    !1)
                    },
                    submitAnswer: function () {
                        this.imgTime,
                            Number(this.answerVal);
                        var e = Object(M["getUrl"])("courseId")
                            , t = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP")
                            , i = new FormData;
                        i.append("imgTime", this.imgTime),
                            i.append("answer", Number(this.answerVal));
                        var s = this;
                        t && (t.open("post", parent.location.origin + "/els/html/preventCheat/preventCheat.checkAnswer.do?courseId=" + e),
                            t.onreadystatechange = function () {
                                if (4 == t.readyState && 200 == t.status) {
                                    var e = JSON.stringify(t.responseText);
                                    e.includes("true") ? (s.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_SUCCESS"),
                                        clearInterval(s.countTimer),
                                        clearInterval(s.playTimer),
                                        clearTimeout(s.lastTimer),
                                        clearInterval(s.preventCheatInterval),
                                        s.preventCheatFlag = !1,
                                        s.playTime = 0,
                                        s.answerVal = "",
                                        console.log("上次执行的时间:" + s.preventCheatTime),
                                        s.nextPlayTime = s.maxTime - s.preventCheatTime,
                                        console.log("上次剩余的时间：" + s.nextPlayTime),
                                        s.preventCheatTime = (Math.random() * (s.maxTime - s.minTime) + s.minTime).toFixed(1),
                                        console.log("这次摇到的时间:" + s.preventCheatTime),
                                        s.nextPlayTime = Number(s.nextPlayTime) + Number(s.preventCheatTime),
                                        console.log("下次执行的时间:" + s.nextPlayTime),
                                        document.getElementsByTagName("video")[0] ? s.addVideoClick(s.nextPlayTime) : s.initPreventCheat(s.nextPlayTime)) : (e.includes("Error"),
                                            s.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_FAIL"),
                                            s.tips = s.$t("v4.js.pc.ocmt.PleaseEnterTheCorrectAnswer"))
                                }
                            }
                        ),
                            t.send(i)
                    },
                    resetPlayTime: function (e, t) {
                        clearTimeout(this.preventCheatInterval),
                            clearInterval(this.countTimer),
                            clearInterval(this.playTimer),
                            clearTimeout(this.lastTimer),
                            clearInterval(this.faceTimer),
                            this.playTime = 0,
                            this.preventCheatTime = (Math.random() * (this.maxTime - this.minTime) + this.minTime).toFixed(1)
                    },
                    addVideoClick: function (e) {
                        var t = this;
                        document.getElementsByTagName("video")[0].onplay = function () {
                            clearTimeout(t.lastTimer),
                                clearInterval(t.playTimer);
                            var i = e ? 1e3 * (60 * e - t.playTime) : 1e3 * (60 * t.preventCheatTime - t.playTime);
                            console.log("剩余触发时间:" + i),
                                t.playTimer = setInterval((function () {
                                    t.playTime++
                                }
                                ), 1e3),
                                t.lastTimer = setTimeout((function () {
                                    t.preventCheatFlag = !0,
                                        t.initPreventCheat("video")
                                }
                                ), i)
                        }
                            ,
                            document.getElementsByTagName("video")[0].onpause = function () {
                                clearInterval(t.playTimer),
                                    clearTimeout(t.lastTimer)
                            }
                            ,
                            document.getElementsByTagName("video")[0].pause(),
                            document.getElementsByTagName("video")[0].play(),
                            t.$store.state.home.jumpFlag && document.getElementsByTagName("video")[0].pause()
                    },
                    addPlayEvent: function () {
                        this.preventCheatTime = (Math.random() * (this.maxTime - this.minTime) + this.minTime).toFixed(1),
                            this.playTime = 0,
                            document.getElementsByTagName("video")[0] ? this.addVideoClick() : this.initPreventCheat()
                    }
                },
                mounted: function () {
                    var e = this;
                    c["c"].getUserInfo().then((function (t) {
                        e.userId = t.bizResult.userId
                    }
                    )),
                        this.addPlayEvent()
                },
                beforeDestroy: function () {
                    clearTimeout(this.lastTimer),
                        clearInterval(this.playTimer),
                        clearInterval(this.countTimer),
                        clearInterval(this.preventCheatInterval),
                        clearInterval(this.faceTimer)
                }
            }
            , K = G
            , W = (i("4812"),
                i("2877"))
            , Z = Object(W["a"])(K, U, V, !1, null, "43fe5bcf", null)
            , Y = Z.exports
            , X = function () {
                var e = this
                    , t = e.$createElement
                    , i = e._self._c || t;
                return e.hangUpFlag ? i("div", {
                    staticClass: "hangUp-box",
                    staticStyle: {
                        width: "100%",
                        height: "100%"
                    }
                }, [e.loginFlag ? i("div", {
                    staticClass: "loginOut-wrap"
                }, [i("div", {
                    staticClass: "header-tips"
                }, [e._v("\n            " + e._s(e.$t("v4.js.pc.ocmt.systemHint")) + "\n        ")]), i("div", {
                    staticClass: "tips-content",
                    staticStyle: {
                        padding: "20px",
                        "font-size": "18px"
                    }
                }, [e._v("\n            " + e._s(e.$t("v4.js.pc.ocmt.loginOutSystem")) + "\n            \n        ")]), i("div", {
                    staticClass: "confirmBtn"
                }, [i("div", {
                    staticClass: "btn",
                    on: {
                        click: e.loginOutConfirm
                    }
                }, [e._v("\n                " + e._s(e.$t("v4.js.pc.ocmt.confirm")) + "\n            ")])])]) : i("div", {
                    staticClass: "hangUp-wrap"
                }, [i("div", {
                    staticClass: "header-tips"
                }, [e._v("\n            " + e._s(e.$t("v4.js.pc.ocmt.systemHint")) + "\n        ")]), i("div", {
                    staticClass: "tips-content",
                    staticStyle: {
                        padding: "20px",
                        "font-size": "18px"
                    }
                }, [e._v("\n            长时间未操作页面,"), i("span", {
                    staticStyle: {
                        color: "#eb5352"
                    }
                }, [e._v(e._s(e.timeCount))]), e._v("秒后退出登录\n        ")]), i("div", {
                    staticClass: "confirmBtn"
                }, [i("div", {
                    staticClass: "btn",
                    on: {
                        click: e.confirm
                    }
                }, [e._v("\n                " + e._s(e.$t("v4.js.pc.ocmt.confirm")) + "\n            ")])])])]) : e._e()
            }
            , $ = []
            , ee = {
                data: function () {
                    return {
                        hangUpFlag: !1,
                        operateTime: 0,
                        timeCount: 60,
                        timer: null,
                        timeInterval: 3e4,
                        xys: {
                            x0: 0,
                            y0: 0
                        },
                        xy: {
                            x0: 0,
                            y0: 0
                        },
                        loginFlag: !1,
                        timerNoOperate: null
                    }
                },
                props: {
                    preventHangTime: {
                        type: Number,
                        default: 0
                    }
                },
                computed: {},
                watch: {},
                methods: {
                    initHangUp: function () {
                        var e = this;
                        document.body.onmousemove = function (t) {
                            e.xys = {
                                x0: t.clientX,
                                y0: t.clientY
                            }
                        }
                            ,
                            this.startTimer()
                    },
                    startTimer: function () {
                        var e = this;
                        clearInterval(this.timerNoOperate),
                            clearInterval(this.timer),
                            this.timerNoOperate = setInterval((function () {
                                e.checkMouseMove(e.xys)
                            }
                            ), e.timeInterval)
                    },
                    exitfullscreen: function () {
                        try {
                            document.exitFullscreen ? document.exitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen()
                        } catch (e) { }
                    },
                    checkMouseMove: function (e) {
                        var t = this;
                        this.xy.x0 == e.x0 && this.xy.y0 == e.y0 ? (this.operateTime += this.timeInterval,
                            this.operateTime / 1e3 / 60 >= this.preventHangTime && (t.timeCount = 60,
                                this.$emit("pauseOrPlay", !1),
                                this.$emit("saveStudyLog", "PREVENT_HANG_POPUP"),
                                this.exitfullscreen(),
                                this.hangUpFlag = !0,
                                clearInterval(this.timerNoOperate),
                                this.timer = setInterval((function () {
                                    if (t.timeCount--,
                                        t.timeCount < 0) {
                                        var e = 0;
                                        document.body.onmousemove = function () {
                                            0 == e && (console.log("PREVENT_HANG_LOGOUT"),
                                                t.$emit("saveStudyLog", "PREVENT_HANG_LOGOUT"),
                                                t.hangUpFlag = !0,
                                                t.loginFlag = !0,
                                                console.log("loginOut!!"),
                                                c["a"].APILoginOut()),
                                                e++
                                        }
                                            ,
                                            t.hangUpFlag = !1,
                                            clearInterval(t.timer),
                                            console.log("退出登录")
                                    }
                                }
                                ), 1e3))) : (this.operateTime = 0,
                                    this.xy.x0 = e.x0,
                                    this.xy.y0 = e.y0)
                    },
                    confirm: function () {
                        this.timeCount = 0,
                            clearInterval(this.timer),
                            this.operateTime = 0,
                            this.xys = {
                                x0: 0,
                                y0: 0
                            },
                            this.xy = {
                                x0: 0,
                                y0: 0
                            },
                            this.$emit("pauseOrPlay", !0),
                            this.hangUpFlag = !1,
                            this.startTimer(),
                            this.$emit("saveStudyLog", "PREVENT_HANG_OPERATE")
                    },
                    loginOutConfirm: function () {
                        top.open("/login/login.logout.do", "_self")
                    }
                },
                mounted: function () {
                    clearInterval(this.timer),
                        this.initHangUp()
                },
                beforeDestroy: function () {
                    clearInterval(this.timerNoOperate),
                        clearInterval(this.timer)
                }
            }
            , te = ee
            , ie = (i("d26f"),
                Object(W["a"])(te, X, $, !1, null, "91b5bc54", null))
            , se = ie.exports
            , ne = i("6846")
            , ae = i.n(ne)
            , oe = i("49fb")
            , re = i.n(oe)
            , ce = i("9a48")
            , le = i.n(ce)
            , ue = i("2d5a")
            , de = i.n(ue)
            , he = i("8170")
            , me = i.n(he)
            , pe = i("aef4")
            , ve = i.n(pe)
            , fe = i("da9d")
            , ge = i.n(fe)
            , Ae = function () {
                var e = this
                    , t = e.$createElement
                    , i = e._self._c || t;
                return i("div", {
                    staticClass: "course-test__wrap"
                }, [i("Exam", {
                    attrs: {
                        visible: e.visible,
                        tipCount: e.tipCount,
                        list: e.list,
                        view: e.view,
                        analysis: e.originData.answerAnalysis,
                        time: e.time,
                        disabled: e.isSubmit || e.isPreview,
                        answer: e.answer
                    },
                    on: {
                        cancel: e.onCancel
                    }
                }, [i("template", {
                    slot: "footer"
                }, [e.view || e.isPreview ? i("a-button", {
                    staticClass: "submit",
                    attrs: {
                        type: "primary"
                    },
                    on: {
                        click: e.onContinue
                    }
                }, [e._v("\n        知道了\n      ")]) : i("a-button", {
                    staticClass: "submit",
                    attrs: {
                        type: "primary",
                        loading: e.isSubmit
                    },
                    on: {
                        click: e.onSubmit
                    }
                }, [e._v("\n        提交\n      ")])], 1)], 2), i("Result", e._b({
                    on: {
                        cancel: e.onCancelResult
                    }
                }, "Result", e.resultModal, !1))], 1)
            }
            , ye = []
            , Ce = function () {
                var e = this
                    , t = e.$createElement
                    , i = e._self._c || t;
                return i("a-modal", e._g(e._b({
                    attrs: {
                        width: "960px",
                        destroyOnClose: "",
                        dialogClass: "custome-course__modal"
                    },
                    scopedSlots: e._u([{
                        key: "title",
                        fn: function () {
                            return [i("span", {
                                staticClass: "title"
                            }, [e._v("\n      随堂测试\n      "), e.view ? i("span", {
                                staticClass: "pass"
                            }, [e._v("已通过")]) : e._e(), e.time ? i("span", {
                                class: ["time", e.time < "00:00:11" && "time__red"]
                            }, [e._v(e._s(e.time))]) : e._e()])]
                        },
                        proxy: !0
                    }, {
                        key: "footer",
                        fn: function () {
                            return [e._t("footer")]
                        },
                        proxy: !0
                    }], null, !0)
                }, "a-modal", e.$attrs, !1, !0), e.$listeners), [i("div", {
                    staticClass: "content"
                }, [e._l(e.list, (function (t, s) {
                    return i("div", {
                        key: t.title + "--" + s,
                        class: ["subject-item", t.required && "subject-item__require", e.view && "subject-item__view"]
                    }, [i("h6", {
                        staticClass: "subject-item__title"
                    }, [i("span", {
                        staticClass: "subject-item__required"
                    }, [e._v("*")]), i("span", {
                        staticClass: "subject-item__index"
                    }, [e._v(e._s(s + 1 < 10 ? "0" + (s + 1) : s + 1))]), e._v("\n        " + e._s(t.title) + "\n        "), "checkbox" === t.type ? i("span", {
                        staticClass: "tag"
                    }, [e._v("\n          多选\n        ")]) : e._e()]), "checkbox" === t.type ? i("div", {
                        staticClass: "checkbox__item"
                    }, [e.view ? i("a-checkbox-group", {
                        attrs: {
                            disabled: e.view,
                            value: e.answer[t.id]
                        }
                    }, e._l(t.options, (function (t) {
                        return i("div", {
                            key: t.value,
                            staticClass: "checkbox__item__option"
                        }, [i("a-checkbox", {
                            attrs: {
                                value: t.value
                            }
                        }, [e._v("\n              " + e._s(t.label) + "\n            ")])], 1)
                    }
                    )), 0) : i("a-checkbox-group", {
                        attrs: {
                            disabled: e.disabled
                        },
                        on: {
                            change: t.onChange
                        }
                    }, e._l(t.options, (function (s) {
                        return i("div", {
                            key: s.value,
                            staticClass: "checkbox__item__option",
                            on: {
                                click: t.onChange
                            }
                        }, [i("a-checkbox", {
                            attrs: {
                                value: s.value
                            }
                        }, [e._v("\n              " + e._s(s.label) + "\n            ")])], 1)
                    }
                    )), 0)], 1) : e._e(), "radio" === t.type ? i("div", {
                        staticClass: "radio__item"
                    }, [e.view ? i("a-radio-group", {
                        attrs: {
                            disabled: e.view,
                            value: e.view ? e.answer[t.id][0] : e.answer[t.id]
                        }
                    }, e._l(t.options, (function (t) {
                        return i("div", {
                            key: t.value,
                            staticClass: "radio__item__option"
                        }, [i("a-radio", {
                            attrs: {
                                value: t.value
                            }
                        }, [e._v("\n              " + e._s(t.label) + "\n            ")])], 1)
                    }
                    )), 0) : i("a-radio-group", {
                        attrs: {
                            disabled: e.disabled
                        },
                        on: {
                            change: t.onChange
                        }
                    }, e._l(t.options, (function (s) {
                        return i("div", {
                            key: s.value,
                            staticClass: "radio__item__option",
                            on: {
                                click: t.onChange
                            }
                        }, [i("a-radio", {
                            attrs: {
                                value: s.value
                            }
                        }, [e._v("\n              " + e._s(s.label) + "\n            ")])], 1)
                    }
                    )), 0)], 1) : e._e(), e.view ? i("div", {
                        staticClass: "subject-item__result"
                    }, [e.analysis ? i("div", {
                        staticClass: "result-item"
                    }, [i("span", {
                        staticClass: "result-item__tag"
                    }, [e._v("\n            标准答案\n          ")]), i("span", {
                        staticClass: "result-item__reason"
                    }, [e._v("\n            " + e._s(t.rightContent) + "\n          ")])]) : e._e(), e.analysis ? i("div", {
                        staticClass: "result-item"
                    }, [i("span", {
                        staticClass: "result-item__tag"
                    }, [e._v("\n            试题解析\n          ")]), i("span", {
                        staticClass: "result-item__reason"
                    }, [e._v("\n            " + e._s(t.questionAnalysis) + "\n          ")])]) : e._e(), i("span", {
                        class: ["result-item__icon", "result-item__icon__" + (t.isRight ? "success" : "error")]
                    })]) : e._e()])
                }
                )), e.tipCount ? i("div", {
                    staticClass: "tip"
                }, [i("p", {
                    staticClass: "tip__title"
                }, [e._v("\n        提示\n      ")]), i("p", {
                    staticClass: "tip__text"
                }, [e._v("\n        1.倒计时结束后将自动收卷，以卷面答题情况判定分数；\n        "), i("br"), e._v("\n        " + e._s(2 === e.tipCount ? "2.该随堂测试已开启强制测试，及格后方可观看后续课程内容；" : "") + "\n      ")])]) : e._e()], 2), e._t("default")], 2)
            }
            , Ie = []
            , Te = {
                list: Array,
                time: String,
                tipCount: Number,
                view: Boolean,
                analysis: Boolean,
                answer: Object,
                disabled: Boolean
            }
            , Se = {
                props: Te,
                methods: {
                    getSlot: function (e) {
                        console.log(e)
                    }
                }
            }
            , we = Se
            , be = (i("f99f"),
                Object(W["a"])(we, Ce, Ie, !1, null, null, null))
            , xe = be.exports
            , ke = i("f64c")
            , Ee = {
                ERROR: {
                    img: i("2e5a"),
                    result: "很遗憾，未通过！",
                    tip: "测试结果与你本节课程的完成度相关哦",
                    visible: !0,
                    footer: !1,
                    status: "ERROR"
                },
                SUCCESS: {
                    img: i("5add"),
                    result: "恭喜您，已通过！",
                    tip: "请继续后面的学习吧！",
                    visible: !0,
                    footer: !1,
                    status: "SUCCESS"
                },
                TIP: {
                    img: "",
                    tip: "当前测试为强制测试，通过测试后才能继续学习",
                    visible: !0,
                    footer: !1,
                    status: "TIP"
                }
            }
            , _e = {
                TRUE_FALSE: "radio",
                MULTIPLE: "checkbox",
                SINGLE: "radio"
            }
            , Pe = function () {
                var e = this
                    , t = e.$createElement
                    , i = e._self._c || t;
                return i("a-modal", e._g(e._b({
                    attrs: {
                        visible: e.visible,
                        width: "660px",
                        dialogClass: "custome-course-reault__modal"
                    }
                }, "a-modal", e.$attrs, !1), e.$listeners), [e.img ? i("img", {
                    attrs: {
                        src: e.img,
                        alt: ""
                    }
                }) : e._e(), i("div", {
                    staticClass: "result"
                }, [e._v("\n    " + e._s(e.result) + "\n  ")]), i("div", {
                    staticClass: "tip"
                }, [e._v("\n    " + e._s(e.tip) + "\n  ")]), i("div", {
                    staticClass: "buttons"
                }, e._l(e.buttons, (function (t) {
                    return i("a-button", e._b({
                        key: t.text,
                        on: {
                            click: t.click
                        }
                    }, "a-button", t, !1), [e._v("\n      " + e._s(t.text) + "\n    ")])
                }
                )), 1)])
            }
            , De = []
            , Re = {
                img: File | String,
                result: String,
                tip: String,
                buttons: Array,
                visible: Boolean
            }
            , Ne = {
                props: Re,
                data: function () {
                    return {}
                }
            }
            , Oe = Ne
            , Be = (i("3f0f"),
                Object(W["a"])(Oe, Pe, De, !1, null, null, null))
            , je = Be.exports
            , Fe = i("5c44")
            , Le = i("7e0a")
            , Qe = i("c1df")
            , Ue = i.n(Qe)
            , Ve = i("2ef0")
            , Me = i.n(Ve);
        function Je(e, t) {
            var i = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var s = Object.getOwnPropertySymbols(e);
                t && (s = s.filter((function (t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }
                ))),
                    i.push.apply(i, s)
            }
            return i
        }
        function He(e) {
            for (var t = 1; t < arguments.length; t++) {
                var i = null != arguments[t] ? arguments[t] : {};
                t % 2 ? Je(Object(i), !0).forEach((function (t) {
                    Object(o["a"])(e, t, i[t])
                }
                )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : Je(Object(i)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                }
                ))
            }
            return e
        }
        var ze = {
            data: function () {
                return {
                    resultModal: {},
                    view: !1,
                    isPreview: !1,
                    time: "",
                    visible: !1,
                    isSubmit: !1,
                    originData: {},
                    timer: null,
                    options: {},
                    answer: {},
                    isVideo: !1
                }
            },
            components: {
                Exam: xe,
                Result: je
            },
            props: {
                allInFixTest: {
                    type: Array,
                    default: function () {
                        return []
                    }
                }
            },
            computed: {
                list: function () {
                    var e, t = this, i = this.originData, s = this.options, n = this.view;
                    return null === i || void 0 === i || null === (e = i.questionList) || void 0 === e ? void 0 : e.map((function (e) {
                        var i = e.itemType
                            , a = e.content
                            , o = e.questionId
                            , r = s[o] || {}
                            , c = r.options
                            , l = r.rightContent
                            , u = r.questionAnalysis
                            , d = r.isRight
                            , h = n ? {
                                rightContent: l,
                                questionAnalysis: u,
                                isRight: d
                            } : {};
                        return He({
                            type: _e[i],
                            require: !0,
                            title: a,
                            onChange: t.onChange.bind(t, o),
                            options: c,
                            id: o
                        }, h)
                    }
                    ))
                },
                tipCount: function () {
                    var e;
                    return this.view || this.isPreview ? 0 : (null === (e = this.originData) || void 0 === e ? void 0 : e.mandatoryTest) ? 2 : 1
                }
            },
            methods: {
                show: function (e) {
                    var t = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function i() {
                        var s, n, a, o, r, c;
                        return regeneratorRuntime.wrap((function (i) {
                            while (1)
                                switch (i.prev = i.next) {
                                    case 0:
                                        if (s = e.infixTest,
                                            n = e.isTag,
                                            a = e.time,
                                            o = e.isVideo,
                                            r = e.isPreview,
                                            i.prev = 1,
                                            c = null === s || void 0 === s ? void 0 : s.data,
                                            t.visible = !1,
                                            t.isSubmit = !1,
                                            t.isVideo = o,
                                            t.answer = {},
                                            t.options = {},
                                            t.resultModal = {},
                                            t.originData = {},
                                            t.closeCalcTime(),
                                            !("NO_JOIN" === (null === c || void 0 === c ? void 0 : c.userState) && n && a < (null === s || void 0 === s ? void 0 : s.offset)) || r) {
                                            i.next = 13;
                                            break
                                        }
                                        return i.abrupt("return", ke["a"].info("未达到弹出时间，无法提前作答"));
                                    case 13:
                                        if (!r) {
                                            i.next = 21;
                                            break
                                        }
                                        return t.isPreview = !0,
                                            t.isSubmit = !1,
                                            t.visible = !0,
                                            i.next = 19,
                                            t.getCourseList(c);
                                    case 19:
                                        i.next = 23;
                                        break;
                                    case 21:
                                        return i.next = 23,
                                            t.onStart(c);
                                    case 23:
                                        t.originData = Object.assign({}, c),
                                            i.next = 31;
                                        break;
                                    case 26:
                                        i.prev = 26,
                                            i.t0 = i["catch"](1),
                                            t.visible = !1,
                                            t.view = !1,
                                            ke["a"].error("获取随堂测试数据失败，请重试！");
                                    case 31:
                                    case "end":
                                        return i.stop()
                                }
                        }
                        ), i, null, [[1, 26]])
                    }
                    )))()
                },
                onCancel: function () {
                    var e = this.view
                        , t = this.isPreview;
                    e || t || (this.closeCalcTime(),
                        this.onPlayControl("PAUSE")),
                        (e || t) && this.onContinue()
                },
                onSubmit: function (e) {
                    var t = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function i() {
                        var s, n, a, o, r, c, l, u, d, h;
                        return regeneratorRuntime.wrap((function (i) {
                            while (1)
                                switch (i.prev = i.next) {
                                    case 0:
                                        if (t.isSubmit = !0,
                                            s = t.list,
                                            n = t.answer,
                                            i.prev = 2,
                                            !t.timer || !e) {
                                            i.next = 9;
                                            break
                                        }
                                        for (o = [],
                                            r = 0; r < s.length; r++)
                                            c = s[r],
                                                n[c.id] || o.push(r + 1);
                                        if (!o.length) {
                                            i.next = 9;
                                            break
                                        }
                                        return t.isSubmit = !1,
                                            i.abrupt("return", ke["a"].info("第".concat(o[0], "题未作答")));
                                    case 9:
                                        return t.isSubmit = !1,
                                            l = t.originData.infixSettingId,
                                            u = [],
                                            null === (a = t.list) || void 0 === a || a.map((function (e) {
                                                Array.isArray(t.answer[e.id]) ? t.answer[e.id].forEach((function (t) {
                                                    u.push({
                                                        questionId: e.id,
                                                        answerId: t
                                                    })
                                                }
                                                )) : u.push({
                                                    questionId: e.id,
                                                    answerId: t.answer[e.id] || null
                                                })
                                            }
                                            )),
                                            d = {
                                                settingId: l,
                                                questionAndAnswerList: u,
                                                sourceCorpCode: t.originData.corpCode
                                            },
                                            i.next = 16,
                                            Object(Le["m"])(d);
                                    case 16:
                                        h = i.sent,
                                            t.closeCalcTime(),
                                            t.showResult(null === h || void 0 === h ? void 0 : h.data),
                                            t.syncInFixTestData(null === h || void 0 === h ? void 0 : h.data),
                                            ke["a"].success("提交成功！"),
                                            i.next = 29;
                                        break;
                                    case 23:
                                        i.prev = 23,
                                            i.t0 = i["catch"](2),
                                            console.log(i.t0),
                                            t.closeCalcTime(),
                                            ke["a"].error("提交失败，请重试！"),
                                            t.isSubmit = !1;
                                    case 29:
                                    case "end":
                                        return i.stop()
                                }
                        }
                        ), i, null, [[2, 23]])
                    }
                    )))()
                },
                onChange: function (e, t) {
                    this.isPreview ? ke["a"].info("预览中无法答题") : t.target ? this.answer[e] = t.target.value : this.answer[e] = t
                },
                showResult: function (e) {
                    var t = this.originData.mandatoryTest;
                    this.view = !1,
                        e ? this.generalSuccess() : t ? this.generalError({
                            buttons: [{
                                text: "重新学习",
                                type: "primary",
                                ghost: !0,
                                click: this.onReStart
                            }]
                        }) : this.generalError()
                },
                onReStart: function () {
                    var e = this.allInFixTest.length
                        , t = this.originData.popupTime;
                    if (console.log(this.allInFixTest, this.originData),
                        e <= 1)
                        this.onPlayControl("RE_START");
                    else {
                        var i = this.allInFixTest.findIndex((function (e) {
                            return e.popupTime === t
                        }
                        ));
                        i <= 0 ? this.onPlayControl("RE_START") : this.onPlayControl("SEEK", this.allInFixTest[i - 1].popupTime + 1)
                    }
                },
                onPlayControl: function (e, t) {
                    var i = this;
                    this.$nextTick((function () {
                        i.visible = !1,
                            i.view = !1,
                            i.hiddenResultModal()
                    }
                    )),
                        this.isVideo && ("RE_START" === e && Fe["a"].replay(),
                            "CONTINUE" === e && Fe["a"].player.play(),
                            "SEEK" === e && Fe["a"].player.seek(t))
                },
                hiddenResultModal: function () {
                    var e = this;
                    this.resultModal.visible = !1,
                        setTimeout((function () {
                            e.resultModal = Object.assign({}, {
                                visible: !1
                            })
                        }
                        ), 300)
                },
                onViewResult: function () {
                    var e = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function t() {
                        var i, s, n;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1)
                                switch (t.prev = t.next) {
                                    case 0:
                                        return e.hiddenResultModal(),
                                            t.next = 3,
                                            Object(Le["g"])({
                                                settingId: null === (i = e.originData) || void 0 === i ? void 0 : i.infixSettingId,
                                                sourceCorpCode: e.originData.corpCode
                                            });
                                    case 3:
                                        n = t.sent,
                                            null === n || void 0 === n || null === (s = n.data) || void 0 === s || s.forEach((function (t) {
                                                var i;
                                                e.options[t.questionId]["isRight"] = null === t || void 0 === t ? void 0 : t.userRight;
                                                var s = [];
                                                null === t || void 0 === t || null === (i = t.questionItems) || void 0 === i || i.forEach((function (e) {
                                                    e.userItem && s.push(e.itemId)
                                                }
                                                )),
                                                    e.answer[t.questionId] = s
                                            }
                                            )),
                                            e.view = !0,
                                            e.visible = !0;
                                    case 7:
                                    case "end":
                                        return t.stop()
                                }
                        }
                        ), t)
                    }
                    )))()
                },
                onContinue: function () {
                    this.onPlayControl("CONTINUE")
                },
                onCancelResult: function () {
                    this.visible = !1,
                        this.view = !1,
                        this.hiddenResultModal()
                },
                onSkip: function () {
                    this.onPlayControl("CONTINUE")
                },
                onStart: function (e) {
                    var t = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function i() {
                        return regeneratorRuntime.wrap((function (i) {
                            while (1)
                                switch (i.prev = i.next) {
                                    case 0:
                                        return t.answer = {},
                                            t.options = {},
                                            i.prev = 2,
                                            t.hiddenResultModal(),
                                            i.next = 6,
                                            t.getCourseList(e);
                                    case 6:
                                        t.visible = !0,
                                            t.view = !1,
                                            t.startCalcTime(null === e || void 0 === e ? void 0 : e.testDuration),
                                            i.next = 14;
                                        break;
                                    case 11:
                                        throw i.prev = 11,
                                        i.t0 = i["catch"](2),
                                        new Error(i.t0);
                                    case 14:
                                    case "end":
                                        return i.stop()
                                }
                        }
                        ), i, null, [[2, 11]])
                    }
                    )))()
                },
                getCourseList: function (e) {
                    var t = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function i() {
                        var s, n, a, o, r, c, l;
                        return regeneratorRuntime.wrap((function (i) {
                            while (1)
                                switch (i.prev = i.next) {
                                    case 0:
                                        return i.prev = 0,
                                            e = e || t.originData,
                                            r = null === (s = e) || void 0 === s || null === (n = s.questionList) || void 0 === n ? void 0 : n.map((function (e) {
                                                return e.questionId
                                            }
                                            )),
                                            i.next = 5,
                                            Object(Le["h"])({
                                                questionIds: r,
                                                infixSettingId: null === (a = e) || void 0 === a ? void 0 : a.infixSettingId,
                                                sourceCorpCode: null === (o = e) || void 0 === o ? void 0 : o.corpCode
                                            });
                                    case 5:
                                        c = i.sent,
                                            l = {},
                                            null === c || void 0 === c || c.data.forEach((function (e) {
                                                var t, i, s = e.questionId, n = e.questionAnalysis, a = e.questionItems;
                                                l[s] = {
                                                    options: [],
                                                    questionAnalysis: n,
                                                    rightContent: []
                                                },
                                                    l[s].options = a.map((function (e) {
                                                        var t = e.rightAnswer
                                                            , i = e.content
                                                            , n = e.itemId;
                                                        return t && l[s].rightContent.push(i),
                                                        {
                                                            value: n,
                                                            label: i,
                                                            isRight: t
                                                        }
                                                    }
                                                    )),
                                                    l[s].rightContent = null === (t = l[s]) || void 0 === t || null === (i = t.rightContent) || void 0 === i ? void 0 : i.join(",")
                                            }
                                            )),
                                            t.options = l,
                                            i.next = 14;
                                        break;
                                    case 11:
                                        throw i.prev = 11,
                                        i.t0 = i["catch"](0),
                                        Error(i.t0);
                                    case 14:
                                    case "end":
                                        return i.stop()
                                }
                        }
                        ), i, null, [[0, 11]])
                    }
                    )))()
                },
                closeCalcTime: function () {
                    this.timer && (clearInterval(this.timer),
                        this.time = "",
                        this.timer = null)
                },
                startCalcTime: function (e) {
                    var t = this;
                    e && (this.time = this.secondsToStr(60 * e),
                        this.timer && this.closeCalcTime(),
                        this.timer = setInterval((function () {
                            var i = t.time ? Ue.a.duration(t.time).as("seconds") : 60 * e;
                            i -= 1,
                                i < 0 ? t.onSubmit(!1) : t.time = t.secondsToStr(i)
                        }
                        ), 1e3))
                },
                secondsToStr: function (e) {
                    var t = Ue.a.duration(e, "seconds");
                    return Ue()({
                        h: t.hours(),
                        m: t.minutes(),
                        s: t.seconds()
                    }).format("HH:mm:ss")
                },
                syncInFixTestData: function (e) {
                    var t = {
                        true: "PASS",
                        false: "NO_PASS"
                    }
                        , i = Me.a.cloneDeep(He(He({}, this.originData), {}, {
                            userState: t[e]
                        }));
                    this.$emit("updateInFixTest", i)
                },
                generalSuccess: function () {
                    this.visible = !1,
                        this.resultModal = Object.assign({}, He(He({}, Ee.SUCCESS), {}, {
                            buttons: [{
                                text: "查看试卷",
                                type: "primary",
                                ghost: !0,
                                click: this.onViewResult
                            }, {
                                text: "继续学习",
                                type: "primary",
                                click: this.onContinue
                            }]
                        }))
                },
                generalError: function (e) {
                    var t;
                    this.visible = !1,
                        this.resultModal = Object.assign({}, He(He({}, Ee.ERROR), {}, {
                            buttons: [(null === e || void 0 === e || null === (t = e.buttons) || void 0 === t ? void 0 : t[0]) || {
                                text: "暂时跳过",
                                type: "primary",
                                ghost: !0,
                                click: this.onSkip
                            }, {
                                text: "重新答题",
                                type: "primary",
                                click: this.onStart.bind(this, this.originData)
                            }]
                        }))
                },
                generalTip: function () {
                    this.visible = !1,
                        this.resultModal = Object.assign({}, He(He({}, Ee.TIP), {}, {
                            buttons: [{
                                text: "知道了",
                                type: "primary",
                                click: this.onStart.bind(this, this.originData)
                            }]
                        }))
                }
            }
        }
            , qe = ze
            , Ge = Object(W["a"])(qe, Ae, ye, !1, null, null, null)
            , Ke = Ge.exports
            , We = i("c0e9")
            , Ze = i.n(We)
            , Ye = i("52db")
            , Xe = i.n(Ye)
            , $e = i("d225")
            , et = i("b0b4")
            , tt = function () {
                function e() {
                    Object($e["a"])(this, e),
                        Object(o["a"])(this, "wrapDom", null),
                        Object(o["a"])(this, "iframeDom", null),
                        Object(o["a"])(this, "waterMarkDom", null),
                        Object(o["a"])(this, "toggleFullDom", null),
                        Object(o["a"])(this, "base64Url", ""),
                        Object(o["a"])(this, "urlType", ""),
                        Object(o["a"])(this, "url", ""),
                        Object(o["a"])(this, "setting", {}),
                        Object(o["a"])(this, "isViewFull", !1),
                        Object(o["a"])(this, "isSystemFull", !1),
                        Object(o["a"])(this, "isFull", !1),
                        Object(o["a"])(this, "deviceType", "")
                }
                return Object(et["a"])(e, [{
                    key: "init",
                    value: function (e) {
                        this.options = e,
                            this.destory(),
                            this.addStyle(),
                            this.initDom(),
                            this.initUrl(),
                            this.deviceType = this.getDeviceType(),
                            this.addEvent(),
                            this.initWaterMark()
                    }
                }, {
                    key: "addStyle",
                    value: function () {
                        var e = this.options.style;
                        e || (e = "\n            .custom-view-full{\n                position: fixed !important;\n                width: 100vw !important;\n                height: 100vh !important;\n                z-index: 99 !important;\n                left: 0 !important;\n                top: 0 !important;\n            }\n            .custom-view-full__mobile{\n                position: fixed !important;\n                width: 100vh !important;\n                height: 100vw !important;\n                z-index: 99 !important;\n                top: 0 !important;\n                left: 100% !important;\n                transform-origin: 0 0;\n                transform: rotateZ(90deg);\n                overflow: hidden;\n            }\n            .custom-view-full__water{\n                position: fixed !important;\n                width: 100vw !important;\n                height: 100vh !important;\n                z-index: 100 !important;\n                left: 0 !important;\n                top: 0 !important;\n            }\n            .custom-view-full__water__mobile{\n              position: fixed !important;\n              width: 100vh !important;\n              height: 100vw !important;\n              z-index: 100 !important;\n              left: 0 !important;\n              top: 0 !important;\n            }\n        ");
                        var t = document.getElementById("styles_js");
                        t || (t = document.createElement("style"),
                            t.type = "text/css",
                            t.id = "styles_js",
                            document.getElementsByTagName("head")[0].appendChild(t)),
                            t.appendChild(document.createTextNode(e))
                    }
                }, {
                    key: "destory",
                    value: function () {
                        this.destoryEvent(),
                            this.wrapDom = null,
                            this.iframeDom = null,
                            this.waterMarkDom = null,
                            this.toggleFullDom = null,
                            this.base64Url = "",
                            this.urlType = "",
                            this.url = "",
                            this.setting = {},
                            this.isViewFull = !1,
                            this.isSystemFull = !1,
                            this.isFull = !1,
                            this.deviceType = ""
                    }
                }, {
                    key: "destoryEvent",
                    value: function () {
                        document.removeEventListener("keydown", this.escExit.bind(this))
                    }
                }, {
                    key: "initDom",
                    value: function () {
                        var e = this.options
                            , t = e.wrapSelector
                            , i = e.iframeSelector
                            , s = e.fullSelector;
                        t && (this.wrapDom = document.querySelector(t),
                            this.wrapDom && (this.wrapDom.style.position = "releative")),
                            i && (this.iframeDom = document.querySelector(i)),
                            s && (this.toggleFullDom = document.querySelector(s))
                    }
                }, {
                    key: "initUrl",
                    value: function () {
                        var e = this.options
                            , t = e.url
                            , i = e.isViewFull
                            , s = e.isSystemFull;
                        if (t) {
                            var n = new URL(t)
                                , a = n.host;
                            "live.polyv.cn" === a ? (this.urlType = "live",
                                this.isViewFull = !0) : (this.urlType = "",
                                    this.isSystemFull = !0)
                        }
                        void 0 !== i && (this.isViewFull = i),
                            void 0 !== s && (this.isSystemFull = s),
                            this.isSystemFull && (this.isViewFull = !1),
                            i && (this.isSystemFull = !1)
                    }
                }, {
                    key: "toggleFullView",
                    value: function (e) {
                        var t = this.isSystemFull
                            , i = this.isViewFull
                            , s = this.isFull;
                        void 0 !== e && (s = e),
                            s ? (t && this.exitSystemFull(),
                                i && this.exitViewFull(this.wrapDom),
                                this.isFull = !1) : (t && this.toSystemFull(this.iframeDom),
                                    i && this.toViewFull(this.wrapDom),
                                    this.isFull = !0)
                    }
                }, {
                    key: "addEvent",
                    value: function () {
                        document.addEventListener("keydown", this.escExit.bind(this))
                    }
                }, {
                    key: "escExit",
                    value: function (e) {
                        27 === e.keyCode && this.toggleFullView(!0)
                    }
                }, {
                    key: "toViewFull",
                    value: function (e) {
                        "mobile" === this.deviceType && "live" === this.urlType ? (e.className += " custom-view-full__mobile",
                            this.waterMarkDom.className += " custom-view-full__water__mobile") : (e.className += " custom-view-full",
                                this.waterMarkDom.className += " custom-view-full__water")
                    }
                }, {
                    key: "exitViewFull",
                    value: function (e) {
                        "mobile" === this.deviceType && "live" === this.urlType ? (e.className = e.className.replace("custom-view-full__mobile", ""),
                            this.waterMarkDom.className = this.waterMarkDom.className.replace("custom-view-full__water__mobile", "")) : (e.className = e.className.replace("custom-view-full", ""),
                                this.waterMarkDom.className = this.waterMarkDom.className.replace("custom-view-full__water", ""))
                    }
                }, {
                    key: "toSystemFull",
                    value: function (e) {
                        console.log("进行iframe系统全屏操作"),
                            e.requestFullscreen ? e.requestFullscreen() : e.webkitRequestFullScreen ? e.webkitRequestFullScreen() : e.mozRequestFullScreen ? e.mozRequestFullScreen() : e.msRequestFullscreen()
                    }
                }, {
                    key: "exitSystemFull",
                    value: function () {
                        console.log("进行网页全屏操作"),
                            document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen()
                    }
                }, {
                    key: "initWaterMark",
                    value: function () {
                        var e = Object(a["a"])(regeneratorRuntime.mark((function e() {
                            var t;
                            return regeneratorRuntime.wrap((function (e) {
                                while (1)
                                    switch (e.prev = e.next) {
                                        case 0:
                                            if (!this.wrapDom || this.waterMarkDom) {
                                                e.next = 14;
                                                break
                                            }
                                            return t = document.createElement("div"),
                                                this.waterMarkDom = t,
                                                e.next = 5,
                                                this.getWaterMark();
                                        case 5:
                                            t.style.position = "absolute",
                                                t.style.zIndex = "999",
                                                t.style.left = "0",
                                                t.style.top = "0",
                                                t.style.width = "100%",
                                                t.style.height = "100%",
                                                t.style.pointerEvents = "none",
                                                t.style.background = "url(".concat(this.base64Url, ") left top repeat"),
                                                this.wrapDom.append(t);
                                        case 14:
                                        case "end":
                                            return e.stop()
                                    }
                            }
                            ), e, this)
                        }
                        )));
                        function t() {
                            return e.apply(this, arguments)
                        }
                        return t
                    }()
                }, {
                    key: "getWaterMark",
                    value: function () {
                        var e = Object(a["a"])(regeneratorRuntime.mark((function e() {
                            var t, i, s, n, a, o, r, l, u, d, h, m, p, v, f, g;
                            return regeneratorRuntime.wrap((function (e) {
                                while (1)
                                    switch (e.prev = e.next) {
                                        case 0:
                                            return e.next = 2,
                                                c["a"].APIconfirmWatermark();
                                        case 2:
                                            t = e.sent,
                                                i = t.bizResult,
                                                s = "true" === i.enableWatermark,
                                                n = i.waterMarkShowObject ? i.waterMarkShowObject.split(",") : [],
                                                a = [],
                                                n.forEach((function (e) {
                                                    "EMPLOYEE_CODE" === e ? a.push(i.employeeCode) : "USER_NAME" === e ? a.push(i.userName) : "LOGIN_NAME" === e && a.push(i.loginName)
                                                }
                                                )),
                                                a = a.join(" "),
                                                s && (o = a.length,
                                                    r = "middle",
                                                    l = "mobile" === this.deviceType,
                                                    h = l ? i.waterMarkDensity / 100 : 1.1 - i.waterMarkDensity / 100,
                                                    m = i.waterMarkTransparency / 100,
                                                    p = 40 * o * h + 200 > document.documentElement.offsetWidth ? document.documentElement.offsetWidth - 150 : 40 * o * h + 200,
                                                    v = .8 * p,
                                                    u = (p - 100) / 1.7,
                                                    d = (p - 100) / 1.5,
                                                    40 * o * h + 150 > document.documentElement.offsetWidth && (r = "end"),
                                                    f = '<svg xmlns="http://www.w3.org/2000/svg"  width="'.concat(p, 'px" height="').concat(v, "px\">\n                            <text \n                              x='").concat(u, "px'\n                              y='").concat(d, "px'\n                              text-anchor=\"").concat(r, '"\n                              stroke="#999"\n                              dominant-baseline="middle"\n                              stroke-opacity="0.25"\n                              fill="#999"\n                              transform="rotate(-45, 120 120)"\n                              style="font-size: 18px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:').concat(m, '">\n                              ').concat(a, "\n                            </text>\n                          </svg>"),
                                                    g = "data:image/svg+xml;base64,".concat(window.btoa(unescape(encodeURIComponent(f)))),
                                                    this.base64Url = g);
                                        case 10:
                                        case "end":
                                            return e.stop()
                                    }
                            }
                            ), e, this)
                        }
                        )));
                        function t() {
                            return e.apply(this, arguments)
                        }
                        return t
                    }()
                }, {
                    key: "getDeviceType",
                    value: function () {
                        var e = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent);
                        return e ? "mobile" : "pc"
                    }
                }], [{
                    key: "getInstance",
                    value: function () {
                        return e.instance || (e.instance = new e),
                            e.instance
                    }
                }]),
                    e
            }();
        Object(o["a"])(tt, "instance", null);
        var it = tt.getInstance();
        function st(e, t) {
            var i = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var s = Object.getOwnPropertySymbols(e);
                t && (s = s.filter((function (t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }
                ))),
                    i.push.apply(i, s)
            }
            return i
        }
        function nt(e) {
            for (var t = 1; t < arguments.length; t++) {
                var i = null != arguments[t] ? arguments[t] : {};
                t % 2 ? st(Object(i), !0).forEach((function (t) {
                    Object(o["a"])(e, t, i[t])
                }
                )) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : st(Object(i)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                }
                ))
            }
            return e
        }
        var at = {
            name: "course-play",
            data: function () {
                return {
                    urlJson: null,
                    isPlaying: !0,
                    TimeId1: null,
                    courseData: [],
                    curId: "",
                    curType: "",
                    minStudyTime: "",
                    curVideoId: "",
                    noteId: "",
                    resourceRelIdNoteId: "",
                    resourceRelId: "",
                    curTime: null,
                    seek: 0,
                    curIndex: [0, 0],
                    open: !0,
                    recordList: [],
                    recordTime: 0,
                    recordTimeId: null,
                    recordTimeTemp: 0,
                    recordTimeIdTemp: null,
                    studyRate: 0,
                    isReplayBtn: !1,
                    canSaveRecord: !0,
                    seeking: !1,
                    seeked: "",
                    videoCheck: !0,
                    canRecord: !0,
                    startTime: 0,
                    endTime: 0,
                    continueTime: 0,
                    isVideo: !1,
                    pageIndex: 0,
                    pcEdgeBrowerPreview: !1,
                    curTimeToFinish: 0,
                    noPreviewCurTimeToFinish: 0,
                    corpCode: "",
                    excludeCorpCodeList: [],
                    isIE11: !1,
                    isEdge: !1,
                    mustReplayCanFinish: !1,
                    verificationType: "",
                    hangUpFlag: !1,
                    preventCheatFlag: !1,
                    preventCheatTime: 0,
                    preventHangTime: 0,
                    pauseCountTime: 0,
                    maxTime: 0,
                    minTime: 0,
                    checkType: 2,
                    pausecountTimer: null,
                    firstEnterStudyFlag: !1,
                    studyLogData: {
                        studyLogVO: {
                            minStudyTime: "",
                            courseCode: "",
                            courseStandard: "ONLINEVIDEOCOURSE",
                            courseItemId: "",
                            courseTitle: "",
                            videoDuration: "",
                            courseItemName: "",
                            courseId: "",
                            mark: ""
                        },
                        eventType: ""
                    },
                    allowDrag: !1,
                    allowHighSpeed: !1,
                    allowMinStudyTime: !1,
                    addVideoClickFlag: !1,
                    settingBtn: !1,
                    heartBeatFlag: !1,
                    handoutVideo: !1,
                    handoutVideoNoteId: "/courseSetting/preview/handout?id=null",
                    resetHandoutAndVideoProps: !1,
                    seekingTimer: null,
                    seekingSaveFlag: !0,
                    activeName: "contents",
                    QAactiveName: "quiz",
                    QAformData: {},
                    questionData: [],
                    showPlaceholder: !0,
                    topicData: [],
                    inputTopicText: "",
                    icon_completed: ae.a,
                    icon_learning: re.a,
                    shareVisible: !1,
                    teacherValue: 3.7,
                    icon_download: le.a,
                    isHoverActive: !1,
                    btnRightActive: de.a,
                    btnRightDefault: me.a,
                    btnLeftActive: ve.a,
                    btnLeftDefault: ge.a,
                    navMsg: "myNote",
                    noteMsg: "",
                    isCreateNote: !1,
                    createNote: {
                        note_title: "",
                        note_content: "",
                        secrecy: !1,
                        isSendShow: !1,
                        noteId: ""
                    },
                    noteDownLoadVisible: !1,
                    otherNoteDownloadItem: null,
                    noteJumpPeriodVisible: !1,
                    uploadList: [],
                    showChoiceVisible: !1,
                    navActive: "1",
                    discussionValue: "",
                    replyValue: "",
                    commentList: [],
                    sendCommentIsShow: !1,
                    sendReplyIsShow: !1,
                    referenceMaterial: [],
                    courseInfo: {
                        selectCount: 0,
                        coursePeriod: 0,
                        courseScore: 0,
                        categoryNamePath: "",
                        getWay: "",
                        publishDate: "",
                        teacherList: [],
                        meaning: "",
                        orientObj: "",
                        objectives: "",
                        avgPoint: 0
                    },
                    moment: Ue.a,
                    userInfo: null,
                    loading: !1,
                    condition: {
                        pageNo: 1,
                        pageSize: 10
                    },
                    satelliteList: [],
                    totalNumber: 0,
                    totalPages: 0,
                    listLoading: !1,
                    myNotes: [],
                    myNoteCondition: {
                        pageNo: 1,
                        pageSize: 1e4
                    },
                    otherNotes: [],
                    otherNoteCondition: {
                        pageNo: 1,
                        pageSize: 1e4
                    },
                    jumpPeriodSecond: 0,
                    jumpPeriodTime: 0,
                    noteStatus: "create",
                    isUploadImage: !0,
                    defaultAvatar: Xe.a,
                    notejumpPeriod: null,
                    singleNoteInfo: null,
                    notejumpPeriodInfo: null,
                    chapterInfo: null,
                    isfullscreen: "",
                    timer: null,
                    isbizResultShow: !1,
                    hostName: window.location.origin,
                    coursePlayBoxHeight: "670px",
                    infixTests: [],
                    infixTest: {},
                    campData: {},
                    showCamp: !1,
                    campVisible: !1,
                    notShowCampAd: !1
                }
            },
            components: {
                AliPlayer: L["a"],
                AliyunPreview: Q["a"],
                PreventCheat: Y,
                HangUp: se,
                Test: Ke
            },
            computed: {
                isRead: function () {
                    return function () {
                        var e = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].itemId : "";
                        if (e && this.notejumpPeriod && this.notejumpPeriod.chapterId && this.curChapterId && this.userInfo && this.userInfo.userId && this.notejumpPeriod.createBy && this.notejumpPeriod.sectionId === e && this.curChapterId === this.notejumpPeriod.chapterId && this.userInfo.userId !== this.notejumpPeriod.createBy) {
                            var t = "";
                            "video" === this.curType ? t = document.querySelector("#J_prismPlayer>video") : "audio" === this.curType && (t = document.querySelector("#J_prismPlayer>audio"),
                                t || (t = document.querySelector("#J_prismPlayer>video")));
                            var i = 0;
                            if (t && (i = t.currentTime ? t.currentTime : 0),
                                i >= this.notejumpPeriod.playbackPosition)
                                return !0
                        }
                        return !1
                    }
                },
                ellipsisSpan: function () {
                    if (this.courseInfo.teacherList && this.courseInfo.teacherList.length) {
                        var e = "";
                        return this.courseInfo.teacherList.forEach((function (t, i) {
                            e += "".concat(0 === i ? "" : ",").concat(t.teacherName)
                        }
                        )),
                            e.length > 8 ? e.slice(0, 8) + "..." : e
                    }
                    return ""
                },
                isShowJumpPeriod: function () {
                    var e = this;
                    return function (t) {
                        var i = "";
                        return e.courseData.forEach((function (e, s) {
                            e.chapterId === t.chapterId && e.resourceDTOS.forEach((function (e, s) {
                                e.itemId === t.sectionId && (i = e.resourceType || e.resourceClass || "")
                            }
                            ))
                        }
                        )),
                            "video" === i || "audio" === i
                    }
                },
                gWay: function () {
                    if (this.courseInfo) {
                        var e = this.courseInfo.getWay;
                        if (e) {
                            if ("STUDYPLAN" === e || "STUDY_PLAN" === e)
                                return "安排课程";
                            if ("SELF" === e)
                                return "自选";
                            if ("BTM_PROJECT" === e)
                                return "培训项目";
                            if ("RM_PORJECT" === e)
                                return "学习地图";
                            if ("POST_SYSTEM" === e)
                                return "岗位体系";
                            if ("EP_PROJECT" === e)
                                return "时光易培";
                            if ("CIRCLE_PROJECT" === e)
                                return "岗位课程包"
                        }
                        return ""
                    }
                    return ""
                },
                noMore: function () {
                    return this.commentList.length === this.totalNumber
                },
                disabled: function () {
                    return this.loading || this.noMore
                },
                QANum: function () {
                    return this.QAformData.title ? 140 - this.QAformData.title.length : 140
                },
                arrowLeft: function () {
                    return "quiz" === this.QAactiveName ? 29 : 124
                },
                language: function () {
                    return window.$cookies.get("local_") || "zh_CN"
                },
                aliPlayer: function () {
                    return "video" === this.curType || "audio" === this.curType ? this.$refs.aliPlayer : null
                },
                player: function () {
                    return "video" === this.curType || "audio" === this.curType ? this.$refs.aliPlayer.player : null
                },
                curChapterId: function () {
                    return this.courseData[this.curIndex[0]].chapterId
                },
                curChapterName: function () {
                    return this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].chapterName ? this.courseData[this.curIndex[0]].chapterName : ""
                },
                curChapterContent: function () {
                    return this.courseData[this.curIndex[0]]
                },
                curInfo: function () {
                    return this.curIndex && this.courseData && this.courseData.length > 0 ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]] : null
                },
                currentStudyTime: function () {
                    var e = this.curIndex && this.courseData && this.courseData.length > 0 ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]] : null
                        , t = e && e.currentStudyTime ? e.currentStudyTime : 0;
                    return e ? e.minStudyTime - t - this.recordTime : 0
                },
                nextIndex: function () {
                    return this.courseData[this.curIndex[0]] && !this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1] + 1] ? this.courseData[this.curIndex[0] + 1] ? [this.curIndex[0] + 1, 0] : null : [this.curIndex[0], this.curIndex[1] + 1]
                },
                nextInfo: function () {
                    return this.nextIndex ? this.courseData[this.nextIndex[0]].resourceDTOS[this.nextIndex[1]] : null
                },
                nextId: function () {
                    return this.nextInfo ? this.nextInfo.resourceId : ""
                },
                courseParams: function () {
                    return decodeURIComponent(this.$route.params.courseInfo).split("&")
                },
                courseId: function () {
                    return this.courseParams[0]
                },
                providerCorpCode: function () {
                    return this.courseParams[1]
                },
                sourceId: function () {
                    return this.courseParams[2]
                },
                courseTitle: function () {
                    return parent.document.title
                },
                isDefaultHideControl: function () {
                    return this.isVideo && !this.noteId
                },
                urlIframeHasControl: function () {
                    var e = this.$route.query.from
                        , t = this.currentStudyTime
                        , i = this.urlJson;
                    return "preview" === e || (!!("preview" !== e && t > 0 && i && i.minStudyTime) || !("preview" === e || !i || 0 !== t && !i.confirmFinish || !i.minStudyTime))
                },
                isPreview: function () {
                    var e = this.$route.query.from;
                    return "preview" === e
                }
            },
            watch: {
                curIndex: {
                    handler: function () {
                        var e = this;
                        this.curVideoId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId : "",
                            this.noteId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId : "",
                            this.infixTests = this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].infixTests || [],
                            this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "",
                            this.curTime = {
                                minStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                                currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                            },
                            this.courseData[this.curIndex[0]] && "url" === this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType && this.$store.dispatch("preview/fetchPreviewAction", {
                                param: {
                                    providerCorpCode: this.providerCorpCode,
                                    chapterId: this.courseData[this.curIndex[0]].chapterId,
                                    id: this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceId
                                },
                                callback: function (t) {
                                    e.urlJson = t;
                                    var i = e.recordList.find((function (t) {
                                        return t.resourceId === e.curId
                                    }
                                    ));
                                    i && e.$set(e.urlJson, "confirmFinish", i.confirmFinish),
                                        t.content || (setTimeout((function () {
                                            var e = document.getElementsByTagName("iframe")[0];
                                            e.style.display = "none"
                                        }
                                        ), 0),
                                            setTimeout((function () {
                                                var e = document.getElementsByTagName("iframe")[0];
                                                e.style.display = "block",
                                                    e.style.height = "100%",
                                                    e.style.width = "100%"
                                            }
                                            ), 0))
                                }
                            })
                    },
                    deep: !0
                },
                courseData: {
                    handler: function () {
                        var e = this;
                        this.curVideoId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId : "",
                            this.noteId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId : "",
                            this.infixTests = this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].infixTests || [],
                            this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "",
                            this.curTime = {
                                minStudyTime: this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                                currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                            },
                            this.courseData[this.curIndex[0]] && "url" === this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType && this.$store.dispatch("preview/fetchPreviewAction", {
                                param: {
                                    providerCorpCode: this.providerCorpCode,
                                    chapterId: this.courseData[this.curIndex[0]].chapterId,
                                    id: this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceId
                                },
                                callback: function (t) {
                                    e.urlJson = t;
                                    var i = e.recordList.find((function (t) {
                                        return t.resourceId === e.curId
                                    }
                                    ));
                                    e.initHeart(),
                                        i && e.$set(e.urlJson, "confirmFinish", i.confirmFinish),
                                        t.content || (setTimeout((function () {
                                            var e = document.getElementsByTagName("iframe")[0];
                                            e.style.display = "none"
                                        }
                                        ), 0),
                                            setTimeout((function () {
                                                var e = document.getElementsByTagName("iframe")[0];
                                                e.style.display = "block",
                                                    e.style.height = "100%",
                                                    e.style.width = "100%"
                                            }
                                            ), 0))
                                }
                            })
                    },
                    deep: !0
                },
                currentStudyTime: function (e) {
                    0 === e && "video" !== this.curType && "audio" !== this.curType && (this.recordTimeId && clearInterval(this.recordTimeId),
                        this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp),
                        this.updateCourseRecord())
                },
                recordTime: function (e) {
                    var t = this;
                    "video" !== this.curType && "audio" !== this.curType && e % 180 === 0 && 0 !== e && (this.updateCourseRecord(1),
                        this.recordTimeId && clearInterval(this.recordTimeId)),
                        ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && (this.curTimeToFinish = Math.round(this.player.getDuration() * this.courseData[this.curIndex[0]].finishPercent),
                            this.noPreviewCurTimeToFinish = Math.round(.5 * this.player.getDuration())),
                        ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && e === this.noPreviewCurTimeToFinish && (this.canRecord && (this.updateCourseRecord(),
                            this.canRecord = !1),
                            clearTimeout(this.TimeId1),
                            this.TimeId1 = setTimeout((function () {
                                t.canRecord = !0
                            }
                            ), 1e3)),
                        ("video" === this.curType || "audio" === this.curType) && this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && e === this.noPreviewCurTimeToFinish && !this.allowDrag && (this.canRecord && (this.updateCourseRecord(),
                            this.canRecord = !1),
                            clearTimeout(this.TimeId1),
                            this.TimeId1 = setTimeout((function () {
                                t.canRecord = !0
                            }
                            ), 1e3))
                },
                urlJson: {
                    handler: function (e) {
                        "url" === this.curType && e.content && it.init({
                            wrapSelector: ".aliPlayer-content .ac-main",
                            iframeSelector: ".iframe-content",
                            fullSelector: ".icon.iconfont.icon-quanping.full-screen",
                            url: e.content
                        })
                    },
                    deep: !0
                }
            },
            directives: {
                focus: {
                    inserted: function (e, t) {
                        var i = t.value;
                        i && e.focus()
                    }
                }
            },
            methods: {
                downLoadTxt: function (e, t) {
                    var i = document.createElement("a");
                    if (i.setAttribute("href", "data:text/plain;charset=utf-8," + encodeURIComponent(t)),
                        i.setAttribute("download", e),
                        document.createEvent) {
                        var s = document.createEvent("MouseEvents");
                        s.initEvent("click", !0, !0),
                            i.dispatchEvent(s)
                    } else
                        i.click();
                    this.noteDownLoadVisible = !1
                },
                toggleThumbsUp: Object(Ve["throttle"])((function (e) {
                    var t = this
                        , i = {
                            coursePraise: {
                                courseId: this.courseId,
                                praiseStatus: !e
                            }
                        };
                    P(i).then((function () {
                        t.getCourseInfo()
                    }
                    ))
                }
                ), 300),
                toggleCollection: Object(Ve["throttle"])((function (e) {
                    var t = this
                        , i = {
                            courseId: this.courseId
                        };
                    e ? _(i).then((function () {
                        t.getCourseInfo()
                    }
                    )) : E(i).then((function () {
                        t.getCourseInfo()
                    }
                    ))
                }
                ), 300),
                downLoadRefer: function (e) {
                    window.open(e.refStoredFileId, "target")
                },
                showRefer: function (e) {
                    window.open(e.refStoredFileId, "target")
                },
                queryReferences: function () {
                    var e = this
                        , t = {
                            courseId: this.courseId
                        };
                    y(t).then((function (t) {
                        var i = t.bizResult;
                        e.referenceMaterial = i || []
                    }
                    ))
                },
                initScroll: function () {
                    this.loading = !1,
                        this.condition.pageNo = 1,
                        this.commentList = [],
                        this.totalNumber = 0,
                        this.totalPages = 0
                },
                load: function () {
                    this.commentList.length < this.totalNumber && (this.loading = !0),
                        this.getCourseDiscuss("load")
                },
                delComment: function (e, t) {
                    var i = this;
                    this.$confirm("确认删除当前评论吗？", "提示", {
                        confirmButtonText: "确定",
                        cancelButtonText: "取消",
                        type: "warning"
                    }).then((function () {
                        var t = {
                            discussIds: e.discussId || "",
                            csrfToken: ""
                        };
                        C(t).then((function (e) {
                            "1001" == e.code && (i.$message.success("讨论删除成功！"),
                                i.getCourseDiscuss("init"))
                        }
                        ))
                    }
                    )).catch((function () { }
                    ))
                },
                choiceReply: function (e, t) {
                    e.isReplyShow = !e.isReplyShow,
                        this.commentList[t] = e
                },
                sendReply: function (e) {
                    var t = this;
                    if (this.replyValue) {
                        var i = {
                            discuss: {
                                idPath: e.idPath,
                                objectId: this.courseId,
                                contentPreview: this.replyValue || ""
                            }
                        };
                        this.sendReplyIsShow = !0,
                            I(i).then((function (e) {
                                t.sendReplyIsShow = !1,
                                    e.bizResult ? (t.$message.success("回复成功！"),
                                        t.replyValue = "",
                                        t.getCourseDiscuss("init")) : t.$message.warning("回复失败！")
                            }
                            ))
                    } else
                        this.$message.warning("请先输入回复信息。")
                },
                sendDiscuss: function () {
                    var e = this;
                    if (this.discussionValue) {
                        var t = {
                            discuss: {
                                objectId: this.courseId,
                                contentPreview: this.discussionValue
                            },
                            isShare: !0
                        };
                        this.sendCommentIsShow = !0,
                            T(t).then((function (t) {
                                e.sendCommentIsShow = !1,
                                    t.bizResult ? (e.$message.success("发表成功！"),
                                        e.discussionValue = "",
                                        e.getCourseDiscuss("init")) : e.$message.warning("发表失败！")
                            }
                            )).catch((function () {
                                e.sendCommentIsShow = !1
                            }
                            )).finally((function () {
                                e.sendCommentIsShow = !1
                            }
                            ))
                    } else
                        this.$message.warning("请先输入评论信息。")
                },
                getCourseDiscuss: function () {
                    var e = this
                        , t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    "init" === t && (this.condition.pageNo = 1,
                        this.condition.pageSize = 10,
                        this.initScroll());
                    var i = {
                        courseType: "NEW_COURSE_CENTER",
                        courseId: this.courseId,
                        page: {
                            pageNo: this.condition.pageNo,
                            pageSize: this.condition.pageSize
                        }
                    };
                    S(i).then((function (t) {
                        var i = t.bizResult
                            , s = i.rows
                            , n = i.total
                            , a = i.totalPages;
                        s && (e.commentList = [].concat(Object(r["a"])(e.commentList), Object(r["a"])(s.map((function (e) {
                            return nt(nt({}, e), {}, {
                                isReplyShow: !1
                            })
                        }
                        ))))),
                            e.totalNumber = n,
                            e.totalPages = a,
                            e.loading = !1,
                            e.condition.pageNo > e.totalPages || e.condition.pageNo++
                    }
                    ))
                },
                navToTeacherPage: function (e) {
                    if (this.courseInfo.teacherList.length) {
                        var t = "NEW_COURSE_CENTER";
                        window.open(location.origin + "/els/html/teacher/teacher.teacherTopHeader.do?teacherId=".concat(e, "&courseType=").concat(t))
                    }
                },
                getCourseInfo: function () {
                    var e = this
                        , t = {
                            courseId: this.courseId
                        };
                    w(t).then((function (t) {
                        console.log("getCourseInfoJson", t.bizResult),
                            e.courseInfo = t.bizResult || {
                                selectCount: 0,
                                coursePeriod: 0,
                                courseScore: 0,
                                categoryNamePath: "",
                                getWay: "",
                                publishDate: "",
                                teacherList: [],
                                meaning: "",
                                orientObj: "",
                                objectives: "",
                                avgPoint: 0
                            }
                    }
                    ))
                },
                toggleNavItem: function (e) {
                    "4" === e && 4 !== this.navActive && this.addHits(),
                        this.navActive = e
                },
                clickUpLoad: function () {
                    this.$refs.uploadFile.type = "file"
                },
                changeUpLoad: function (e) {
                    var t = this.uploadList.length
                        , i = !0;
                    if (e.target.files && e.target.files.length) {
                        console.log("files", e.target.files[0]);
                        for (var s = Array.from(e.target.files), n = 0; n <= s.length - 1; n++)
                            if (!s[n].type.includes("image")) {
                                i = !1;
                                break
                            }
                        if (!i)
                            return void this.$message.warning("请选择图片文件！！！")
                    }
                    t ? t + Array.from(e.target.files).length <= 9 ? (this.isUploadImage = !1,
                        this.uploadImageFile(Array.from(e.target.files)),
                        this.$refs.uploadFile.type = "") : this.$message.warning("图片最多可上传9张") : Array.from(e.target.files).length <= 9 ? (this.isUploadImage = !1,
                            this.uploadImageFile(Array.from(e.target.files)),
                            this.$refs.uploadFile.type = "") : this.$message.warning("图片最多可上传9张")
                },
                deleteItem: function (e) {
                    this.uploadList = this.uploadList.filter((function (t, i) {
                        return e !== i
                    }
                    ))
                },
                jumpPeriod: function (e, t) {
                    var i = this;
                    this.updateCourseRecord();
                    var s = null;
                    if ("video" === this.curType ? s = document.querySelector("#J_prismPlayer>video") : "audio" === this.curType && (s = document.querySelector("#J_prismPlayer>audio"),
                        s || (s = document.querySelector("#J_prismPlayer>video"))),
                        s && s.pause(),
                        this.notejumpPeriod = e,
                        this.courseData.forEach((function (e, t) {
                            e.chapterId === i.notejumpPeriod.chapterId && e.resourceDTOS.forEach((function (e, t) {
                                e.itemId === i.notejumpPeriod.sectionId && (i.notejumpPeriodInfo = nt({}, e))
                            }
                            ))
                        }
                        )),
                        this.jumpPeriodSecond = e.playbackPosition || 0,
                        this.jumpPeriodTime = this.showTime(e.playbackPosition),
                        "window" === t) {
                        var n = this.userInfo
                            , a = this.notejumpPeriod
                            , o = this.notejumpPeriodInfo
                            , r = this.jumpPeriodSecond;
                        !n || !a || n.userId !== a.createBy || n && a && n.userId !== a.createBy && o && o.currentPosition && o.currentPosition >= r ? this.noteJumpPeriodVisible = !0 : this.confirmPositionPlay()
                    } else
                        this.noteJumpPeriodVisible = !0
                },
                showTime: function (e) {
                    if (e < 60)
                        return e < 10 ? "00:0" + e : "00:" + e;
                    var t = Math.floor(e / 60)
                        , i = Math.floor(e % 60);
                    if (t < 60)
                        return t < 10 ? i < 10 ? "0" + t + ":0" + i : "0" + t + ":" + i : i < 10 ? t + ":0" + i : t + ":" + i;
                    var s = Math.floor(t / 60)
                        , n = Math.floor(t % 60)
                        , a = s < 10 ? "0" + s : s
                        , o = n < 10 ? "0" + n : n
                        , r = i < 10 ? "0" + i : i;
                    return a + ":" + o + ":" + r
                },
                editPeriod: function (e) {
                    this.singleNoteInfo = e,
                        this.createNote.note_title = e.noteName,
                        this.createNote.note_content = e.content,
                        this.createNote.secrecy = e.isSecret,
                        this.createNote.noteId = e.noteId,
                        this.isCreateNote = !0,
                        this.noteStatus = "update"
                },
                confirmPositionPlay: function () {
                    var e = this;
                    this.noteJumpPeriodVisible = !1;
                    var t = this.userInfo
                        , i = this.notejumpPeriod
                        , s = this.notejumpPeriodInfo
                        , n = this.jumpPeriodSecond;
                    console.log(t, i, s, n),
                        (t && i && t.userId === i.createBy || t && i && t.userId !== i.createBy && s && s.currentPosition && s.currentPosition >= n) && this.$nextTick((function () {
                            e.courseData.forEach((function (t, i) {
                                t.chapterId === e.notejumpPeriod.chapterId && t.resourceDTOS.forEach((function (t, s) {
                                    t.itemId === e.notejumpPeriod.sectionId && (e.curIndex = [i, s],
                                        e.curId = t.resourceId,
                                        e.curVideoId = t.resourceRelId,
                                        e.isVideo = !0,
                                        e.curType = t.resourceType || t.resourceClass,
                                        setTimeout((function () {
                                            e.seek = e.jumpPeriodSecond || 0,
                                                e.$refs.aliPlayer.aliPlayer(e.curVideoId, "pause")
                                        }
                                        ), 0))
                                }
                                ))
                            }
                            ))
                        }
                        ))
                },
                closePositionPlay: function () {
                    this.noteJumpPeriodVisible = !1
                },
                showDownLoadDialog: function (e) {
                    var t = this;
                    console.log(e),
                        this.noteDownLoadVisible = !0,
                        this.jumpPeriodTime = this.showTime(e.playbackPosition),
                        this.otherNoteDownloadItem = e,
                        this.otherNoteDownloadItem.faceUrl = this.otherNoteDownloadItem.faceUrl.includes("default_180") ? this.otherNoteDownloadItem.faceUrl : "/".concat(this.otherNoteDownloadItem.faceUrl),
                        this.courseData.forEach((function (i, s) {
                            i.chapterId === e.chapterId && i.resourceDTOS.forEach((function (n, a) {
                                n.itemId === e.sectionId && (t.chapterInfo = nt(nt(nt({}, n), i), {}, {
                                    mIndex: s
                                }))
                            }
                            ))
                        }
                        ))
                },
                initNoteInfo: function () {
                    this.createNote = {
                        note_title: "",
                        note_content: "",
                        secrecy: "",
                        isSendShow: !1
                    },
                        this.isCreateNote = !1
                },
                sendNote: function () {
                    var e = this
                        , t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : ""
                        , i = arguments.length > 1 ? arguments[1] : void 0
                        , s = arguments.length > 2 ? arguments[2] : void 0;
                    "toggle" === t && (this.createNote.note_title = i.noteName,
                        this.createNote.note_content = i.content,
                        this.createNote.secrecy = i.isSecret,
                        this.createNote.noteId = i.noteId,
                        this.noteStatus = "update",
                        this.createNote.secrecy = !this.createNote.secrecy);
                    var n = this.createNote
                        , a = n.note_title
                        , o = n.note_content
                        , r = n.secrecy
                        , c = n.noteId;
                    if (a.trim())
                        if (o.trim()) {
                            var l = "";
                            "video" === this.curType ? l = document.querySelector("#J_prismPlayer>video") : "audio" === this.curType && (l = document.querySelector("#J_prismPlayer>audio"),
                                l || (l = document.querySelector("#J_prismPlayer>video")));
                            var u = 0;
                            l && (u = l.currentTime ? parseInt(l.currentTime) : 0),
                                "toggle" === t && i.playbackPosition && (u = i.playbackPosition);
                            var d = this.curChapterContent.chapterId || ""
                                , h = this.curInfo.itemId || "";
                            i && (d = i.chapterId || "",
                                h = i.sectionId || ""),
                                console.log("!msg && !item && this.singleNoteInfo", t, !i, this.singleNoteInfo),
                                !i && this.singleNoteInfo && "update" === this.noteStatus && (d = this.singleNoteInfo.chapterId || "",
                                    h = this.singleNoteInfo.sectionId || "",
                                    u = this.singleNoteInfo.playbackPosition || "");
                            var m = {
                                "courseNote.courseId": this.courseId,
                                "courseNote.noteId": "create" === this.noteStatus ? "" : c,
                                "courseNote.noteName": a,
                                "courseNote.content": o,
                                "courseNote.isSecret": r,
                                "courseNote.playbackPosition": u,
                                "courseNote.chapterId": d,
                                "courseNote.sectionId": h
                            };
                            this.createNote.isSendShow = !0,
                                b(m).then((function () {
                                    e.createNote.isSendShow = !1,
                                        e.initNoteInfo(),
                                        "create" === e.noteStatus ? e.$message.success("笔记发布成功！") : s ? "open" === s ? e.$message.success("笔记状态已公开！") : "close" === s && e.$message.success("笔记状态已保密！") : e.$message.success("笔记更新成功！"),
                                        e.getMyNoteAndOtherNoteList("me", e.myNoteCondition),
                                        e.singleNoteInfo = null
                                }
                                ))
                        } else
                            this.$message.warning("笔记内容不能为空！");
                    else
                        this.$message.warning("笔记标题不能为空！")
                },
                delMyNote: function (e) {
                    var t = this;
                    this.$confirm("确认删除当前笔记吗？", "提示", {
                        confirmButtonText: "确定",
                        cancelButtonText: "取消",
                        type: "warning"
                    }).then((function () {
                        var i = {
                            noteId: e.noteId || ""
                        };
                        k(i).then((function (e) {
                            t.getMyNoteAndOtherNoteList("me", t.myNoteCondition, "init")
                        }
                        ))
                    }
                    )).catch((function () { }
                    ))
                },
                toggleCreateNote: function () {
                    this.isCreateNote = !0,
                        this.noteStatus = "create",
                        this.createNote.note_title = "",
                        this.createNote.note_content = "",
                        this.createNote.secrecy = !1,
                        this.createNote.isSendShow = !1,
                        this.createNote.noteId = ""
                },
                noteEnter: function (e) {
                    this.noteMsg = e + "-enter"
                },
                noteLeave: function (e) {
                    this.noteMsg = e + "-leave"
                },
                navToggle: function (e) {
                    this.navMsg = e,
                        this.isCreateNote = !1,
                        "myNote" === e ? this.getMyNoteAndOtherNoteList("me", this.myNoteCondition) : "otherNote" === e && this.getMyNoteAndOtherNoteList("other", this.otherNoteCondition)
                },
                enterDefault: function () {
                    this.isHoverActive = !0
                },
                leaveDefault: function () {
                    this.isHoverActive = !1
                },
                getImage: function (e, t) {
                    return new Promise((function (i, s) {
                        var n = new XMLHttpRequest;
                        n.open("get", e, !0),
                            n.setRequestHeader("Cache-Control", "no-cache"),
                            n.responseType = "blob",
                            n.onload = function () {
                                200 == this.status && (document.getElementById(t).src = URL.createObjectURL(this.response),
                                    i())
                            }
                            ,
                            n.onerror = function () {
                                s()
                            }
                            ,
                            n.send()
                    }
                    ))
                },
                saveDownload: function (e) {
                    var t = this
                        , i = document.querySelector("#sw-main-img");
                    this.getImage(i.src, "sw-main-img").then((function (e) {
                        console.log("res", e)
                    }
                    )).finally((function () {
                        var e = document.getElementById("sw-main-content");
                        e.style.display = "block",
                            t.$nextTick((function () {
                                Ze()(document.getElementById("sw-main"), {
                                    allowTaint: !1,
                                    useCORS: !0
                                }).then((function (i) {
                                    var s = i.toDataURL("image/png")
                                        , n = t.courseInfo && t.courseInfo.courseTitle ? t.courseInfo.courseTitle + "分享" : "默认课程分享";
                                    t.downloadShareFile(n, s),
                                        e.style.display = "none"
                                }
                                ))
                            }
                            ))
                    }
                    ))
                },
                downloadShareFile: function (e, t) {
                    var i = function (e) {
                        for (var t = e.split(";base64,"), i = t[0].split(":")[1], s = window.atob(t[1]), n = s.length, a = new Uint8Array(n), o = 0; o < n; ++o)
                            a[o] = s.charCodeAt(o);
                        return new Blob([a], {
                            type: i
                        })
                    }
                        , s = document.createElement("a")
                        , n = i(t)
                        , a = document.createEvent("HTMLEvents");
                    a.initEvent("click", !0, !0),
                        s.download = e,
                        s.href = URL.createObjectURL(n),
                        s.click()
                },
                copyText: function (e) {
                    var t = document.createElement("input");
                    t.setAttribute("id", "cp_hgz_input"),
                        t.value = e,
                        document.getElementsByTagName("body")[0].appendChild(t),
                        document.getElementById("cp_hgz_input").select(),
                        document.execCommand("copy"),
                        document.getElementById("cp_hgz_input").remove(),
                        this.$message.success("课程链接已复制，快去分享吧~")
                },
                closeDialog: function () {
                    this.shareVisible = !1
                },
                shareCourse: function () {
                    this.shareVisible = !0
                },
                videoSeeking: function () {
                    var e = this;
                    this.seekingSaveFlag = !1,
                        clearTimeout(this.seekingTimer),
                        this.seekingTimer = setTimeout((function () {
                            e.seekingSaveFlag = !0,
                                clearTimeout(e.seekingTimer)
                        }
                        ), 5e3)
                },
                initHeart: function () {
                    var e = this;
                    clearInterval(this.heartTimer);
                    var t = {
                        courseId: this.courseId,
                        eln_session_id: Object(M["getUrl"])("eln_session_id")
                    };
                    c["c"].loadCourseSystemSeting(t).then((function (t) {
                        "1001" == t.code && (!t.bizResult.heartBeat || e.curInfo.finish && !t.bizResult.continueHeartBeat || (e.heartTimer = setInterval((function () {
                            c["c"].heartBeatSetData(e.courseId)
                        }
                        ), 6e4),
                            e.heartBeatFlag = !0))
                    }
                    ))
                },
                resetHandoutAndVideo: function () {
                    this.resetHandoutAndVideoProps = !0
                },
                openAndCloseVideo: function (e) {
                    this.handoutVideoNoteId = "/courseSetting/preview/handout?id=" + e.noteId + "&iframeType=PIP";
                    document.getElementById("aliPlayer");
                    this.handoutVideo = !!e.flag,
                        this.resetHandoutAndVideoProps = !e.flag
                },
                openHandoutOperate: function (e) {
                    e && (this.handoutVideoNoteId = "/courseSetting/preview/handout?id=" + e,
                        this.handoutVideo = !this.handoutVideo,
                        this.resetHandoutAndVideoProps = !this.resetHandoutAndVideoProps)
                },
                toFullVideo: function () {
                    it.toggleFullView()
                },
                exitFullscreen: function () {
                    document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen()
                },
                getCourseData: function () {
                    var e = this
                        , t = {
                            courseId: this.sourceId,
                            providerCorpCode: this.providerCorpCode
                        };
                    c["b"].APIshowCourseChapter(t).then((function (t) {
                        e.courseData = t.bizResult.filter((function (e) {
                            return e.resourceDTOS.length > 0
                        }
                        )),
                            e.settingBtn = e.courseData[0].customAliVideoCorp,
                            "preview" !== e.$route.query.from && !1 === e.pcEdgeBrowerPreview ? e.getStudyRecordList(e.setPlaytimePosition) : e.setPlaytimePosition(),
                            e.isPlaying = !0
                    }
                    ))
                },
                setPlaytimePosition: function () {
                    var e = this;
                    this.recordLearningStatus("ENTER_STUDY"),
                        this.recordLearningStatus("COURSE_SIGN_IN");
                    var t, i = this.recordList.find((function (e) {
                        return 1 === e.confirmLearning
                    }
                    )), s = i ? this.courseData.findIndex((function (e) {
                        return e.resourceDTOS.some((function (e) {
                            return e.resourceId === i.resourceId
                        }
                        ))
                    }
                    )) : -1;
                    void 0 !== i && s >= 0 ? (t = this.courseData.findIndex((function (e) {
                        return e.resourceDTOS.some((function (e) {
                            return e.resourceId === i.resourceId
                        }
                        ))
                    }
                    )),
                        this.curIndex = [t, this.courseData[t].resourceDTOS.findIndex((function (e) {
                            return e.resourceId === i.resourceId
                        }
                        ))],
                        this.pageIndex = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].pageIndex || 0,
                        this.curType = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType,
                        this.minStudyTime = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime,
                        "video" !== this.curType && "audio" !== this.curType || (this.isVideo = !0),
                        this.curId = i.resourceId,
                        this.minStudyTime = i.minStudyTime,
                        this.curVideoId = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId,
                        this.noteId = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId,
                        this.infixTests = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].infixTests || [],
                        this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "",
                        this.curTime = {
                            minStudyTime: this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                            currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                        }) : (this.pageIndex = this.courseData[0] && this.courseData[0].resourceDTOS[0] && this.courseData[0].resourceDTOS[0].pageIndex || 0,
                            this.curType = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].resourceType : "",
                            this.minStudyTime = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].minStudyTime : "",
                            "video" !== this.curType && "audio" !== this.curType || (this.isVideo = !0),
                            this.curId = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].resourceId : "");
                    var n = this.recordList.find((function (t) {
                        return t.resourceId === e.curId
                    }
                    ));
                    void 0 === n || null === n.currentPosition || 1 === n.confirmFinish || "video" !== this.curType && "audio" !== this.curType || (this.seek = n.currentPosition + 1 > this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].playTime ? 0 : n.currentPosition),
                        this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp),
                        this.recordTimeTemp = this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0,
                        ("video" !== this.curType && "audio" !== this.curType || ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1) && ("video" !== this.curType && "audio" !== this.curType || this.allowDrag || this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                            confirmButtonText: "确定",
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }),
                            this.recordTime = 0,
                            this.recordTimeId = setInterval((function () {
                                e.recordTime++
                            }
                            ), 1e3))
                },
                syncStudyRecord: function () {
                    if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                        var e = {
                            courseId: this.courseId,
                            sourceId: this.sourceId,
                            providerCorpCode: this.providerCorpCode
                        };
                        c["c"].APIsyncStudyRecord(e)
                    }
                },
                getStudyRecordList: function () {
                    var e = this
                        , t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null
                        , i = {
                            courseId: this.courseId,
                            sourceId: this.sourceId,
                            providerCorpCode: this.providerCorpCode
                        };
                    c["c"].APIgetStudyRecordList(i).then((function (i) {
                        e.recordList = i.bizResult,
                            e.recordList && e.recordList.length > 0 && e.recordList[0].alert && e.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">管理员调整了这门课程的内容，您的学习记录可能因此发生变化。</span>', "", {
                                confirmButtonText: e.$t("v4.js.pc.ocmt.confirm"),
                                showClose: !1,
                                dangerouslyUseHTMLString: !0
                            }),
                            e.recordList.forEach((function (t) {
                                e.courseData.forEach((function (i) {
                                    i.resourceDTOS.forEach((function (i) {
                                        i.resourceId === t.resourceId && (1 === t.confirmFinish && e.$set(i, "finish", !0),
                                            e.$set(i, "currentStudyTime", t.currentStudyTime),
                                            e.$set(i, "currentPosition", t.currentPosition),
                                            e.$set(i, "pageIndex", t.pageIndex))
                                    }
                                    ))
                                }
                                ))
                            }
                            )),
                            t && t()
                    }
                    ))
                },
                updateCourseRecord: function (e, t) {
                    var i = this;
                    if ("preview" !== this.$route.query.from && (!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1) && this.canSaveRecord) {
                        if (!this.allowDrag && !this.seekingSaveFlag && ("video" === this.curType || "audio" === this.curType))
                            return;
                        t && clearInterval(this.recordTimeIdTemp);
                        var s = this.recordList.find((function (e) {
                            return e.resourceId === i.curId
                        }
                        ))
                            , n = void 0 !== s ? s.recordId : null;
                        if (void 0 !== s && 1 !== s.confirmFinish || void 0 === s) {
                            var a = 0;
                            "video" !== this.curType && "audio" !== this.curType || (a = this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish ? this.recordTime : this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish ? this.curTimeToFinish : Math.round(Math.max(this.seek, this.player.getCurrentTime())));
                            var o = {
                                recordId: n,
                                courseId: this.courseId,
                                sourceId: this.sourceId,
                                providerCorpCode: this.providerCorpCode,
                                chapterId: this.curChapterId,
                                resourceId: this.curId,
                                timeToFinish: this.curTimeToFinish,
                                currentPosition: a,
                                type: this.curType,
                                currentStudyTime: "video" === this.curType || "audio" == this.curType ? this.recordTimeTemp - this.curTime.currentStudyTime : this.recordTime,
                                pageIndex: "video" !== this.curType && "audio" !== this.curType && this.$refs.aliPreview ? this.$refs.aliPreview.currentCount : 0
                            };
                            this.canSaveRecord = !1,
                                c["c"].APIupdateCourseRecord(o).then((function (t) {
                                    i.getStudyRecordList((function () {
                                        e && (i.recordTimeId && clearInterval(i.recordTimeId),
                                            i.recordTime = 0,
                                            i.recordTimeId = setInterval((function () {
                                                i.recordTime++
                                            }
                                            ), 1e3)),
                                            i.canSaveRecord = !0
                                    }
                                    )),
                                        i.getStudyRate()
                                }
                                ))
                        }
                    }
                },
                getStudyRate: function () {
                    var e = this
                        , t = {
                            courseId: this.courseId,
                            sourceId: this.sourceId,
                            providerCorpCode: this.providerCorpCode
                        };
                    c["c"].APIgetStudyRate(t).then((function (t) {
                        e.studyRate = t.bizResult,
                            localStorage.studyRate = e.studyRate
                    }
                    ))
                },
                checkoutSection: function (e, t) {
                    var i = this
                        , s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                    arguments.length > 3 && arguments[3];
                    Fe["a"].dispose(),
                        clearInterval(this.heartTimer),
                        this.firstEnterStudyFlag && this.recordLearningStatus("QUIT_COURSE_ITEM");
                    var n = e.resourceId
                        , a = e.resourceType
                        , o = e.minStudyTime;
                    if (this.mustReplayCanFinish = !1,
                        this.updateCourseRecord(),
                        this.videoCheck = !1,
                        "video" !== this.curType && "audio" !== this.curType || this.player.pause(),
                        this.recordTimeId && clearInterval(this.recordTimeId),
                        this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp),
                        e.pageIndex && (this.pageIndex = e.pageIndex),
                        this.curType = a,
                        "video" !== this.curType && "audio" !== this.curType && (this.isPlaying = !0),
                        "video" === this.curType || "audio" === this.curType ? this.resetHandoutAndVideo() : (document.pictureInPictureElement && document.exitPictureInPicture(),
                            this.handoutVideo = !1),
                        "video" === this.curType || "audio" === this.curType) {
                        var r = this.recordList.find((function (e) {
                            return e.resourceId === n
                        }
                        ));
                        void 0 !== r && null !== r.currentPosition && 1 !== r.confirmFinish && r.currentPosition < r.timeToFinish ? (this.seeked = r.currentPosition,
                            this.seek = r.currentPosition) : (this.seeked = 0,
                                this.seek = 0),
                            this.$refs.aliPlayer && (this.$refs.aliPlayer.seeked = this.seeked,
                                this.player.seek(0))
                    }
                    this.preventCheatFlag && ("video" == this.curType || "audio" == this.curType ? this.$refs.preventCheat.resetPlayTime(this.preventCheatTime) : this.$refs.preventCheat.initPreventCheat(this.preventCheatTime)),
                        this.recordTime = 0,
                        this.recordTimeTemp = 0,
                        this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp),
                        this.$nextTick((function () {
                            i.isVideo = !1,
                                i.curId = n,
                                i.minStudyTime = o,
                                i.curIndex = [t, s],
                                i.curVideoId = i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].resourceRelId : "",
                                i.noteId = i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].noteId : "",
                                i.infixTests = i.courseData[i.curIndex[0]] && i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].infixTests || [],
                                i.resourceRelIdNoteId = i.courseData[i.curIndex[0]] ? (i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].noteResource || {}).resourceRelId : "",
                                i.curTime = {
                                    minStudyTime: i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].minStudyTime : "",
                                    currentStudyTime: i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].currentStudyTime : ""
                                },
                                i.recordTimeTemp = i.courseData[i.curIndex[0]] && i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].currentStudyTime ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].currentStudyTime : 0,
                                "video" !== i.curType && "audio" != i.curType || (i.isVideo = !0,
                                    i.$refs.aliPlayer && i.$refs.aliPlayer.aliPlayer(i.curVideoId),
                                    i.recordTimeIdTemp = setInterval((function () {
                                        i.recordTimeTemp++
                                    }
                                    ), 1e3)),
                                ("video" !== i.curType && "audio" !== i.curType || ("video" === i.curType || "audio" === i.curType) && i.isEdge && i.excludeCorpCodeList.indexOf(i.corpCode) > -1) && ("video" !== i.curType && "audio" !== i.curType || i.allowDrag || i.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                                    confirmButtonText: i.$t("v4.js.pc.ocmt.confirm"),
                                    showClose: !1,
                                    dangerouslyUseHTMLString: !0
                                }),
                                    i.recordTimeId = setInterval((function () {
                                        i.recordTime++
                                    }
                                    ), 1e3)),
                                i.recordLearningStatus("ENTER_COURSE_ITEM")
                        }
                        ))
                },
                toggleCollapse: function (e, t) {
                    e.fold = !e.fold,
                        this.$set(this.courseData, t, e)
                },
                startRecord: function () { },
                play: function () {
                    var e = this
                        , t = this;
                    this.isCanPlayInTest(),
                        clearTimeout(this.pausecountTimer),
                        this.pausecountTimer = setTimeout((function () {
                            t.pauseCountTime && t.recordLearningStatus("PLAY")
                        }
                        ), 1e3),
                        ("video" === this.curType || "audio" === this.curType) && (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && (clearInterval(this.recordTimeId),
                            this.recordTimeId = setInterval((function () {
                                e.recordTime++
                            }
                            ), 1e3)),
                        "video" !== this.curType && "audio" !== this.curType || (clearInterval(this.recordTimeIdTemp),
                            this.recordTimeIdTemp = setInterval((function () {
                                e.recordTimeTemp++
                            }
                            ), 1e3)),
                        this.isPlaying = !0,
                        this.videoCheck = !0
                },
                pause: function () {
                    console.log("pause--pause");
                    var e = this;
                    this.pauseCountTime = 0,
                        clearTimeout(this.pausecountTimer),
                        this.pausecountTimer = setTimeout((function () {
                            e.pauseCountTime++,
                                e.recordLearningStatus("PAUSE")
                        }
                        ), 1e3),
                        ("video" === this.curType || "audio" === this.curType) && (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && clearInterval(this.recordTimeId),
                        "video" !== this.curType && "audio" !== this.curType || clearInterval(this.recordTimeIdTemp)
                },
                ended: function () {
                    var e = this;
                    console.log("视频播放完成！章节结束时间"),
                        !this.campData.trainingCampId || this.campData.hasInterest || this.notShowCampAd || (this.campVisible = !0,
                            setTimeout((function () {
                                e.campVisible = !1
                            }
                            ), 2e4)),
                        this.recordLearningStatus("COMPLETE_COURSE_ITEM"),
                        this.getStudyRecordList((function () {
                            e.canSaveRecord = !0
                        }
                        )),
                        this.$nextTick((function () {
                            var t = e.recordList.find((function (t) {
                                return t.resourceId === e.curId
                            }
                            ));
                            !e.isIE11 && !e.isEdge || e.isIE11 && e.excludeCorpCodeList.indexOf(e.corpCode) > -1 && !e.allowDrag && e.recordTime >= e.noPreviewCurTimeToFinish ? (e.mustReplayCanFinish = !1,
                                e.updateCourseRecord(),
                                e.aliPlayer.resetPlayer()) : e.isIE11 && e.excludeCorpCodeList.indexOf(e.corpCode) > -1 && !e.allowDrag && e.recordTime < e.noPreviewCurTimeToFinish && (void 0 === t || 1 !== t.confirmFinish) ? (e.mustReplayCanFinish = !0,
                                    clearInterval(e.recordTimeId),
                                    e.updateCourseRecord()) : (e.mustReplayCanFinish = !1,
                                        e.aliPlayer.resetPlayer()),
                                e.isPlaying = !1,
                                e.isReplayBtn = !0,
                                setTimeout((function () {
                                    e.isPlaying || "preview" === e.$route.query.from || "unionpay" !== e.corpCode || e.playNextSection()
                                }
                                ), 1e3)
                        }
                        ))
                },
                ready: function () {
                    this.curTimeToFinish = Math.round(this.player.getDuration() * this.courseData[this.curIndex[0]].finishPercent),
                        this.noPreviewCurTimeToFinish = Math.round(.5 * this.player.getDuration());

                    var e = this;

                    /// ===========================================================
                    /// NicolasLemon - 修改1：修改seek和当前学习时间指向最小学习时间
                    e.seek = this.curTimeToFinish + 10;
                    e.curTime.currentStudyTime = this.curTimeToFinish + 10;
                    /// ===========================================================

                    "video" != this.curType && "audio" != this.curType || document.getElementsByClassName("rate-list").length && document.getElementsByClassName("rate-list")[0].addEventListener("click", (function (t) {
                        var i = t.target.innerText.replace("x", "");
                        e.studyLogData.studyLogVO.mark = i,
                            e.recordLearningStatus("SPEED_CHANGE")
                    }
                    ))
                },
                timeupdate: function () {
                    var e = this;
                    if (this.videoCheck && ("video" === this.curType || "audio" === this.curType)) {
                        var t = Math.floor(this.player.getCurrentTime() + .1)
                            , i = this.recordList.find((function (t) {
                                return t.resourceId === e.curId
                            }
                            ));

                        /// ==================================================
                        /// NicolasLemon - 修改2：初始化进度条的位置，指向seek
                        if (t < this.seek) {
                            this.player.seek(this.seek);
                            t = this.seek;
                        }
                        /// ==================================================

                        if (t > this.seek && t - this.seek > 3 && (void 0 === i || 1 !== i.confirmFinish) && !this.allowDrag && "preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                            /// ==================================================
                            /// NicolasLemon - 修改3：破解进度条不可向前拖动的问题
                            // this.player.seek(this.seek);
                            this.player.seek(t);
                            /// ==================================================
                        }
                        else {
                            var s = t > 2 ? t : 0;
                            this.seek = Math.max(this.seek, s)
                        }
                        (void 0 === i || 1 !== i.confirmFinish) && (t > this.curTimeToFinish || this.minStudyTime === this.recordTimeTemp) && (!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.allowDrag) && (this.canRecord && (this.updateCourseRecord(),
                            this.canRecord = !1),
                            clearTimeout(this.TimeId1),
                            this.TimeId1 = setTimeout((function () {
                                e.canRecord = !0
                            }
                            ), 1e3)),
                            t !== this.curTimeToFinish && (0 === t || t % 180 !== 0 && this.minStudyTime !== this.recordTimeTemp) || !(!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.allowDrag) || (this.canRecord && (this.updateCourseRecord(),
                                this.canRecord = !1),
                                clearTimeout(this.TimeId1),
                                this.TimeId1 = setTimeout((function () {
                                    e.canRecord = !0
                                }
                                ), 1e3))
                    }
                },
                rePlay: function () {
                    this.resetHandoutAndVideo(),
                        this.player.seek(0),
                        this.isPlaying = !0,
                        this.seek = 0,
                        this.play(),
                        this.isReplayBtn = !1,
                        this.recordTime = 0,
                        this.recordTimeTemp = 0
                },
                playNextSection: function () {
                    var e = this;
                    this.resetHandoutAndVideo(),
                        this.isPlaying = !0,
                        this.updateCourseRecord(),
                        this.$nextTick((function () {
                            e.curType = e.nextInfo.resourceType,
                                e.minStudyTime = e.nextInfo.minStudyTime,
                                e.curId = e.nextId,
                                e.curIndex = e.nextIndex ? e.nextIndex.slice(0) : null;
                            var t = e.recordList.find((function (t) {
                                return t.resourceId === e.curId
                            }
                            ));
                            void 0 !== t && null !== t.currentPosition && 1 !== t.confirmFinish ? e.seek = t.currentPosition : e.seek = 0,
                                "video" !== e.curType && "audio" !== e.curType || (e.isVideo = !0,
                                    e.$refs.aliPlayer.aliPlayer()),
                                ("video" !== e.curType && "audio" !== e.curType || ("video" === e.curType || "audio" === e.curType) && e.isEdge && e.excludeCorpCodeList.indexOf(e.corpCode) > -1) && ("video" !== e.curType && "audio" !== e.curType || e.allowDrag || e.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                                    confirmButtonText: e.$t("v4.js.pc.ocmt.confirm"),
                                    showClose: !1,
                                    dangerouslyUseHTMLString: !0
                                }),
                                    e.recordTime = 0,
                                    e.recordTimeId = setInterval((function () {
                                        e.recordTime++
                                    }
                                    ), 1e3))
                        }
                        ))
                },
                writeRecordWhileClose: function () {
                    var e = this;
                    if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                        this.recordLearningStatus("QUIT_STUDY");
                        var t = this.recordList.find((function (t) {
                            return t.resourceId === e.curId
                        }
                        ))
                            , i = void 0 !== t ? t.recordId : null;
                        this.endTime = Date.now(),
                            this.continueTime = this.endTime - this.startTime;
                        var s = 0;
                        "video" !== this.curType && "audio" !== this.curType || ((this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish) && (s = this.recordTime),
                            s = this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish ? this.curTimeToFinish : Math.round(Math.max(this.seek, this.player.getCurrentTime())));
                        var n = {
                            recordId: i,
                            courseId: this.courseId,
                            sourceId: this.sourceId,
                            providerCorpCode: this.providerCorpCode,
                            chapterId: this.curChapterId,
                            resourceId: this.curId,
                            timeToFinish: this.curTimeToFinish,
                            currentPosition: s,
                            type: this.curType,
                            currentStudyTime: "video" === this.curType || "audio" == this.curType ? this.recordTimeTemp - this.curTime.currentStudyTime : this.recordTime,
                            pageIndex: "video" !== this.curType && "audio" === this.curType && this.$refs.aliPreview ? this.$refs.aliPreview.currentCount : 0
                        };
                        if (navigator.sendBeacon) {
                            var a = {
                                type: "text/plain; charset=UTF-8"
                            }
                                , o = new Blob([JSON.stringify(n)], a);
                            navigator.sendBeacon("/tbc-rms/record/writeRecordWhileClose", o)
                        } else {
                            var r = new XMLHttpRequest;
                            r.open("POST", "/tbc-rms/record/writeRecordWhileClose", !0),
                                r.setRequestHeader("Content-Type", "application/json"),
                                r.send(JSON.stringify(n))
                        }
                    }
                },
                registerClosePageEvent: function () {
                    window.addEventListener("beforeunload", this.writeRecordWhileClose)
                },
                handlePause: function (e) {
                    var t = e.target.tagName;
                    "Space" === e.code && "TEXTAREA" !== t && (this.checkoutStatus(!1),
                        e.preventDefault())
                },
                registerSpaceEvent: function () {
                    document.addEventListener("keydown", this.handlePause)
                },
                checkoutStatus: function (e) {
                    "video" !== this.curType && "audio" !== this.curType || !this.player || (!e || "VIDEO" !== e.target.tagName) && e || document.querySelector(".prism-play-btn").click()
                },
                checkBrowerIsEdgeAndIE11: function () {
                    var e = window.navigator.userAgent
                        , t = function () {
                            return "ActiveXObject" in window
                        }();
                    t && (this.isIE11 = !0),
                        e.indexOf("Edge/") > 0 && (this.isEdge = !0);
                    return t && this.excludeCorpCodeList.indexOf(this.corpCode) < 0 && (!localStorage.getItem("IETipsTime") || Object(M["getCurrentDateFormat"])(new Date, "yyyyMMdd") > localStorage.getItem("IETipsTime")) ? (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过IE浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                        confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                        showClose: !1,
                        showCancelButton: !0,
                        cancelButtonText: "今日不再提醒",
                        dangerouslyUseHTMLString: !0
                    }).then((function () { }
                    )).catch((function () {
                        localStorage.setItem("IETipsTime", Object(M["getCurrentDateFormat"])(new Date, "yyyyMMdd"))
                    }
                    )),
                        !0) : e.indexOf("Edge/") > 0 && this.excludeCorpCodeList.indexOf(this.corpCode) < 0 && (!localStorage.getItem("IETipsTime") || Object(M["getCurrentDateFormat"])(new Date, "yyyyMMdd") > localStorage.getItem("IETipsTime")) ? (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过Edge浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                            confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                            showClose: !1,
                            showCancelButton: !0,
                            cancelButtonText: "今日不再提醒",
                            dangerouslyUseHTMLString: !0
                        }).then((function () { }
                        )).catch((function () {
                            localStorage.setItem("IETipsTime", Object(M["getCurrentDateFormat"])(new Date, "yyyyMMdd"))
                        }
                        )),
                            !0) : e.indexOf("Safari") > -1 && e.indexOf("Chrome") < 0 && (!localStorage.getItem("IETipsTime") || Object(M["getCurrentDateFormat"])(new Date, "yyyyMMdd") > localStorage.getItem("IETipsTime")) && (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过Safari浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                                confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                                showClose: !1,
                                showCancelButton: !0,
                                cancelButtonText: "今日不再提醒",
                                dangerouslyUseHTMLString: !0
                            }).then((function () { }
                            )).catch((function () {
                                localStorage.setItem("IETipsTime", Object(M["getCurrentDateFormat"])(new Date, "yyyyMMdd"))
                            }
                            )),
                                !0)
                },
                clickCloseSaveRecord: function () {
                    var e = this;
                    window.addEventListener("message", (function (t) {
                        try {
                            var i = JSON.parse(t.data)
                        } catch (s) {
                            return
                        }
                        switch (i.action) {
                            case "studyRecordWhileClose":
                                e.writeRecordWhileClose(),
                                    window.parent.postMessage(t.data, "*"),
                                    console.log("处理成功，返回消息！");
                                break
                        }
                    }
                    ), !1)
                },
                getSystemSeting: function () {
                    var e = this
                        , t = {
                            courseId: this.courseId,
                            eln_session_id: Object(M["getUrl"])("eln_session_id")
                        };
                    c["c"].loadCourseSystemSeting(t).then((function (t) {
                        "1001" == t.code && (t.bizResult.checkType && (e.checkType = t.bizResult.checkType,
                            e.maxTime = t.bizResult.preventCheatTimeTo,
                            e.minTime = t.bizResult.preventCheatTime,
                            e.preventCheatTime = (Math.random() * (t.bizResult.preventCheatTimeTo - t.bizResult.preventCheatTime) + t.bizResult.preventCheatTime).toFixed(1),
                            e.verificationType = "preventCheat",
                            e.preventCheatFlag = !0),
                            t.bizResult.enablePreventHang && (e.verificationType = "hangUp",
                                e.hangUpFlag = !0,
                                e.preventHangTime = t.bizResult.preventHangTime),
                            !t.bizResult.heartBeat || e.curInfo.finish && !t.bizResult.continueHeartBeat || (e.heartBeatFlag = !0,
                                e.$refs.aliPlayer.addVideoClick()))
                    }
                    ))
                },
                isReady: function () {
                    ("video" == this.curType || "audio" === this.curType) && this.addVideoClickFlag && this.$refs.preventCheat && this.$refs.preventCheat.addVideoClick(),
                        "preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview ? (this.addVideoClickFlag = !0,
                            this.getSystemSeting()) : this.$refs.aliPlayer && this.$refs.aliPlayer.addVideoClick()
                },
                pauseOrPlay: function (e) {
                    this.isVideo && (!e && this.player ? this.player.pause() : this.player.play())
                },
                saveStudyLog: function (e) {
                    this.recordLearningStatus(e)
                },
                recordLearningStatus: function (e) {
                    if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                        "PREVENT_HANG_LOGOUT" == e && window.removeEventListener("beforeunload", this.writeRecordWhileClose),
                            "ENTER_STUDY" == e && (this.firstEnterStudyFlag = !0),
                            this.studyLogData.studyLogVO.minStudyTime = null == this.curInfo.minStudyTime ? "" : this.curInfo.minStudyTime,
                            this.studyLogData.eventType = e,
                            this.studyLogData.studyLogVO.courseItemId = this.curId,
                            this.studyLogData.studyLogVO.courseItemName = this.curInfo.resourceName,
                            this.studyLogData.studyLogVO.courseId = this.courseId,
                            this.studyLogData.studyLogVO.courseTitle = parent.title;
                        try {
                            this.studyLogData.studyLogVO.videoDuration = "video" != this.curType && "audio" !== this.curType || !this.player ? "" : Math.floor(1e3 * this.player.getDuration())
                        } catch (i) {
                            console.log(i)
                        }
                        var t = JSON.parse(JSON.stringify(this.studyLogData));
                        c["c"].saveStudyLog(this.courseId, t).then((function (e) { }
                        ))
                    }
                },
                getCourseSetting: function () {
                    var e = this
                        , t = {
                            courseId: this.courseId
                        };
                    c["b"].APIshowCourseSetting(t).then((function (t) {
                        e.allowDrag = 1 == t.bizResult.allowDrag,
                            e.allowHighSpeed = 1 == t.bizResult.allowHighSpeed,
                            e.allowMinStudyTime = 1 == t.bizResult.allowMinStudyTime
                    }
                    ))
                },
                playOrPauseReordTime: function (e) {
                    var t = this;
                    e ? clearInterval(this.recordTimeId) : this.recordTimeId = setInterval((function () {
                        t.recordTime++
                    }
                    ), 1e3),
                        e ? clearInterval(this.recordTimeIdTemp) : this.recordTimeIdTemp = setInterval((function () {
                            t.recordTimeTemp++
                        }
                        ), 1e3)
                },
                handletabClick: function (e, t) {
                    var i = this;
                    this.$nextTick((function () {
                        i.navMsg = "myNote",
                            i.isCreateNote = !1;
                        var s = document.querySelector("#el-tabsA .el-tabs__active-bar");
                        "preview" !== i.$route.query.from ? "contents" === e.name ? s.style = "transform:translateX(".concat(t.target.offsetLeft + (t.target.clientWidth - 16 - 20) / 2 + 10, "px)!important") : "note" === e.name ? s.style = "transform:translateX(".concat(t.target.offsetLeft + (t.target.clientWidth - 16) / 2, "px)!important") : "QA" === e.name && (s.style = "transform:translateX(".concat(t.target.offsetLeft + (t.target.clientWidth - 16 - 20) / 2 + 10, "px)!important")) : "contents" === e.name && (s.style = "transform:translateX(".concat(t.target.offsetLeft + t.target.clientWidth / 2 - 7, "px)!important"))
                    }
                    ))
                },
                uploadImageFile: function (e) {
                    var t = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function i() {
                        var s, n, a, o, r;
                        return regeneratorRuntime.wrap((function (i) {
                            while (1)
                                switch (i.prev = i.next) {
                                    case 0:
                                        s = 0;
                                    case 1:
                                        if (!(s <= e.length - 1)) {
                                            i.next = 11;
                                            break
                                        }
                                        return n = e[s],
                                            i.next = 5,
                                            t.uploadFileProcess(n);
                                    case 5:
                                        a = i.sent,
                                            o = JSON.parse(a),
                                            r = o.bizResult,
                                            t.uploadList.push(nt(nt({}, r), {}, {
                                                name: n.name,
                                                size: n.size,
                                                type: n.type
                                            }));
                                    case 8:
                                        s++,
                                            i.next = 1;
                                        break;
                                    case 11:
                                        t.isUploadImage = !0;
                                    case 12:
                                    case "end":
                                        return i.stop()
                                }
                        }
                        ), i)
                    }
                    )))()
                },
                uploadFileProcess: function (e) {
                    var t = window.$cookies.get("corpCode")
                        , i = window.$cookies.get("eln_session_id")
                        , s = "text/plain"
                        , n = "bgImage"
                        , a = !0
                        , o = "NO_OPT"
                        , r = "qa_wenda"
                        , c = "pic"
                        , l = 0;
                    return new Promise((function (u, d) {
                        var h = new XMLHttpRequest;
                        h.open("post", "".concat(origin, "/tbc-rms/video/uploadFileToProcess?corpCode=").concat(t, "&eln_session_id=").concat(i, "&responseFormat=").concat(s, "&processor=").concat(n, "&system=").concat(a, "&processType=").concat(o, "&uploadedFrom=").concat(r, "&resourceClass=").concat(c, "&categoryId=").concat(l));
                        var m = new FormData;
                        m.append("multipartFile", e),
                            m.append("current_app_id", window.sessionStorage.getItem("current_app_id")),
                            h.onreadystatechange = function () {
                                4 == h.readyState && 200 == h.status && u(h.responseText)
                            }
                            ,
                            h.send(m)
                    }
                    ))
                },
                saveQuestion: function () {
                    if (this.isUploadImage)
                        if (this.QAformData.title) {
                            this.topicData.push(this.courseTitle);
                            var e = {
                                title: this.QAformData.title,
                                content: this.QAformData.content,
                                topic: this.topicData.join(",")
                            }
                                , t = this
                                , i = new FormData;
                            i.append("question.title", e.title),
                                i.append("question.content", e.content),
                                i.append("question.topic", e.topic),
                                this.uploadList.forEach((function (e, t) {
                                    i.append("question.attachmentList[".concat(t, "].storeFileId"), e.url || ""),
                                        i.append("question.attachmentList[".concat(t, "].storeFileName"), e.fileName || e.name || ""),
                                        i.append("question.attachmentList[".concat(t, "].resourceId"), e.resourceId || ""),
                                        i.append("question.attachmentList[".concat(t, "].attachmentType"), "PICTURE")
                                }
                                ));
                            var s = new XMLHttpRequest
                                , n = window.location.origin;
                            s.open("post", "".concat(n, "/els/html/course/courseStudy.courseAskPublishJson.do")),
                                s.send(i),
                                s.onreadystatechange = function () {
                                    4 == s.readyState && 200 == s.status && (t.$message({
                                        message: t.$t("v4.js.pc.ocmt.Successful"),
                                        type: "success"
                                    }),
                                        t.QAformData = {},
                                        t.topicData = [],
                                        t.uploadList = [],
                                        t.showChoiceVisible = !1)
                                }
                        } else
                            this.$message({
                                message: this.$t("v4.js.pc.ocmt.QuestionEmpty"),
                                type: "error"
                            });
                    else
                        this.$message.warning("图片上传中...请稍等！")
                },
                inputFocus: function () {
                    this.showPlaceholder = !1
                },
                inputBlur: function () {
                    this.showPlaceholder = !0,
                        this.inputTopicText && (this.topicData.push(this.inputTopicText),
                            this.inputTopicText = "")
                },
                deleteTopicItem: function (e) {
                    this.topicData.splice(e, 1)
                },
                getRelativeQuestion: function () {
                    var e, t = this, i = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>《》/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？ ]");
                    e = i.test(this.courseTitle) ? "" : this.courseTitle,
                        c["c"].relativeQuestionJson(e).then((function (e) {
                            e && 1001 === e.code && (t.questionData = e.bizResult.rows || [])
                        }
                        ))
                },
                goToQuestion: function (e) {
                    var t = window.location.origin
                        , i = Object(M["getUrl"])("eln_session_id");
                    window.open("".concat(t, "/qa/html/question.do?elsSign=").concat(i, "&questionId=").concat(e))
                },
                handleTabChange: function (e) {
                    this.QAactiveName = e,
                        "relatedQuestion" === e && this.getRelativeQuestion()
                },
                getMyNoteAndOtherNoteList: function (e, t) {
                    var i = this
                        , s = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : "init";
                    "init" === s && (this.myNoteCondition.pageNo = 1,
                        this.otherNoteCondition.pageNo = 1,
                        t.pageNo = 1);
                    var n = {
                        courseId: this.courseId,
                        processType: e,
                        page: {
                            pageNo: t.pageNo,
                            pageSize: t.pageSize
                        }
                    };
                    x(n).then((function (t) {
                        var s = t.bizResult;
                        "me" === e ? i.myNotes = s || [] : "other" === e && (i.otherNotes = s || [])
                    }
                    ))
                },
                isCanPlayInTest: function () {
                    var e, t = this.$route.query.from, i = "preview" === t;
                    if (i || !this.isVideo || !this.infixTests.length)
                        return !0;
                    var s = Fe["a"].currentTime
                        , n = null === (e = this.infixTests) || void 0 === e ? void 0 : e.some((function (e) {
                            var t = e.popupTime
                                , i = e.userState
                                , n = e.mandatoryTest;
                            return n && "PASS" !== i && t === s
                        }
                        ));
                    return n && (ke["a"].destroy(),
                        ke["a"].info("请先完成随堂测试"),
                        Fe["a"].player.pause()),
                        !n
                },
                onTagClick: function (e, t, i) {
                    var s = this.$route.query.from;
                    this.infixTest = e.data,
                        this.$refs.aliPlayer.pause(),
                        this.$refs.courseTest.show({
                            infixTest: e,
                            testList: t,
                            isTag: !0,
                            time: i,
                            isVideo: this.isVideo,
                            isPreview: "preview" === s
                        })
                },
                onStartDocumentTest: function () {
                    var e = this.$route.query.from
                        , t = "preview" === e;
                    this.currentStudyTime > 0 && !t ? ke["a"].info("还需观看".concat(Object(M["TimeToString"])(this.currentStudyTime), "并完成随堂测试后完成学习")) : this.$refs.courseTest.show({
                        infixTest: {
                            data: this.infixTests[0],
                            offset: 1
                        },
                        time: 100,
                        isVideo: this.isVideo,
                        isPreview: t
                    })
                },
                onTimeMatch: function (e) {
                    var t, i = this;
                    console.log("infixTest:", e);
                    var s = this.$route.query.from
                        , n = null === e || void 0 === e || null === (t = e.data) || void 0 === t ? void 0 : t.userState;
                    "preview" !== s && "PASS" === n || (this.$refs.aliPlayer.pause(),
                        Object(M["exitFullscreen"])(document.querySelector("#J_prismPlayer video")),
                        setTimeout((function () {
                            i.$refs.courseTest.show({
                                infixTest: e,
                                isVideo: i.isVideo,
                                isPreview: "preview" === s
                            })
                        }
                        ), 0))
                },
                onCompleteSeek: function (e) {
                    var t = this.$route.query.from;
                    if ("preview" !== t) {
                        var i = e.filter((function (e) {
                            var t = (null === e || void 0 === e ? void 0 : e.data) || {}
                                , i = t.userState
                                , s = t.mandatoryTest;
                            return "PASS" !== i && s
                        }
                        ));
                        if (i.length) {
                            i.sort((function (e, t) {
                                return e.offset - t.offset
                            }
                            ));
                            var s = i[0].offset - 1;
                            s = s < 0 ? 0 : s,
                                this.$refs.aliPlayer.player.seek(s),
                                ke["a"].info("请先完成随堂测试")
                        }
                    }
                },
                updateInFixTest: function (e) {
                    var t = !0
                        , i = this.infixTests.map((function (i) {
                            return i.infixSettingId === e.infixSettingId ? "PASS" === i.userState ? i : ("PASS" !== e.userState && (t = !1),
                                e) : ("PASS" !== e.userState && (t = !1),
                                    i)
                        }
                        ));
                    i = Object.assign([], i),
                        this.courseData[this.curIndex[0]] && (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].infixTests = i),
                        this.infixTests = Object.assign([], i);
                    var s = {
                        NO_JOIN: "未完成",
                        NO_PASS: "未完成",
                        PASS: "已完成"
                    };
                    this.isVideo && (Fe["a"].generalTestList(i.map((function (e) {
                        return nt(nt({}, e), {}, {
                            userStateText: s[e.userState],
                            userStateColor: "#1888FF"
                        })
                    }
                    ))),
                        Fe["a"].setPrismTag()),
                        t && this.updateCourseRecord("", "clear")
                },
                getCampData: function () {
                    var e = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function t() {
                        var i;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1)
                                switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2,
                                            R(e.courseId);
                                    case 2:
                                        if (i = t.sent,
                                            i.success) {
                                            t.next = 5;
                                            break
                                        }
                                        return t.abrupt("return", e.$message.error(i.message));
                                    case 5:
                                        e.campData = i.data,
                                            i.data.trainingCampId && (i.data.hasInterest || setTimeout((function () {
                                                e.showCamp = !0
                                            }
                                            ), 3e3),
                                                e.queryTodayCampShow());
                                    case 7:
                                    case "end":
                                        return t.stop()
                                }
                        }
                        ), t)
                    }
                    )))()
                },
                addHits: function () {
                    var e = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function t() {
                        var i;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1)
                                switch (t.prev = t.next) {
                                    case 0:
                                        return t.next = 2,
                                            F({
                                                trainingCampId: e.campData.trainingCampId
                                            });
                                    case 2:
                                        i = t.sent,
                                            console.log(i);
                                    case 4:
                                    case "end":
                                        return t.stop()
                                }
                        }
                        ), t)
                    }
                    )))()
                },
                queryTodayCampShow: function () {
                    var e = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function t() {
                        var i, s;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1)
                                switch (t.prev = t.next) {
                                    case 0:
                                        return i = {
                                            trainingCampId: e.campData.trainingCampId,
                                            courseId: e.courseId
                                        },
                                            t.next = 3,
                                            N(i);
                                    case 3:
                                        if (s = t.sent,
                                            s.success) {
                                            t.next = 6;
                                            break
                                        }
                                        return t.abrupt("return", e.$message.error(s.message));
                                    case 6:
                                        e.notShowCampAd = s.data || !1;
                                    case 7:
                                    case "end":
                                        return t.stop()
                                }
                        }
                        ), t)
                    }
                    )))()
                },
                closeCampAd: function () {
                    var e = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function t() {
                        var i, s;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1)
                                switch (t.prev = t.next) {
                                    case 0:
                                        if (e.campVisible = !1,
                                            !e.notShowCampAd) {
                                            t.next = 8;
                                            break
                                        }
                                        return i = {
                                            trainingCampId: e.campData.trainingCampId,
                                            courseId: e.courseId,
                                            hasPrompt: !0
                                        },
                                            t.next = 5,
                                            O(i);
                                    case 5:
                                        if (s = t.sent,
                                            s.success) {
                                            t.next = 8;
                                            break
                                        }
                                        return t.abrupt("return", e.$message.error(s.message));
                                    case 8:
                                    case "end":
                                        return t.stop()
                                }
                        }
                        ), t)
                    }
                    )))()
                },
                toggleInterest: function () {
                    var e = this;
                    return Object(a["a"])(regeneratorRuntime.mark((function t() {
                        var i, s;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1)
                                switch (t.prev = t.next) {
                                    case 0:
                                        return i = e.campData.hasInterest ? j : B,
                                            t.next = 3,
                                            i({
                                                trainingCampId: e.campData.trainingCampId
                                            });
                                    case 3:
                                        if (s = t.sent,
                                            s.success) {
                                            t.next = 6;
                                            break
                                        }
                                        return t.abrupt("return", e.$message.error(s.message));
                                    case 6:
                                        e.campData.hasInterest = !e.campData.hasInterest;
                                    case 7:
                                    case "end":
                                        return t.stop()
                                }
                        }
                        ), t)
                    }
                    )))()
                },
                goTrainingCamp: function () {
                    var e = location.origin;
                    window.open(e + "/frontend-page/trainingCampDetail/" + this.campData.trainingCampId)
                }
            },
            beforeDestroy: function () {
                clearInterval(this.heartTimer),
                    document.removeEventListener("keyup", this.handlePause),
                    this.timer && clearInterval(this.timer)
            },
            destroyed: function () {
                window.removeEventListener("beforeunload", this.writeRecordWhileClose),
                    this.timer && clearInterval(this.timer)
            },
            created: function () {
                var e = this;
                this.getCourseSetting(),
                    this.$nextTick((function () {
                        var t = document.querySelector("#el-tabsA .el-tabs__active-bar")
                            , i = document.querySelector(".el-tabs__item").clientWidth;
                        "preview" !== e.$route.query.from ? t.style = "transform:translateX(".concat(i / 2 - 17 + 10, "px)!important") : t.style = "transform:translateX(".concat(i / 2 - 7, "px)!important")
                    }
                    ))
            },
            mounted: function () {
                var e = this;
                this.coursePlayBoxHeight = document.getElementsByClassName("player-container")[0].offsetWidth / 1.777 + 128 + "px",
                    window.addEventListener("resize", (function () {
                        document.getElementsByClassName("course-play-container")[0].style.height = document.getElementsByClassName("player-container")[0].offsetWidth / 1.777 + 128 + "px"
                    }
                    )),
                    this.corpCode = window.$cookies.get("corp_code") || window.$cookies.get("corpCode"),
                    this.registerClosePageEvent(),
                    this.registerSpaceEvent(),
                    this.clickCloseSaveRecord(),
                    this.$store.dispatch("nav1/fetchGetAuthCorpsAction", {
                        type: 0
                    }).then((function (t) {
                        e.excludeCorpCodeList = t,
                            e.pcEdgeBrowerPreview = e.checkBrowerIsEdgeAndIE11(),
                            e.syncStudyRecord(),
                            e.getCourseData(),
                            e.getStudyRate(),
                            e.getRelativeQuestion(),
                            e.startTime = Date.now()
                    }
                    )),
                    this.getCourseInfo(),
                    this.getCourseDiscuss("init"),
                    l["a"].getUserInfo().then((function (t) {
                        e.userInfo = t.bizResult
                    }
                    )),
                    this.queryReferences(),
                    this.getMyNoteAndOtherNoteList("me", this.myNoteCondition),
                    D({
                        courseId: this.courseId
                    }).then((function (t) {
                        var i = t.bizResult;
                        e.isbizResultShow = i
                    }
                    )),
                    this.getCampData()
            }
        }
            , ot = at
            , rt = (i("bf68"),
                i("c206"),
                Object(W["a"])(ot, s, n, !1, null, "107d2548", null));
        t["default"] = rt.exports
    },
    dfcd: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAARZJREFUOBHlkkFLAkEUgHdyDx3VDoKQ4E0Jb56DTCgKoYN4qR8R/Y7wFP0LIdglwpOHDt77A0t1SAxPHrqt3yxvhp1xQe8NfL5533sz485uEHgjTdMh3Hg6wN3Bpe8PfEGum7YacdfQB2cUbeA07EqcDfiLIQsasCpY+ItrSY8th4hzsp6YE2IVXiXPhwnJI8SsSaTwpk88hraIH+KTUupdchtwMxbeIwZwJIWSbfjHE8XFnPH85i0smL9wYd9Fd0JvF38FFalP9VtoQkfEBXFE4y2bfInLAu6UyRjWYA4oZ0XzQ1MD5vBgnIm4Z4jg0DgdnS+RUz9xCdTBHzXEBz1/+YKzQb6w71zfgT9ixNKX5BGYZ7flDQm0WV3DIlGvAAAAAElFTkSuQmCC"
    },
    f99f: function (e, t, i) {
        "use strict";
        var s = i("6710")
            , n = i.n(s);
        n.a
    }
}]);
