var saveProgressInter, //定时器
    threeScreenPlayerStateInterval,
    interval, //定时器时长（单位:秒）
    rate = rate, //比率（progressMeasure）
    vbox_server = "",
    fromNetWorkSetting = false,
    logId = '',
    hasSwitch = "",
    vboxSelectVideo;
var wmv_inter,
    wmv_inter_a,
    updateStudiedTime,
    testIsVideoPlaying;
var preventCheatInterval;
var _timmout = 1;
var errorMsg = '网络连接中断';

var studyCourse;

var asyncBrowser = isAsync();
// 心跳逻辑
var isheart = false;//是否开启心跳
var isCompleted = false; //是否看完视频
var iscontinueHeartBeat = false;//学完是否开启心跳
var heartInterval;//心跳定时器
var heartApifun = function () {
    console.log('发起心跳请求fun');
    // $.get(window.location.origin + "/ubr/heartbeat/beat?courseId="+ info.courseId);
    $.ajax({
        type: "POST",
        dataType: 'json',
        contentType: "application/json;charset=utf-8",
        url: window.location.origin + '/bdc/log/universalInterf',
        data: JSON.stringify({
            'study_heartbeat': {
                'course_id': info.courseId,
                'corp_code': info.corpCode,
                'user_id': window.CONFIG.userId
            }
        })
    });
};
/**
 * 设置cookie
 * @param {string} name  键名
 * @param {string} value 键值
 * @param {integer} days cookie周期
 */
var cookieUtil = {
    setCookie: function (name, value, days) {
        var expires;
        if (days) {
            var date = new Date();
            date.setTime(date.getTime() + (days * 10 * 60 * 1000));
            expires = "; expires=" + date.toGMTString();
        } else {
            expires = "";
        }
        document.cookie = name + "=" + value + expires + "; path=/";
    },

    getCookie: function (name) {
        var nameEQ = name + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1, c.length);
            if (c.indexOf(nameEQ) == 0) return c.substring(nameEQ.length, c.length);
        }
        return null;
    },

    deleteCookie: function (name) {
        cookieUtil.setCookie(name, "", -1);
    }

}

//阿里视频器播放错误
var videoErrStatus = false;
window.errorEvent = function (e, params) {
    console.log('errorEventerrorEvent', params);
    videoErrStatus = true;
};

//阿里视频器 视频播放状态
var videoPlay = {};
window.aliplayerApi = function (e, params) {
    console.log('aliplayerApi', params);
    videoPlay = params;
};
//训练营计时器
var trainingCampPromptTimer = null
function setTrainingCampPromptTimer(time = 20000) {
    trainingCampPromptTimer = setTimeout(closeTrainingCampPrompt, time)
}
function showTrainingCamp(isEnd) {
    if (isTrainingCampPrompt) {
        if (!isCompleted) {//已经学完不再弹出
            let courseStandard = $('#standard').val();
            console.log(courseStandard, 'courseStandard')
            if (courseStandard === 'TWOSCREEN' || courseStandard === 'ONESCREEN') {//单分屏和双分屏结束不弹出，三分屏结束弹出
                if (!isEnd) {
                    if (trainingCampData.trainingCampId && (hasInterest != 'true' || hasInterest != true)) {
                        $('html').css({ height: '100vh', overflow: 'hidden' })
                        $('.training-camp-mask').show()
                        setTrainingCampPromptTimer()
                    }
                }
            } else {//三分屏结尾弹出
                if (isEnd) {
                    if (trainingCampData.trainingCampId && (hasInterest != 'true' || hasInterest != true)) {
                        $('html').css({ height: '100vh', overflow: 'hidden' })
                        $('.training-camp-mask').show()
                        setTrainingCampPromptTimer()
                    }
                }
            }
        }
    }
}
function showNetErrorTip(erroxrMsg) {
    ncp.successTip("", {
        title: "",
        time: 180000,
        skin: "ncp-time-tip ncp-fail-tip",
        closeBtn: false,
        btn: false,
        content: "<div style='font-size: 14px;margin: 5px 10px; padding: 5px 0px;'>" + '<div style="float:left;background: url(/web-static/assets/courseV2/img/error_tip.png) no-repeat;background-size: 20px 20px;text-indent: 25px;">当前网络状态不佳，学习记录保存失败。请点击“关闭”退出课程后，再次进入课程继续学习！</div>' + '<div style="float: right;color: #15A9F0" onclick="alertErrorMsg(errorMsg)">查看错误信息</div><div style="clear: both"></div>' + "</div>"
    })
}
function alertErrorMsg(errorMsg) {
    var html_ = '<div style="width: 320px; background: white;position: fixed;left: 0;right: 0;top: 0;bottom: 0;z-index: 999;margin: auto;height: 300px;" id="errorMsgTip"><div style="background: #558AD6;color: white;padding: 10px 10px;">错误信息</div><div style="height: 320px;background: white;overflow-y: scroll;word-wrap: break-word;padding: 0px 15px;padding-left: 25px;margin-top: 15px;font-size: 13px" class="tipContent">' + errorMsg + '</div><div style="padding: 10px 50px;background: white;"><div style="padding: 5px 10px;background: #558AD6;color: white;float: right;cursor: pointer;"onclick="hideErrorTip()">确认</div><div style="clear: both;"></div></div></div>'
    $('body').append(html_);
}
function hideErrorTip() {
    $('#errorMsgTip').remove();
}
function myBrowser() {
    var userAgent = navigator.userAgent;
    if (userAgent.indexOf("Chrome") > -1) {
        return "Chrome";
    }
    if (userAgent.indexOf("Firefox") > -1) {
        return "Firefox";
    } //判断是否Firefox浏览器
    if (userAgent.indexOf("Safari") > -1) {
        return "Safari";
    } //判断是否Safari浏览器
    if (userAgent.indexOf("compatible") > -1 && userAgent.indexOf("MSIE") > -1 && !isOpera) {
        return "IE";
    }; //判断是否IE浏览器
    if (userAgent.indexOf("Opera") > -1) {
        return "Opera"
    }; //判断是否Opera浏览器
    return "UNKNOWN";
}
//是否使用同步ajax，已发现高版本谷歌禁用同步ajax
//返回true使用异步ajax
function isAsync() {
    var userAgent = navigator.userAgent;
    if (userAgent.indexOf("Chrome") > -1) {
        return true;
    }
    return false;
}
if (!window.JSON) {
    window.JSON = {
        parse: function (jsonStr) {
            return eval('(' + jsonStr + ')');
        },
        stringify: function (jsonObj) {
            var result = '',
                curVal;
            if (jsonObj === null) {
                return String(jsonObj);
            }
            switch (typeof jsonObj) {
                case 'number':
                case 'boolean':
                    return String(jsonObj);
                case 'string':
                    return '"' + jsonObj + '"';
                case 'undefined':
                case 'function':
                    return undefined;
            }

            switch (Object.prototype.toString.call(jsonObj)) {
                case '[object Array]':
                    result += '[';
                    for (var i = 0, len = jsonObj.length; i < len; i++) {
                        curVal = JSON.stringify(jsonObj[i]);
                        result += (curVal === undefined ? null : curVal) + ",";
                    }
                    if (result !== '[') {
                        result = result.slice(0, -1);
                    }
                    result += ']';
                    return result;
                case '[object Date]':
                    return '"' + (jsonObj.toJSON ? jsonObj.toJSON() : jsonObj.toString()) + '"';
                case '[object RegExp]':
                    return "{}";
                case '[object Object]':
                    result += '{';
                    for (i in jsonObj) {
                        if (jsonObj.hasOwnProperty(i)) {
                            curVal = JSON.stringify(jsonObj[i]);
                            if (curVal !== undefined) {
                                result += '"' + i + '":' + curVal + ',';
                            }
                        }
                    }
                    if (result !== '{') {
                        result = result.slice(0, -1);
                    }
                    result += '}';
                    return result;

                case '[object String]':
                    return '"' + jsonObj.toString() + '"';
                case '[object Number]':
                case '[object Boolean]':
                    return jsonObj.toString();
            }
        }
    };
}

define(function (require, exports, module) {
    function getVideoSec(type) {//获取视频播放时长
        var timedom;
        var aliobj = document.getElementById("iframe_aliplayer").contentWindow;
        if (type == 'sum') {
            timedom = aliobj.document.querySelector(".current-time");//总时长
        } else {
            timedom = aliobj.document.querySelector(".current-time");//已播放时长
        }
        var vtime = timedom && timedom.innerText;
        var vsec = tbcUtils.timeToSec(vtime);
        return vsec;
    }

    var xy = { x0: 0, y0: 0 };
    var _xy = { x0: 0, y0: 0 };
    var timerNoOperate;
    // 是否开启防挂机
    var enablePreventHang;
    // 防挂机开启的时间
    var preventHangTime;
    //未操作页面的时间
    var operateTime = 0;
    //检测未操作页面的时间间隔
    var timeInterval = 30000;

    function initPreventHangTime(CONFIG, INFO, studyCourse) {
        $('body').on("mousemove", null, function (e) {
            _xy = {
                x0: e.clientX,
                y0: e.clientY
            };
        });
        function startTimer() {
            clearInterval(timerNoOperate);
            timerNoOperate = setInterval(function () {
                checkMouseMove(_xy);
            }, timeInterval);
        }

        startTimer();
        var exitTime = 30;
        var maxTime = exitTime;
        var refreshTimer;
        function checkMouseMove(o) {
            var onSureFlag = false;
            if (xy.x0 == o.x0 && xy.y0 == o.y0) {
                operateTime += timeInterval;
                console.log(operateTime / 1000 / 60 >= preventHangTime);
                if (operateTime / 1000 / 60 >= preventHangTime) {
                    //获取h5播放器
                    window.aliplayerApi = function (e, params) {
                        videoPlay = params;
                    };
                    //防挂机弹窗弹出后，视频暂停
                    videoPlay.pause();
                    clearInterval(timerNoOperate);
                    maxTime = exitTime;
                    //获取全屏状态
                    var isFullScreen = videoPlay.fullscreenService.getIsFullScreen();
                    if (!!window.aliplayerApi && isFullScreen) {
                        videoPlay.fullscreenService.cancelFullScreen();
                    }
                    $.ajax({
                        type: "POST",
                        url: CONFIG.ctx + "html/studyCourse/studyCourse.saveStudyLog.do?courseId=" + INFO.courseId + "&eventType=PREVENT_HANG_POPUP",
                        async: true,
                        success: function (d) {
                            console.log("ubr save");
                        }
                    });
                    ncp.count({
                        countTime: 60,
                        content: TIPS['els.exitPreTip1'] + '<time id="count-time"></time>' + TIPS['els.exitLastTip2'],
                        timeEnd: function () {
                            if (!onSureFlag) {
                                //倒计时结束
                                clearInterval(refreshTimer);
                                clearInterval(timerNoOperate);
                                if (INFO.viewMode != 'browsed') {
                                    studyCourse.onbeforeunloadHandler(true);
                                }
                                $.ajax({
                                    type: "POST",
                                    url: CONFIG.ctx + "html/studyCourse/studyCourse.saveStudyLog.do?courseId=" + INFO.courseId + "&eventType=PREVENT_HANG_LOGOUT",
                                    async: false,
                                    success: function (d) {
                                        console.log("ubr save");
                                        $.ajax({ url: '/els/html/courseStudyItem/courseStudyItem.logOut.do' });
                                        var alreadyClick = true;
                                        $('body').on("mousedown", null, function (e) {
                                            if (alreadyClick) {
                                                togglePlayState(false);
                                                ncp.validate({
                                                    content: TIPS['els.autoExit'], area: ['520px', '250px'], onLoad: function (_self) {
                                                        //_self是此弹窗
                                                    }, onSure: function (index) {
                                                        while (true) {
                                                            var cookieSessionId = cookieUtil.getCookie('eln_session_id');
                                                            if (cookieSessionId) {
                                                                cookieUtil.deleteCookie('eln_session_id');
                                                                console.log('删除cookie');
                                                            } else {
                                                                break;
                                                            }
                                                        }
                                                        if (GetQuery(window.location.href, 'host')) {
                                                            window.open('http://' + GetQuery(window.location.href, 'host') + '/login/login.logout.do', '_self');
                                                        } else {
                                                            window.open('/login/login.logout.do', '_self');
                                                        }
                                                        layer.closeAll();
                                                    },
                                                    onEnd: function () {
                                                        videoPlay.play();
                                                    }
                                                });
                                                alreadyClick = false;
                                            }
                                        });
                                    }
                                });

                            }

                        },
                        onSure: function (index) {
                            onSureFlag = true;
                            $.ajax({
                                type: "POST",
                                url: CONFIG.ctx + "html/studyCourse/studyCourse.saveStudyLog.do?courseId=" + INFO.courseId + "&eventType=PREVENT_HANG_OPERATE",
                                async: false,
                                success: function (d) {
                                    console.log("ubr save");
                                }
                            });
                            maxTime = exitTime;
                            operateTime = 0;
                            clearInterval(refreshTimer);
                            timerNoOperate = setInterval(function () {
                                checkMouseMove(_xy)
                            }, timeInterval);
                            layer.close(index)
                        },
                        onEnd: function () {
                            videoPlay.play();
                        }
                    });

                }
            } else {
                operateTime = 0;
                xy.x0 = o.x0;
                xy.y0 = o.y0;
            }
        }
    }


    //tools
    window.T = {};
    // css loader
    var _CSS_URLS = [];
    T.loadCss = function (url) {
        url = require.toUrl(url);
        // 已存在时跳出
        if (_CSS_URLS.length > 0 && _CSS_URLS.join(',').indexOf(url) !== -1) {
            return;
        }
        _CSS_URLS.push(url);
        var link = document.createElement('link');
        link.type = 'text/css';
        link.rel = 'stylesheet';
        link.href = url;
        document.getElementsByTagName('head')[0].appendChild(link);
    };

    function togglePlayState(state, initialState) {
        var $palyerContainer = $("#palyerContainerId");
        window.aliplayerApi = function (e, params) {
            videoPlay = params;
        };
        if (window.aliplayerApi && Object.getOwnPropertyNames(videoPlay).length !== 0) {
            if (state) {
                videoPlay.play();
                $palyerContainer.css("displayer", "block");
            } else {
                $palyerContainer.css("displayer", "none");
                videoPlay.pause();
            }
        }
        //火狐ie10中的scorm url 类课程
        if (!!window.isScorm || !!window.isUrlCourse) {
            if (state) {
                $("#palyerContainerId,#urlCourseIframeId").removeClass("hideViaPosition");
            } else {
                $("#palyerContainerId,#urlCourseIframeId").addClass("hideViaPosition");
            }
        }
    }

    function GetQuery(url, name) {
        var reg = new RegExp("(^|&)" + name + "=([^&]*)(&|$)", "i");
        if (!url.split("?")[1]) {
            return null;
        }
        var r = url.split("?")[1].split("#")[0].match(reg);
        if (r != null) return unescape(r[2]);
        return null;
    }
    function beforeunload_fun() {
        console.log("高版本的chrome调用的关闭保存");
        var courseId = info.courseId;

        window.aliplayerApi = function (e, params) {
            console.log('params--->', params);
            videoPlay = params;
        };
        console.log('高版本的chrome调用的关闭保存 videoPlay--->', videoPlay);

        saveUrlAndIndexAndDocPrecent(courseId, playTime, true);
        if (playTime > 30) {
            playTime = 0;//如果播放时间大于30s就说明已经保存播放时间，清零处理
        }
        $.ajax({
            type: "POST",
            async: asyncBrowser,
            url: CONFIG.ctx + "html/courseStudyItem/courseStudyItem.exitStudy.do?courseId=" + courseId, //获取课程资源信息
            success: function (d) {
            }
        });
    };
    //scorm 放大
    function zoomScormCourse() {

        if (window.isScorm) {
            var lessenBtn = $("#lessenScormCourse"), zoomBtn = $("#zoomScormCourse");
            $("#ScormCtrlBar").removeClass("hide");
            $("#handouts").attr("style", "width:100%;" + "height:500px !important;");
            lessenBtn.removeClass("hide");
            var $currWrap = $(".cl-play"),
                fullClass = "cl-url-full-screen";
            zoomBtn.click(function () {
                lessenBtn.show();
                $currWrap.addClass(fullClass);
                $("#handouts").attr("style", "width:100%;" + "height:" + $(window).height() + "px !important;");
                $("body").addClass("full-body");
            })
            lessenBtn.click(function () {
                $(this).hide();
                $currWrap.removeClass(fullClass);
                $("#handouts").attr("style", "width:100%;" + "height:500px !important;");
                $("body").removeClass("full-body");
                //全屏模式下双击退出
            });
            $(document).keydown(function (event) {
                var e = event || window.event;
                if (e && e.keyCode == 27) {
                    if (window.isScorm && $("body").hasClass("full-body")) {
                        lessenBtn.trigger("click");
                    }
                }
            });
            //scorm 背景设为白
            $("#handouts").parent("#palyerContainerId").css("background", "#fff");
        }

    }

    //判断是否为二分屏讲义
    function checkIsTwoScreenLecture(d) {
        var _streamMediaArr;
        try {
            _streamMediaArr = d.STREAM_MEDIA.split('?');
        } catch (e) { //二分屏HTML课件
            _streamMediaArr = d.LECTURE_SHEET.split('?');
        }

        var _smu = _streamMediaArr[0];
        var fileExt = _smu.substring(_smu.lastIndexOf('.') + 1, _smu.length);
        fileExt = fileExt.toLowerCase();
        if (fileExt == 'html' || fileExt == 'htm' || fileExt == 'swf') {
            return true;
        }

        return false;
    }

    //二分屏讲义放大
    function zoomTwoScreenCourse() {
        var lessenBtn = $("#lessenScormCourse"), zoomBtn = $("#zoomTwoScreenCourse");
        $("#TwoScreenCtrlBar").removeClass("hide");
        $("#handouts").attr("style", "width:100%;" + "height:500px !important;");
        lessenBtn.removeClass("hide");
        var $currWrap = $(".cl-play"),
            fullClass = "cl-url-full-screen";

        zoomBtn.click(function () {
            lessenBtn.show();
            $currWrap.addClass(fullClass);
            $("#handouts").attr("style", "width:100%;" + "height:" + $(window).height() + "px !important;");
            $("body").addClass("full-body");
        });

        lessenBtn.click(function () {
            $(this).hide();
            $currWrap.removeClass(fullClass);
            $("#handouts").attr("style", "width:100%;" + "height:500px !important;");
            $("body").removeClass("full-body");
            //全屏模式下双击退出
        });
    }

    //init
    var _tbcdialogInit = function () {
        require([CONFIG.ctx + 'js/up.js']);
        T.loadCss(CONFIG.ctxRemote + 'css/tbc_components.css');
    };

    var learnFourFootwork = {

        //页面加载
        pageLoader: function (url, id, param) {
            var p = $('#' + id).parent();
            p.load(url, param || {});
        },

        pageLoaderClass: function (url, className, param) {
            var p = $('.' + className).parent();
            p.load(url, param || {});
        },

        //进入学习
        enterCourse: function (courseId, state) {
            var url = CONFIG.ctx + 'html/studyCourse/studyCourse.enterCourse.do?courseId=' + courseId;
            if (state != null && state == "finished") {
                url = url + "&isPassed=true"
            }
            this.pageLoaderClass(url, 'courseStudyStep', null);
            return false;
        },

        //是否为最后一步（学习步骤）
        isCurrentStepEnd: function (stepName) {
            var result = false;
            try {
                result = ($('#courseInfoSteps ul li').last().hasClass('cur') && $('#courseInfoSteps a').last().attr('onclick').indexOf(stepName) != -1);
            } catch (e) {
            }
            return result;
        }
    };


    var examDisabledAndGetScore;
    var goToStep = '';
    exports.setGoToStep = function (willGoStep) {
        goToStep = willGoStep;
    };

    var clearTrackRecord; //开启时防作弊验证失败不记录进度

    // 是否开启防作弊(2: 防作弊, 1: 人脸识别, 0: 未开启)
    var enablePreventCheat;

    var preventCheatTime;  // 防作弊开启时间
    var preventMaxTime;  // 防作弊区间最大时间
    var preventMinTime;  // 防作弊区间最小时间


    exports.enable = function (val) {
        var nextPlayTime;
        if (val == 'assets') {
            nextPlayTime = preventMaxTime - Number(preventCheatTime)
            var nextCheatTime = (Math.random() * (preventMaxTime - Number(preventCheatTime)) + Number(preventCheatTime)).toFixed(1)
            nextPlayTime += Number(nextCheatTime)
        }
        var time = val ? nextPlayTime * 60 * 1000 : preventCheatTime * 60 * 1000
        // console.log('下次执行的时间：'+ time)
        // preventCheatInterval = setInterval(preventCheat, preventCheatTime * 60 * 1000);
        preventCheatInterval = setInterval(preventCheat, time);
        function preventCheat() {
            console.log('防作弊开启');
            window.aliplayerApi = function (e, params) {
                videoPlay = params;
            };
            if (window.aliplayerApi != null && window.aliplayerApi != undefined && Object.getOwnPropertyNames(videoPlay).length !== 0) {
                var playState = videoPlay.getStatus();
                if ((videoType == "flv" || videoType == "mp4") && playState != "playing" && playState != "ready") {
                    return;
                }
            }
            clearInterval(preventCheatInterval);

            //防作弊弹窗弹出后，视频暂停
            videoPlay.pause();

            function closeWindow() {
                window.opener = null;
                window.open('', '_self');
                window.close();
            }

            $.get(CONFIG.ctx + "html/preventCheat/preventCheat.load.do?courseType=NEW_COURSE_CENTER&courseId=" + info.courseId, function (data) {
                //获取播放器全屏状态，仅H5支持。
                var isFullScreen = videoPlay.fullscreenService.getIsFullScreen();
                if (!!window.aliplayerApi && isFullScreen) {
                    videoPlay.fullscreenService.cancelFullScreen();
                }

                clearTimeout(preventCheatTimer);
                var preventCheatTimer = setTimeout(function () {
                    // window.open('', '_self');
                    // console.log('计时结束');
                    if (clearTrackRecord && enablePreventCheat) {
                        //验证失败不记录进度
                        window.removeEventListener('beforeunload', beforeunload_fun)
                    }
                    var scoId = $('.scormItem-no.cl-catalog-playing').attr('data-id');
                    var url;
                    if (typeof (scoId) == "undefined") {
                        url = CONFIG.ctx + "html/studyCourse/studyCourse.saveStudyLog.do?courseId=" + info.courseId + "&eventType=PREVENT_CHEAT_LOGOUT";
                    } else {
                        url = CONFIG.ctx + "html/studyCourse/studyCourse.saveStudyLog.do?courseId=" + info.courseId + "&eventType=PREVENT_CHEAT_LOGOUT&scoId=" + scoId;
                    }
                    $.ajax({
                        type: "POST",
                        url: url,
                        async: asyncBrowser,
                        success: function (d) {
                            console.log("ubr save");
                            closeWindow();
                        },
                        error: function () {
                            console.log("ubr save");
                            closeWindow();
                        }
                    });

                }, 62000)


                ncp.validate({
                    content: data, onLoad: function (_self) {
                        //_self是此弹窗
                    }, onSure: function (index) {
                        if (!validate()) {
                            return;
                        }

                        var url = CONFIG.ctx + "html/preventCheat/preventCheat.checkAnswer.do?courseId=" + info.courseId;
                        $.post(url, { imgTime: $("#imgTime").val(), answer: $("#answer").val() }, function (data) {
                            if (data.success) {
                                exports.enable('assets');
                                layer.close(index)
                                clearTimeout(preventCheatTimer)
                            } else if (data.message == "Error") {
                                $("#tip").html(TIPS['els.common.enterTheCorrectAnswer'] + "！");
                            } else {
                                $("#tip").html(TIPS['els.common.identifyCodeIsInvalid'] + "！");
                            }
                        });

                    },
                    onEnd: function () {
                        videoPlay.play();
                    }
                });
            });
            function validate() {
                var value = $("#answer").val();
                var positiveInteger = new RegExp("^[0-9]*$");
                var negativeInteger = new RegExp("^\-[1-9][0-9]*$");
                if (value == "") {
                    $("#tip").html(TIPS['els.common.enterTheCorrectAnswer'] + "！");
                    return false;
                }

                if (!(positiveInteger.test(value) || negativeInteger.test(value))) {
                    $("#answer").val("");
                    $("#tip").html(TIPS['els.common.enterNumber'] + "！");
                    return false;
                }

                $("#tip").html("");
                return true;
            }
        }
    };

    /* 人脸识别 */
    var facRecognition = {
        faceTimer: null, // 弹窗定时器
        faceCountDownTimer: null, // 倒计时定时器
        qrcode: null, // 二维码

        // 关闭浏览器
        closeWindow: function () {
            // close chrome;It is effective when it is only one.
            window.opener = null;
            setTimeout(function () {
                window.location.href = "about:blank";
                window.close();
            }, 1000);
        },
        randomWord: function (randomFlag, min, max) {
            var str = "",
                range = min,
                arr = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z'];

            // 随机产生
            if (randomFlag) {
                range = Math.round(Math.random() * (max - min)) + min;
            }
            for (var i = 0; i < range; i++) {
                var pos = Math.round(Math.random() * (arr.length - 1));
                str += arr[pos];
            }
            return str;
        },
        // 人脸识别倒计时
        faceCountDown: function (seconds, currentTimer) {
            var _this = this;
            if (_this.faceCountDownTimer != null) {
                clearInterval(_this.faceCountDownTimer);
                _this.faceCountDownTimer = null;
            }
            _this.faceCountDownTimer = setInterval(function () {
                if (seconds > 1) {
                    seconds--;
                    var minute = Math.floor(seconds / 60),
                        second = seconds % 60;
                    var countDwonHtml = ''
                    if (minute > 0) {
                        countDwonHtml = '<strong>' + minute + '</strong>' + '分' + '<strong>' + second + '</strong>' + '秒'
                    } else {
                        countDwonHtml = '<strong>' + second + '</strong>' + '秒'
                    }
                    $('#face-count-down').html(countDwonHtml)
                } else {
                    // 清除定时器
                    clearInterval(_this.currentTimer);
                    clearInterval(_this.faceCountDownTimer);
                    _this.clearLearnLog();
                    _this.closeWindow();
                }
            }, 1000)
        },
        // 初始化人脸识别二维码
        initQrcode: function () {
            var qrcodeHtml = '<div id="qrcode" class="qr-container" style="display:none;">'
                + '<div class="qr-bg"></div>'
                + '<div class="qr-content">'
                + '<h4>系统提示</h4><div id="qr-img" class="qr-img"></div>'
                + '<div class="qr-tips">请通过云端学习APP的“扫一扫”完成验证'
                + '<p><span id="face-count-down" class="qr-countdown"></span>&nbsp;内未完成验证将退出课程学习</p></div>'
                + '</div>'
                + '</div>'
            $('body').append(qrcodeHtml);

            // 生成二维码
            this.qrcode = new QRCode(document.getElementById("qr-img"), {
                text: '',
                width: 200,
                height: 200
            });
        },
        // 初始化 WebSocket
        initWS: function (initWSvideoPlay) {
            var _this = this;
            _this.initQrcode();

            // var origin = window.location.origin;
            var protocol = window.location.href.indexOf('http') > -1 ? 'http://' : 'https://';
            var socketOrigin = GetQuery(window.location.href, 'host') ? protocol + GetQuery(window.location.href, 'host') : window.location.origin;
            console.log(socketOrigin)
            var sock = new SockJS(socketOrigin + "/biz-oim/webSocket/handler?deviceId=" + _this.randomWord(false, 32));

            // 连接建立发送
            sock.onopen = function () {
                sock.send(
                    JSON.stringify({
                        code: 1,
                        params: {
                            qrCode: _this.randomWord(false, 10),
                            local: $.cookie('local_'),
                            type: 'QR_STUDYCOURSE_SIGN'
                        }
                    })
                );
            };

            // 接收客户端返回信息
            sock.onmessage = function (msg) {
                console.log('接收socket返回信息: ' + msg.data);
                var data = JSON.parse(msg.data);
                if (data.code == 1) {
                    // 生成二维码
                    _this.qrcode.makeCode(data.bizResult + '&userId=' + window.CONFIG.userId);
                    $('#qrcode').show();
                    // 扫码倒计时(3分钟)
                    _this.faceCountDown(3 * 60, _this.faceTimer);
                } else if (data.code == 7) {
                    // 扫码成功
                    $("#qrcode").remove();
                    // 清除定时器
                    clearTimeout(_this.faceTimer);
                    clearInterval(_this.faceCountDownTimer);


                    facRecognition.initFace(true);
                    initWSvideoPlay.play();//视频播放
                } else if (data.code == 6) {
                    console.log('验证失败');
                    _this.clearLearnLog();
                    _this.closeWindow();
                } else if (data.code == 2) {
                    console.log('已扫码');
                } else if (data.code == 4) {
                    console.log('二维码过期');
                }
            };

            // 断开连接 自动重连
            sock.onclose = function (msg) {
                alert('WebSocket连接发生错误，请刷新页面！');
            };
            // 发生错误
            sock.onerror = function (msg) {
                alert('WebSocket连接发生错误，请刷新页面！');
            };
        },
        // 初始化方法
        initFace: function (nextFlag) {
            if (nextFlag) {
                var prevTime = Number(preventCheatTime);
                var nextTime = preventMaxTime - prevTime;
                var timeGap = (Math.random() * nextTime + prevTime).toFixed(1);
                nextTime += Number(timeGap);
            }
            var time = nextFlag ? nextTime : preventCheatTime;
            var timestamp = time * 60 * 1000;
            console.log("nextTime: " + time + '分钟');

            if (this.faceTimer != null) {
                clearInterval(this.faceTimer);
                this.faceTimer = null;
            }

            // 弹框定时器
            this.faceTimer = setTimeout(function () {
                // 暂停视频
                // console.log('弹框定时器');
                window.aliplayerApi = function (e, params) {
                    videoPlay = params;
                };
                facRecognition.initWS(videoPlay);

                if (videoPlay != null && videoPlay != undefined) {
                    var playState = videoPlay.getStatus();
                    // console.log('人脸识别 - >播放状态',playState);
                    if ((videoType == "flv" || videoType == "mp4") && playState != "playing") {
                        return;
                    }
                }
                // console.log('人脸识别 - >视频暂停');
                videoPlay.pause(); //视频暂停
            }, timestamp);
        },
        // 清除学习记录
        clearLearnLog: function () {
            var scoId = $('.scormItem-no.cl-catalog-playing').attr('data-id');
            var url;
            if (typeof (scoId) == "undefined") {
                url = CONFIG.ctx + "html/studyCourse/studyCourse.saveStudyLog.do?courseId=" + info.courseId + "&eventType=PREVENT_CHEAT_LOGOUT";
            } else {
                url = CONFIG.ctx + "html/studyCourse/studyCourse.saveStudyLog.do?courseId=" + info.courseId + "&eventType=PREVENT_CHEAT_LOGOUT&scoId=" + scoId;
            }
            $.ajax({
                type: "POST",
                url: url,
                async: asyncBrowser,
                success: function (d) {
                    console.log("ubr save");
                    closeWindow();
                },
                error: function () {
                    console.log("ubr save");
                    closeWindow();
                }
            });
        }
    }

    //如果设置了防挂机，退出课程页面时不再提示
    var tips = true;
    //learnMultiScreenCoruse

    exports.coursePlayEvent = function (INFO) {
        if (hasSwitch != "1") {
            studyCourse.setVboxServer(INFO.vbox_server);
        }
        studyCourse.coursePlay(INFO.scoId, INFO);

        //如果是企顾司课程 则全屏播放
        var fullScreen = $("#fullScreen").val();
        if (fullScreen && fullScreen === "true") {
            $("#zoomScormCourse").trigger("click");
        }
    };

    exports.learnMultiScreenCoruse = function (INFO, hasCollection) {
        exports.coursePlayEvent(INFO);
        // console.log("加载js");
        function onunload_fun() {
            try {
                studyCourse.onbeforeunloadHandler(true);
            } catch (err) {
                console.log(err);
            }
            //真的是退出 目前只支持IE，FireFox
            $.ajax({
                type: "POST",
                async: asyncBrowser,
                url: CONFIG.ctx + "html/courseStudyItem/courseStudyItem.exitStudy.do?courseId=" + INFO.courseId, //获取课程资源信息
                success: function (d) {
                }
            });
            if (heartInterval) { clearTimeout(heartInterval); heartInterval = null; }
        }

        if (INFO.viewMode != 'browsed') {
            //视频 退出保存进度
            window.onbeforeunload = function (e) {
                try {
                    studyCourse.onbeforeunloadHandler(true);
                    $.ajax({
                        type: "POST",
                        async: asyncBrowser,
                        url: CONFIG.ctx + "html/courseStudyItem/courseStudyItem.exitStudy.do?courseId=" + INFO.courseId, //获取课程资源信息
                        success: function (d) {
                        }
                    });
                } catch (err) {
                    console.log(err);
                }
            };

            window.addEventListener('beforeunload', onunload_fun);

            //3分钟,检测最大同时观看视频人数
            setInterval(function () {
                $.ajax({
                    type: "POST",
                    url: CONFIG.ctx + "html/courseStudyItem/courseStudyItem.updateTimestepByUserTimmer.do",
                    success: function (d) {
                    }
                });
            }, 3 * 60 * 1000);
            //定时保存
            setInterval(function () {
                studyCourse.onbeforeunloadHandler();
            }, 180 * 1000);
        }


        $(function () {
            //观看课程，加载各种操作项的js
            try {
                INFO.current_server = INFO.vbox_server;
                studyCourse.setVboxServer(INFO.vbox_server);
            } catch (e) {

            }
            $("#goBack").click(function () {
                studyCourse.onbeforeunloadHandler(true);
            })
            // $('#playBarrageId').css('visibility', 'hidden');
        });

        /**
         * 窗体布局、事件绑定
         */
        function autoSize() {
            var vH = $('#videoCon').height();
            //修正布局
            $('#handouts').height(vH);
        }

        $(window).resize(function () {
            autoSize();
        });

        //防挂机
        $(function () {
            var ylflag = $.cookie(INFO.corpCode + '_ylflag');
            $.get('/els/html/course/course.loadCourseSystemSeting.do?courseId=' + INFO.courseId + "&eln_session_id=" + CONFIG.elnSessionId, function (data) {
                console.log('get课程设置1');
                isheart = !!data.heartBeat;
                iscontinueHeartBeat = !!data.continueHeartBeat;

                if (isCompleted && iscontinueHeartBeat && info.viewMode != 'browsed') {
                    console.log('启动心跳播放-已学完');
                    heartApifun();
                    heartInterval = window.setInterval(function () {
                        console.log('心跳定时播放-已学完');
                        heartApifun();
                    }, 60 * 1000);
                }

                enablePreventHang = data.enablePreventHang;
                preventHangTime = data.preventHangTime;

                enablePreventCheat = data.checkType;
                // console.log('checkType: ' + enablePreventCheat);

                preventMaxTime = data.preventCheatTimeTo;
                preventMinTime = data.preventCheatTime;
                clearTrackRecord = data.clearTrackRecords;

                preventCheatTime = (Math.random() * (preventMaxTime - preventMinTime) + preventMinTime).toFixed(1)
                if (enablePreventHang) {
                    window.aliplayerApi = function (e, params) {
                        console.log('params--->', params);
                        videoPlay = params;
                    };
                    console.log('videoPlay--->', videoPlay);
                    initPreventHangTime(CONFIG, INFO, studyCourse)
                }

                // 防作弊
                if (enablePreventCheat == 2) {
                    exports.enable();
                } else if (enablePreventCheat == 1) { // 人脸识别
                    facRecognition.initFace();
                } else {
                    return false;
                }
            });

            autoSize();
            $('#learnThreeScreenExit').click(function () {
                if (ylflag == '1') {
                    window.close();
                } else {
                    var courseId = $(this).attr('course-id');
                    var methodName = '';
                    if (goToStep.indexOf("_VIEW") != -1) {
                        methodName = getRealMethodName(goToStep);
                    } else {
                        methodName = 'enterCourse';
                    }
                    var url = '/els/html/studyCourse/studyCourse.' + methodName + '.do?courseId=' + courseId + '&willGoStep=' + goToStep;
                    if (INFO._host_ctx_path != '' && INFO._host_ctx_path != null) {
                        url = INFO._host_ctx_path + 'html/studyCourse/studyCourse.' + methodName + '.do?courseId=' + courseId + '&willGoStep=' + goToStep;
                    }
                    window.location.href = url;
                }
            });

            $('#scoPrev,#scoNext').click(function (e) {
                //scoElementId 当前停留元素ID
                if (scoElementId == undefined) return;

                var isPrev = ($(this).attr('id') == 'scoPrev'),
                    isNext = ($(this).attr('id') == 'scoNext'),
                    targetObj, //sco li OBJ
                    nextObj = function (currId) {
                        var currObj = $('#' + currId);
                        if (isPrev)
                            targetObj = currObj.prev(); //上一个
                        else if (isNext)
                            targetObj = currObj.next(); //下一个
                        var newCurrId = targetObj.attr('id');
                        //“文件夹”情况下，再取一次
                        if ($('#' + newCurrId + ' span').hasClass('folder')) {
                            var newCurrObj = $('#' + newCurrId);
                            if (isPrev)
                                targetObj = newCurrObj.prev();
                            else if (isNext)
                                targetObj = newCurrObj.next();
                        }
                        return targetObj;
                    };
                targetObj = nextObj(scoElementId);

                var scoLinkObj = $('#' + targetObj.attr('id') + ' a.play-btn');
                if (scoLinkObj.length > 0)
                    scoLinkObj.click();
                else
                    $(this).addClass('aDisabled');
            });

            // 网络设置 点击事件
            $(".cl-net-setting").click(function (e) {
                var actionUrl = '/els/html/courseStudyItem/courseStudyItem.listFileServer.do?currentHost=' + info.current_server;
                var viewNetWorkSetting = $('#viewNetWorkSetting').val();
                if (viewNetWorkSetting == "true") {
                    actionUrl = '/els/html/courseStudyItem/courseStudyItem.listInnerFileServer.do?currentHost=' + info.current_server + '&courseId=' + info.courseId;
                    actionUrl += "&elsSign=" + info._els_sign;
                }
                actionUrl = actionUrl + "&courseType=NEW_COURSE_CENTER";
                $.post(actionUrl, function (data) {
                    var options = [];
                    if (data == undefined || data == null || data.length <= 0) {
                        options = [{ value: '', text: TIPS['els.course.defautlService'] }];
                    } else {
                        $.each(data, function (i, n) {
                            if (n.networkServer == true) {
                                options.push({ value: n.host, text: n.fileServerName, selected: "selected" })
                            } else {
                                options.push({ value: n.host, text: n.fileServerName, selected: "" })
                            }

                        });
                    }
                    togglePlayState(false);
                    ncp.network({
                        title: TIPS['els.netWorkSetting'],
                        msg: TIPS['els.common.pleaseSelectNetwork'],
                        options: options,
                        onSure: function (index, _self) {
                            var viewNetWorkSetting = $('#viewNetWorkSetting').val();
                            // if (!$.browser.msie && viewNetWorkSetting == 'false' && (navigator.userAgent).toLowerCase().indexOf("trident") < 0) {
                            //     return;
                            // }
                            var courseId = info.courseId;
                            var _current_host = _self.find(".selected-text").attr("data-value");
                            if (null == _current_host) {
                                return;
                            }
                            if (info.current_server != undefined && info.current_server.indexOf(_current_host) >= 0) {
                                return;
                            }
                            if (_current_host.indexOf('21tb.com') >= 0 && viewNetWorkSetting == 'false') {
                                //公网
                                _current_host = '21tb-video.21tb.com';
                            }

                            var scoId = $("#courseItemId").find('.cl-catalog-playing').attr("data-id");
                            var standard = $('#standard').val();
                            if (_current_host != '21tb.com' || viewNetWorkSetting == 'true') {
                                studyCourse.setVboxServer(_current_host);
                            }
                            info.current_server = _current_host;
                            studyCourse.setVboxServer(info.current_server);
                            studyCourse.fromNetWorkSetting(viewNetWorkSetting);
                            studyCourse.coursePlay(scoId, info);
                        },
                        onEnd: function () {
                            togglePlayState(true)
                        }
                    })
                })
            });

            //课程详情
            $('.vod_course_detail').click(function () {
                $.post(CONFIG.ctx + 'html/courseCenter/courseCenter.checkUserCanViewCourseDetail.do', { "courseId": courseId }, function (data) {
                    if (data.success == true) {
                        var _url = 'html/course/course.courseInfo.do?courseId=' + INFO.courseId + '&p=';
                        if (INFO._host_ctx_path != null && INFO._host_ctx_path != '') {
                            _url = INFO._host_ctx_path + "/" + _url;
                        } else {
                            _url = CONFIG.ctx + _url + "&elsSign=" + INFO._els_sign;
                        }
                        window.open(_url, '_courseInfo');
                    } else {
                        ncp.alert({
                            title: i18n('v4.js.sysTips'),
                            content: data.message
                        });
                    }
                });
            });
        });
    };


    //wmv  var  start
    var playTime = 0;
    var duration = 0;
    var settleTime = 0;
    var startd = new Date();
    var globalCurrentRate = 0;
    var loadRate = 60;
    var saveProgress = 0;

    //播放WMV 课程
    var saveProgressByWmv = {
        //记录时间
        rememberTime: function (courseId, scoId, needDuration) {
            try {
                if (needDuration === 'true') {
                    var wmvDuration = saveProgressByWmv.getObj('mPlayer').currentMedia.duration;
                    // alert(wmvDuration);
                    if (wmvDuration > 0) {
                        $.post(CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.saveWmvDuration.do',
                            { 'wmvDuration': wmvDuration, 'courseId': courseId, 'scoId': scoId }, function (data) {
                                if (data.success) {
                                    window.clearInterval(wmv_inter);
                                }

                            }, 'json');
                    }
                }
            } catch (e) {
                window.clearInterval(wmv_inter);
            }

        },
        //开始计算时间
        startRememberTime: function (courseId, scoId, needDuration) {
            //每1000毫秒 调用
            wmv_inter = setInterval(function () {
                saveProgressByWmv.rememberTime(courseId, scoId, needDuration);
            }, 1000);
        },
        //开始记录进度
        startRememberStudyStep: function (courseId, scoId) {
            interval = 60 * 3;
            wmv_inter_a = setInterval(function () {
                saveProgressByWmv.savePorgress(courseId, scoId);
            }, 1000 * interval);
        },
        //正常记录进度
        rememberStudyStep: function () {
            //duration媒体总长度
            if (duration == 0 || duration > 7200000) {
                if (settleTime > 300) {
                    globalCurrentRate = 100;
                }
            } else {
                globalCurrentRate = Math.round(settleTime / duration * 100);
            }
            if (globalCurrentRate == 0 || globalCurrentRate < loadRate
                || globalCurrentRate == '' || isNaN(globalCurrentRate)) return;

            if (globalCurrentRate >= loadRate) {
                if (saveProgress == 0) {
                    //记录进度
                    this.savePorgress(wmvCourseId, wmvScoId);
                    saveProgress = 1;
                }
            }
        },
        getObj: function (objName) {
            try {
                if (document.getElementById) {
                    return eval('document.getElementById("' + objName + '")');
                } else {
                    return eval('document.all.' + objName);
                }
            } catch (e) {
                $.tbcmsg({
                    msg: '<p class="dialog-msg">' + i18n("!v4.js.browserNotSupport") + '</p>',
                    onlyOk: true
                });
            }
        },
        //离开页面
        onbeforeunloadSelf: function () {
            duration = 0;
            settleTime = 0;
            globalCurrentRate = 0;
            saveProgress = 0;
            startd = new Date();
            window.clearInterval(wmv_inter);
            window.clearInterval(wmv_inter_a);
        },
        startSave: function (courseId, scoId, needDuration) {
            this.onbeforeunloadSelf();
            this.startRememberTime(courseId, scoId, needDuration);
            this.startRememberStudyStep(courseId, scoId);
        },
        savePorgress: function (courseId, scoId) {
            //var param = 'processType=THREESCREENWMV&courseId=' + courseId + '&scoId=' + scoId;
            var param = 'courseId=' + courseId + '&scoId=' + scoId;
            if (processType && processType != '') {
                param = param + '&processType=' + processType;
            }

            studyCourse.doSaveProgress(param, scoId, true);
        },
        //测试wmv是否在播放
        testIsPlaying: function (cnt) {
            try {
                var playState;
                if (this.getObj('mPlayer') == undefined && ("tianan-cyber" == CONFIG.corpCode || "tietong" == CONFIG.corpCode)) {
                    playState = undefined;
                } else {
                    playState = videoPlay.getStatus();
                }

                console.log("是否在播放");
                //视频无法播放，切换到公网.
                if (videoErrStatus || (("tianan-cyber" == CONFIG.corpCode || "tietong" == CONFIG.corpCode) && playState == undefined) || playState == undefined) {
                    console.log("切换网络设置");
                    var course_id = $('#courseId').val();
                    var standard = $('#standard').val();
                    //视频服务器切换到公网
                    studyCourse.setVboxServer('');
                    studyCourse.setHasSwitch("1");
                    //点击网络设置，自动变成公网默认选中
                    info.current_server = '';
                    //播放
                    var INFO = {
                        courseId: course_id,
                        courseStandard: standard,
                        viewMode: info.viewMode
                    };

                    var currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
                    window.setTimeout(function () {
                        currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
                    }, 500);

                    var scoId = $(currObj).attr('data-id');
                    if (!cnt) {
                        cnt = 0;
                    }

                    if (cnt < 3) {
                        cnt++;
                        studyCourse.coursePlay(scoId, info, cnt);
                    }
                }
            } catch (e) {

            }
        },
        //测试flv和mp4是否在播放
        testIsPlayingForMp4: function (cnt) {
            function privateMethodForMp4() {
                var course_id = $('#courseId').val();
                var standard = $('#standard').val();
                //视频服务器切换到公网
                studyCourse.setVboxServer('');
                studyCourse.setHasSwitch("1");
                //点击网络设置，自动变成公网默认选中
                info.current_server = '';
                //播放
                var INFO = {
                    courseId: course_id,
                    courseStandard: standard,
                    viewMode: info.viewMode
                };

                var currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
                window.setTimeout(function () {
                    currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
                }, 500);


                if (!cnt) {
                    cnt = 0;
                }

                if (cnt < 3) {
                    cnt++;
                    if (cnt === 2) {
                        // 第二遍 去掉locationTime 重新加载
                        var objHtml = $('#handouts').html();
                        objHtml = objHtml.replaceAll("locationTime", "locationTimeRem");
                        $('#handouts').html('').html(objHtml);
                    } else {
                        // 第一遍从 切到公网执行
                        studyCourse.coursePlay($(currObj).attr('data-id'), info, cnt);
                    }
                }
            }

            try {
                // console.log("videoErrStatus---->", videoErrStatus);
                //视频无法播放，切换到公网.
                if (videoErrStatus) {
                    window.clearInterval(testIsVideoPlaying);
                    privateMethodForMp4();
                }
            } catch (e) {
            }
        }
    };

    //listFileServer
    exports.listFileServer = function (info) {
        $('#saveFileServer').click(function () {
            var dialogO = $('#dialog');
            if (dialogO.length > 0) {
                dialogO.dialog("destroy");
            }
        });
        $('.tbc-dialog-cancel').click(function () {
            var dialogO = $('#dialog')
            if (dialogO.length > 0) {
                dialogO.dialog("destroy");
            }
        });

        $(function () {
            $('#saveFileServer').click(function () {
                var viewNetWorkSetting = $('#viewNetWorkSetting').val();
                if (!$.browser.msie && viewNetWorkSetting == 'false' && (navigator.userAgent).toLowerCase().indexOf("trident") < 0) {
                    return;
                }
                var courseId = $('#courseId').val();
                var _current_host = $('#fileServerSelect').val();
                if (null == _current_host) {
                    return;
                }
                if ($('#currentHost').val().indexOf(_current_host) >= 0) {
                    return;
                }
                if (_current_host.indexOf('21tb.com') >= 0 && viewNetWorkSetting == 'false') {
                    //公网
                    _current_host = '21tb-video.21tb.com';
                } else {

                }

                var scoId = $('#vodtree .cur a').attr("data-id");
                var standard = $('#standard').val();
                if (_current_host != '21tb.com' || viewNetWorkSetting == 'true') {
                    studyCourse.setVboxServer(_current_host);
                }
                info.current_server = _current_host;
                studyCourse.setVboxServer(info.current_server);
                studyCourse.fromNetWorkSetting(viewNetWorkSetting);
                studyCourse.coursePlay(scoId, info);
            });
        })
    };

    //更新studiedTime的显示时间 ldc
    exports.updateRateTime = function (rateTimmer, minStudyTime) {
        updateStudiedTime = setInterval(function () {
            var oldTime = parseFloat($('#studiedTime').html());
            if (oldTime + rateTimmer >= minStudyTime) {
                $('#studiedTime').html(minStudyTime);
                window.clearInterval(updateStudiedTime);
            } else {
                $('#studiedTime').html(oldTime + rateTimmer);
            }
        }, 1000 * 60 * rateTimmer);
    };

    exports.updateTwoScreenRateTime = function (rateTimmer, d) {
        console.log('两份屏更新已学进度rateTimmer --- > ', rateTimmer);

        if (d.CHAPTER_URL) {
            var minStudyTime = $('#minStudyTime').html();
            var oldTime = parseFloat($('#studiedTime').html());
            if ((minStudyTime - oldTime) < rateTimmer) {
                rateTimmer = minStudyTime - oldTime;
            }
            updateStudiedTime = setInterval(function () {
                minStudyTime = $('#minStudyTime').html();
                oldTime = parseFloat($('#studiedTime').html());
                if ((oldTime + rateTimmer) >= minStudyTime || (d.isComplete == 'true' || (d.isComplete !== "false" && d.isComplete))) {
                    $('#studiedTime').html(minStudyTime);
                    window.clearInterval(updateStudiedTime);
                } else {
                    $('#studiedTime').html(oldTime + rateTimmer);
                }
            }, 1000 * 60 * rateTimmer);

        } else {
            var _streamMediaArr;
            console.log('_streamMediaArr', _streamMediaArr);
            try {
                _streamMediaArr = d.STREAM_MEDIA.split('?');
            } catch (e) { //二分屏HTML课件
                _streamMediaArr = d.LECTURE_SHEET.split('?');
            }
            var _smu = _streamMediaArr[0];
            var fileExt = _smu.substring(_smu.lastIndexOf('.') + 1, _smu.length);//视频格式
            fileExt = fileExt.toLowerCase();
            console.log('fileExt', fileExt);
            if (fileExt == 'html' || fileExt == 'htm') {
                updateStudiedTime = setInterval(function () {
                    var minStudyTime = $('#minStudyTime').html();
                    var studiedTime = $('#studiedTime').html();
                    if (studiedTime >= minStudyTime || d.isComplete == 'true' || (d.isComplete !== "false" && d.isComplete)) {
                        console.log('已学时间完毕');
                        $('#studiedTime').html(minStudyTime);
                        window.clearInterval(updateStudiedTime);
                    } else {
                        studiedTime = parseInt(studiedTime) + 3;
                        if (minStudyTime < studiedTime) {
                            $('#studiedTime').html(minStudyTime);
                        } else {
                            $('#studiedTime').html(studiedTime);
                        }
                    }
                }, 1000 * 60 * rateTimmer);
            } else {
                updateStudiedTime = setInterval(function () {
                    window.aliplayerApi = function (e, params) {
                        videoPlay = params;
                    };
                    var minStudyTime = $('#minStudyTime').html();
                    var dura = videoPlay.getDuration() - 3;
                    var videoPlayTime = videoPlay.getCurrentTime();
                    var parseTime = parseInt(videoPlayTime / 60);
                    if (parseTime >= minStudyTime || (videoPlayTime - dura >= 0) || d.isComplete == 'true' || (d.isComplete !== "false" && d.isComplete)) {
                        console.log('已学时间完毕');
                        $('#studiedTime').html(minStudyTime);
                        window.clearInterval(updateStudiedTime);
                    } else {
                        $('#studiedTime').html(parseTime);
                    }
                }, 1000 * 60 * rateTimmer);
            }
        }
    };

    //身份确认
    function checkIdentity(courseId, d) {
        document.getElementById('dialog').style.display = 'block';
        //点击叉关闭弹框
        $('.dialog-close_area').on('click', function () {
            $('#dialog').css('display', 'none');
            $("#goNextStep").addClass("hide");
            if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                try {
                    var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                    var dataType = $nextStep.attr("data-type");
                    if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                        $nextStep.removeAttr("onclick");
                    }
                } catch (e) {
                    console.log(e);
                }
            }

        });
        //点击确定关闭弹框
        $('.confirm-btn').on('click', function () {
            $.post(CONFIG.ctx + 'html/studyCourse/studyCourse.loadStudyRecordRel.do', { 'courseId': courseId }, function (data) {
                if (data && data.success) {
                    var loginName = $('#account').val();
                    var password = $('#psd').val();
                    if (loginName == '' || password == '') {
                        $.vfdialog({
                            cont: '请输入用户名或密码',
                            onlySure: true,
                            width: 260,
                            cls: 'resume-vfdialog',
                            height: 20
                        });
                        $("#goNextStep").addClass("hide");
                        $('#dialog').css('display', 'none');
                        if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                            try {
                                var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                var dataType = $nextStep.attr("data-type");
                                if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                    $nextStep.removeAttr("onclick");
                                }
                            } catch (e) {
                                console.log(e);
                            }
                        }
                        return false;
                    }
                    $.post(CONFIG.ctx + '/html/studyCourse/studyCourse.checkIdentity.do', { 'loginName': loginName, 'password': password }, function (data) {
                        if (data && data.success) {
                            $.post(CONFIG.ctx + '/html/studyCourse/studyCourse.changeStudyRecord.do', { 'courseId': courseId }, function (data) {
                                if (!data.success) {
                                    $.vfdialog({
                                        cont: data.message,
                                        onlySure: true,
                                        width: 260,
                                        height: 20
                                    });
                                    $("#goNextStep").addClass("hide");
                                    if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                                        try {
                                            var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                            var dataType = $nextStep.attr("data-type");
                                            if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                                $nextStep.removeAttr("onclick");
                                            }
                                        } catch (e) {
                                            console.log(e);
                                        }
                                    }
                                    return false;
                                } else {
                                    $("#goNextStep").removeClass("hide");
                                    togglePlayState(false);
                                    var subTitleString = '';

                                    if (d.score && d.score != 'null' && d.score != '0.0') {
                                        subTitleString = TIPS['els.getScore'];
                                        // 判断是否展示学分
                                        if (null == d.hideCourseScore || d.hideCourseScore != 'true') {
                                            subTitleString = subTitleString + "<span class='cs-caution' style='color: #49A9EE'>" + d.score + "</span>" + TIPS['common.credit'];
                                        }
                                    }
                                    if (d.coursePeriod != null && d.coursePeriod != '' && d.coursePeriod != '0' && d.coursePeriod != 'null' && d.coursePeriod != '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.coursePeriod + "</span>学时";
                                    }
                                    if (d.get_score && d.get_score != 'null' && d.get_score != '0.0') {
                                        subTitleString = TIPS['els.getScore'] + "<span class='cs-caution' style='color: #49A9EE'>" + d.get_score + "</span>" + TIPS['common.credit'];
                                    }
                                    if (d.get_score && d.get_score != 'null' && d.get_score != '0.0') {
                                    }
                                    if (d.transAmount && d.transAmount != '0' && d.transAmount != 'null' && d.transAmount != '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.transAmount + "</span>" + d.dimLabel;
                                    }
                                    if (d.coinAmount && d.coinAmount != '0' && d.coinAmount != 'null' && d.coinAmount != '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.coinAmount + "</span>" + TIPS['els.common.mcCoin'];
                                    }
                                    var titleString = i18n("!v4.js.completeCourse") + '"' + ($("#courseTitle").text().trim()) + '"!';
                                    elpui.use('modal', function () {
                                        var modal = elpui.modal;
                                        modal.success({
                                            title: titleString,
                                            content: subTitleString + "！",
                                            cls: 'self-dialog-class-name',
                                            end: togglePlayState(true),
                                        });
                                    });
                                }
                            });
                        } else {
                            $.vfdialog({
                                cont: data.message,
                                onlySure: true,
                                width: 260,
                                height: 20
                            });
                            $("#goNextStep").addClass("hide");
                            $('#dialog').css('display', 'none');
                            if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                                try {
                                    var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                    var dataType = $nextStep.attr("data-type");
                                    if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                        $nextStep.removeAttr("onclick");
                                    }
                                } catch (e) {
                                    console.log(e);
                                }
                            }
                            return false;
                        }
                    });
                } else {
                    return false;
                }
            });
            $('#dialog').css('display', 'none');
        });
    };
    var saveUrlAndIndexAndDocPrecent;

    //NEW_COURSE_CENTER
    exports.learnOnlineUrlCourse = function (courseId, timmer) {
        var EventUtil = {
            addHandler: function (element, type, handler) {
                if (element.addEventListener) {
                    element.addEventListener(type, handler, false);
                } else if (element.attachEvent) {
                    element.attachEvent("on" + type, handler);
                } else {
                    element["on" + type] = handler;
                }
            }
        };
        EventUtil.addHandler(window, "online", function () {
            console.log("联网状态-OK");
        });
        EventUtil.addHandler(window, "offline", function () {
            console.log("离线状态-Oops");
            showNetErrorTip('网络连接中断')
        });
        // 保存进度方法
        saveUrlAndIndexAndDocPrecent = function saveUrlAndIndexAndDocPrecent(courseId, _timmmer, exit) {
            var async = isAsync();
            $.ajax({
                url: CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.saveCoursePrecent.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId,
                type: 'post',
                dataType: 'json',
                async: async,
                data: {
                    courseId: courseId,
                    playTime: _timmmer,
                    exit: exit
                },
                success: function (d) {
                    $('.ncp-time-tip.ncp-fail-tip').hide();
                    if (d != null) {
                        var minStudyTime = $('time:first').html();
                        var courseProgress = parseFloat(d.courseProgress);
                        var studiedTime = minStudyTime * courseProgress / 100;
                        studiedTime = parseInt(studiedTime);
                        $('#studiedTime').html(studiedTime);
                        //完成时，删除定时器
                        if (d.courseProgress == 100 || d.courseProgress == '100') {
                            window.clearInterval(preventCheatInterval)
                            window.removeEventListener('beforeunload', beforeunload_fun)

                            $(this).stopTime('timelabel');
                            $(this).stopTime('timelabel2');
                            if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                                $("#goNextStep").removeClass("hide");
                                showTrainingCamp()
                                try {
                                    var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                    var dataType = $nextStep.attr("data-type");
                                    if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                        $nextStep.attr("onclick", "loadStudyStep('" + dataType + "')");
                                        $nextStep.css("cursor", "pointer");
                                    }
                                } catch (e) {
                                    console.log(e);
                                }
                            }
                            if (d.stepToGetScore == 'false' && exit != true) {
                                // 弹窗显示已经完成 进入下一步
                                ncp.successTip("", {
                                    title: "",
                                    time: 4000,
                                    skin: " ncp-time-tip",
                                    closeBtn: false,
                                    btn: false,
                                    content: "<div style='font-size: 14px;margin: 5px 10px;'><span class='cl-catalog-icon' style='display: inline-block;margin-top: 0px;height: 20px;'></span>" + TIPS['els.course.studyCompleteTipNew'] + "</div>"
                                })
                            } else if (d.stepToGetScore == 'true' && exit != true) {
                                var corpCode = $("#courseCorpCode").val();
                                if ('linkstart' == corpCode || 'roxadustat' == corpCode || 'crmedicon' == corpCode || '3sbio' == corpCode) {
                                    checkIdentity(courseId, d);
                                } else {
                                    togglePlayState(false);
                                    var subTitleString = TIPS['els.getScore'];
                                    // 判断是否展示学分
                                    if (null == d.hideCourseScore || d.hideCourseScore != 'true') {
                                        subTitleString = subTitleString + "<span class='cs-caution' style='color: #49A9EE'>" + d.score + "</span>" + TIPS['common.credit'];
                                    }
                                    subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.coursePeriod + "</span>学时";
                                    var corpCodeCqrcpx = $('#corpCodeCqrcpx').val();
                                    if (corpCodeCqrcpx == 'cqrcpx') {
                                        subTitleString = TIPS['els.getScore'] + "<span class='cs-caution' style='color: #49A9EE'>" + d.score + "</span>" + '学时';
                                    }
                                    if (d.transAmount && d.transAmount != '0' && d.transAmount != 'null' && d.transAmount != '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.transAmount + "</span>" + d.dimLabel;
                                    }
                                    if (d.coinAmount && d.coinAmount != '0' && d.coinAmount != 'null' && d.coinAmount != '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.coinAmount + "</span>" + TIPS['els.common.mcCoin'];
                                    }
                                    var titleString = i18n("!v4.js.completeCourse") + '"' + ($("#courseTitle").text().trim()) + '"!';
                                    if (corpCodeCqrcpx == 'kuntuo') {
                                        titleString = '温馨提示：任何问题，请随时反馈培训部门，加油！';
                                    }
                                    elpui.use('modal', function () {
                                        var modal = elpui.modal;
                                        modal.success({
                                            title: titleString,
                                            content: subTitleString + "！",
                                            cls: 'self-dialog-class-name',
                                            end: togglePlayState(true)
                                        });
                                    })
                                }
                            }
                        }
                    } else {
                        var corpCode = $("#courseCorpCode").val();
                        if ('linkstart' == corpCode || 'roxadustat' === corpCode) {
                            checkStudyRecordRel(courseId);
                        }
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    // $(this).stopTime('timelabel');
                    console.log('Oops..');
                    errorMsg = 'jqXHR:' + window.JSON.stringify(jqXHR)
                    errorMsg += ',textStatus:' + window.JSON.stringify(textStatus)
                    errorMsg += ',errorThrown:' + window.JSON.stringify(errorThrown)
                    errorMsg += ',navigator.onLine:' + navigator.onLine
                    showNetErrorTip(errorMsg)
                }
            })
        };

        exports.checkStudyRecordRel = function (courseId, minStudyTime) {
            $.post(CONFIG.ctx + 'html/studyCourse/studyCourse.loadStudyRecordRel.do', { 'courseId': courseId }, function (data) {
                if (data && data.success) {
                    document.getElementById('dialog').style.display = 'block';
                    //点击叉关闭弹框
                    $('.dialog-close_area').on('click', function () {
                        $('#dialog').css('display', 'none');
                        $("#goNextStep").addClass("hide");
                        if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                            try {
                                var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                var dataType = $nextStep.attr("data-type");
                                if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                    $nextStep.removeAttr("onclick");
                                }
                            } catch (e) {
                                console.log(e);
                            }
                        }
                    });

                    $('.confirm-btn').on('click', function () {
                        var loginName = $('#account').val();
                        var password = $('#psd').val();
                        if (loginName == '' || password == '') {
                            $.vfdialog({
                                cont: '请输入用户名或密码',
                                onlySure: true,
                                width: 260,
                                cls: 'resume-vfdialog',
                                height: 20
                            });
                            $('#dialog').css('display', 'none');
                            $("#goNextStep").addClass("hide");
                            if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                                try {
                                    var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                    var dataType = $nextStep.attr("data-type");
                                    if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                        $nextStep.removeAttr("onclick");
                                    }
                                } catch (e) {
                                    console.log(e);
                                }
                            }
                            return false;
                        }
                        $.post(CONFIG.ctx + '/html/studyCourse/studyCourse.checkIdentity.do', { 'loginName': loginName, 'password': password }, function (data) {
                            if (data && data.success) {
                                $.post(CONFIG.ctx + '/html/studyCourse/studyCourse.changeStudyRecord.do', { 'courseId': courseId }, function (data) {
                                    if (!data.success) {
                                        $.vfdialog({
                                            cont: data.message,
                                            onlySure: true,
                                            width: 260,
                                            height: 20
                                        });
                                        $('#dialog').css('display', 'none');
                                        $("#goNextStep").addClass("hide");
                                        if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                                            try {
                                                var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                                var dataType = $nextStep.attr("data-type");
                                                if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                                    $nextStep.removeAttr("onclick");
                                                }
                                            } catch (e) {
                                                console.log(e);
                                            }
                                        }
                                        return false;
                                    } else {
                                        var d = data.jsonObj;
                                        togglePlayState(false);
                                        var subTitleString = TIPS['els.getScore'];
                                        // 判断是否展示学分
                                        if (null == d.hideCourseScore || d.hideCourseScore != 'true') {
                                            subTitleString = subTitleString + "<span class='cs-caution' style='color: #49A9EE'>" + d.getScore + "</span>" + TIPS['common.credit'];
                                        }
                                        if (d.coursePeriod != null && d.coursePeriod != '' && d.coursePeriod != '0' && d.coursePeriod != 'null' && d.coursePeriod != '0.0') {
                                            subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.coursePeriod + "</span>学时";
                                        }
                                        if (d.transAmount && d.transAmount != '0' && d.transAmount != 'null' && d.transAmount != '0.0') {
                                            subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.transAmount + "</span>" + d.dimLabel;
                                        }
                                        if (d.coinAmount && d.coinAmount != '0' && d.coinAmount != 'null' && d.coinAmount != '0.0') {
                                            subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + d.coinAmount + "</span>" + TIPS['els.common.mcCoin'];
                                        }
                                        var titleString = i18n("!v4.js.completeCourse") + '"' + ($("#courseTitle").text().trim()) + '"!';
                                        elpui.use('modal', function () {
                                            var modal = elpui.modal;
                                            modal.success({
                                                title: titleString,
                                                content: subTitleString + "！",
                                                cls: 'self-dialog-class-name',
                                                end: togglePlayState(true),
                                            });
                                        });
                                        $('#studiedTime').html(minStudyTime);
                                        $("#goNextStep").removeClass("hide");
                                    }
                                });
                            } else {
                                $.vfdialog({
                                    cont: data.message,
                                    onlySure: true,
                                    width: 260,
                                    height: 20
                                });
                                $('#dialog').css('display', 'none');
                                $("#goNextStep").addClass("hide");
                                if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                                    try {
                                        var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                        var dataType = $nextStep.attr("data-type");
                                        if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                            $nextStep.removeAttr("onclick");
                                        }
                                    } catch (e) {
                                        console.log(e);
                                    }
                                }
                                return false;
                            }
                        });
                        $('#dialog').css('display', 'none');
                    });
                } else {
                    $('#dialog').css('display', 'none');
                }
            });
        };
        //窗口关闭前保存进度--
        //使用这个而不是window.onbeforeunload，在高版本的chrome也可以调用
        window.addEventListener('beforeunload', beforeunload_fun);
        if (parseFloat($('time:first').html()) == 0) {
            saveUrlAndIndexAndDocPrecent(courseId, playTime, false)
        }
        function onunload_fun() {
            try {
                if (clearTrackRecord && enablePreventCheat) {
                    console.log('不记录进度')
                } else {
                    saveUrlAndIndexAndDocPrecent(courseId, playTime, true);
                }
                if (playTime != undefined && playTime > 30) {
                    playTime = 0;//如果播放时间大于30s就说明已经保存播放时间，清零处理
                }
            } catch (e) {
                console.log(e)
            }
            //真的是退出 目前只支持IE，FireFox
            $.ajax({
                type: "POST",
                async: asyncBrowser,
                url: CONFIG.ctx + "html/courseStudyItem/courseStudyItem.exitStudy.do?courseId=" + courseId, //获取课程资源信息
                success: function (d) {
                }
            });
            if (heartInterval) { clearTimeout(heartInterval); heartInterval = null; }
        }

        $(function () {
            //start
            //优化页面关闭保存进度 beforeunload
            window.addEventListener('beforeunload', onunload_fun);
            if (typeof (info) !== "undefined" && info.courseCourseStudyFinished === "true") {
                return;
            }
            //end
            playTime = 0;
            setInterval(function () {
                playTime++;
            }, 1000);
            // 保存进度
            var thisObj = $('#newViewerPlaceHolder');
            require([CONFIG.ctxRemote + 'js/jquery.timers.js'], function () {
                //timmer * 1000
                //TODO 此处优化学习进度保存的频率
                thisObj.everyTime(60 * 1000, 'timelabel', function (i) {
                    var minStudyTime = $('time:first').html();
                    if (typeof (minStudyTime) == "undefined")
                        minStudyTime = 3;
                    var studiedTime = $('#studiedTime').html();
                    if (typeof (studiedTime) == "undefined")
                        studiedTime = 0;
                    if (playTime >= 170 || (parseInt(studiedTime) * 60 + playTime + 10 >= parseInt(minStudyTime) * 60)) {
                        saveUrlAndIndexAndDocPrecent(courseId, playTime);
                        // 自动保存后要把定时变量重置
                        playTime = 0;
                    }
                });

                thisObj.everyTime(3 * 60 * 1000, 'timelabel2', function (i) {
                    $.post(CONFIG.ctx + "html/courseStudyItem/courseStudyItem.updateTimestepByUserTimmer.do");
                })
            });
            $("#goBack").click(function () {
                // 保存学习进度
                saveUrlAndIndexAndDocPrecent(courseId, timmer, true);
            })
        });

        //单分屏防挂机
        $(function () {
            $.get('/els/html/course/course.loadCourseSystemSeting.do?courseId=' + courseId + "&eln_session_id=" + CONFIG.elnSessionId, function (data) {
                console.log('get课程设置2');
                isheart = !!data.heartBeat;
                iscontinueHeartBeat = !!data.continueHeartBeat;

                if (isheart && info.viewMode != 'browsed') {
                    if (!isCompleted || iscontinueHeartBeat) {
                        console.log('启动心跳2');
                        heartApifun();
                        heartInterval = window.setInterval(function () {
                            console.log('心跳定时2');
                            heartApifun();
                        }, 60 * 1000);
                    }
                }

                enablePreventHang = data.enablePreventHang;
                preventHangTime = data.preventHangTime;

                enablePreventCheat = data.checkType;
                console.log('checkType: ' + enablePreventCheat);

                preventMaxTime = data.preventCheatTimeTo;
                preventMinTime = data.preventCheatTime;
                clearTrackRecord = data.clearTrackRecords;

                preventCheatTime = (Math.random() * (preventMaxTime - preventMinTime) + preventMinTime).toFixed(1)

                if (enablePreventHang) {
                    initPreventHangTime(CONFIG, info, studyCourse);
                }
                // 防作弊
                if (enablePreventCheat == 2) {
                    exports.enable();
                } else if (enablePreventCheat == 1) { // 人脸识别
                    facRecognition.initFace();
                } else {
                    return false;
                }

            }
            )
        });

    };
    //NEW_COURSE_CENTER modify by ldc
    exports.learnOnlineDocCourse = function (courseId, timmer) {
        exports.learnOnlineUrlCourse(courseId, timmer);
    };

    //签到
    function signIn() {
        var dom = '<div class="signIn-box"><div class="signIn-warp"><div class="signImg"></div><div class="signInBtn innerBtn" id="signInBtn" style="text-align:center;margin:0 10%;height:33px;line-height:33px;border-radius:16.5px;color:#ffffff;background-color:#1788ff;margin-top:15px">签到</div><div class="quitStudy innerBtn" id="quitStudyBtn" style="text-align:center;margin:0 10%;height:33px;line-height:33px;border-radius:16.5px;color:#1788ff;background-color:#ffffff;border:1px solid #1788ff;margin-top:10px">退出课程学习</div></div><div>'
        debugger;
        $('body').append(dom)
        $('.signIn-warp').on('click', '.innerBtn', function (e) {
            console.log(e)
            if ($(this)[0].innerText == '签到') {
                //签到
            } else {
                $('.signIn-box').hide();
                //退出签到
                //    window.open('', '_self');
            }
            // if($(this).){}
        })
    };

    var EventUtil = {
        addHandler: function (element, type, handler) {
            if (element.addEventListener) {
                element.addEventListener(type, handler, false);
            } else if (element.attachEvent) {
                element.attachEvent("on" + type, handler);
            } else {
                element["on" + type] = handler;
            }
        }
    };



    // 播放（新）
    window.tbc_play = function (e, params) {
        if (isheart && info.viewMode != 'browsed') {
            if (!isCompleted || iscontinueHeartBeat) {
                console.log('启动心跳播放');
                heartApifun();
                heartInterval = window.setInterval(function () {
                    console.log('心跳定时播放');
                    heartApifun();
                }, 60 * 1000);
            }
        }

        var courseStandard = info.courseStandard;
        if (courseStandard === 'TWOSCREEN') {
            console.log('播放');
            return;
        }
        var p = {
            courseId: params.courseId,
            scoId: params.scoId,
        };

        $.ajax({
            url: CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.play.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId,
            data: p,
            async: true,
            type: 'post',
            dataType: 'json',
            success: function (res) {

            }
        });
    };

    // 暂停（新）
    window.tbc_suspend = function (e, params) {
        console.log('清除心跳');
        if (heartInterval) { clearTimeout(heartInterval); heartInterval = null; }
        var courseStandard = info.courseStandard;
        if (courseStandard === 'TWOSCREEN') {
            console.log('暂停');
            return;
        }

        var p = {
            courseId: params.courseId,
            scoId: params.scoId,
            location: params.location,
        };
        $.ajax({
            url: CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.pause.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId,
            data: p,
            async: true,
            type: 'post',
            dataType: 'json',
            success: function (res) {
            }
        });
    };

    // 播放完成（新）
    window.LUO_completeEvent = function (params, data) {
        //更新章节图标
        changeScoIcon(params.scoId);
        if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
            $("#goNextStep").removeClass("hide");
            try {
                var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                var dataType = $nextStep.attr("data-type");
                if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                    $nextStep.attr("onclick", "loadStudyStep('" + dataType + "')");
                    $nextStep.css("cursor", "pointer");
                }
            } catch (e) {
                console.log(e);
            }
        }

        if (info.stepToGetScore != 'COURSE_COURSE_STUDY') {
            // 弹窗显示已经完成 进入下一步
            ncp.successTip("", {
                title: "",
                time: 4000,
                skin: " ncp-time-tip",
                closeBtn: false,
                btn: false,
                content: "<div style='font-size: 14px;margin: 5px 10px;'><span class='cl-catalog-icon' style='display: inline-block;margin-top: 0px;height: 20px;'></span>" + TIPS['els.course.studyCompleteTipNew'] + "</div>"
            })
        } else if (info.stepToGetScore == 'COURSE_COURSE_STUDY') {
            var corpCode = info.corpCode;
            var courseId = info.courseId;
            if ('linkstart' == corpCode || 'roxadustat' === corpCode || 'crmedicon' == corpCode || '3sbio' == corpCode) {
                checkIdentity(courseId, data);
            } else {
                togglePlayState(false);
                var subTitleString = TIPS['els.getScore'];
                // 判断是否展示学分
                if (null == data.hideCourseScore || data.hideCourseScore != 'true') {
                    subTitleString = subTitleString + "<span class='cs-caution' style='color: #49A9EE'>" + data.get_score + "</span>" + TIPS['common.credit'];
                }
                if (data.coursePeriod != null && data.coursePeriod != '' && data.coursePeriod != '0' && data.coursePeriod != 'null' && data.coursePeriod != '0.0') {
                    subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + data.coursePeriod + "</span>学时";
                }
                var corpCodeCqrcpx = $('#corpCodeCqrcpx').val();
                if (corpCodeCqrcpx == 'cqrcpx') {
                    subTitleString = TIPS['els.getScore'] + "<span class='cs-caution' style='color: #49A9EE'>" + data.get_score + "</span>" + '学时';
                }
                if (data.transAmount && data.transAmount !== 'null' && data.transAmount !== '0' && data.transAmount !== '0.0') {
                    subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + data.transAmount + "</span>" + data.dimLabel;
                }

                if (data.coinAmount && data.coinAmount !== 'null' && data.coinAmount !== '0' && data.coinAmount !== '0.0') {
                    subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + data.coinAmount + "</span>" + TIPS['els.common.mcCoin'];
                }
                var titleString = i18n("!v4.js.completeCourse") + '"' + ($("#courseTitle").text().trim()) + '"!';
                if (corpCodeCqrcpx == 'kuntuo') {
                    titleString = '温馨提示：任何问题，请随时反馈培训部门，加油！';
                }
                elpui.use('modal', function () {
                    var modal = elpui.modal;
                    modal.success({
                        title: titleString,
                        content: subTitleString + "！",
                        cls: 'self-dialog-class-name',
                        end: togglePlayState(true)
                    });
                });
            }
        }
    };

    //课程学习
    studyCourse = {

        iframPage: function (url) {
            return '<iframe style="width:100%;height:100%;border:none;frameborder=0" border="0"  frameborder="0" src="' + url + '"></iframe>';
        },
        scrollingIframPage: function (url) {
            return '<iframe class="nano-iframe" name="nanoIframe" style="width:100%;border:none;frameborder=0" border="0" frameborder="0" src="' + url + '"></iframe>';
        },
        setVboxServer: function (server) {
            vbox_server = server;
        },
        setHasSwitch: function (num) {
            hasSwitch = num
        },
        fromNetWorkSetting: function (flag) {
            fromNetWorkSetting = flag;
        },

        //课程学习,点击观看课程
        learn: function (courseId) {
            if (courseId == undefined || courseId == "") {
                ncp.alert({
                    content: i18n("!v4.js.courseNotExit")
                });
                return false;
            }
            var courseStandard;
            //检测课程是否允许重复学习，如果允许，返回课程对象信息
            $.post(CONFIG.ctx + 'html/course/course.courseInfoJson.do', { "courseId": courseId }, function (data) {
                if (data == "false") {

                    ncp.alert({
                        content: i18n("!v4.js.contactAdmin")
                    });
                    return false;
                }
                courseStandard = data.courseStandard;
                studyCourse.learnCourse(courseId, courseStandard);
            });
        },

        //课程学习
        learnCourse: function (courseId, type) {
            if (type == "ONLINEDOC") {//文档类课程
                //获取文档类课程子文件的url
                $.post(CONFIG.ctx + 'html/course/course.obtainFsCountUrl.do', { "courseId": courseId }, function (data) {
                    if (data == null || data.fsCountUrl == null) {
                        ncp.alert({
                            content: i18n("v4.js.courseBroken")
                        });
                        return false;
                    }
                    require([CONFIG.ctxRemote + 'js/jquery.jsonp.js'], function () {
                        $.jsonp({
                            url: data.fsCountUrl,
                            data: data,
                            callbackParameter: "callback",
                            callback: "jsonp",
                            success: function (data, textStatus) {
                                var intCnt = data.subFileCount;
                                var msg = data.processMessage;
                                if (intCnt == 0) {
                                    $.msgF(i18n("v4.js.courseBroken"));
                                } else if (intCnt < 0) {
                                    $.msgF(msg);
                                } else if (intCnt > 0) {
                                    var url = CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.learn.do?courseId=' + courseId + '&courseCount=' + intCnt,
                                        h = window.screen.height,
                                        w = window.screen.width;
                                    try {
                                        //window.open(url, 'learnWindow', 'height=' + h + ', width=' + w + ', top=0, left=0, toolbar=no, menubar=no, scrollbars=yes, resizable=yes,location=no, status=no')
                                        //window.learnWindow = window.open(url, 'learnWindow', 'top=0, left=0, toolbar=no, menubar=no, scrollbars=yes, resizable=yes,location=no, status=no',true);
                                        location.href = url;
                                    } catch (e) {
                                        //alert(e);
                                    }
                                }
                                else {
                                    $.msgF(i18n("v4.js.uploadError"));
                                }
                            }
                        })
                    });
                });
                return false;
            }
            //只有scorm课程才有这个url
            var newScormUrl = "";
            if (type.toLowerCase().indexOf("scorm") > -1) {//scorm类课程
                $.ajax({
                    type: "POST",
                    url: CONFIG.ctx + "/html/courseStudyItem/courseStudyItem.getNewScormUrl.do?courseId=" + courseId, //获取课程资源信息
                    async: false,
                    success: function (d) {
                        newScormUrl = d.url;
                    }
                });
            }
            var url = CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.learn.do?courseId=' + courseId + '&vb_server=' + vbox_server + '&willGoStep=' + goToStep;
            if (newScormUrl != null && newScormUrl != "") {
                var host = window.location.host;
                url = newScormUrl + url + "&elsSign=" + CONFIG.elnSessionId + "&host=" + host;
            }
            //内部tbc课跳转http
            if (type == "ONESCREEN" || type == "TWOSCREEN" || type == "THREESCREEN") { //如果为tbc类型课程
                $.ajax({
                    type: "POST",
                    url: CONFIG.ctx + "html/courseInfo/courseinfo.getTbcCourseIp.do?courseId=" + courseId,
                    async: false,
                    success: function (d) {
                        if (d.success) {
                            url = "http" + "://" + d.message + CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.learn.do?courseId=' + courseId + '&vb_server=' + vbox_server + '&willGoStep=' + goToStep + "&eln_session_id=" + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId;
                        }
                    }
                });
            }
            location.href = url;
        },

        //根据课程类型和路径 学习课程
        learnByType: function (courseStandard, courseId, filePath) {
            if (courseStandard == 'DOWNLOAD') {
                window.open(filePath, '_blank_course_download');
            } else {
                studyCourse.learn(courseId);
            }
        },

        /**
         * 点击课程目录树章节节点，加载课件视频、讲义（三分屏）
         * 视频：#videoCon
         */
        coursePlay: function (scoId, INFO, cnt) {
            // console.log(INFO);
            var isView = INFO.viewMode === 'browsed';
            // console.log('标记切换');
            if (!isView && !(INFO.courseStandard === 'CHAPTEROLINEURL')) {
                //检测两分屏课程是否可以保存进度
                coursePlay.checkSaveTwoScreen(INFO.courseId, coursePlay._lastScoid, false);
                //切换章节，记录上一个观看的章节
                coursePlay.saveUserLastWatchSco(INFO.courseId, coursePlay._lastScoid);
            } else if (INFO.courseStandard === 'CHAPTEROLINEURL') {
                var param = 'courseId=' + INFO.courseId + '&scoId=' + coursePlay._lastScoid + '&progress_measure=8&session_time=0:0:180';
                studyCourse.doSaveProgress(param, coursePlay._lastScoid, false);
            }

            try {
                studyCourse.onbeforeunloadHandlerForEveryCourse();
            } catch (e) {

            }
            try {
                //用于vbox切换视频资源，视频资源没有拉取完还在执行定时器，清除定时器
                clearTimeout(vboxSelectVideo);
            } catch (e) {

            }
            window.aliplayerApi = function (e, params) {
                console.log('aliplayerApi', params);
                videoPlay = params;

                if (params.getStatus() == 'ready') {
                    var res = {
                        courseId: INFO.course_id,
                        scoId: INFO.scoId,
                        duration: params.getDuration() * 1000
                    };
                    console.log(res, 'duration视频长度');

                    $.ajax({
                        url: CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.saveDuration.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId,
                        data: res,
                        async: true,
                        type: 'post',
                        dataType: 'json',
                        success: function (res) {

                        }
                    });
                }

            };
            var playTime = 0;
            if (videoPlay) {
                try {
                    window.onbeforeunload = function () { };
                    playTime = videoPlay.getCurrentTime();
                } catch (e) {
                }
            }
            var sourceUrl = "html/courseStudyItem/courseStudyItem.selectResource.do";
            if (isView) {
                sourceUrl = "html/coursePreview/coursepreview.selectResource.do";
            }
            function addOfflineHandler() {
                EventUtil.addHandler(window, "offline", function () {
                    console.log("离线状态-Oops");
                    showNetErrorTip('网络连接中断')
                });
            }
            $.ajax({
                type: "POST",
                url: CONFIG.ctx + sourceUrl + "?host=" + CONFIG.hostDomain + "&vbox_server=" + vbox_server + "&fromNetWorkSetting=" + fromNetWorkSetting + "&chooseHttp=" + document.location.protocol + "&courseType=NEW_COURSE_CENTER" + "&eln_session_id=" + CONFIG.elnSessionId, //获取课程资源信息
                data: "scoId=" + scoId + "&courseId=" + INFO.courseId
                    + "&firstLoad=" + (CONFIG.firstLoad ? "true" : "false")
                    + "&location=" + playTime,
                async: false,
                success: function (d) {
                    // 环球课程讲义定制
                    if (d.showNote != null && d.showNote == "true") {
                        if (d.noteUrl != null && d.noteUrl != "")
                            $('#courseReference').html('<br/><ul class="cd-data-list"><li class="cd-data-item"><span>' + d.noteName + '</span><a href="'
                                + d.noteUrl + '" class="cd-icon pull-right cd-icon-see" target="_blank"></a>');
                        else
                            $('#courseReference').html('');
                    }

                    window.aliplayerApi = function (e, params) {
                        videoPlay = params;
                    };
                    isCompleted = d.isComplete == 'false' ? false : true;
                    console.log('切换章节时清除心跳');
                    if (heartInterval) { clearTimeout(heartInterval); heartInterval = null; }
                    if (isCompleted && iscontinueHeartBeat) {
                        console.log('启动心跳播放-已学完');
                        heartApifun();
                        heartInterval = window.setInterval(function () {
                            console.log('心跳定时播放-已学完');
                            heartApifun();
                        }, 60 * 1000);
                    }
                    //保存视频总时长
                    setTimeout(function () {
                        if (!videoErrStatus && Object.getOwnPropertyNames(videoPlay).length !== 0 && videoPlay.getStatus()) {
                            var data = {
                                courseId: info.courseId,
                                scoId: info.scoId,
                                duration: videoPlay.getDuration() * 1000
                            };
                            if (data && data.courseId && data.scoId && data.duration && duration.duration != 0) {
                                $.ajax({
                                    url: CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.saveDuration.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId,
                                    data: data,
                                    async: true,
                                    type: 'post',
                                    dataType: 'json',
                                    success: function (res) {
                                        console.log('保存视频总时长-->', videoPlay.getDuration());
                                    }
                                });
                            }
                        }
                    }, 10000);


                    CONFIG.firstLoad = false;
                    var screenType = INFO.courseStandard.toUpperCase();
                    // 清除未执行完成的定时内容
                    try {
                        // console.log("清·4");
                        window.clearInterval(saveProgressInter);
                        window.clearInterval(wmv_inter);
                        window.clearInterval(wmv_inter_a);
                        window.clearInterval(preventCheatInterval);
                        window.clearInterval(updateStudiedTime);
                        // if (enablePreventCheat && (d.isComplete == 'false')) {
                        //   exports.enable();
                        // }
                        if (d.isComplete == 'false') {
                            // 防作弊
                            if (enablePreventCheat == 2) {
                                exports.enable();
                            } else if (enablePreventCheat == 1) { // 人脸识别
                                facRecognition.initFace();
                            }
                        }

                        processType = '';
                    } catch (e) {
                    }

                    coursePlay._lastScoid = INFO.scoId;

                    if (screenType == 'THREESCREEN') {
                        $('#playBarrageId').css('display', 'block');
                        coursePlay.threeScreen(INFO.courseId, scoId, INFO.viewMode, d, cnt);
                        addOfflineHandler()
                    } else if (screenType == 'TWOSCREEN') { //两分屏
                        console.log('切换章节记录');
                        // console.log(d);
                        $('#minStudyTime').html(d.minStudyTime);
                        if (d.isComplete == 'true' || (d.isComplete !== "false" && d.isComplete)) {
                            $('#studiedTime').html(d.minStudyTime);
                        } else if (parseInt(d.studiedTime) > parseInt(d.minStudyTime)) {
                            $('#studiedTime').html(d.minStudyTime);
                        } else {
                            $('#studiedTime').html(d.studiedTime)
                        }
                        exports.updateTwoScreenRateTime(rateTimmer, d);
                        $('#twoScreenInter').removeClass('hide');
                        var barWidth = $('.vodbar .barleft').width() - 30;
                        //二分屏播放
                        coursePlay.twoScreen(INFO.courseId, INFO.scoId, INFO.viewMode, d, cnt);
                        coursePlay._startTime = new Date().getTime();
                        //二分屏讲义放大处理
                        if (checkIsTwoScreenLecture(d)) {
                            zoomTwoScreenCourse();
                        } else {
                            $("#TwoScreenCtrlBar").addClass("hide");
                            $("#handouts").attr("style", "width:100%;" + "height:400px;");
                            $("#lessenScormCourse").addClass("hide");
                        }
                        addOfflineHandler()
                    } else if ((screenType == 'SCORM12') || (screenType == 'SCORM13') || (screenType == 'SCORM14')) {//scorm课件
                        $(".cl-barrage-wrap").hide();
                        window.isScorm = true;
                        zoomScormCourse();
                        coursePlayScorm.scorm(INFO.courseId, scoId, INFO.viewMode, d);
                        addOfflineHandler()
                    } else if (screenType == 'ONESCREEN') {
                        if (d.mp4path != undefined && d.mp4path != null && d.mp4path != '') {
                            $('#viewerPlaceHolder').attr("src", CONFIG.ctx + "/html/study/study.playOneScreen.do?courseType=NEW_COURSE_CENTER&mp4Path=" + d.mp4path + "&courseId=" + INFO.courseId);
                        }
                    } else if (screenType == 'ONLINEPACKAGE') {
                        if (d.filePath != undefined && d.filePath != null && d.filePath != '') {
                            $('#viewerPlaceHolder').attr("src", d.filePath);
                        }
                        addOfflineHandler()
                    } else if (screenType == 'CHAPTEROLINEURL') {
                        if (d.CHAPTER_URL != undefined && d.CHAPTER_URL != null && d.CHAPTER_URL != '') {
                            $('#minStudyTime').html(d.minStudyTime);
                            if (d.isComplete == 'true' || (d.isComplete !== "false" && d.isComplete)) {
                                $('#studiedTime').html(d.minStudyTime);
                            } else if (parseInt(d.studiedTime) > parseInt(d.minStudyTime)) {
                                $('#studiedTime').html(d.minStudyTime);
                            } else {
                                $('#studiedTime').html(d.studiedTime)
                            }
                            exports.updateTwoScreenRateTime(rateTimmer, d);
                            $('#twoScreenInter').removeClass('hide');
                            var barWidth = $('.vodbar .barleft').width() - 30;
                            zoomTwoScreenCourse();
                            console.log("-----------" + INFO.fileHref);
                            if (INFO.fileHref && INFO.fileHref.indexOf("chuanghehui") >= 0) {
                                coursePlay.chhChapterUrl(INFO.courseId, scoId, INFO.viewMode, d);
                            } else {
                                coursePlay.chapterUrl(INFO.courseId, scoId, INFO.viewMode, d);
                            }
                        }
                        addOfflineHandler()
                    } else {
                        togglePlayState(false);
                        ncp.alert({
                            content: i18n("!v4.js.unknownCourseType"),
                            onEnd: function () {
                                togglePlayState(true)
                            }
                        });
                    }
                    // coursePlay._lastScoid = scoId;
                    //检测用户是否有课程在学习，并把当前课程设置为正在学习状态（每人有且只有一门课程是正在学习状态）
                    if (screenType.indexOf("SCORM") > -1) {
                        scoId = "null";
                    }
                    studyCheck(INFO.courseId, scoId);
                },
                error: function () {
                    togglePlayState(false);
                    ncp.alert({
                        content: i18n("!v4.js.errorTryAgain"),
                        onEnd: function () {
                            togglePlayState(true)
                        }
                    });
                }
            })

        },

        /**
         * 窗口关闭时视频播放动作
         */
        onbeforeunloadHandler: function (exit) {
            try {
                var course_id = $('#courseId').val(),
                    standard = $('#standard').val();
                if (exit && (standard === 'TWOSCREEN' || standard == 'THREESCREEN' || standard == 'CHAPTEROLINEURL')) {
                    $.post(CONFIG.ctx + 'html/course/course.checkCourseStudy.do?exit=true', { "courseId": course_id });
                }

                if ((standard === 'TWOSCREEN' || standard == 'THREESCREEN' || standard == 'CHAPTEROLINEURL')) {
                    coursePlay.checkSaveTwoScreen(course_id, coursePlay._lastScoid, false, exit);
                }
                // window.onbeforeunload();
            } catch (e) {
                //window.opener.reloadCourseCourseStudy();
            }
        },

        /**
         * 切换章节时视频播放动作
         */
        onbeforeunloadHandlerForEveryCourse: function () {
            if (window.opener && typeof window.opener.reloadCourseCourseStudy == 'function') {
                window.opener.reloadCourseCourseStudy();
            }
        },

        //保存学习进度
        doSaveProgress: function (p, scoId, async, upLearningTime) {
            logId = logId || '';
            var exit = false;
            if (p.indexOf("exit") != -1) {
                exit = true;
            }
            // console.log("请求前scoId-->" + scoId);
            async = isAsync();
            $.ajax({
                url: CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.saveProgress.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId,
                data: p + '&logId=' + logId,
                async: async,
                type: 'post',
                dataType: 'json',
                success: function (data) {
                    $('.ncp-time-tip.ncp-fail-tip').hide();
                    logId = data.logId;
                    console.log('是否完成 ---- > ', data.completed);
                    if (data.completed == true || data.completed == 'true') {
                        //已完成时，删除定时器
                        window.clearInterval(saveProgressInter);
                        if (threeScreenPlayerStateInterval) {
                            window.clearInterval(threeScreenPlayerStateInterval);
                        }
                        //更新章节图标
                        console.log('upLearningTime', upLearningTime);
                        changeScoIcon(scoId, upLearningTime);
                        //弹出训练营
                        showTrainingCamp()                     //完成时，删除定时器
                        if (data.courseProgress == 100 || data.courseProgress == '100') {
                            window.onbeforeunload = null;
                            // $(this).stopTime('timelabel');
                            if ($("#courseInfoSteps").find(".cs-item-exam,.cs-item-evaluate").length > 0) {
                                $("#goNextStep").removeClass("hide");
                                try {
                                    var $nextStep = $("#courseInfoSteps").find(".cs-item-study").next("li").find("a");
                                    var dataType = $nextStep.attr("data-type");
                                    if (dataType != null && dataType != undefined && (dataType == 'COURSE_EVALUATE' || dataType == 'COURSE_EXAM')) {
                                        $nextStep.attr("onclick", "loadStudyStep('" + dataType + "')");
                                        $nextStep.css("cursor", "pointer");
                                    }
                                } catch (e) {
                                    console.log(e);
                                }
                            }
                            if (info.stepToGetScore != 'COURSE_COURSE_STUDY' && exit != true) {
                                // 弹窗显示已经完成 进入下一步
                                ncp.successTip("", {
                                    title: "",
                                    time: 4000,
                                    skin: " ncp-time-tip",
                                    closeBtn: false,
                                    btn: false,
                                    content: "<div style='font-size: 14px;margin: 5px 10px;'><span class='cl-catalog-icon' style='display: inline-block;margin-top: 0px;height: 20px;'></span>" + TIPS['els.course.studyCompleteTipNew'] + "</div>"
                                })
                            } else if (info.stepToGetScore == 'COURSE_COURSE_STUDY' && exit != true) {
                                var corpCode = info.corpCode;
                                var courseId = info.courseId;
                                if ('linkstart' == corpCode || 'roxadustat' === corpCode || 'crmedicon' == corpCode || '3sbio' == corpCode) {
                                    checkIdentity(courseId, data);
                                } else {
                                    togglePlayState(false);
                                    var subTitleString = TIPS['els.getScore'];
                                    // 判断是否展示学分
                                    if (null == data.hideCourseScore || data.hideCourseScore != 'true') {
                                        subTitleString = subTitleString + "<span class='cs-caution' style='color: #49A9EE'>" + data.get_score + "</span>" + TIPS['common.credit'];
                                    }
                                    if (data.coursePeriod != null && data.coursePeriod != '' && data.coursePeriod != '0' && data.coursePeriod != 'null' && data.coursePeriod != '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + data.coursePeriod + "</span>学时";
                                    }
                                    var corpCodeCqrcpx = $('#corpCodeCqrcpx').val();
                                    if (corpCodeCqrcpx == 'cqrcpx') {
                                        subTitleString = TIPS['els.getScore'] + "<span class='cs-caution' style='color: #49A9EE'>" + data.get_score + "</span>" + '学时';
                                    }
                                    if (data.transAmount && data.transAmount !== 'null' && data.transAmount !== '0' && data.transAmount !== '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + data.transAmount + "</span>" + data.dimLabel;
                                    }

                                    if (data.coinAmount && data.coinAmount !== 'null' && data.coinAmount !== '0' && data.coinAmount !== '0.0') {
                                        subTitleString = subTitleString + "，<span class='cs-caution' style='color: #49A9EE'>" + data.coinAmount + "</span>" + TIPS['els.common.mcCoin'];
                                    }
                                    var titleString = i18n("!v4.js.completeCourse") + '"' + ($("#courseTitle").text().trim()) + '"!';
                                    if (corpCodeCqrcpx == 'kuntuo') {
                                        titleString = '温馨提示：任何问题，请随时反馈培训部门，加油！';
                                    }
                                    elpui.use('modal', function () {
                                        var modal = elpui.modal;
                                        modal.success({
                                            title: titleString,
                                            content: subTitleString + "！",
                                            cls: 'self-dialog-class-name',
                                            end: togglePlayState(true)
                                        });
                                    });
                                }
                            }
                        }
                    }
                },
                error: function (jqXHR, textStatus, errorThrown) {
                    console.log('Oops..');
                    errorMsg = 'jqXHR:' + window.JSON.stringify(jqXHR)
                    errorMsg += ',textStatus:' + window.JSON.stringify(textStatus)
                    errorMsg += ',errorThrown:' + window.JSON.stringify(errorThrown)
                    errorMsg += ',navigator.onLine:' + navigator.onLine
                    showNetErrorTip(errorMsg)
                }
            });
        }

    };

    var startTime;//学习开始时间
    var videoType;
    var wmvCourseId = "";
    var wmvScoId = "";
    var processType = '';

    //课件资源加载
    var coursePlay = {
        _lastScoid: null,
        _startTime: 0,

        //记录上次观看的章节信息
        saveUserLastWatchSco: function (courseId, scoId) {
            if (scoId) {
                $.ajax({
                    type: "POST",
                    url: CONFIG.ctx + "html/studyCourse/studyCourse.lastScoRecord.do?courseId=" + courseId + "&scoId=" + scoId,
                    async: true,
                    success: function (d) {
                        console.log("ubr save");
                    }
                });
            }
        },

        //检测是否可以保存两分屏课程进度
        checkSaveTwoScreen: function (courseId, scoId, async, exit) {
            if (scoId) {
                var now = new Date().getTime(),
                    st = this._startTime;
                if (!interval) {
                    interval = 3 * 60;
                }

                if (st != 0 && now - st < interval * 1000) {
                    //保存两分屏课程进度
                    // console.log('检测是否可以保存两分屏课程进度');
                    this.saveTwoScreen(courseId, scoId, Math.floor((now - st) / 1000), async, exit);
                }
                this._startTime = new Date().getTime();
            }
        },

        //记录多分屏进度
        saveTwoScreen: function (courseId, scoId, time, async, exit, upLearningTime) {
            startTime = getDate();
            window.aliplayerApi = function (e, params) {
                videoPlay = params;
            };
            // var playTime;
            if (Object.getOwnPropertyNames(videoPlay).length !== 0) {
                try { // getCurrentTime 获取当前进度条的播放秒数
                    playTime = videoPlay.getCurrentTime() + 3;
                } catch (e) {
                    console.log(e);
                }
            }
            var param = 'courseId=' + courseId + '&scoId=' + scoId + '&progress_measure=8&session_time=0:0:' + time;
            console.log("第" + playTime / 60 + "次保存,playTime-->" + playTime + "");
            if (playTime) {
                param = param + "&location=" + playTime;
            }

            if (processType && processType != '') {
                param = param + '&processType=' + processType;
            }
            if (exit) {
                param = param + '&exit=' + exit;
                console.log(exit);
            }
            studyCourse.doSaveProgress(param, scoId, async, upLearningTime);
        },

        //三分屏
        threeScreen: function (courseId, scoId, viewMode, d, cnt) {
            //记录章节开始学习时间 progress_measure
            startTime = getDate();
            var jyUrl = encodeURI(d.LECTURE_SHEET);
            var courseType = d.COURSE_TYPE;//之课类型
            var _fileSrc = "";//文档类课程URL存放
            var videoUrls = [];
            var videoUrl;
            //以下判断是之课，讲义取HANDOUT_URL
            if (courseType !== 'undefined' && courseType !== undefined && courseType !== "" && courseType === "ZHIKE") {
                var handoutUrl = d.HANDOUT_URL;
                if (handoutUrl == null || handoutUrl === undefined || handoutUrl === "") {
                    jyUrl = "";
                } else {
                    jyUrl = handoutUrl;
                }

                var streamUrl = d.STREAM_MEDIA;
                if (streamUrl !== null && streamUrl !== "" && streamUrl !== undefined) {
                    videoUrl = encodeURIComponent(streamUrl);
                }
                _fileSrc = d.LECTURE_SHEET;
            } else {
                if (d.STREAM_MEDIA.indexOf(",") > -1) {
                    var videoUrlBeforeEncode = d.STREAM_MEDIA.split(",");
                    for (var i = 0; i < videoUrlBeforeEncode.length; i++) {
                        videoUrls.push(encodeURIComponent(videoUrlBeforeEncode[i]));
                    }
                } else {
                    videoUrl = encodeURIComponent(d.STREAM_MEDIA);
                }
            }
            var lectureUrl = d.LECTURE_SHEET;
            if (courseType !== 'undefined' && courseType !== undefined && courseType !== "" && courseType === "ZHIKE" && lectureUrl !== null && lectureUrl !== "" && lectureUrl !== undefined) {
                _fileSrc = lectureUrl + "&time=" + new Date().getTime();
                videoUrl = lectureUrl;//赋值视频URl为了后面判断资源类型准备
            }
            //讲义是否存在
            if ((jyUrl == 'undefined' || jyUrl == undefined) && (videoUrl == 'undefined' || videoUrl == undefined)
                && (videoUrls.length < 1)) {
                togglePlayState(false);
                ncp.alert({
                    content: i18n("!v4.js.serverDoNotHaveThis"),
                    onEnd: function () {
                        togglePlayState(true);
                    }
                });
                return false;
            }

            if (viewMode == 'browsed') {
                d.isComplete = 'true';
            } else {
                viewMode = 'normal';
            }
            console.log('三分屏开始');
            if ((videoUrl == null || videoUrl == "") && (courseType == "" || courseType == null || courseType == undefined)) {
                checkVboxUrlThreeScreen(courseId, scoId, viewMode, d, cnt, videoUrls, 0)
            } else {
                var videoParams = {
                    'flvPath': videoUrl,
                    'publicVideoPath': d.publicVideoPath,
                    'courseId': courseId,
                    'scoId': scoId,
                    'viewMode': viewMode,
                    'location': d.location,
                    'isComplete': d.isComplete,
                    'needDuration': d.needDuration,
                    'oldDuration': d.oldDuration
                };
                //update 2012 0615 caoxiao for wmv course  start
                var fileExt = videoUrl.substring(videoUrl.lastIndexOf('.') + 1, videoUrl.length);
                fileExt = fileExt.toLowerCase();
                if (fileExt == "flv" || fileExt == "mp4" || fileExt == "m3u8") {
                    videoType = "flv";
                    videoParams.playOrPause = true;
                    $('#videoCon').html(elnPlayer.videoFlvHtml(videoParams));
                    if (viewMode != 'browsed') {
                        var threeScreenPlayTime = 0;
                        try {
                            //检测三分屏视频播放状态，获取视频播放停止状态,并且该章节没有完成
                            if (d.isComplete !== 'true') {
                                threeScreenPlayerStateInterval = window.setInterval(function () {
                                    var playState;
                                    try {
                                        window.aliplayerApi = function (e, params) {
                                            videoPlay = params;
                                        };
                                        playState = videoPlay.getStatus();
                                        threeScreenPlayTime += 5;
                                    } catch (e) {
                                        console.log("can not get playState");
                                    }
                                    //如果检测到三分屏视频播放已经停止
                                    if (playState && "ended" === playState) {
                                        coursePlay.saveTwoScreen(courseId, scoId, threeScreenPlayTime, true);
                                    }
                                }, 5000);
                            }
                        } catch (e) {
                            console.log("save threeScreen course occur exception");
                        }
                        //记录进度
                        interval = 3 * 60;
                        if (d.duraiton != undefined || d.duraiton != "undefined") {
                            if ((d.duraiton / 1000) * 0.9 < 30) {
                                interval = 40;
                            } else if ((d.duraiton / 1000) * 0.9 < interval) {
                                interval = (d.duraiton / 1000) * 0.9;
                            }
                        }
                        console.log(interval, '---->秒后保存三分屏进度');
                        saveProgressInter = window.setInterval(function () {
                            coursePlay.saveTwoScreen(courseId, scoId, interval, true);
                            threeScreenPlayTime = 0;
                        }, interval * 1000);
                    }
                } else {
                    //wmv需要转换格式播放
                    ncp.alert({
                        // content: TIPS['v4.js.wx.exam.notAvailableVideo'],
                        content: 'wmv视频格式无法播放，请使用IE浏览器观看',
                        onEnd: function () {
                            togglePlayState(true);
                        }
                    });
                    return false;
                }
            }

            //update 2012 0615 caoxiao for wmv course  end
            //讲义
            if (jyUrl == 'undefined' || jyUrl === null || jyUrl === "") {
                console.log(i18n("v4.js.jyUrlNotExist"));
            } else {
                $('#fileUrlId').html(studyCourse.scrollingIframPage(jyUrl));
                $(".cl-catalog").find("#clZoomLink").off("click");
                $(".cl-catalog").find("#clZoomLink").on("click", function () {
                    window.open(jyUrl);
                })
            }
            return true;
        },

        //两分屏
        twoScreen: function (courseId, scoId, viewMode, d, cnt) {

            var _streamMediaArr;
            var _fileSrc;
            var _fileSrcs = [];
            console.log("info.scoId-->" + info.scoId);
            scoId = info.scoId;
            if ((d.STREAM_MEDIA != undefined && d.STREAM_MEDIA != "undefined" && d.STREAM_MEDIA.indexOf(",") > -1)
                || (d.LECTURE_SHEET != undefined && d.LECTURE_SHEET != "undefined" && d.LECTURE_SHEET.indexOf(",") > -1)) {
                try {
                    _fileSrcs = d.LECTURE_SHEET.split(",");
                } catch (e) {
                    _fileSrcs = d.STREAM_MEDIA.split(",");
                }
            } else {
                try {
                    _streamMediaArr = d.STREAM_MEDIA.split('?');
                    _fileSrc = d.STREAM_MEDIA;
                    console.log("STREAM_MEDIA-->" + _fileSrc);
                } catch (e) { //二分屏HTML课件
                    _streamMediaArr = d.LECTURE_SHEET.split('?');
                    _fileSrc = d.LECTURE_SHEET;
                    console.log("LECTURE_SHEET-->" + _fileSrc);
                }
            }
            //两分屏FLV
            if (viewMode == 'browsed') {
                d.isComplete = 'true';
            } else {
                viewMode = 'normal';
            }
            console.log('两分屏开始');
            if ((_streamMediaArr == null || _streamMediaArr == "") && (_fileSrc == null || _fileSrc == "")) {
                checkVboxUrlTwoScreen(courseId, scoId, viewMode, d, cnt, _fileSrcs, 0)
            } else {//有多个视频备用地址时
                var _smu = _streamMediaArr[0];
                var fileExt = _smu.substring(_smu.lastIndexOf('.') + 1, _smu.length);//视频格式
                fileExt = fileExt.toLowerCase();
                var courseResourceHtml;

                if (fileExt == 'flv' || fileExt == 'mp4' || fileExt == 'm3u8') {
                    videoType = "flv";
                    var videoParams = {
                        'flvPath': encodeURIComponent(_fileSrc),
                        'publicVideoPath': d.publicVideoPath,
                        'courseId': courseId,
                        'scoId': scoId,
                        'location': d.location,
                        'viewMode': viewMode,
                        'isComplete': d.isComplete,
                        'needDuration': d.needDuration,
                        'oldDuration': d.oldDuration
                    };
                    videoParams.playOrPause = true;
                    courseResourceHtml = elnPlayer.videoFlvHtml(videoParams);
                    $('#handouts').html(courseResourceHtml);
                    $('#playBarrageId').css('display', 'block');

                    setTimeout(function () {
                        saveProgressByWmv.testIsPlayingForMp4(cnt);
                    }, 10000);
                } else if (fileExt == 'html' || fileExt == 'htm' || fileExt == 'swf') {
                    courseResourceHtml = studyCourse.iframPage(encodeURI(_fileSrc));
                    $('#handouts').html(courseResourceHtml);
                    $('#playBarrageId').css('display', 'none');
                } else { //二分屏WMV
                    var courseType = d.COURSE_TYPE;
                    if (courseType !== null && courseType !== "" && courseType !== undefined && courseType === "ZHIKE") {
                        _fileSrc = _fileSrc + "&time=" + new Date().getTime();
                    }
                    courseResourceHtml = studyCourse.iframPage(encodeURI(_fileSrc));
                    $('#handouts').html(courseResourceHtml);
                    $('#playBarrageId').css('display', 'none');
                    /* togglePlayState(false);
                     ncp.alert({
                         content: TIPS['els.course.otherErrorTip'],
                         onEnd: function () {
                             togglePlayState(true);
                         }
                     });
                     return false;*/
                }
            }


            console.log("两分屏记录开始");
            //下面单位都是秒

            if (viewMode != 'browsed') {
                console.log(d)
                interval = 10;
                var saveVideoTimeFlag = 180;
                var videoMinStudyTime = d.minStudyTime;
                var videoPlayTime;
                var counter = 1;
                if (d.isComplete == "true") {
                    console.log('已完成！');
                    return;
                } else if (fileExt == 'html' || fileExt == 'htm' || (d.COURSE_TYPE == 'ZHIKE' && fileExt.indexOf('/pe/course/manage/view') != -1)) {
                    var studiedTime = $('#studiedTime').html();
                    if (videoMinStudyTime && (videoMinStudyTime <= 3 || videoMinStudyTime - studiedTime <= 3)) {//最短学习时间<=3分钟
                        console.log('讲义小于三分钟,最短学习时间 videoMinStudyTime', videoMinStudyTime);
                        console.log('已学时间 studiedTime', studiedTime);
                        saveProgressInter = window.setInterval(function () {
                            counter++;
                            console.log('counter', counter);
                            if (counter % 6 == 0) {
                                coursePlay.saveTwoScreen(courseId, coursePlay._lastScoid, 65, false, false, true);
                            }
                        }, interval * 1000);
                    } else {
                        console.log('讲义大于三分钟,最短学习时间 videoMinStudyTime', videoMinStudyTime);
                        console.log('已学时间 minStudyTime', studiedTime);
                        saveProgressInter = window.setInterval(function () {
                            counter++;
                            console.log('counter', counter);
                            if (counter % 6 == 0) {    //最后的 几次（2 或者 1次）， 已播时间-最短学习时间
                                console.log('剩余三分之内');
                                coursePlay.saveTwoScreen(courseId, coursePlay._lastScoid, 65, false, false, true);
                            } else if (counter % 18 == 0) {   // 每三分钟一次
                                console.log('三分钟保存一次');
                                coursePlay.saveTwoScreen(courseId, coursePlay._lastScoid, 185, false, false, true);
                            }

                        }, interval * 1000);

                    }
                } else {
                    if (videoMinStudyTime && videoMinStudyTime <= 3) {//最短学习时间<=3分钟
                        saveProgressInter = window.setInterval(function () {
                            window.aliplayerApi = function (e, params) {
                                videoPlay = params;
                            };
                            videoPlayTime = videoPlay.getCurrentTime() + 5; //当前播放进度
                            var videoDuratio = videoPlay.getDuration();//视频总时长
                            if (videoMinStudyTime > videoDuratio) { //最短学习时长 > 视频长度
                                videoMinStudyTime = videoDuratio;
                            }
                            console.log('当前播放进度playTime', videoPlayTime);
                            // 每三分钟一次           ||   最后2次
                            //(已播放时间 % 3 < 1 &&) || (当前播放时间是否大于3 && 当前视频总时长 - 已播放时间 < 3)
                            if (videoPlayTime - videoMinStudyTime * 60 >= 0) {
                                coursePlay.saveTwoScreen(courseId, coursePlay._lastScoid, interval, false, false, true);
                            }
                        }, interval * 1000);
                    } else {
                        console.log('大于三分钟');
                        saveProgressInter = window.setInterval(function () {
                            window.aliplayerApi = function (e, params) {
                                videoPlay = params;
                            };
                            videoPlayTime = videoPlay.getCurrentTime() + 5; //当前播放进度
                            var videoDuratio = videoPlay.getDuration();//视频总时长
                            console.log('当前播放进度playTime', videoPlayTime);
                            if (videoMinStudyTime > videoDuratio) { //最短学习时长 > 视频长度
                                videoMinStudyTime = videoDuratio;
                            }
                            if (videoPlayTime > (saveVideoTimeFlag * counter)) {   // 每三分钟一次
                                counter++;
                                console.log('三分钟保存——>下次是', counter);
                                coursePlay.saveTwoScreen(courseId, coursePlay._lastScoid, interval, false, false, true);
                            }
                            if (videoPlayTime - videoMinStudyTime * 60 >= 0) {    //最后的 几次（2 或者 1次）， 已播时间-最短学习时间
                                console.log('三分之内');
                                coursePlay.saveTwoScreen(courseId, coursePlay._lastScoid, interval, false, false, true);
                            }

                        }, interval * 1000);

                    }
                }


            }
            return true;
        },

        chapterUrl: function (courseId, scoId, viewMode, d) {
            var iframe = '<iframe class="high-url-course-content" id="highUrlCourseIframeId" src="' + d.CHAPTER_URL + '" frameborder="0" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>';
            $('#handouts').html(iframe);
            window.clearInterval(saveProgressInter);
            //记录进度
            interval = 60 * 3;
            saveProgressInter = window.setInterval(function () {
                coursePlay.saveTwoScreen(courseId, scoId, interval, true);
            }, interval * 1000);
        },
        //创合汇课程
        chhChapterUrl: function (courseId, scoId, viewMode, d) {
            let url = d.CHAPTER_URL;
            require(['https://g.alicdn.com/de/prismplayer/2.9.19/aliplayer-h5-min.js'], function (d) {
                T.loadCss('https://g.alicdn.com/de/prismplayer/2.9.19/skins/default/aliplayer-min.css');
                var iframe = '<div id="highUrlCourseIframeId"></div>';
                $('#handouts').html(iframe);
                let player = new Aliplayer({
                    id: 'highUrlCourseIframeId',
                    source: url,//播放地址，可以是第三方点播地址,或阿里云点播服务中的播放地址。
                    width: "100%",
                    height: "500px",
                    autoplay: "true",
                    preload: "true",
                    skinLayout: [
                        {
                            "name": "controlBar",
                            "align": "blabs",
                            "x": 0,
                            "y": 0,
                            "children": [
                                {
                                    "name": "progress",
                                    "align": "blabs",
                                    "x": 0,
                                    "y": 44
                                },
                                {
                                    "name": "playButton",
                                    "align": "tl",
                                    "x": 15,
                                    "y": 12
                                },
                                {
                                    "name": "fullScreenButton",
                                    "align": "tr",
                                    "x": 10,
                                    "y": 12
                                },
                                {
                                    "name": "volume",
                                    "align": "tr",
                                    "x": 5,
                                    "y": 10
                                },
                                {
                                    "name": "timeDisplay",
                                    "align": "tl",
                                    "x": 10,
                                    "y": 7
                                },
                                {
                                    "name": "setting",
                                    "align": "tr",
                                    "x": 15,
                                    "y": 12
                                }
                            ]
                        }
                    ]
                }, function (player) {
                    console.log('The player is created.')
                    player.play()
                });
            });
            window.clearInterval(saveProgressInter);
            //记录进度
            interval = 60 * 3;
            saveProgressInter = window.setInterval(function () {
                coursePlay.saveTwoScreen(courseId, scoId, interval, true);
            }, interval * 1000);
        }
    };

    //视频播放器
    var elnPlayer = {
        //ali_player
        videoFlvHtml: function (p) {
            /** NicolasLemon修改1 */
            // 将最小学习时间赋给location，并且将毫秒转换成秒
            p.location = p.oldDuration / 1000;
            if (p.flvPath == undefined || p.courseId == undefined || p.scoId == undefined
                || p.viewMode == undefined || p.viewMode == undefined) {
                $.tbcmsg({
                    msg: '<p class="dialog-msg">' + i18n("!v4.js.coursewareIncomplete") + '</p>',
                    onlyOk: true
                });
                return false;
            }

            var ali_html = '<iframe id="iframe_aliplayer" name="iframe_aliplayer" src="/template-frontent/bipartitescreen" frameBorder="no" style="width: 100%;border: 0;" height="530" ' +
                'mode="2" ' +
                'allowfullscreen="true" ' +
                'modetype="2" ' +
                'selfwidth="100%" ' +
                'selfheight="530px" ' +
                'actionpath="' + decodeURIComponent(p.flvPath) + '" ' +
                'params="' + tbcUtils.parseParam(p) + '" ' +
                'selftype="1" ' +
                'playtype="" ' +
                'progress="" ' +
                'courseid="' + p.courseId + '" ' +
                'scoid="' + p.scoId + '" ' +
                'iscomplete="' + p.isComplete + '" ' +
                'locationtime="' + p.location + '" ' +
                'rate="' + (p.rate ? p.rate : '') + '" ' +
                'viewmode="' + p.viewMode + '" ' +
                'watermarkuser="' + markUserName + '" ' +
                'watermarkid="' + markEmployeeCode + '" ' +
                'markLoginName="' + markLoginName + '" ' +
                'waterMarkTransparency="' + waterMarkTransparency + '" ' +
                'waterMarkDensity="' + waterMarkDensity + '" ' +

                'savedurationurl="' + ((p.needDuration == 'true' || p.needDuration == true) ? (encodeURIComponent(CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.saveDuration.do?oldDuration=' + p.oldDuration + '&eln_session_id=' + CONFIG.elnSessionId + '&elsSign=' + CONFIG.elnSessionId)) : '') + '" ' +
                'playurl="' + (p.playOrPause ? (encodeURIComponent(CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.play.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId)) : '') + '" ' +
                'pauseurl="' + (p.playOrPause ? (encodeURIComponent(CONFIG.ctx + 'html/courseStudyItem/courseStudyItem.pause.do?eln_session_id=' + CONFIG.elnSessionId + "&elsSign=" + CONFIG.elnSessionId)) : '') + '" ' +
                'publicvideopath="' + ((p.publicVideoPath && $.trim(p.publicVideoPath) != '') ? p.publicVideoPath : '') + '" ' +
                'starttime="' + (startTime ? encodeURIComponent(startTime) : '') + '" ' +
                'logId="" ' +

                'onplay="tbc_play" ' +
                'onsuspend="tbc_suspend" ' +
                'onerrorevent="errorEvent" ' +
                'onaliplayerApi="aliplayerApi" ' +
                'onhancomplete="completeEvent"></iframe>';

            return ali_html;
        },
    };

    //获取当前时间
    function getDate() {
        var _f = function (v) {
            return v < 10 ? '0' + v : v;
        };
        var _date = new Date();
        date = _date.getFullYear() + '-' + _f((_date.getMonth() + 1)) + '-' + _f(_date.getDate())
            + ' ' + _f(_date.getHours()) + ':' + _f(_date.getMinutes()) + ':' + _f(_date.getSeconds());
        return date;
    }

    //更新章节图标
    function changeScoIcon(scoId, upLearningTime) {

        try {
            if (upLearningTime && info.courseStandard === 'TWOSCREEN') {
                var minStudyTime = $('#minStudyTime').html();
                $('#studiedTime').html(minStudyTime);
            }
            // console.log(minStudyTime);
            $("[data-id='" + scoId + "']").removeClass("item-no").addClass("item-done").addClass("cl-catalog-link-done");
            if ($("#corpCode") && $("#corpCode").val() == "cqrcpx") {
                $("span[data-id='" + scoId + "']").text("【已学完】");
            }
        } catch (e) {
        }
    }

    //检测用户是否有课程在学习，并把当前课程设置为正在学习状态（每人有且只有一门课程是正在学习状态）
    function studyCheck(courseId, scoId) {
        $.post(CONFIG.ctx + 'html/coursestudyrecord/coursestudyrecord.studyCheck.do?courseId=' + courseId + '&scoId=' + scoId + "&eln_session_id=" + CONFIG.elnSessionId, function (data) {
        });
    }

    function getRealMethodName(type) {
        switch (type) {
            case "COURSE_PRETEST_VIEW":
                return "viewPretestPage";
                break;
            case "COURSE_COURSE_STUDY_VIEW":
                return "viewStudyPage";
                break;
            case "COURSE_EVALUATE_VIEW":
                return "viewEvaluatePage";
                break;
            case "COURSE_EXAM_VIEW":
                return "viewCourseExamPage";
                break;
        }
    }
    //三分屏
    function checkVboxUrlThreeScreen(courseId, scoId, viewMode, d, cnt, videoUrls, count) {
        if (count >= videoUrls.length) {
            // calibrationCount++;
            var course_id = $('#courseId').val();
            var standard = $('#standard').val();
            //视频服务器切换到公网
            studyCourse.setVboxServer('');
            studyCourse.setHasSwitch("1");
            //点击网络设置，自动变成公网默认选中
            info.current_server = '';
            // //播放
            var INFO = {
                courseId: course_id,
                courseStandard: standard,
                viewMode: info.viewMode
            };

            var currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
            window.setTimeout(function () {
                currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
            }, 500);

            studyCourse.coursePlay($(currObj).attr('data-id'), info, cnt);
            return;
        }

        var videoParams = {
            'flvPath': videoUrls[count],
            'publicVideoPath': undefined,
            'courseId': courseId,
            'scoId': scoId,
            'viewMode': viewMode,
            'location': d.location,
            'isComplete': d.isComplete,
            'needDuration': d.needDuration,
            'oldDuration': d.oldDuration,
            'isVbox': true
        };
        //update 2012 0615 caoxiao for wmv course  start
        var fileExt = videoUrls[count].substring(videoUrls[count].lastIndexOf('.') + 1, videoUrls[count].length);
        fileExt = fileExt.toLowerCase();
        if (fileExt == "flv" || fileExt == "mp4" || fileExt == "m3u8") {
            videoType = "flv";
            videoParams.playOrPause = true;
            $('#videoCon').html(elnPlayer.videoFlvHtml(videoParams));
            if (viewMode != 'browsed') {
                var threeScreenPlayTime = 0;
                try {
                    //检测三分屏视频播放状态，获取视频播放停止状态,并且该章节没有完成
                    if (d.isComplete !== 'true') {
                        threeScreenPlayerStateInterval = window.setInterval(function () {
                            var playState;
                            try {
                                window.aliplayerApi = function (e, params) {
                                    videoPlay = params;
                                };
                                playState = videoPlay.getStatus();
                                threeScreenPlayTime += 5;
                            } catch (e) {
                                console.log("can not get playState");
                            }
                            //如果检测到三分屏视频播放已经停止
                            if (playState && "ended" == playState) {
                                console.log("-->>threeScreenPlayTime=" + threeScreenPlayTime)
                                coursePlay.saveTwoScreen(courseId, scoId, threeScreenPlayTime, true);
                            }
                        }, 5000);
                    }
                } catch (e) {
                    console.log("save threeScreen course occur exception");
                }

                //记录进度
                interval = 3 * 60;
                if (d.duraiton != undefined || d.duraiton != "undefined") {
                    if ((d.duraiton / 1000) * 0.9 < 30) {
                        interval = 40;
                    } else if ((d.duraiton / 1000) * 0.9 < interval) {
                        interval = (d.duraiton / 1000) * 0.9;
                    }
                }
                saveProgressInter = window.setInterval(function () {
                    coursePlay.saveTwoScreen(courseId, scoId, interval, true);
                    threeScreenPlayTime = 0;
                }, interval * 1000);

                count++;
                vboxSelectVideo = setTimeout(function () {
                    window.aliplayerApi = function (e, params) {
                        console.log('aliplayerApi', params);
                        videoPlay = params;
                    };
                    var playState = videoPlay.getStatus();
                    if (playState == 'pause') {
                        clearInterval(saveProgressInter);
                        checkVboxUrlThreeScreen(courseId, scoId, viewMode, d, cnt, videoUrls, count);
                    }
                }, 10000);
            }

        } else {
            //wmv需要转换格式播放
            ncp.alert({
                // content: TIPS['v4.js.wx.exam.notAvailableVideo'],
                content: 'wmv视频格式无法播放，请使用IE浏览器观看',
                onEnd: function () {
                    togglePlayState(true);
                }
            });
            return false;
        }
    }

    //二分屏
    function checkVboxUrlTwoScreen(courseId, scoId, viewMode, d, cnt, _fileSrcs, count) {
        if (count >= _fileSrcs.length || (_fileSrcs.length >= 6 && count === 2)) {
            console.log('视频服务器切换到公网');
            var course_id = $('#courseId').val();
            var standard = $('#standard').val();
            //视频服务器切换到公网
            studyCourse.setVboxServer('');
            studyCourse.setHasSwitch("1");
            //点击网络设置，自动变成公网默认选中
            info.current_server = '';
            //播放
            var INFO = {
                courseId: course_id,
                courseStandard: standard,
                viewMode: info.viewMode
            };

            var currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
            window.setTimeout(function () {
                currObj = $("#courseItemId").find('.cl-catalog-playing')[0];
            }, 500);

            studyCourse.coursePlay($(currObj).attr('data-id'), info, cnt);
            return;
        }

        var _smu = _fileSrcs[count].split("?")[0];
        var fileExt = _smu.substring(_smu.lastIndexOf('.') + 1, _smu.length);
        fileExt = fileExt.toLowerCase();
        var courseResourceHtml;

        if (fileExt == 'flv' || fileExt == 'mp4' || fileExt == 'm3u8') {
            videoType = "flv";
            var videoParams = {
                'flvPath': encodeURIComponent(_fileSrcs[count]),
                'publicVideoPath': undefined,
                'courseId': courseId,
                'scoId': scoId,
                'location': d.location,
                'viewMode': viewMode,
                'isComplete': d.isComplete,
                'needDuration': d.needDuration,
                'oldDuration': d.oldDuration,
                'isVbox': true
            };
            videoParams.playOrPause = true;
            courseResourceHtml = elnPlayer.videoFlvHtml(videoParams);//h5播放器
            $('#handouts').html(courseResourceHtml);
            $('#playBarrageId').css('display', 'block');//网络设置显隐
            count++;
            // console.log('videoErrStatus--->', videoErrStatus);
            vboxSelectVideo = setTimeout(function () {
                // 阿里播放器报错误码和视频缓冲状态
                console.log('saveProgressInter--->', saveProgressInter);
                if (videoErrStatus) {
                    clearInterval(saveProgressInter);
                    checkVboxUrlTwoScreen(courseId, scoId, viewMode, d, cnt, _fileSrcs, count);
                }
            }, 10000);
        } else if (fileExt == 'html' || fileExt == 'htm' || fileExt == 'swf') {
            courseResourceHtml = studyCourse.iframPage(encodeURI(_fileSrc));
            $('#handouts').html(courseResourceHtml);
            $('#playBarrageId').css('display', 'none');
        } else { //二分屏WMV
            togglePlayState(false);
            ncp.alert({
                content: TIPS['v4.js.wx.exam.notAvailableVideo'],
                onEnd: function () {
                    togglePlayState(true);
                }
            });
            return false;
        }
    }
});

//视频播放结束
function aliplayerEnd() {
    console.log('结束');
    showTrainingCamp(true)
    window.aliplayerApi = function (e, params) {
        videoPlay = params;
    };
    var iframe = document.getElementById('iframe_aliplayer');
    var sid = iframe.getAttribute('scoid');
    var courseStandard = info.courseStandard;
    if (courseStandard === 'TWOSCREEN' || courseStandard === 'THREESCREEN') {
        var param = 'courseId=' + info.courseId + '&scoId=' + sid + '&progress_measure=8&session_time=0:0:60';
        param = param + "&location=" + videoPlay.getDuration();
        studyCourse.doSaveProgress(param, sid, true, true);
        // coursePlay.saveTwoScreen(info.courseId, sid, videoPlay.getDuration(), false);
    }
}
