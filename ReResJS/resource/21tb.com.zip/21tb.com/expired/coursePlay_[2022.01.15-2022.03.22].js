(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["coursePlay"], {
    "0040": function (e, t, i) {
        "use strict";
        var n = function () {
        };
        e.exports = function (e) {
            return {
                filterToEnabled: function (t, i) {
                    var r = {main: [], facade: []};
                    return t ? "string" === typeof t && (t = [t]) : t = [], e.forEach((function (e) {
                        e && ("websocket" !== e.transportName || !1 !== i.websocket ? t.length && -1 === t.indexOf(e.transportName) ? n("not in whitelist", e.transportName) : e.enabled(i) ? (n("enabled", e.transportName), r.main.push(e), e.facadeTransport && r.facade.push(e.facadeTransport)) : n("disabled", e.transportName) : n("disabled from server", "websocket"))
                    })), r
                }
            }
        }
    }, "0e88": function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("ada0").EventEmitter, o = function () {
        };

        function s(e, t, i) {
            o(t), r.call(this), this.Receiver = e, this.receiveUrl = t, this.AjaxObject = i, this._scheduleReceiver()
        }

        n(s, r), s.prototype._scheduleReceiver = function () {
            o("_scheduleReceiver");
            var e = this, t = this.poll = new this.Receiver(this.receiveUrl, this.AjaxObject);
            t.on("message", (function (t) {
                o("message", t), e.emit("message", t)
            })), t.once("close", (function (i, n) {
                o("close", i, n, e.pollIsClosing), e.poll = t = null, e.pollIsClosing || ("network" === n ? e._scheduleReceiver() : (e.emit("close", i || 1006, n), e.removeAllListeners()))
            }))
        }, s.prototype.abort = function () {
            o("abort"), this.removeAllListeners(), this.pollIsClosing = !0, this.poll && this.poll.abort()
        }, e.exports = s
    }, 1015: function (e, t) {
        e.exports = "1.4.0"
    }, "13c0": function (e, t, i) {
        "use strict";
        (function (t) {
            var i = t.WebSocket || t.MozWebSocket;
            e.exports = i ? function (e) {
                return new i(e)
            } : void 0
        }).call(this, i("c8ba"))
    }, 1548: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("ada0").EventEmitter, o = function () {
        };

        function s(e, t) {
            o(e), r.call(this);
            var i = this;
            this.bufferPosition = 0, this.xo = new t("POST", e, null), this.xo.on("chunk", this._chunkHandler.bind(this)), this.xo.once("finish", (function (e, t) {
                o("finish", e, t), i._chunkHandler(e, t), i.xo = null;
                var n = 200 === e ? "network" : "permanent";
                o("close", n), i.emit("close", null, n), i._cleanup()
            }))
        }

        n(s, r), s.prototype._chunkHandler = function (e, t) {
            if (o("_chunkHandler", e), 200 === e && t) for (var i = -1; ; this.bufferPosition += i + 1) {
                var n = t.slice(this.bufferPosition);
                if (i = n.indexOf("\n"), -1 === i) break;
                var r = n.slice(0, i);
                r && (o("message", r), this.emit("message", r))
            }
        }, s.prototype._cleanup = function () {
            o("_cleanup"), this.removeAllListeners()
        }, s.prototype.abort = function () {
            o("abort"), this.xo && (this.xo.close(), o("close"), this.emit("close", null, "user"), this.xo = null), this._cleanup()
        }, e.exports = s
    }, 1816: function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("440d"), r = i("9c59"), o = /^[A-Za-z][A-Za-z0-9+-.]*:\/\//,
                s = /^([a-z][a-z0-9.+-]*:)?(\/\/)?([\S\s]*)/i,
                a = "[\\x09\\x0A\\x0B\\x0C\\x0D\\x20\\xA0\\u1680\\u180E\\u2000\\u2001\\u2002\\u2003\\u2004\\u2005\\u2006\\u2007\\u2008\\u2009\\u200A\\u202F\\u205F\\u3000\\u2028\\u2029\\uFEFF]",
                c = new RegExp("^" + a + "+");

            function u(e) {
                return (e || "").toString().replace(c, "")
            }

            var l = [["#", "hash"], ["?", "query"], function (e) {
                    return e.replace("\\", "/")
                }, ["/", "pathname"], ["@", "auth", 1], [NaN, "host", void 0, 1, 1], [/:(\d+)$/, "port", void 0, 1], [NaN, "hostname", void 0, 1, 1]],
                d = {hash: 1, query: 1};

            function h(e) {
                var i;
                i = "undefined" !== typeof window ? window : "undefined" !== typeof t ? t : "undefined" !== typeof self ? self : {};
                var n = i.location || {};
                e = e || n;
                var r, s = {}, a = typeof e;
                if ("blob:" === e.protocol) s = new m(unescape(e.pathname), {}); else if ("string" === a) for (r in s = new m(e, {}), d) delete s[r]; else if ("object" === a) {
                    for (r in e) r in d || (s[r] = e[r]);
                    void 0 === s.slashes && (s.slashes = o.test(e.href))
                }
                return s
            }

            function p(e) {
                e = u(e);
                var t = s.exec(e);
                return {protocol: t[1] ? t[1].toLowerCase() : "", slashes: !!t[2], rest: t[3]}
            }

            function f(e, t) {
                if ("" === e) return t;
                var i = (t || "/").split("/").slice(0, -1).concat(e.split("/")), n = i.length, r = i[n - 1], o = !1,
                    s = 0;
                while (n--) "." === i[n] ? i.splice(n, 1) : ".." === i[n] ? (i.splice(n, 1), s++) : s && (0 === n && (o = !0), i.splice(n, 1), s--);
                return o && i.unshift(""), "." !== r && ".." !== r || i.push(""), i.join("/")
            }

            function m(e, t, i) {
                if (e = u(e), !(this instanceof m)) return new m(e, t, i);
                var o, s, a, c, d, v, y = l.slice(), g = typeof t, T = this, w = 0;
                for ("object" !== g && "string" !== g && (i = t, t = null), i && "function" !== typeof i && (i = r.parse), t = h(t), s = p(e || ""), o = !s.protocol && !s.slashes, T.slashes = s.slashes || o && t.slashes, T.protocol = s.protocol || t.protocol || "", e = s.rest, s.slashes || (y[3] = [/(.*)/, "pathname"]); w < y.length; w++) c = y[w], "function" !== typeof c ? (a = c[0], v = c[1], a !== a ? T[v] = e : "string" === typeof a ? ~(d = e.indexOf(a)) && ("number" === typeof c[2] ? (T[v] = e.slice(0, d), e = e.slice(d + c[2])) : (T[v] = e.slice(d), e = e.slice(0, d))) : (d = a.exec(e)) && (T[v] = d[1], e = e.slice(0, d.index)), T[v] = T[v] || o && c[3] && t[v] || "", c[4] && (T[v] = T[v].toLowerCase())) : e = c(e);
                i && (T.query = i(T.query)), o && t.slashes && "/" !== T.pathname.charAt(0) && ("" !== T.pathname || "" !== t.pathname) && (T.pathname = f(T.pathname, t.pathname)), n(T.port, T.protocol) || (T.host = T.hostname, T.port = ""), T.username = T.password = "", T.auth && (c = T.auth.split(":"), T.username = c[0] || "", T.password = c[1] || ""), T.origin = T.protocol && T.host && "file:" !== T.protocol ? T.protocol + "//" + T.host : "null", T.href = T.toString()
            }

            function v(e, t, i) {
                var o = this;
                switch (e) {
                    case"query":
                        "string" === typeof t && t.length && (t = (i || r.parse)(t)), o[e] = t;
                        break;
                    case"port":
                        o[e] = t, n(t, o.protocol) ? t && (o.host = o.hostname + ":" + t) : (o.host = o.hostname, o[e] = "");
                        break;
                    case"hostname":
                        o[e] = t, o.port && (t += ":" + o.port), o.host = t;
                        break;
                    case"host":
                        o[e] = t, /:\d+$/.test(t) ? (t = t.split(":"), o.port = t.pop(), o.hostname = t.join(":")) : (o.hostname = t, o.port = "");
                        break;
                    case"protocol":
                        o.protocol = t.toLowerCase(), o.slashes = !i;
                        break;
                    case"pathname":
                    case"hash":
                        if (t) {
                            var s = "pathname" === e ? "/" : "#";
                            o[e] = t.charAt(0) !== s ? s + t : t
                        } else o[e] = t;
                        break;
                    default:
                        o[e] = t
                }
                for (var a = 0; a < l.length; a++) {
                    var c = l[a];
                    c[4] && (o[c[1]] = o[c[1]].toLowerCase())
                }
                return o.origin = o.protocol && o.host && "file:" !== o.protocol ? o.protocol + "//" + o.host : "null", o.href = o.toString(), o
            }

            function y(e) {
                e && "function" === typeof e || (e = r.stringify);
                var t, i = this, n = i.protocol;
                n && ":" !== n.charAt(n.length - 1) && (n += ":");
                var o = n + (i.slashes ? "//" : "");
                return i.username && (o += i.username, i.password && (o += ":" + i.password), o += "@"), o += i.host + i.pathname, t = "object" === typeof i.query ? e(i.query) : i.query, t && (o += "?" !== t.charAt(0) ? "?" + t : t), i.hash && (o += i.hash), o
            }

            m.prototype = {
                set: v,
                toString: y
            }, m.extractProtocol = p, m.location = h, m.trimLeft = u, m.qs = r, e.exports = m
        }).call(this, i("c8ba"))
    }, "195e": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAkCAYAAACE7WrnAAAAAXNSR0IArs4c6QAAAeRJREFUSA2t1rFOwkAYB/CrAgsDdTXxAZwYCAvGjQ4GBxzwLYyDCQ9hYqLxLWSQQePQEWUhhDC5Y4KjEGUhNfX/Jz1SegftFS9pev16/fW7u8KdVa1Wv4UQ4+AYWZbl5nK5Z5QvxBIXC5Cvae0h1gF677ruo+a+EloHLRsC6+KiCfBtGdRUdjSxlZDv+xUcr47j3DYajd2Vm6GLWEi2BXY5mUxe6vW6LWPhc2KIDwFzZrNZV4cZQQF2COwh2k1jSGaGbt6wLksqiA9zzDABR1tDAXD9LxCyqiCrM2KJujafz0Wv1xODwUAmsDwDu0gEEen3+2I6nQrP4y9HKce1Wm1vY0YSwXSLfD4visWioiCQQbvTtVAUKZVKAv8KOogxRwsZIvwUDhTIFAlS3Feg4XAo5JjEdCfcTRUK3zWo+0pGnBnOELPitLOrCcqnAnFm2CVDbKxAfHsKbKSFTDGuPGshHcYZ1RSPy9dGKIwVCgWRzWY1juhwDczo7kRjHLNyuRwNL6659rESm5H26SDINU8uoFtB8JryRakhZHMXXn1TQZxu27avZDY8G0NA3vHVn7dard/UEDMBUmm325MwYpQRxwTdOdEhhGK/IwCJtjXrIOONFqEfHIutH97+gTq3fk+mW78/x4rsts5rq4YAAAAASUVORK5CYII="
    }, "20d6": function (e, t, i) {
        "use strict";
        var n = i("5ca1"), r = i("0a49")(6), o = "findIndex", s = !0;
        o in [] && Array(1)[o]((function () {
            s = !1
        })), n(n.P + n.F * s, "Array", {
            findIndex: function (e) {
                return r(this, e, arguments.length > 1 ? arguments[1] : void 0)
            }
        }), i("9c6c")(o)
    }, 2582: function (e, t, i) {
        "use strict";
        var n = i("cfe6"), r = "abcdefghijklmnopqrstuvwxyz012345";
        e.exports = {
            string: function (e) {
                for (var t = r.length, i = n.randomBytes(e), o = [], s = 0; s < e; s++) o.push(r.substr(i[s] % t, 1));
                return o.join("")
            }, number: function (e) {
                return Math.floor(Math.random() * e)
            }, numberString: function (e) {
                var t = ("" + (e - 1)).length, i = new Array(t + 1).join("0");
                return (i + this.number(e)).slice(-t)
            }
        }
    }, "26a0": function (e, t, i) {
        "use strict";
        (function (t) {
            e.exports = {
                isOpera: function () {
                    return t.navigator && /opera/i.test(t.navigator.userAgent)
                }, isKonqueror: function () {
                    return t.navigator && /konqueror/i.test(t.navigator.userAgent)
                }, hasDomain: function () {
                    if (!t.document) return !0;
                    try {
                        return !!t.document.domain
                    } catch (e) {
                        return !1
                    }
                }
            }
        }).call(this, i("c8ba"))
    }, "26e3": function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("3fb5"), r = i("9f3a"), o = i("d5e5");
            e.exports = function (e) {
                function i(t, i) {
                    r.call(this, e.transportName, t, i)
                }

                return n(i, r), i.enabled = function (i, n) {
                    if (!t.document) return !1;
                    var s = o.extend({}, n);
                    return s.sameOrigin = !0, e.enabled(s) && r.enabled()
                }, i.transportName = "iframe-" + e.transportName, i.needBody = !0, i.roundTrips = r.roundTrips + e.roundTrips - 1, i.facadeTransport = e, i
            }
        }).call(this, i("c8ba"))
    }, "287b": function (e, t, i) {
    }, "397f": function (e, t, i) {
        "use strict";
        var n = i("c282"), r = i("621f"), o = i("3fb5"), s = i("ada0").EventEmitter, a = i("13c0"), c = function () {
        };

        function u(e, t, i) {
            if (!u.enabled()) throw new Error("Transport created when disabled");
            s.call(this), c("constructor", e);
            var o = this, l = r.addPath(e, "/websocket");
            l = "https" === l.slice(0, 5) ? "wss" + l.slice(5) : "ws" + l.slice(4), this.url = l, this.ws = new a(this.url, [], i), this.ws.onmessage = function (e) {
                c("message event", e.data), o.emit("message", e.data)
            }, this.unloadRef = n.unloadAdd((function () {
                c("unload"), o.ws.close()
            })), this.ws.onclose = function (e) {
                c("close event", e.code, e.reason), o.emit("close", e.code, e.reason), o._cleanup()
            }, this.ws.onerror = function (e) {
                c("error event", e), o.emit("close", 1006, "WebSocket connection broken"), o._cleanup()
            }
        }

        o(u, s), u.prototype.send = function (e) {
            var t = "[" + e + "]";
            c("send", t), this.ws.send(t)
        }, u.prototype.close = function () {
            c("close");
            var e = this.ws;
            this._cleanup(), e && e.close()
        }, u.prototype._cleanup = function () {
            c("_cleanup");
            var e = this.ws;
            e && (e.onmessage = e.onclose = e.onerror = null), n.unloadDel(this.unloadRef), this.unloadRef = this.ws = null, this.removeAllListeners()
        }, u.enabled = function () {
            return c("enabled"), !!a
        }, u.transportName = "websocket", u.roundTrips = 2, e.exports = u
    }, "3a74": function (e, t, i) {
        "use strict";
        var n = i("8ff7"), r = i.n(n);
        r.a
    }, "3e1e": function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("3fb5"), r = i("7577"), o = i("1548"), s = i("df09"), a = i("73aa"), c = i("26a0");

            function u(e) {
                if (!a.enabled && !s.enabled) throw new Error("Transport created when disabled");
                r.call(this, e, "/xhr_streaming", o, s)
            }

            n(u, r), u.enabled = function (e) {
                return !e.nullOrigin && (!c.isOpera() && s.enabled)
            }, u.transportName = "xhr-streaming", u.roundTrips = 2, u.needBody = !!t.document, e.exports = u
        }).call(this, i("c8ba"))
    }, "3fb5": function (e, t) {
        "function" === typeof Object.create ? e.exports = function (e, t) {
            t && (e.super_ = t, e.prototype = Object.create(t.prototype, {
                constructor: {
                    value: e,
                    enumerable: !1,
                    writable: !0,
                    configurable: !0
                }
            }))
        } : e.exports = function (e, t) {
            if (t) {
                e.super_ = t;
                var i = function () {
                };
                i.prototype = t.prototype, e.prototype = new i, e.prototype.constructor = e
            }
        }
    }, "40b2": function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("54d6"), o = i("73aa"), s = i("7577");

        function a(e) {
            if (!r.enabled) throw new Error("Transport created when disabled");
            s.call(this, e, "/htmlfile", r, o)
        }

        n(a, s), a.enabled = function (e) {
            return r.enabled && e.sameOrigin
        }, a.transportName = "htmlfile", a.roundTrips = 2, e.exports = a
    }, "440d": function (e, t, i) {
        "use strict";
        e.exports = function (e, t) {
            if (t = t.split(":")[0], e = +e, !e) return !1;
            switch (t) {
                case"http":
                case"ws":
                    return 80 !== e;
                case"https":
                case"wss":
                    return 443 !== e;
                case"ftp":
                    return 21 !== e;
                case"gopher":
                    return 70 !== e;
                case"file":
                    return !1
            }
            return 0 !== e
        }
    }, "47e4": function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("9a833");

        function o(e) {
            r.call(this), this.initEvent("message", !1, !1), this.data = e
        }

        n(o, r), e.exports = o
    }, "486c": function (e, t, i) {
        "use strict";
        (function (t) {
            i("7725");
            var n, r = i("1816"), o = i("3fb5"), s = i("930c"), a = i("2582"), c = i("84fc"), u = i("621f"),
                l = i("c282"), d = i("0040"), h = i("d5e5"), p = i("26a0"), f = i("48cd"), m = i("9a833"),
                v = i("97a2"), y = i("a0e2"), g = i("e362"), T = i("47e4"), w = i("b9a8"), b = function () {
                };

            function C(e, t, i) {
                if (!(this instanceof C)) return new C(e, t, i);
                if (arguments.length < 1) throw new TypeError("Failed to construct 'SockJS: 1 argument required, but only 0 present");
                v.call(this), this.readyState = C.CONNECTING, this.extensions = "", this.protocol = "", i = i || {}, i.protocols_whitelist && f.warn("'protocols_whitelist' is DEPRECATED. Use 'transports' instead."), this._transportsWhitelist = i.transports, this._transportOptions = i.transportOptions || {}, this._timeout = i.timeout || 0;
                var n = i.sessionId || 8;
                if ("function" === typeof n) this._generateSessionId = n; else {
                    if ("number" !== typeof n) throw new TypeError("If sessionId is used in the options, it needs to be a number or a function.");
                    this._generateSessionId = function () {
                        return a.string(n)
                    }
                }
                this._server = i.server || a.numberString(1e3);
                var o = new r(e);
                if (!o.host || !o.protocol) throw new SyntaxError("The URL '" + e + "' is invalid");
                if (o.hash) throw new SyntaxError("The URL must not contain a fragment");
                if ("http:" !== o.protocol && "https:" !== o.protocol) throw new SyntaxError("The URL's scheme must be either 'http:' or 'https:'. '" + o.protocol + "' is not allowed.");
                var s = "https:" === o.protocol;
                if ("https:" === y.protocol && !s) throw new Error("SecurityError: An insecure SockJS connection may not be initiated from a page loaded over HTTPS");
                t ? Array.isArray(t) || (t = [t]) : t = [];
                var c = t.sort();
                c.forEach((function (e, t) {
                    if (!e) throw new SyntaxError("The protocols entry '" + e + "' is invalid.");
                    if (t < c.length - 1 && e === c[t + 1]) throw new SyntaxError("The protocols entry '" + e + "' is duplicated.")
                }));
                var l = u.getOrigin(y.href);
                this._origin = l ? l.toLowerCase() : null, o.set("pathname", o.pathname.replace(/\/+$/, "")), this.url = o.href, b("using url", this.url), this._urlInfo = {
                    nullOrigin: !p.hasDomain(),
                    sameOrigin: u.isOriginEqual(this.url, y.href),
                    sameScheme: u.isSchemeEqual(this.url, y.href)
                }, this._ir = new w(this.url, this._urlInfo), this._ir.once("finish", this._receiveInfo.bind(this))
            }

            function I(e) {
                return 1e3 === e || e >= 3e3 && e <= 4999
            }

            o(C, v), C.prototype.close = function (e, t) {
                if (e && !I(e)) throw new Error("InvalidAccessError: Invalid code");
                if (t && t.length > 123) throw new SyntaxError("reason argument has an invalid length");
                if (this.readyState !== C.CLOSING && this.readyState !== C.CLOSED) {
                    var i = !0;
                    this._close(e || 1e3, t || "Normal closure", i)
                }
            }, C.prototype.send = function (e) {
                if ("string" !== typeof e && (e = "" + e), this.readyState === C.CONNECTING) throw new Error("InvalidStateError: The connection has not been established yet");
                this.readyState === C.OPEN && this._transport.send(c.quote(e))
            }, C.version = i("1015"), C.CONNECTING = 0, C.OPEN = 1, C.CLOSING = 2, C.CLOSED = 3, C.prototype._receiveInfo = function (e, t) {
                if (b("_receiveInfo", t), this._ir = null, e) {
                    this._rto = this.countRTO(t), this._transUrl = e.base_url ? e.base_url : this.url, e = h.extend(e, this._urlInfo), b("info", e);
                    var i = n.filterToEnabled(this._transportsWhitelist, e);
                    this._transports = i.main, b(this._transports.length + " enabled transports"), this._connect()
                } else this._close(1002, "Cannot connect to server")
            }, C.prototype._connect = function () {
                for (var e = this._transports.shift(); e; e = this._transports.shift()) {
                    if (b("attempt", e.transportName), e.needBody && (!t.document.body || "undefined" !== typeof t.document.readyState && "complete" !== t.document.readyState && "interactive" !== t.document.readyState)) return b("waiting for body"), this._transports.unshift(e), void l.attachEvent("load", this._connect.bind(this));
                    var i = Math.max(this._timeout, this._rto * e.roundTrips || 5e3);
                    this._transportTimeoutId = setTimeout(this._transportTimeout.bind(this), i), b("using timeout", i);
                    var n = u.addPath(this._transUrl, "/" + this._server + "/" + this._generateSessionId()),
                        r = this._transportOptions[e.transportName];
                    b("transport url", n);
                    var o = new e(n, this._transUrl, r);
                    return o.on("message", this._transportMessage.bind(this)), o.once("close", this._transportClose.bind(this)), o.transportName = e.transportName, void (this._transport = o)
                }
                this._close(2e3, "All transports failed", !1)
            }, C.prototype._transportTimeout = function () {
                b("_transportTimeout"), this.readyState === C.CONNECTING && (this._transport && this._transport.close(), this._transportClose(2007, "Transport timed out"))
            }, C.prototype._transportMessage = function (e) {
                b("_transportMessage", e);
                var t, i = this, n = e.slice(0, 1), r = e.slice(1);
                switch (n) {
                    case"o":
                        return void this._open();
                    case"h":
                        return this.dispatchEvent(new m("heartbeat")), void b("heartbeat", this.transport)
                }
                if (r) try {
                    t = s.parse(r)
                } catch (o) {
                    b("bad json", r)
                }
                if ("undefined" !== typeof t) switch (n) {
                    case"a":
                        Array.isArray(t) && t.forEach((function (e) {
                            b("message", i.transport, e), i.dispatchEvent(new T(e))
                        }));
                        break;
                    case"m":
                        b("message", this.transport, t), this.dispatchEvent(new T(t));
                        break;
                    case"c":
                        Array.isArray(t) && 2 === t.length && this._close(t[0], t[1], !0);
                        break
                } else b("empty payload", r)
            }, C.prototype._transportClose = function (e, t) {
                b("_transportClose", this.transport, e, t), this._transport && (this._transport.removeAllListeners(), this._transport = null, this.transport = null), I(e) || 2e3 === e || this.readyState !== C.CONNECTING ? this._close(e, t) : this._connect()
            }, C.prototype._open = function () {
                b("_open", this._transport && this._transport.transportName, this.readyState), this.readyState === C.CONNECTING ? (this._transportTimeoutId && (clearTimeout(this._transportTimeoutId), this._transportTimeoutId = null), this.readyState = C.OPEN, this.transport = this._transport.transportName, this.dispatchEvent(new m("open")), b("connected", this.transport)) : this._close(1006, "Server lost session")
            }, C.prototype._close = function (e, t, i) {
                b("_close", this.transport, e, t, i, this.readyState);
                var n = !1;
                if (this._ir && (n = !0, this._ir.close(), this._ir = null), this._transport && (this._transport.close(), this._transport = null, this.transport = null), this.readyState === C.CLOSED) throw new Error("InvalidStateError: SockJS has already been closed");
                this.readyState = C.CLOSING, setTimeout(function () {
                    this.readyState = C.CLOSED, n && this.dispatchEvent(new m("error"));
                    var r = new g("close");
                    r.wasClean = i || !1, r.code = e || 1e3, r.reason = t, this.dispatchEvent(r), this.onmessage = this.onclose = this.onerror = null, b("disconnected")
                }.bind(this), 0)
            }, C.prototype.countRTO = function (e) {
                return e > 100 ? 4 * e : 300 + e
            }, e.exports = function (e) {
                return n = d(e), i("9fa7")(C, e), C
            }
        }).call(this, i("c8ba"))
    }, "48cd": function (e, t, i) {
        "use strict";
        (function (t) {
            var i = {};
            ["log", "debug", "warn"].forEach((function (e) {
                var n;
                try {
                    n = t.console && t.console[e] && t.console[e].apply
                } catch (r) {
                }
                i[e] = n ? function () {
                    return t.console[e].apply(t.console, arguments)
                } : "log" === e ? function () {
                } : i.log
            })), e.exports = i
        }).call(this, i("c8ba"))
    }, "54d6": function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("3fb5"), r = i("f1f8"), o = i("621f"), s = i("ada0").EventEmitter, a = i("2582"),
                c = function () {
                };

            function u(e) {
                c(e), s.call(this);
                var i = this;
                r.polluteGlobalNamespace(), this.id = "a" + a.string(6), e = o.addQuery(e, "c=" + decodeURIComponent(r.WPrefix + "." + this.id)), c("using htmlfile", u.htmlfileEnabled);
                var n = u.htmlfileEnabled ? r.createHtmlfile : r.createIframe;
                t[r.WPrefix][this.id] = {
                    start: function () {
                        c("start"), i.iframeObj.loaded()
                    }, message: function (e) {
                        c("message", e), i.emit("message", e)
                    }, stop: function () {
                        c("stop"), i._cleanup(), i._close("network")
                    }
                }, this.iframeObj = n(e, (function () {
                    c("callback"), i._cleanup(), i._close("permanent")
                }))
            }

            n(u, s), u.prototype.abort = function () {
                c("abort"), this._cleanup(), this._close("user")
            }, u.prototype._cleanup = function () {
                c("_cleanup"), this.iframeObj && (this.iframeObj.cleanup(), this.iframeObj = null), delete t[r.WPrefix][this.id]
            }, u.prototype._close = function (e) {
                c("_close", e), this.emit("close", null, e), this.removeAllListeners()
            }, u.htmlfileEnabled = !1;
            var l = ["Active"].concat("Object").join("X");
            if (l in t) try {
                u.htmlfileEnabled = !!new t[l]("htmlfile")
            } catch (d) {
            }
            u.enabled = u.htmlfileEnabled || r.iframeEnabled, e.exports = u
        }).call(this, i("c8ba"))
    }, "5bfa": function (e, t, i) {
    }, "621f": function (e, t, i) {
        "use strict";
        var n = i("1816"), r = function () {
        };
        e.exports = {
            getOrigin: function (e) {
                if (!e) return null;
                var t = new n(e);
                if ("file:" === t.protocol) return null;
                var i = t.port;
                return i || (i = "https:" === t.protocol ? "443" : "80"), t.protocol + "//" + t.hostname + ":" + i
            }, isOriginEqual: function (e, t) {
                var i = this.getOrigin(e) === this.getOrigin(t);
                return r("same", e, t, i), i
            }, isSchemeEqual: function (e, t) {
                return e.split(":")[0] === t.split(":")[0]
            }, addPath: function (e, t) {
                var i = e.split("?");
                return i[0] + t + (i[1] ? "?" + i[1] : "")
            }, addQuery: function (e, t) {
                return e + (-1 === e.indexOf("?") ? "?" + t : "&" + t)
            }
        }
    }, 6945: function (e, t, i) {
        "use strict";
        e.exports = [i("397f"), i("3e1e"), i("b185"), i("7b4d"), i("26e3")(i("7b4d")), i("40b2"), i("26e3")(i("40b2")), i("e2b3"), i("e556"), i("26e3")(i("e2b3")), i("f84c")]
    }, "6eff": function (e, t, i) {
        "use strict";
        i.r(t);
        var n = function () {
                var e = this, t = e.$createElement, n = e._self._c || t;
                return n("div", {staticClass: "course-play-container"}, [n("div", {
                    staticClass: "player-container",
                    on: {
                        click: function (t) {
                            return t.stopPropagation(), e.checkoutStatus(t)
                        }
                    }
                }, [n("div", [e.hangUpFlag ? n("hangUp", {
                    attrs: {
                        preventHangTime: e.preventHangTime,
                        maxTime: e.maxTime,
                        minTime: e.minTime
                    }, on: {pauseOrPlay: e.pauseOrPlay, saveStudyLog: e.saveStudyLog}
                }) : e._e(), e.preventCheatFlag ? n("preventCheat", {
                    ref: "preventCheat",
                    attrs: {
                        preventCheatTime: e.preventCheatTime,
                        maxTime: e.maxTime,
                        minTime: e.minTime,
                        checkType: e.checkType
                    },
                    on: {pauseOrPlay: e.pauseOrPlay, saveStudyLog: e.saveStudyLog}
                }) : e._e()], 1), e.showMasking ? n("div", {staticClass: "masking-wrapper"}, [n("div", {staticClass: "masking-box"}, [n("p", {staticClass: "masking-title"}, [e._v(e._s(e.$t("v4.js.pc.ocmt.previewTips")))]), n("p", {staticClass: "masking-content"}, [e._v(e._s(e.maskingMsg))]), n("div", {staticClass: "masking-botton"}, [n("div", {on: {click: e.quitCourse}}, [e._v(e._s(e.$t("v4.js.pc.ocmt.quitCourse")))]), n("div", {on: {click: e.continuePreview}}, [e._v(e._s(e.$t("v4.js.pc.ocmt.continuePreview")))])])])]) : e._e(), e.handoutVideo ? n("div", {staticClass: "handout-iframe-content"}, [n("iframe", {
                    staticClass: "handout-iframe",
                    attrs: {src: e.handoutVideoNoteId}
                })]) : e._e(), !e.isVideo || "video" !== e.curType && "audio" !== e.curType ? e._e() : n("aliPlayer", {
                    ref: "aliPlayer",
                    attrs: {
                        resetHandoutAndVideoProps: e.resetHandoutAndVideoProps,
                        id: "aliPlayer",
                        type: e.curType,
                        allowHighSpeed: e.allowHighSpeed,
                        allowMinStudyTime: e.allowMinStudyTime,
                        videoId: e.curVideoId,
                        curTime: e.curTime,
                        recordTime: e.recordTimeTemp,
                        noteId: e.noteId,
                        resourceRelId: e.resourceRelIdNoteId,
                        settingBtn: e.settingBtn,
                        seek: e.seek,
                        heartBeatFlag: e.heartBeatFlag,
                        courseId: e.courseId
                    },
                    on: {
                        seeking: e.videoSeeking,
                        openAndCloseVideoParent: e.openAndCloseVideo,
                        play: e.play,
                        pause: e.pause,
                        ended: e.ended,
                        ready: e.ready,
                        timeupdate: e.timeupdate,
                        isReady: e.isReady,
                        updateAndClear: e.updateCourseRecord
                    }
                }), "url" === e.curType ? [e.urlJson && e.urlJson.content ? n("iframe", {
                    ref: "urlContent",
                    staticClass: "iframe-content",
                    attrs: {src: e.urlJson.content}
                }) : n("div", {
                    ref: "urlContent",
                    staticClass: "iframe-content",
                    domProps: {innerHTML: e._s(e.urlJson && e.urlJson.code)}
                }), "preview" !== e.$route.query.from && e.currentStudyTime > 0 && e.urlJson && e.urlJson.minStudyTime ? n("span", {staticClass: "min-study"}, [e._v("需要 " + e._s(e._f("TimeToString")(e.currentStudyTime)) + "完成学习\n        "), n("span", {
                    staticClass: "icon iconfont icon-quanping full-screen",
                    on: {
                        click: function (t) {
                            return e.toFullVideo(e.$refs.urlContent)
                        }
                    }
                })]) : e._e(), "preview" !== e.$route.query.from && e.urlJson && (0 === e.currentStudyTime || e.urlJson.confirmFinish) && e.urlJson.minStudyTime ? n("span", {staticClass: "min-study"}, [e._v(e._s(e.$t("v4.js.pc.ocmt.completedLearning")) + "\n        "), n("span", {
                    staticClass: "icon iconfont icon-quanping full-screen",
                    on: {
                        click: function (t) {
                            return e.toFullVideo(e.$refs.urlContent)
                        }
                    }
                })]) : e._e(), "preview" === e.$route.query.from ? n("span", {staticClass: "min-study"}, [e._v(e._s(e.$t("v4.js.pc.ocmt.preview")) + "\n        "), n("span", {
                    staticClass: "icon iconfont icon-quanping full-screen",
                    on: {
                        click: function (t) {
                            return e.toFullVideo(e.$refs.urlContent)
                        }
                    }
                })]) : e._e()] : e._e(), "video" !== e.curType && "url" !== e.curType && "audio" !== e.curType && "" !== e.curType ? n("aliyun-preview", {
                    ref: "aliPreview",
                    attrs: {resourceRelId: e.curVideoId, pageIndex: e.pageIndex, isFinish: e.curInfo.finish},
                    on: {isReady: e.isReady}
                }, [e.currentStudyTime > 0 && "preview" !== e.$route.query.from ? n("span", {staticClass: "tips"}, [e._v("需要 "), n("span", {staticClass: "tips-content"}, [e._v(e._s(e._f("TimeToString")(e.currentStudyTime)))]), e._v(" 完成学习")]) : e._e(), "preview" === e.$route.query.from ? n("span", {staticClass: "tips"}, [e._v(e._s(e.$t("v4.js.pc.ocmt.preview")))]) : e._e()]) : e._e(), !e.isPlaying && e.isReplayBtn ? n("div", {
                    staticClass: "player-endInfo",
                    class: {"has-replay-btn": e.mustReplayCanFinish}
                }, [e.mustReplayCanFinish ? n("div", {staticClass: "player-replay-tip"}, [n("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.replayTips1")))]), n("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.replayTips2")))])]) : e._e(), n("div", {staticClass: "player-opt-btn"}, [e.mustReplayCanFinish ? n("button", {
                    staticClass: "replay-btn",
                    on: {click: e.rePlay}
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.reView")))]) : e._e(), "unionpay" === e.corpCode ? [e.nextIndex ? e._e() : n("p", ["zh" === e.language ? n("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.Islastsection")))]) : n("span", [e._v("This is the last section")])])] : [e.nextIndex ? n("button", {
                    staticClass: "next-button",
                    on: {click: e.playNextSection}
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.nextSection")))]) : n("p", ["zh" === e.language ? n("span", [e._v("已是最后一节")]) : n("span", [e._v("This is the last section")])])]], 2)]) : e._e()], 2), n("div", {staticClass: "rightList-container"}, [n("el-tabs", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.open,
                        expression: "open"
                    }],
                    staticClass: "el-tabs",
                    attrs: {stretch: ""},
                    on: {"tab-click": e.handletabClick},
                    model: {
                        value: e.activeName, callback: function (t) {
                            e.activeName = t
                        }, expression: "activeName"
                    }
                }, [n("el-tab-pane", {
                    attrs: {
                        label: e.$t("v4.js.pc.ocmt.contents"),
                        name: "contents"
                    }
                }), "preview" !== e.$route.query.from ? n("el-tab-pane", {
                    attrs: {
                        label: e.$t("v4.js.pc.ocmt.QA"),
                        name: "QA"
                    }
                }) : e._e()], 1), n("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: "contents" === e.activeName,
                        expression: 'activeName ==="contents"'
                    }], staticClass: "chapter-container"
                }, [n("div", {
                    staticClass: "collapse-box-btn", on: {
                        click: function (t) {
                            e.open = !e.open
                        }
                    }
                }, [n("img", {
                    directives: [{name: "show", rawName: "v-show", value: e.open, expression: "open"}],
                    attrs: {src: i("eeb5"), alt: ""}
                }), n("img", {
                    directives: [{name: "show", rawName: "v-show", value: !e.open, expression: "!open"}],
                    attrs: {src: i("195e"), alt: ""}
                })]), n("div", {
                    directives: [{name: "show", rawName: "v-show", value: e.open, expression: "open"}],
                    staticClass: "chapter-section-box"
                }, [n("div", {staticClass: "chapter-box"}, e._l(e.courseData, (function (t, i) {
                    return n("ul", {key: i}, [n("li", {
                        staticClass: "chapter",
                        attrs: {title: t.chapterName},
                        on: {
                            click: function (n) {
                                return e.toggleCollapse(t, i)
                            }
                        }
                    }, ["zh_CN" === e.language ? n("span", [e._v("第" + e._s(e._f("convertToChinaNum")(i + 1)) + "章 " + e._s(t.chapterName))]) : n("span", [e._v("Chapter " + e._s(i + 1))])]), n("div", {staticClass: "section"}, e._l(t.resourceDTOS, (function (t, r) {
                        return n("li", {
                            key: r,
                            staticClass: "section-item",
                            class: {finish: t.finish},
                            on: {
                                click: function (n) {
                                    return e.checkoutSection(t, i, r)
                                }
                            }
                        }, [n("div", {
                            class: {
                                "first-line": !0,
                                active: e.curId === t.resourceId
                            }
                        }, [n("span", {
                            staticClass: "icon-box",
                            attrs: {title: t.resourceName}
                        }, ["video" === t.resourceType ? n("span", {staticClass: "icon-section-video icon iconfont icon-btn_ywc"}) : e._e(), "audio" === t.resourceType ? n("span", {staticClass: "icon-section-video icon iconfont icon-yinpin"}) : e._e(), "document" === t.resourceType ? n("span", {staticClass: "icon-section-video icon iconfont icon-ic_zzkk"}) : e._e(), "url" === t.resourceType ? n("span", {staticClass: "icon-section-video icon iconfont icon-URL"}) : e._e(), n("span", {staticClass: "section-title"}, [e._v(e._s(t.resourceName))])]), t.finish ? n("span", {staticClass: "finish-tig"}, [n("span", {staticClass: "icon iconfont icon-icon_gouxuan"}), e._v(e._s(e.$t("v4.js.pc.ocmt.completed")))]) : e._e(), t.finish || e.curId !== t.resourceId ? e._e() : n("span", ["zh_CN" === e.language ? n("span", [e._v("学习中")]) : n("span", [e._v("learning")])])]), n("div", {staticClass: "second-line"}, ["video" !== t.resourceType && "audio" !== t.resourceType && t.minStudyTime ? n("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.minStudyTime")) + ": " + e._s(e._f("TimeToString")(t.minStudyTime)))]) : e._e(), "video" === t.resourceType || "audio" === t.resourceType ? [e.allowMinStudyTime && t.minStudyTime ? n("span", [e._v(e._s(e.$t("v4.js.pc.ocmt.minStudyTime")) + ": " + e._s(e._f("TimeToString")(t.minStudyTime)))]) : n("span", [e._v("\n                            " + e._s("video" === t.resourceType ? "zh_CN" === e.language ? "视频时长:" : "Video Duration: " : "zh_CN" === e.language ? "音频时长: " : "Audio Duration: ") + e._s(e._f("TimeToString")(t.playTime)) + "\n                        ")])] : e._e()], 2)])
                    })), 0)])
                })), 0)])]), n("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: "QA" === e.activeName,
                        expression: 'activeName ==="QA"'
                    }], staticClass: "QA-container"
                }, [n("div", {
                    staticClass: "QA-box-btn", on: {
                        click: function (t) {
                            e.open = !e.open
                        }
                    }
                }, [n("img", {
                    directives: [{name: "show", rawName: "v-show", value: e.open, expression: "open"}],
                    attrs: {src: i("eeb5"), alt: ""}
                }), n("img", {
                    directives: [{name: "show", rawName: "v-show", value: !e.open, expression: "!open"}],
                    attrs: {src: i("195e"), alt: ""}
                })]), n("div", {
                    directives: [{name: "show", rawName: "v-show", value: e.open, expression: "open"}],
                    staticClass: "QA-section-box"
                }, [n("div", {staticClass: "QA-box"}, [n("div", {staticClass: "QA-tabs"}, [n("div", {
                    staticClass: "quiz",
                    class: {isActive: "quiz" === e.QAactiveName},
                    on: {
                        click: function (t) {
                            return e.handleTabChange("quiz")
                        }
                    }
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.quiz")))]), n("div", {
                    staticClass: "relatedQuestion",
                    class: {isActive: "relatedQuestion" === e.QAactiveName},
                    on: {
                        click: function (t) {
                            return e.handleTabChange("relatedQuestion")
                        }
                    }
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.relatedQuestion")))]), n("span", {
                    staticClass: "cl-triangle-cell cl-triangle-active",
                    staticStyle: {display: "block"}
                }, [n("span", {
                    staticClass: "cl-triangle-arrow",
                    style: {left: e.arrowLeft + "px"}
                }), n("span", {
                    staticClass: "cl-arrow-inner",
                    style: {left: e.arrowLeft + "px"}
                })])]), n("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: "quiz" === e.QAactiveName,
                        expression: 'QAactiveName === "quiz"'
                    }], staticClass: "quiz-box"
                }, [n("p", {staticClass: "quiz-label quiz-label1"}, [e._v("还可以输入" + e._s(e.QANum) + "个字")]), n("el-form", {
                    ref: "form",
                    attrs: {model: e.QAformData, "label-width": "13px"},
                    nativeOn: {
                        submit: function (e) {
                            e.preventDefault()
                        }
                    }
                }, [n("el-form-item", [n("el-input", {
                    attrs: {type: "textarea", maxlength: "140"},
                    model: {
                        value: e.QAformData.title, callback: function (t) {
                            e.$set(e.QAformData, "title", t)
                        }, expression: "QAformData.title"
                    }
                })], 1), n("p", {staticClass: "quiz-label quiz-label2"}, [e._v(e._s(e.$t("v4.js.pc.ocmt.Addquestionsupplement")))]), n("el-form-item", [n("el-input", {
                    attrs: {type: "textarea"},
                    model: {
                        value: e.QAformData.content, callback: function (t) {
                            e.$set(e.QAformData, "content", t)
                        }, expression: "QAformData.content"
                    }
                })], 1), n("p", {staticClass: "quiz-label quiz-label3"}, [e._v(e._s(e.$t("v4.js.pc.ocmt.topic")))]), n("el-form-item", [n("div", {staticClass: "quiz-topic"}, [e._l(e.topicData, (function (t, i) {
                    return n("span", {staticClass: "topic-item"}, [e._v("\n                    " + e._s(t) + "\n                    "), n("span", {
                        staticClass: "deleteItem",
                        on: {
                            click: function (t) {
                                return e.deleteTopicItem(i)
                            }
                        }
                    }, [e._v("x")])])
                })), n("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: e.inputTopicText,
                        expression: "inputTopicText"
                    }, {
                        name: "show",
                        rawName: "v-show",
                        value: e.topicData.length <= 3,
                        expression: "topicData.length <= 3"
                    }],
                    attrs: {type: "text", maxlength: "13"},
                    domProps: {value: e.inputTopicText},
                    on: {
                        focus: e.inputFocus, blur: e.inputBlur, input: function (t) {
                            t.target.composing || (e.inputTopicText = t.target.value)
                        }
                    }
                }), n("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: e.showPlaceholder && 0 === e.topicData.length,
                        expression: "showPlaceholder && topicData.length === 0"
                    }], staticClass: "placeholder"
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.topicTips")))])], 2)])], 1), n("p", {staticClass: "courseName"}), n("div", {
                    staticClass: "QA-saveBtn",
                    on: {click: e.saveQuestion}
                }, [e._v("\n              " + e._s(e.$t("v4.js.pc.ocmt.save")) + "\n            ")])], 1), n("div", {
                    directives: [{
                        name: "show",
                        rawName: "v-show",
                        value: "relatedQuestion" === e.QAactiveName,
                        expression: 'QAactiveName === "relatedQuestion"'
                    }], staticClass: "question-box"
                }, e._l(e.questionData, (function (t, i) {
                    return n("div", {staticClass: "qusetion-item"}, [n("div", {staticClass: "qusetion-item-header"}, [t.userFaceUrl ? n("img", {
                        attrs: {
                            src: t.userFaceUrl,
                            alt: ""
                        }
                    }) : n("img", {
                        attrs: {
                            src: "/els/images/student/card/default_180.png",
                            alt: ""
                        }
                    }), n("div", {staticClass: "header-detail"}, [n("p", [e._v(e._s(t.nickName) + " "), n("span", {
                        staticClass: "answer",
                        on: {
                            click: function (i) {
                                return e.goToQuestion(t.questionId)
                            }
                        }
                    }, [e._v(e._s(t.answerCount) + "个答案")])]), n("p", {staticClass: "time"}, [e._v(e._s(t.lastModifyTime))])])]), n("div", {staticClass: "qusetion-item-content"}, [e._v("\n                " + e._s(t.title) + "\n              ")]), t.answer ? n("div", {staticClass: "question-item-answer"}, [n("span", [e._v(e._s(t.answer.nickName) + "：")]), n("span", {
                        staticStyle: {display: "inline-block"},
                        domProps: {innerHTML: e._s(t.answer.content)}
                    })]) : e._e()])
                })), 0)])])])], 1)])
            }, r = [], o = (i("3b2b"), i("a481"), i("ac6a"), i("20d6"), i("7514"), i("28a5"), i("8e44")), s = i("704d"),
            a = i("9ff8"), c = function () {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", [e.preventCheatFlag && 2 == e.checkType ? i("div", {
                    staticClass: "pCheat-box",
                    staticStyle: {width: "100%", height: "100%"}
                }, [i("div", {staticClass: "pCheat-wrap"}, [i("div", {staticClass: "header-tips"}, [e._v("\n               " + e._s(e.$t("v4.js.pc.ocmt.systemHint")) + "\n            ")]), i("div", {staticStyle: {padding: "20px"}}, [i("div", {staticClass: "pCheat-title"}, [e._v("请完成下方的题目，"), i("span", {
                    staticClass: "pCheat-title-count",
                    staticStyle: {color: "#14ABEF"}
                }, [e._v(e._s(e.timeCount))]), e._v(" 秒内未完成将退出课程学习")]), i("div", {staticClass: "pCheat-img-box"}, [i("img", {
                    staticClass: "pCheat-img",
                    staticStyle: {cursor: "pointer"},
                    attrs: {id: "identifyCode", src: e.imgUrl}
                }), i("input", {
                    directives: [{name: "model", rawName: "v-model", value: e.imgTime, expression: "imgTime"}],
                    attrs: {id: "imgTime", type: "hidden"},
                    domProps: {value: e.imgTime},
                    on: {
                        input: function (t) {
                            t.target.composing || (e.imgTime = t.target.value)
                        }
                    }
                }), i("a", {
                    staticClass: "pCheat-img-link",
                    attrs: {href: "javascript:;", id: "changeNext"},
                    on: {click: e.changeNext}
                }, [e._v(e._s(e.$t("v4.js.pc.ocmt.changeOne")))])]), i("div", {
                    staticClass: "vld-row",
                    staticStyle: {"text-align": "center", "margin-top": "20px"}
                }, [i("input", {
                    directives: [{
                        name: "model",
                        rawName: "v-model",
                        value: e.answerVal,
                        expression: "answerVal"
                    }],
                    staticClass: "pCheat-input-text",
                    attrs: {type: "text", id: "answer", placeholder: "", maxlength: "10"},
                    domProps: {value: e.answerVal},
                    on: {
                        blur: e.validate, input: function (t) {
                            t.target.composing || (e.answerVal = t.target.value)
                        }
                    }
                }), i("span", {
                    staticStyle: {color: "#000"},
                    attrs: {id: "tip"}
                }, [e._v(e._s(e.tips))])])]), i("div", {staticClass: "confirmBtn"}, [i("div", {
                    staticClass: "btn",
                    on: {click: e.submitAnswer}
                }, [e._v("\n                    " + e._s(e.$t("v4.js.pc.ocmt.confirm")) + "\n                ")])])])]) : e._e(), e.preventCheatFlag && 1 == e.checkType ? i("div", {staticClass: "pCheat-box"}, [i("div", {staticClass: "erweima-wrap"}, [i("p", [e._v(e._s(e.$t("v4.js.pc.ocmt.systemHint")))]), i("div", {attrs: {id: "erweima-img"}}), i("p", {staticStyle: {"text-align": "center"}}, [e._v(e._s(e.$t("v4.js.pc.ocmt.APPScanIt")))]), i("p", {staticStyle: {"text-align": "center"}}, [i("span", [e._v(e._s(e.minute))]), e._v("分"), i("span", [e._v(e._s(e.second))]), e._v("秒内未完成将退出课程学习")])])]) : e._e()])
            }, u = [], l = (i("6762"), i("2fdb"), i("c5f6"), i("fa7d")), d = i("d044"), h = i.n(d), p = i("cc7d"),
            f = i.n(p), m = {
                data: function () {
                    return {
                        preventCheatFlag: !1,
                        timeCount: 60,
                        preventCheatInterval: null,
                        countTimer: null,
                        preventCheatTime: 0,
                        imgUrl: "",
                        answerVal: "",
                        tips: "",
                        playTime: 0,
                        playTimer: null,
                        lastTimer: null,
                        nextPlayTime: 0,
                        qrcode: null,
                        minute: 2,
                        second: 59,
                        faceTimer: null,
                        userId: ""
                    }
                },
                props: {
                    maxTime: {type: Number, default: 0},
                    minTime: {type: Number, default: 0},
                    checkType: {type: Number, default: 2}
                },
                computed: {},
                watch: {},
                methods: {
                    initPreventCheat: function (e) {
                        var t = this;
                        if ("video" == e) t.exitfullscreen(), t.$emit("saveStudyLog", "PREVENT_CHEAT_POPUP"), t.preventCheatFlag = !0, clearInterval(t.countTimer), t.$emit("pauseOrPlay", !1), "1" == t.checkType ? setTimeout((function () {
                            t.initErWeima()
                        }), 100) : "2" == t.checkType && (t.preventCheat(), t.timeCount = 60, t.countTimer = setInterval((function () {
                            t.timeCount--, t.timeCount <= 0 && (t.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), t.timeCount = 0, console.log("退出登录"), setTimeout((function () {
                                top.open("about:blank", "_self").close()
                            }), 1e3), clearInterval(t.countTimer))
                        }), 1e3)); else {
                            clearInterval(this.preventCheatInterval);
                            var i = e ? 60 * e * 1e3 : 60 * t.preventCheatTime * 1e3;
                            console.log("自动验证的时间：" + i), this.preventCheatInterval = setTimeout((function () {
                                t.exitfullscreen(), t.$emit("saveStudyLog", "PREVENT_CHEAT_POPUP"), t.preventCheatFlag = !0, t.$emit("pauseOrPlay", !1), "1" == t.checkType ? setTimeout((function () {
                                    t.initErWeima()
                                }), 100) : (t.preventCheat(), t.timeCount = 60, clearInterval(t.countTimer), t.countTimer = setInterval((function () {
                                    t.timeCount--, t.timeCount <= 0 && (t.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), t.timeCount = 0, console.log("退出登录"), setTimeout((function () {
                                        top.open("about:blank", "_self").close()
                                    }), 1e3), clearInterval(t.countTimer))
                                }), 1e3))
                            }), i)
                        }
                    }, randomWord: function (e, t, i) {
                        var n = "", r = t,
                            o = ["0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"];
                        e && (r = Math.round(Math.random() * (i - t)) + t);
                        for (var s = 0; s < r; s++) {
                            var a = Math.round(Math.random() * (o.length - 1));
                            n += o[a]
                        }
                        return n
                    }, initErWeima: function () {
                        var e = this, t = this;
                        clearInterval(this.faceTimer), t.minute = 2, t.second = 59, this.faceTimer = setInterval((function () {
                            t.second--, t.second < 0 && (t.second = 59, t.minute--, t.minute < 0 && (t.second = 0, t.minute = 0, t.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), setTimeout((function () {
                                top.open("about:blank", "_self").close()
                            }), 1e3), clearInterval(e.faceTimer)))
                        }), 1e3), this.qrcode = new h.a(document.getElementById("erweima-img"), {
                            text: "",
                            width: 200,
                            height: 200
                        }), this.webSK()
                    }, webSK: function () {
                        var e, t, i = this, n = this.randomWord(!1, 10), r = window.location.origin,
                            o = this.randomWord(!1, 32);
                        e = new f.a(r + "/biz-oim/webSocket/handler?deviceId=" + o);
                        var s = window.$cookies.get("_local");
                        e.onopen = function (t) {
                            var r = '{"code" : 1, "params" : {"qrCode" : "' + n + '", "oldQrCode" : "", "local" : "' + s + '", "type" : "QR_STUDYCOURSE_SIGN", "userId" :"' + i.userId + '" }}';
                            e.send(r)
                        }, e.onmessage = function (e) {
                            var n = JSON.parse(e.data);
                            1 == n.code ? (t = n.bizResult + "&userId=" + i.userId, i.qrcode.makeCode(t), document.getElementById("erweima-img").setAttribute("title", "")) : 2 == n.code || (6 == n.code ? (clearInterval(this.faceTimer), i.$emit("saveStudyLog", "PREVENT_CHEAT_LOGOUT"), setTimeout((function () {
                                top.open("about:blank", "_self").close()
                            }), 1e3)) : 7 == n.code ? (console.log("用户扫码确认"), clearInterval(i.faceTimer), i.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_SUCCESS"), clearInterval(i.countTimer), clearInterval(i.playTimer), clearTimeout(i.lastTimer), clearInterval(i.preventCheatInterval), i.preventCheatFlag = !1, i.playTime = 0, i.answerVal = "", console.log("上次执行的时间:" + i.preventCheatTime), i.nextPlayTime = i.maxTime - i.preventCheatTime, console.log("上次剩余的时间：" + i.nextPlayTime), i.preventCheatTime = (Math.random() * (i.maxTime - i.minTime) + i.minTime).toFixed(1), console.log("这次摇到的时间:" + i.preventCheatTime), i.nextPlayTime = Number(i.nextPlayTime) + Number(i.preventCheatTime), console.log("下次执行的时间:" + i.nextPlayTime), document.getElementsByTagName("video")[0] ? i.addVideoClick(i.nextPlayTime) : i.initPreventCheat(i.nextPlayTime)) : 4 == n.code && !0)
                        }, e.onclose = function (e) {
                        }, e.onerror = function (e) {
                            alert("WebSocket连接发生错误，请刷新页面！")
                        }
                    }, exitfullscreen: function () {
                        try {
                            document.exitFullscreen ? document.exitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen()
                        } catch (e) {
                        }
                    }, preventCheat: function () {
                        var e = document.getElementsByTagName("head")[0], t = document.createElement("script");
                        t.type = "text/javascript", e.appendChild(t), t.onload = t.onreadystatechange = function () {
                            !this.readyState || "loaded" === this.readyState || this.readyState
                        };
                        var i = parent.location.origin + "/els", n = Object(l["getUrl"])("eln_session_id"),
                            r = "".concat(i, "/html/preventCheat/preventCheat.loadIdentifyCode.do?eln_session_id=").concat(n, "&imgTime="),
                            o = (new Date).getTime();
                        this.imgUrl = r + o, this.imgTime = o
                    }, changeNext: function () {
                        var e = parent.location.origin + "/els", t = Object(l["getUrl"])("eln_session_id"),
                            i = "".concat(e, "/html/preventCheat/preventCheat.loadIdentifyCode.do?eln_session_id=").concat(t, "&imgTime="),
                            n = (new Date).getTime();
                        this.imgUrl = i + n, this.imgTime = n
                    }, validate: function () {
                        var e = new RegExp("^[0-9]*$"), t = new RegExp("^-[1-9][0-9]*$");
                        return "" == this.answerVal ? (this.tips = this.$t("v4.js.pc.ocmt.PleaseEnterTheCorrectAnswer"), !1) : e.test(this.answerVal) || t.test(this.answerVal) ? (this.tips = "", !0) : (this.answerVal = "", this.tips = this.$t("v4.js.pc.ocmt.numPlease"), !1)
                    }, submitAnswer: function () {
                        this.imgTime, Number(this.answerVal);
                        var e = Object(l["getUrl"])("courseId"),
                            t = window.XMLHttpRequest ? new XMLHttpRequest : new ActiveXObject("Microsoft.XMLHTTP"),
                            i = new FormData;
                        i.append("imgTime", this.imgTime), i.append("answer", Number(this.answerVal));
                        var n = this;
                        t && (t.open("post", parent.location.origin + "/els/html/preventCheat/preventCheat.checkAnswer.do?courseId=" + e), t.onreadystatechange = function () {
                            if (4 == t.readyState && 200 == t.status) {
                                var e = JSON.stringify(t.responseText);
                                e.includes("true") ? (n.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_SUCCESS"), clearInterval(n.countTimer), clearInterval(n.playTimer), clearTimeout(n.lastTimer), clearInterval(n.preventCheatInterval), n.preventCheatFlag = !1, n.playTime = 0, n.answerVal = "", console.log("上次执行的时间:" + n.preventCheatTime), n.nextPlayTime = n.maxTime - n.preventCheatTime, console.log("上次剩余的时间：" + n.nextPlayTime), n.preventCheatTime = (Math.random() * (n.maxTime - n.minTime) + n.minTime).toFixed(1), console.log("这次摇到的时间:" + n.preventCheatTime), n.nextPlayTime = Number(n.nextPlayTime) + Number(n.preventCheatTime), console.log("下次执行的时间:" + n.nextPlayTime), document.getElementsByTagName("video")[0] ? n.addVideoClick(n.nextPlayTime) : n.initPreventCheat(n.nextPlayTime)) : (e.includes("Error"), n.$emit("saveStudyLog", "PREVENT_CHEAT_VERIFY_FAIL"), n.tips = n.$t("v4.js.pc.ocmt.PleaseEnterTheCorrectAnswer"))
                            }
                        }), t.send(i)
                    }, resetPlayTime: function (e, t) {
                        clearTimeout(this.preventCheatInterval), clearInterval(this.countTimer), clearInterval(this.playTimer), clearTimeout(this.lastTimer), clearInterval(this.faceTimer), this.playTime = 0, this.preventCheatTime = (Math.random() * (this.maxTime - this.minTime) + this.minTime).toFixed(1)
                    }, addVideoClick: function (e) {
                        var t = this;
                        document.getElementsByTagName("video")[0].onplay = function () {
                            clearTimeout(t.lastTimer), clearInterval(t.playTimer);
                            var i = e ? 1e3 * (60 * e - t.playTime) : 1e3 * (60 * t.preventCheatTime - t.playTime);
                            console.log("剩余触发时间:" + i), t.playTimer = setInterval((function () {
                                t.playTime++
                            }), 1e3), t.lastTimer = setTimeout((function () {
                                t.preventCheatFlag = !0, t.initPreventCheat("video")
                            }), i)
                        }, document.getElementsByTagName("video")[0].onpause = function () {
                            clearInterval(t.playTimer), clearTimeout(t.lastTimer)
                        }, document.getElementsByTagName("video")[0].pause(), document.getElementsByTagName("video")[0].play()
                    }, addPlayEvent: function () {
                        this.preventCheatTime = (Math.random() * (this.maxTime - this.minTime) + this.minTime).toFixed(1), this.playTime = 0, document.getElementsByTagName("video")[0] ? this.addVideoClick() : this.initPreventCheat()
                    }
                },
                mounted: function () {
                    var e = this;
                    o["c"].getUserInfo().then((function (t) {
                        e.userId = t.bizResult.userId
                    })), this.addPlayEvent()
                },
                beforeDestroy: function () {
                    clearTimeout(this.lastTimer), clearInterval(this.playTimer), clearInterval(this.countTimer), clearInterval(this.preventCheatInterval), clearInterval(this.faceTimer)
                }
            }, v = m, y = (i("9b21"), i("2877")), g = Object(y["a"])(v, c, u, !1, null, "a0cbfaf0", null), T = g.exports,
            w = function () {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return e.hangUpFlag ? i("div", {
                    staticClass: "hangUp-box",
                    staticStyle: {width: "100%", height: "100%"}
                }, [e.loginFlag ? i("div", {staticClass: "loginOut-wrap"}, [i("div", {staticClass: "header-tips"}, [e._v("\n            " + e._s(e.$t("v4.js.pc.ocmt.systemHint")) + "\n        ")]), i("div", {
                    staticClass: "tips-content",
                    staticStyle: {padding: "20px", "font-size": "18px"}
                }, [e._v("\n            " + e._s(e.$t("v4.js.pc.ocmt.loginOutSystem")) + "\n            \n        ")]), i("div", {staticClass: "confirmBtn"}, [i("div", {
                    staticClass: "btn",
                    on: {click: e.loginOutConfirm}
                }, [e._v("\n                " + e._s(e.$t("v4.js.pc.ocmt.confirm")) + "\n            ")])])]) : i("div", {staticClass: "hangUp-wrap"}, [i("div", {staticClass: "header-tips"}, [e._v("\n            " + e._s(e.$t("v4.js.pc.ocmt.systemHint")) + "\n        ")]), i("div", {
                    staticClass: "tips-content",
                    staticStyle: {padding: "20px", "font-size": "18px"}
                }, [e._v("\n            长时间未操作页面,"), i("span", {staticStyle: {color: "#eb5352"}}, [e._v(e._s(e.timeCount))]), e._v("秒后退出登录\n        ")]), i("div", {staticClass: "confirmBtn"}, [i("div", {
                    staticClass: "btn",
                    on: {click: e.confirm}
                }, [e._v("\n                " + e._s(e.$t("v4.js.pc.ocmt.confirm")) + "\n            ")])])])]) : e._e()
            }, b = [], C = {
                data: function () {
                    return {
                        hangUpFlag: !1,
                        operateTime: 0,
                        timeCount: 60,
                        timer: null,
                        timeInterval: 3e4,
                        xys: {x0: 0, y0: 0},
                        xy: {x0: 0, y0: 0},
                        loginFlag: !1,
                        timerNoOperate: null
                    }
                }, props: {preventHangTime: {type: Number, default: 0}}, computed: {}, watch: {}, methods: {
                    initHangUp: function () {
                        var e = this;
                        document.body.onmousemove = function (t) {
                            e.xys = {x0: t.clientX, y0: t.clientY}
                        }, this.startTimer()
                    }, startTimer: function () {
                        var e = this;
                        clearInterval(this.timerNoOperate), clearInterval(this.timer), this.timerNoOperate = setInterval((function () {
                            e.checkMouseMove(e.xys)
                        }), e.timeInterval)
                    }, exitfullscreen: function () {
                        try {
                            document.exitFullscreen ? document.exitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitCancelFullScreen ? document.webkitCancelFullScreen() : document.msExitFullscreen && document.msExitFullscreen()
                        } catch (e) {
                        }
                    }, checkMouseMove: function (e) {
                        var t = this;
                        this.xy.x0 == e.x0 && this.xy.y0 == e.y0 ? (this.operateTime += this.timeInterval, this.operateTime / 1e3 / 60 >= this.preventHangTime && (t.timeCount = 60, this.$emit("pauseOrPlay", !1), this.$emit("saveStudyLog", "PREVENT_HANG_POPUP"), this.exitfullscreen(), this.hangUpFlag = !0, clearInterval(this.timerNoOperate), this.timer = setInterval((function () {
                            if (t.timeCount--, t.timeCount < 0) {
                                var e = 0;
                                document.body.onmousemove = function () {
                                    0 == e && (console.log("PREVENT_HANG_LOGOUT"), t.$emit("saveStudyLog", "PREVENT_HANG_LOGOUT"), t.hangUpFlag = !0, t.loginFlag = !0, console.log("loginOut!!"), o["a"].APILoginOut()), e++
                                }, t.hangUpFlag = !1, clearInterval(t.timer), console.log("退出登录")
                            }
                        }), 1e3))) : (this.operateTime = 0, this.xy.x0 = e.x0, this.xy.y0 = e.y0)
                    }, confirm: function () {
                        this.timeCount = 0, clearInterval(this.timer), this.operateTime = 0, this.xys = {
                            x0: 0,
                            y0: 0
                        }, this.xy = {
                            x0: 0,
                            y0: 0
                        }, this.$emit("pauseOrPlay", !0), this.hangUpFlag = !1, this.startTimer(), this.$emit("saveStudyLog", "PREVENT_HANG_OPERATE")
                    }, loginOutConfirm: function () {
                        top.open("/login/login.logout.do", "_self")
                    }
                }, mounted: function () {
                    clearInterval(this.timer), this.initHangUp()
                }, beforeDestroy: function () {
                    clearInterval(this.timerNoOperate), clearInterval(this.timer)
                }
            }, I = C, x = (i("d26f"), Object(y["a"])(I, w, b, !1, null, "91b5bc54", null)), _ = x.exports, S = {
                name: "course-play", data: function () {
                    return {
                        urlJson: null,
                        isPlaying: !0,
                        TimeId1: null,
                        courseData: [],
                        curId: "",
                        curType: "",
                        minStudyTime: "",
                        curVideoId: "",
                        noteId: "",
                        resourceRelIdNoteId: "",
                        resourceRelId: "",
                        curTime: null,
                        seek: 0,
                        curIndex: [0, 0],
                        open: !0,
                        recordList: [],
                        recordTime: 0,
                        recordTimeId: null,
                        recordTimeTemp: 0,
                        recordTimeIdTemp: null,
                        studyRate: 0,
                        isReplayBtn: !1,
                        canSaveRecord: !0,
                        seeking: !1,
                        seeked: "",
                        videoCheck: !0,
                        canRecord: !0,
                        startTime: 0,
                        endTime: 0,
                        continueTime: 0,
                        isVideo: !1,
                        pageIndex: 0,
                        pcEdgeBrowerPreview: !1,
                        curTimeToFinish: 0,
                        noPreviewCurTimeToFinish: 0,
                        corpCode: "",
                        excludeCorpCodeList: [],
                        isIE11: !1,
                        isEdge: !1,
                        mustReplayCanFinish: !1,
                        verificationType: "",
                        hangUpFlag: !1,
                        preventCheatFlag: !1,
                        preventCheatTime: 0,
                        preventHangTime: 0,
                        pauseCountTime: 0,
                        maxTime: 0,
                        minTime: 0,
                        checkType: 2,
                        pausecountTimer: null,
                        firstEnterStudyFlag: !1,
                        studyLogData: {
                            studyLogVO: {
                                minStudyTime: "",
                                courseCode: "",
                                courseStandard: "ONLINEVIDEOCOURSE",
                                courseItemId: "",
                                courseTitle: "",
                                videoDuration: "",
                                courseItemName: "",
                                courseId: "",
                                mark: ""
                            }, eventType: ""
                        },
                        allowDrag: !1,
                        allowHighSpeed: !1,
                        allowMinStudyTime: !1,
                        addVideoClickFlag: !1,
                        settingBtn: !1,
                        heartBeatFlag: !1,
                        handoutVideo: !1,
                        handoutVideoNoteId: "/courseSetting/preview/handout?id=null",
                        resetHandoutAndVideoProps: !1,
                        seekingTimer: null,
                        seekingSaveFlag: !0,
                        showMasking: !1,
                        maskingMsg: "",
                        activeName: "contents",
                        QAactiveName: "quiz",
                        QAformData: {},
                        questionData: [],
                        showPlaceholder: !0,
                        topicData: [],
                        inputTopicText: ""
                    }
                }, components: {AliPlayer: s["a"], AliyunPreview: a["a"], PreventCheat: T, HangUp: _}, computed: {
                    QANum: function () {
                        return this.QAformData.title ? 140 - this.QAformData.title.length : 140
                    }, arrowLeft: function () {
                        return "quiz" === this.QAactiveName ? 29 : 124
                    }, language: function () {
                        return window.$cookies.get("local_") || "zh_CN"
                    }, aliPlayer: function () {
                        return "video" === this.curType || "audio" === this.curType ? this.$refs.aliPlayer : null
                    }, player: function () {
                        return "video" === this.curType || "audio" === this.curType ? this.$refs.aliPlayer.player : null
                    }, curChapterId: function () {
                        return this.courseData[this.curIndex[0]].chapterId
                    }, curInfo: function () {
                        return this.curIndex && this.courseData && this.courseData.length > 0 ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]] : null
                    }, currentStudyTime: function () {
                        var e = this.curIndex && this.courseData && this.courseData.length > 0 ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]] : null,
                            t = e && e.currentStudyTime ? e.currentStudyTime : 0;
                        return e ? e.minStudyTime - t - this.recordTime : 0
                    }, nextIndex: function () {
                        return this.courseData[this.curIndex[0]] && !this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1] + 1] ? this.courseData[this.curIndex[0] + 1] ? [this.curIndex[0] + 1, 0] : null : [this.curIndex[0], this.curIndex[1] + 1]
                    }, nextInfo: function () {
                        return this.nextIndex ? this.courseData[this.nextIndex[0]].resourceDTOS[this.nextIndex[1]] : null
                    }, nextId: function () {
                        return this.nextInfo ? this.nextInfo.resourceId : ""
                    }, courseParams: function () {
                        return decodeURIComponent(this.$route.params.courseInfo).split("&")
                    }, courseId: function () {
                        return this.courseParams[0]
                    }, providerCorpCode: function () {
                        return this.courseParams[1]
                    }, sourceId: function () {
                        return this.courseParams[2]
                    }, courseTitle: function () {
                        return parent.document.title
                    }
                }, watch: {
                    curIndex: {
                        handler: function () {
                            var e = this;
                            this.curVideoId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId : "", this.noteId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId : "", this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "", this.curTime = {
                                minStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                                currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                            }, this.courseData[this.curIndex[0]] && "url" === this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType && this.$store.dispatch("preview/fetchPreviewAction", {
                                param: {
                                    providerCorpCode: this.providerCorpCode,
                                    chapterId: this.courseData[this.curIndex[0]].chapterId,
                                    id: this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceId
                                }, callback: function (t) {
                                    e.urlJson = t;
                                    var i = e.recordList.find((function (t) {
                                        return t.resourceId === e.curId
                                    }));
                                    i && e.$set(e.urlJson, "confirmFinish", i.confirmFinish), t.content || (setTimeout((function () {
                                        var e = document.getElementsByTagName("iframe")[0];
                                        e.style.display = "none"
                                    }), 0), setTimeout((function () {
                                        var e = document.getElementsByTagName("iframe")[0];
                                        e.style.display = "block", e.style.height = "100%", e.style.width = "100%"
                                    }), 0))
                                }
                            })
                        }, deep: !0
                    }, courseData: {
                        handler: function () {
                            var e = this;
                            this.curVideoId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId : "", this.noteId = this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId : "", this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "", this.curTime = {
                                minStudyTime: this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                                currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                            }, this.courseData[this.curIndex[0]] && "url" === this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType && this.$store.dispatch("preview/fetchPreviewAction", {
                                param: {
                                    providerCorpCode: this.providerCorpCode,
                                    chapterId: this.courseData[this.curIndex[0]].chapterId,
                                    id: this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceId
                                }, callback: function (t) {
                                    e.urlJson = t;
                                    var i = e.recordList.find((function (t) {
                                        return t.resourceId === e.curId
                                    }));
                                    e.initHeart(), i && e.$set(e.urlJson, "confirmFinish", i.confirmFinish), t.content || (setTimeout((function () {
                                        var e = document.getElementsByTagName("iframe")[0];
                                        e.style.display = "none"
                                    }), 0), setTimeout((function () {
                                        var e = document.getElementsByTagName("iframe")[0];
                                        e.style.display = "block", e.style.height = "100%", e.style.width = "100%"
                                    }), 0))
                                }
                            })
                        }, deep: !0
                    }, currentStudyTime: function (e) {
                        0 === e && "video" !== this.curType && "audio" !== this.curType && (this.recordTimeId && clearInterval(this.recordTimeId), this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), this.updateCourseRecord())
                    }, recordTime: function (e) {
                        var t = this;
                        "video" !== this.curType && "audio" !== this.curType && e % 180 === 0 && 0 !== e && (this.updateCourseRecord(1), this.recordTimeId && clearInterval(this.recordTimeId)), ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && (this.curTimeToFinish = Math.round(this.player.getDuration() * this.courseData[this.curIndex[0]].finishPercent), this.noPreviewCurTimeToFinish = Math.round(.5 * this.player.getDuration())), ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && e === this.noPreviewCurTimeToFinish && (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                            t.canRecord = !0
                        }), 1e3)), ("video" === this.curType || "audio" === this.curType) && this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && e === this.noPreviewCurTimeToFinish && !this.allowDrag && (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                            t.canRecord = !0
                        }), 1e3))
                    }
                }, directives: {
                    focus: {
                        inserted: function (e, t) {
                            var i = t.value;
                            i && e.focus()
                        }
                    }
                }, methods: {
                    videoSeeking: function () {
                        var e = this;
                        this.seekingSaveFlag = !1, clearTimeout(this.seekingTimer), this.seekingTimer = setTimeout((function () {
                            e.seekingSaveFlag = !0, clearTimeout(e.seekingTimer)
                        }), 5e3)
                    }, initHeart: function () {
                        var e = this;
                        clearInterval(this.heartTimer);
                        var t = {courseId: this.courseId, eln_session_id: Object(l["getUrl"])("eln_session_id")};
                        o["c"].loadCourseSystemSeting(t).then((function (t) {
                            "1001" == t.code && (!t.bizResult.heartBeat || e.curInfo.finish && !t.bizResult.continueHeartBeat || (e.heartTimer = setInterval((function () {
                                o["c"].heartBeatSetData(e.courseId)
                            }), 6e4), e.heartBeatFlag = !0))
                        }))
                    }, resetHandoutAndVideo: function () {
                        this.resetHandoutAndVideoProps = !0
                    }, openAndCloseVideo: function (e) {
                        this.handoutVideoNoteId = "/courseSetting/preview/handout?id=" + e.noteId;
                        document.getElementById("aliPlayer");
                        this.handoutVideo = !!e.flag, this.resetHandoutAndVideoProps = !e.flag
                    }, toFullVideo: function (e) {
                        e.requestFullscreen ? e.requestFullscreen() : e.webkitRequestFullScreen ? e.webkitRequestFullScreen() : e.mozRequestFullScreen ? e.mozRequestFullScreen() : e.msRequestFullscreen()
                    }, exitFullscreen: function () {
                        document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen()
                    }, getCourseData: function () {
                        var e = this, t = {courseId: this.sourceId, providerCorpCode: this.providerCorpCode};
                        o["b"].APIshowCourseChapter(t).then((function (t) {
                            e.courseData = t.bizResult.filter((function (e) {
                                return e.resourceDTOS.length > 0
                            })), e.settingBtn = e.courseData[0].customAliVideoCorp, "preview" !== e.$route.query.from && !1 === e.pcEdgeBrowerPreview ? e.getStudyRecordList(e.setPlaytimePosition) : e.initMasking(), e.isPlaying = !0
                        }))
                    }, setPlaytimePosition: function () {
                        var e = this;
                        this.recordLearningStatus("ENTER_STUDY"), this.recordLearningStatus("COURSE_SIGN_IN");
                        var t = this.recordList.find((function (e) {
                            return 1 === e.confirmLearning
                        })), i = t ? this.courseData.findIndex((function (e) {
                            return e.resourceDTOS.some((function (e) {
                                return e.resourceId === t.resourceId
                            }))
                        })) : -1;
                        void 0 !== t && i >= 0 ? (this.curIndex[0] = this.courseData.findIndex((function (e) {
                            return e.resourceDTOS.some((function (e) {
                                return e.resourceId === t.resourceId
                            }))
                        })), this.curIndex[1] = this.courseData[this.curIndex[0]].resourceDTOS.findIndex((function (e) {
                            return e.resourceId === t.resourceId
                        })), this.pageIndex = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].pageIndex || 0, this.curType = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceType, this.minStudyTime = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime, "video" !== this.curType && "audio" !== this.curType || (this.isVideo = !0), this.curId = t.resourceId, this.minStudyTime = t.minStudyTime, this.curVideoId = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].resourceRelId, this.noteId = this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteId, this.resourceRelIdNoteId = this.courseData[this.curIndex[0]] ? (this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].noteResource || {}).resourceRelId : "", this.curTime = {
                            minStudyTime: this.courseData[this.curIndex[0]] ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].minStudyTime : "",
                            currentStudyTime: this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0
                        }) : (this.pageIndex = this.courseData[0] && this.courseData[0].resourceDTOS[0] && this.courseData[0].resourceDTOS[0].pageIndex || 0, this.curType = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].resourceType : "", this.minStudyTime = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].minStudyTime : "", "video" !== this.curType && "audio" !== this.curType || (this.isVideo = !0), this.curId = this.courseData[0] && this.courseData[0].resourceDTOS[0] ? this.courseData[0].resourceDTOS[0].resourceId : "");
                        var n = this.recordList.find((function (t) {
                            return t.resourceId === e.curId
                        }));
                        void 0 === n || null === n.currentPosition || 1 === n.confirmFinish || "video" !== this.curType && "audio" !== this.curType || (this.seek = n.currentPosition), this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), this.recordTimeTemp = this.courseData[this.curIndex[0]] && this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime ? this.courseData[this.curIndex[0]].resourceDTOS[this.curIndex[1]].currentStudyTime : 0, ("video" !== this.curType && "audio" !== this.curType || ("video" === this.curType || "audio" === this.curType) && this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1) && ("video" !== this.curType && "audio" !== this.curType || this.allowDrag || this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                            confirmButtonText: "确定",
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }), this.recordTime = 0, this.recordTimeId = setInterval((function () {
                            e.recordTime++
                        }), 1e3))
                    }, syncStudyRecord: function () {
                        if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                            var e = {
                                courseId: this.courseId,
                                sourceId: this.sourceId,
                                providerCorpCode: this.providerCorpCode
                            };
                            o["c"].APIsyncStudyRecord(e)
                        }
                    }, getStudyRecordList: function () {
                        var e = this, t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : null,
                            i = {courseId: this.courseId, sourceId: this.sourceId, providerCorpCode: this.providerCorpCode};
                        o["c"].APIgetStudyRecordList(i).then((function (i) {
                            e.recordList = i.bizResult, e.recordList && e.recordList.length > 0 && e.recordList[0].alert && e.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">管理员调整了这门课程的内容，您的学习记录可能因此发生变化。</span>', "", {
                                confirmButtonText: e.$t("v4.js.pc.ocmt.confirm"),
                                showClose: !1,
                                dangerouslyUseHTMLString: !0
                            }), e.recordList.forEach((function (t) {
                                e.courseData.forEach((function (i) {
                                    i.resourceDTOS.forEach((function (i) {
                                        i.resourceId === t.resourceId && (1 === t.confirmFinish && e.$set(i, "finish", !0), e.$set(i, "currentStudyTime", t.currentStudyTime), e.$set(i, "pageIndex", t.pageIndex))
                                    }))
                                }))
                            })), t && t()
                        }))
                    }, updateCourseRecord: function (e, t) {
                        var i = this;
                        if ("preview" !== this.$route.query.from && (!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1) && this.canSaveRecord) {
                            if (!this.allowDrag && !this.seekingSaveFlag && ("video" === this.curType || "audio" === this.curType)) return;
                            t && clearInterval(this.recordTimeIdTemp);
                            var n = this.recordList.find((function (e) {
                                return e.resourceId === i.curId
                            })), r = void 0 !== n ? n.recordId : null;
                            if (void 0 !== n && 1 !== n.confirmFinish || void 0 === n) {
                                var s = 0;
                                "video" !== this.curType && "audio" !== this.curType || (s = this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish ? this.recordTime : this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish ? this.curTimeToFinish : Math.round(Math.max(this.seek, this.player.getCurrentTime())));
                                var a = {
                                    recordId: r,
                                    courseId: this.courseId,
                                    sourceId: this.sourceId,
                                    providerCorpCode: this.providerCorpCode,
                                    chapterId: this.curChapterId,
                                    resourceId: this.curId,
                                    timeToFinish: this.curTimeToFinish,
                                    currentPosition: s,
                                    type: this.curType,
                                    currentStudyTime: "video" === this.curType || "audio" == this.curType ? this.recordTimeTemp - this.curTime.currentStudyTime : this.recordTime,
                                    pageIndex: "video" !== this.curType && "audio" !== this.curType && this.$refs.aliPreview ? this.$refs.aliPreview.currentCount : 0
                                };
                                this.canSaveRecord = !1, o["c"].APIupdateCourseRecord(a).then((function (t) {
                                    i.getStudyRecordList((function () {
                                        e && (i.recordTimeId && clearInterval(i.recordTimeId), i.recordTime = 0, i.recordTimeId = setInterval((function () {
                                            i.recordTime++
                                        }), 1e3)), i.canSaveRecord = !0
                                    })), i.getStudyRate()
                                }))
                            }
                        }
                    }, getStudyRate: function () {
                        var e = this,
                            t = {courseId: this.courseId, sourceId: this.sourceId, providerCorpCode: this.providerCorpCode};
                        o["c"].APIgetStudyRate(t).then((function (t) {
                            e.studyRate = t.bizResult, localStorage.studyRate = e.studyRate
                        }))
                    }, checkoutSection: function (e, t) {
                        var i = this, n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : 0;
                        clearInterval(this.heartTimer), this.firstEnterStudyFlag && this.recordLearningStatus("QUIT_COURSE_ITEM");
                        var r = e.resourceId, o = e.resourceType, s = e.minStudyTime;
                        if (this.mustReplayCanFinish = !1, this.updateCourseRecord(), this.videoCheck = !1, "video" !== this.curType && "audio" !== this.curType || this.player.pause(), this.recordTimeId && clearInterval(this.recordTimeId), this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), e.pageIndex && (this.pageIndex = e.pageIndex), this.curType = o, "video" !== this.curType && "audio" !== this.curType && (this.isPlaying = !0), "video" === this.curType || "audio" === this.curType ? this.resetHandoutAndVideo() : (document.pictureInPictureElement && document.exitPictureInPicture(), this.handoutVideo = !1), "video" === this.curType || "audio" === this.curType) {
                            var a = this.recordList.find((function (e) {
                                return e.resourceId === r
                            }));
                            void 0 !== a && null !== a.currentPosition && 1 !== a.confirmFinish && a.currentPosition < a.timeToFinish ? (this.seeked = a.currentPosition, this.seek = a.currentPosition) : (this.seeked = 0, this.seek = 0), this.$refs.aliPlayer && (this.$refs.aliPlayer.seeked = this.seeked, this.player.seek(0))
                        }
                        this.preventCheatFlag && ("video" == this.curType || "audio" == this.curType ? this.$refs.preventCheat.resetPlayTime(this.preventCheatTime) : this.$refs.preventCheat.initPreventCheat(this.preventCheatTime)), this.recordTime = 0, this.recordTimeTemp = 0, this.recordTimeIdTemp && clearInterval(this.recordTimeIdTemp), this.$nextTick((function () {
                            i.isVideo = !1, i.curId = r, i.minStudyTime = s, i.curIndex = [t, n], i.curVideoId = i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].resourceRelId : "", i.noteId = i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].noteId : "", i.resourceRelIdNoteId = i.courseData[i.curIndex[0]] ? (i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].noteResource || {}).resourceRelId : "", i.curTime = {
                                minStudyTime: i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].minStudyTime : "",
                                currentStudyTime: i.courseData[i.curIndex[0]] ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].currentStudyTime : ""
                            }, i.recordTimeTemp = i.courseData[i.curIndex[0]] && i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].currentStudyTime ? i.courseData[i.curIndex[0]].resourceDTOS[i.curIndex[1]].currentStudyTime : 0, "video" !== i.curType && "audio" != i.curType || (i.isVideo = !0, i.$refs.aliPlayer && i.$refs.aliPlayer.aliPlayer(i.curVideoId), i.recordTimeIdTemp = setInterval((function () {
                                i.recordTimeTemp++
                            }), 1e3)), ("video" !== i.curType && "audio" !== i.curType || ("video" === i.curType || "audio" === i.curType) && i.isEdge && i.excludeCorpCodeList.indexOf(i.corpCode) > -1) && ("video" !== i.curType && "audio" !== i.curType || i.allowDrag || i.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                                confirmButtonText: i.$t("v4.js.pc.ocmt.confirm"),
                                showClose: !1,
                                dangerouslyUseHTMLString: !0
                            }), i.recordTimeId = setInterval((function () {
                                i.recordTime++
                            }), 1e3)), i.recordLearningStatus("ENTER_COURSE_ITEM")
                        }))
                    }, toggleCollapse: function (e, t) {
                        e.fold = !e.fold, this.$set(this.courseData, t, e)
                    }, startRecord: function () {
                    }, play: function () {
                        var e = this, t = this;
                        clearTimeout(this.pausecountTimer), this.pausecountTimer = setTimeout((function () {
                            t.pauseCountTime && t.recordLearningStatus("PLAY")
                        }), 1e3), ("video" === this.curType || "audio" === this.curType) && (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && (clearInterval(this.recordTimeId), this.recordTimeId = setInterval((function () {
                            e.recordTime++
                        }), 1e3)), "video" !== this.curType && "audio" !== this.curType || (clearInterval(this.recordTimeIdTemp), this.recordTimeIdTemp = setInterval((function () {
                            e.recordTimeTemp++
                        }), 1e3)), this.isPlaying = !0, this.videoCheck = !0
                    }, pause: function () {
                        var e = this;
                        this.pauseCountTime = 0, clearTimeout(this.pausecountTimer), this.pausecountTimer = setTimeout((function () {
                            e.pauseCountTime++, e.recordLearningStatus("PAUSE")
                        }), 1e3), ("video" === this.curType || "audio" === this.curType) && (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && clearInterval(this.recordTimeId), "video" !== this.curType && "audio" !== this.curType || clearInterval(this.recordTimeIdTemp)
                    }, ended: function () {
                        var e = this;
                        console.log("视频播放完成！章节结束时间"), this.recordLearningStatus("COMPLETE_COURSE_ITEM"), this.getStudyRecordList((function () {
                            e.canSaveRecord = !0
                        })), this.$nextTick((function () {
                            var t = e.recordList.find((function (t) {
                                return t.resourceId === e.curId
                            }));
                            !e.isIE11 && !e.isEdge || e.isIE11 && e.excludeCorpCodeList.indexOf(e.corpCode) > -1 && !e.allowDrag && e.recordTime >= e.noPreviewCurTimeToFinish ? (e.mustReplayCanFinish = !1, e.updateCourseRecord(), e.aliPlayer.resetPlayer()) : e.isIE11 && e.excludeCorpCodeList.indexOf(e.corpCode) > -1 && !e.allowDrag && e.recordTime < e.noPreviewCurTimeToFinish && (void 0 === t || 1 !== t.confirmFinish) ? (e.mustReplayCanFinish = !0, clearInterval(e.recordTimeId), e.updateCourseRecord()) : (e.mustReplayCanFinish = !1, e.aliPlayer.resetPlayer()), e.isPlaying = !1, e.isReplayBtn = !0, setTimeout((function () {
                                e.isPlaying || "preview" === e.$route.query.from || "unionpay" !== e.corpCode || e.playNextSection()
                            }), 1e3)
                        }))
                    }, ready: function () {
                        this.curTimeToFinish = Math.round(this.player.getDuration() * this.courseData[this.curIndex[0]].finishPercent), this.noPreviewCurTimeToFinish = Math.round(.5 * this.player.getDuration());
                        var e = this;
                        "video" != this.curType && "audio" != this.curType || document.getElementsByClassName("rate-list").length && document.getElementsByClassName("rate-list")[0].addEventListener("click", (function (t) {
                            var i = t.target.innerText.replace("x", "");
                            e.studyLogData.studyLogVO.mark = i, e.recordLearningStatus("SPEED_CHANGE")
                        }))
                    }, timeupdate: function () {
                        var e = this;
                        if (this.videoCheck && ("video" === this.curType || "audio" === this.curType)) {
                            var t = Math.floor(this.player.getCurrentTime()) + 1, i = this.recordList.find((function (t) {
                                return t.resourceId === e.curId
                            }));

                            /** NicolasLemon修改2 */
                            // 修改当前对象的seek时间，在 修改1 中已经将播放器的播放时间设置成需要观看的最小的学习时间
                            this.seek = Math.floor(this.player.getCurrentTime());

                            if (t > this.seek && t - this.seek > 3 && (void 0 === i || 1 !== i.confirmFinish) && !this.allowDrag && "preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) this.player.seek(this.seek); else {
                                var n = t > 2 ? t : 0;
                                this.seek = Math.max(this.seek, n)
                            }
                            (void 0 === i || 1 !== i.confirmFinish) && (t > this.curTimeToFinish || this.minStudyTime === this.recordTimeTemp) && (!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.allowDrag) && (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                                e.canRecord = !0
                            }), 1e3)), t !== this.curTimeToFinish && (0 === t || t % 180 !== 0 && this.minStudyTime !== this.recordTimeTemp) || !(!this.isIE11 && !this.isEdge || (this.isIE11 || this.isEdge) && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.allowDrag) || (this.canRecord && (this.updateCourseRecord(), this.canRecord = !1), clearTimeout(this.TimeId1), this.TimeId1 = setTimeout((function () {
                                e.canRecord = !0
                            }), 1e3))
                        }
                    }, rePlay: function () {
                        this.resetHandoutAndVideo(), this.player.seek(0), this.isPlaying = !0, this.seek = 0, this.play(), this.isReplayBtn = !1, this.recordTime = 0, this.recordTimeTemp = 0
                    }, playNextSection: function () {
                        var e = this;
                        this.resetHandoutAndVideo(), this.isPlaying = !0, this.updateCourseRecord(), this.$nextTick((function () {
                            e.curType = e.nextInfo.resourceType, e.minStudyTime = e.nextInfo.minStudyTime, e.curId = e.nextId, e.curIndex = e.nextIndex ? e.nextIndex.slice(0) : null;
                            var t = e.recordList.find((function (t) {
                                return t.resourceId === e.curId
                            }));
                            void 0 !== t && null !== t.currentPosition && 1 !== t.confirmFinish ? e.seek = t.currentPosition : e.seek = 0, "video" !== e.curType && "audio" !== e.curType || (e.isVideo = !0, e.$refs.aliPlayer.aliPlayer()), ("video" !== e.curType && "audio" !== e.curType || ("video" === e.curType || "audio" === e.curType) && e.isEdge && e.excludeCorpCodeList.indexOf(e.corpCode) > -1) && ("video" !== e.curType && "audio" !== e.curType || e.allowDrag || e.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">请勿手动拖拽课程进度条，以保证课程的正常学习!课程单次学习实际播放时长不得少于课程视频时长的50%</span>', "", {
                                confirmButtonText: e.$t("v4.js.pc.ocmt.confirm"),
                                showClose: !1,
                                dangerouslyUseHTMLString: !0
                            }), e.recordTime = 0, e.recordTimeId = setInterval((function () {
                                e.recordTime++
                            }), 1e3))
                        }))
                    }, writeRecordWhileClose: function () {
                        var e = this;
                        if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                            this.recordLearningStatus("QUIT_STUDY");
                            var t = this.recordList.find((function (t) {
                                return t.resourceId === e.curId
                            })), i = void 0 !== t ? t.recordId : null;
                            this.endTime = Date.now(), this.continueTime = this.endTime - this.startTime;
                            var n = 0;
                            "video" !== this.curType && "audio" !== this.curType || ((this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime < this.noPreviewCurTimeToFinish) && (n = this.recordTime), n = this.isIE11 && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish && !this.allowDrag || this.isEdge && this.excludeCorpCodeList.indexOf(this.corpCode) > -1 && this.recordTime >= this.noPreviewCurTimeToFinish ? this.curTimeToFinish : Math.round(Math.max(this.seek, this.player.getCurrentTime())));
                            var r = {
                                recordId: i,
                                courseId: this.courseId,
                                sourceId: this.sourceId,
                                providerCorpCode: this.providerCorpCode,
                                chapterId: this.curChapterId,
                                resourceId: this.curId,
                                timeToFinish: this.curTimeToFinish,
                                currentPosition: n,
                                type: this.curType,
                                currentStudyTime: "video" === this.curType || "audio" == this.curType ? this.recordTimeTemp - this.curTime.currentStudyTime : this.recordTime,
                                pageIndex: "video" !== this.curType && "audio" === this.curType && this.$refs.aliPreview ? this.$refs.aliPreview.currentCount : 0
                            };
                            if (navigator.sendBeacon) {
                                var o = {type: "text/plain; charset=UTF-8"}, s = new Blob([JSON.stringify(r)], o);
                                navigator.sendBeacon("/tbc-rms/record/writeRecordWhileClose", s)
                            } else {
                                var a = new XMLHttpRequest;
                                a.open("POST", "/tbc-rms/record/writeRecordWhileClose", !0), a.setRequestHeader("Content-Type", "application/json"), a.send(JSON.stringify(r))
                            }
                        }
                    }, registerClosePageEvent: function () {
                        window.addEventListener("beforeunload", this.writeRecordWhileClose)
                    }, handlePause: function (e) {
                        "Space" === e.code && this.checkoutStatus(!1)
                    }, registerSpaceEvent: function () {
                        document.addEventListener("keyup", this.handlePause)
                    }, checkoutStatus: function (e) {
                        "video" !== this.curType && "audio" !== this.curType || !this.player || (!e || "VIDEO" !== e.target.tagName) && e || document.querySelector(".prism-play-btn").click()
                    }, checkBrowerIsEdgeAndIE11: function () {
                        var e = window.navigator.userAgent, t = function () {
                            return "ActiveXObject" in window
                        }();
                        t && (this.isIE11 = !0), e.indexOf("Edge/") > 0 && (this.isEdge = !0);
                        return t && this.excludeCorpCodeList.indexOf(this.corpCode) < 0 ? (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过IE浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                            confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }), !0) : e.indexOf("Edge/") > 0 && this.excludeCorpCodeList.indexOf(this.corpCode) < 0 ? (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过Edge浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                            confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }), !0) : e.indexOf("Safari") > -1 && e.indexOf("Chrome") < 0 && (this.$alert('<div class="message-tip-title"><span class="iconfont icon-info"></span><span class="message-title">提示</span></div><span class="message-cont">当前课程通过Safari浏览器学习，系统将不会记录学习进度。请您更换Google Chrome浏览器或登录微平台及APP进行课程的学习！</span>', "", {
                            confirmButtonText: this.$t("v4.js.pc.ocmt.confirm"),
                            showClose: !1,
                            dangerouslyUseHTMLString: !0
                        }), !0)
                    }, clickCloseSaveRecord: function () {
                        var e = this;
                        window.addEventListener("message", (function (t) {
                            try {
                                var i = JSON.parse(t.data)
                            } catch (n) {
                                return
                            }
                            switch (console.log(i), i.action) {
                                case"studyRecordWhileClose":
                                    e.writeRecordWhileClose(), window.parent.postMessage(t.data, "*"), console.log("处理成功，返回消息！");
                                    break
                            }
                        }), !1)
                    }, getSystemSeting: function () {
                        var e = this, t = {courseId: this.courseId, eln_session_id: Object(l["getUrl"])("eln_session_id")};
                        o["c"].loadCourseSystemSeting(t).then((function (t) {
                            "1001" == t.code && (t.bizResult.checkType && (e.checkType = t.bizResult.checkType, e.maxTime = t.bizResult.preventCheatTimeTo, e.minTime = t.bizResult.preventCheatTime, e.preventCheatTime = (Math.random() * (t.bizResult.preventCheatTimeTo - t.bizResult.preventCheatTime) + t.bizResult.preventCheatTime).toFixed(1), e.verificationType = "preventCheat", e.preventCheatFlag = !0), t.bizResult.enablePreventHang && (e.verificationType = "hangUp", e.hangUpFlag = !0, e.preventHangTime = t.bizResult.preventHangTime), !t.bizResult.heartBeat || e.curInfo.finish && !t.bizResult.continueHeartBeat || (e.heartBeatFlag = !0, e.$refs.aliPlayer.addVideoClick()))
                        }))
                    }, isReady: function () {
                        ("video" == this.curType || "audio" === this.curType) && this.addVideoClickFlag && this.$refs.preventCheat && this.$refs.preventCheat.addVideoClick(), "preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview ? (this.addVideoClickFlag = !0, this.getSystemSeting()) : this.$refs.aliPlayer && this.$refs.aliPlayer.addVideoClick()
                    }, pauseOrPlay: function (e) {
                        this.isVideo && (!e && this.player ? this.player.pause() : this.player.play())
                    }, saveStudyLog: function (e) {
                        console.log("eventType"), this.recordLearningStatus(e)
                    }, recordLearningStatus: function (e) {
                        if ("preview" !== this.$route.query.from && !1 === this.pcEdgeBrowerPreview) {
                            "PREVENT_HANG_LOGOUT" == e && window.removeEventListener("beforeunload", this.writeRecordWhileClose), "ENTER_STUDY" == e && (this.firstEnterStudyFlag = !0), this.studyLogData.studyLogVO.minStudyTime = null == this.curInfo.minStudyTime ? "" : this.curInfo.minStudyTime, this.studyLogData.eventType = e, this.studyLogData.studyLogVO.courseItemId = this.curId, this.studyLogData.studyLogVO.courseItemName = this.curInfo.resourceName, this.studyLogData.studyLogVO.courseId = this.courseId, this.studyLogData.studyLogVO.courseTitle = parent.title;
                            try {
                                this.studyLogData.studyLogVO.videoDuration = "video" != this.curType && "audio" !== this.curType || !this.player ? "" : Math.floor(1e3 * this.player.getDuration())
                            } catch (i) {
                                console.log(i)
                            }
                            var t = JSON.parse(JSON.stringify(this.studyLogData));
                            o["c"].saveStudyLog(this.courseId, t).then((function (e) {
                            }))
                        }
                    }, getCourseSetting: function () {
                        var e = this, t = {courseId: this.courseId};
                        o["b"].APIshowCourseSetting(t).then((function (t) {
                            e.allowDrag = 1 == t.bizResult.allowDrag, e.allowHighSpeed = 1 == t.bizResult.allowHighSpeed, e.allowMinStudyTime = 1 == t.bizResult.allowMinStudyTime
                        }))
                    }, playOrPauseReordTime: function (e) {
                        var t = this;
                        console.log(e + "时间：" + this.recordTimeId), e ? clearInterval(this.recordTimeId) : this.recordTimeId = setInterval((function () {
                            t.recordTime++
                        }), 1e3), e ? clearInterval(this.recordTimeIdTemp) : this.recordTimeIdTemp = setInterval((function () {
                            t.recordTimeTemp++
                        }), 1e3)
                    }, initMasking: function () {
                        var e = this, t = {courseId: this.courseId, alreadyChoose: null};
                        o["c"].checkUserCanLoadCourse(t).then((function (t) {
                            2010 === t.code ? (e.showMasking = !0, e.maskingMsg = t.msg, setInterval((function () {
                                e.showMasking = !0
                            }), 3e5)) : e.setPlaytimePosition()
                        }))
                    }, quitCourse: function () {
                        window.opener = null, window.open("", "_self"), window.close()
                    }, continuePreview: function () {
                        this.showMasking = !1, this.setPlaytimePosition()
                    }, handletabClick: function (e, t) {
                        console.log(e, t)
                    }, saveQuestion: function () {
                        if (this.QAformData.title) {
                            this.topicData.push(this.courseTitle);
                            var e = {
                                title: this.QAformData.title,
                                content: this.QAformData.content,
                                topic: this.topicData.join(",")
                            }, t = this, i = new FormData;
                            i.append("question.title", e.title), i.append("question.content", e.content), i.append("question.topic", e.topic);
                            var n = new XMLHttpRequest, r = window.location.origin;
                            n.open("post", "".concat(r, "/els/html/course/courseStudy.courseAskPublishJson.do")), n.send(i), n.onreadystatechange = function () {
                                4 == n.readyState && 200 == n.status && (t.$message({
                                    message: t.$t("v4.js.pc.ocmt.Successful"),
                                    type: "success"
                                }), t.QAformData = {}, t.topicData = [])
                            }
                        } else this.$message({message: this.$t("v4.js.pc.ocmt.QuestionEmpty"), type: "error"})
                    }, inputFocus: function () {
                        this.showPlaceholder = !1
                    }, inputBlur: function () {
                        this.showPlaceholder = !0, this.inputTopicText && (this.topicData.push(this.inputTopicText), this.inputTopicText = "")
                    }, deleteTopicItem: function (e) {
                        this.topicData.splice(e, 1)
                    }, getRelativeQuestion: function () {
                        var e, t = this, i = new RegExp("[`~!@#$^&*()=|{}':;',\\[\\].<>《》/?~！@#￥……&*（）——|{}【】‘；：”“'。，、？ ]");
                        e = i.test(this.courseTitle) ? "" : this.courseTitle, o["c"].relativeQuestionJson(e).then((function (e) {
                            e && 1001 === e.code && (t.questionData = e.bizResult.rows, console.log(e), console.log(t.questionData))
                        }))
                    }, goToQuestion: function (e) {
                        var t = window.location.origin, i = Object(l["getUrl"])("eln_session_id");
                        window.open("".concat(t, "/qa/html/question.do?elsSign=").concat(i, "&questionId=").concat(e))
                    }, handleTabChange: function (e) {
                        this.QAactiveName = e, "relatedQuestion" === e && this.getRelativeQuestion()
                    }
                }, beforeDestroy: function () {
                    clearInterval(this.heartTimer), document.removeEventListener("keyup", this.handlePause)
                }, destroyed: function () {
                    window.removeEventListener("beforeunload", this.writeRecordWhileClose)
                }, created: function () {
                    this.getCourseSetting()
                }, mounted: function () {
                    var e = this;
                    this.corpCode = window.$cookies.get("corp_code") || window.$cookies.get("corpCode"), this.registerClosePageEvent(), this.registerSpaceEvent(), this.clickCloseSaveRecord(), this.$store.dispatch("nav1/fetchGetAuthCorpsAction", {type: 0}).then((function (t) {
                        e.excludeCorpCodeList = t, e.pcEdgeBrowerPreview = e.checkBrowerIsEdgeAndIE11(), e.syncStudyRecord(), e.getCourseData(), e.getStudyRate(), e.getRelativeQuestion(), e.startTime = Date.now()
                    }))
                }
            }, E = S, A = (i("3a74"), Object(y["a"])(E, n, r, !1, null, "0b225294", null));
        t["default"] = A.exports
    }, "704d": function (e, t, i) {
        "use strict";
        var n = function () {
                var e = this, t = e.$createElement, i = e._self._c || t;
                return i("div", {
                    staticStyle: {
                        width: "100%",
                        height: "100%",
                        position: "relative"
                    }
                }, [i("div", {
                    directives: [{name: "show", rawName: "v-show", value: e.isPlay, expression: "isPlay"}],
                    staticClass: "prism-player",
                    attrs: {id: "J_prismPlayer"}
                }, [i("div", {ref: "waterMarker", staticClass: "waterMarker"})])])
            }, r = [], o = (i("8e6e"), i("456d"), i("28a5"), i("bd86")), s = (i("ac6a"), i("96cf"), i("3b8d")),
            a = (i("c5f6"), i("8e44")), c = i("ccf6"), u = i.n(c), l = i("fa7d"), d = i("9ff8");

        function h(e, t) {
            var i = Object.keys(e);
            if (Object.getOwnPropertySymbols) {
                var n = Object.getOwnPropertySymbols(e);
                t && (n = n.filter((function (t) {
                    return Object.getOwnPropertyDescriptor(e, t).enumerable
                }))), i.push.apply(i, n)
            }
            return i
        }

        function p(e) {
            for (var t = 1; t < arguments.length; t++) {
                var i = null != arguments[t] ? arguments[t] : {};
                t % 2 ? h(Object(i), !0).forEach((function (t) {
                    Object(o["a"])(e, t, i[t])
                })) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(i)) : h(Object(i)).forEach((function (t) {
                    Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(i, t))
                }))
            }
            return e
        }

        var f = {
            props: {
                resetHandoutAndVideoProps: {default: !1, type: Boolean},
                isTitle: {default: "", type: String},
                autoPlay: {default: !0, type: Boolean},
                videoId: {default: "", type: String},
                noteId: {default: "", type: String},
                resourceRelId: {default: "", type: String},
                curTime: {
                    default: function () {
                        return {}
                    }, type: Object
                },
                recordTime: {default: 0, type: Number},
                seek: {default: 0, type: Number},
                setting: {
                    default: function () {
                        return {}
                    }, type: Object
                },
                allowHighSpeed: {default: !0, type: Boolean},
                allowMinStudyTime: {default: !0, type: Boolean},
                type: {default: "", type: String},
                settingBtn: {default: !1, type: Boolean},
                heartBeatFlag: {default: !1, type: Boolean},
                courseId: {default: "", type: String}
            }, data: function () {
                return {
                    player: null,
                    eventList: ["ready", "play", "pause", "canplay", "playing", "ended", "liveStreamStop", "m3u8Retry", "hideBar", "showBar", "waiting", "timeupdate", "snapshoted", "requestFullScreen", "cancelFullScreen", "error", "startSeek", "completeSeek", "seeking"],
                    playAuth: null,
                    isPlay: !0,
                    TimeId: null,
                    sourceUrl: null,
                    playerBuild: 0,
                    seeked: 0,
                    videoAddressUrl: "",
                    updateToken: "",
                    base64Url: "",
                    playWay: "source",
                    heartbeatTime: 0,
                    heartbeatTimer: null,
                    hangUpCheckFlag: !1,
                    yinpinBG: u.a,
                    recordTimeIdTemp: null,
                    recordTimeTemp: 0
                }
            }, components: {AliyunPreview: d["a"]}, computed: {
                components: function () {
                    return this.allowHighSpeed ? [{name: "RateComponent", type: AliPlayerComponent.RateComponent}] : []
                }
            }, watch: {
                resetHandoutAndVideoProps: function (e) {
                    e && (document.pictureInPictureElement && document.exitPictureInPicture(), this.$emit("openAndCloseVideoParent", {
                        flag: 0,
                        noteId: this.noteId
                    }))
                }, videoId: function (e, t) {
                    var i = this;
                    "videoId" !== this.playWay && (console.log("33333:" + e), "" === e || "video" !== this.type && "audio" !== this.type || (clearTimeout(this.TimeId), this.isPlay = !1, this.TimeId = setTimeout((function () {
                        console.log(321555), i.$nextTick((function () {
                            i.isPlay = !0, i.playerBuild, i.aliPlayer(), i.playerBuild++
                        }))
                    }), 1e3)))
                }
            }, methods: {
                openAndCloseVideo: function (e) {
                    var t = document.getElementsByTagName("video")[0];
                    if (e) {
                        try {
                            document.pictureInPictureEnabled && t.requestPictureInPicture()
                        } catch (n) {
                        }
                        this.$emit("openAndCloseVideoParent", {flag: 1, noteId: this.noteId})
                    } else document.pictureInPictureElement && document.exitPictureInPicture(), this.$emit("openAndCloseVideoParent", {
                        flag: 0,
                        noteId: this.noteId
                    });
                    var i = this;
                    t.addEventListener("leavepictureinpicture", (function () {
                        var e = document.getElementById("handoutOperate");
                        e.innerText = i.$t("v4.js.pc.ocmt.viewHandout"), i.$emit("openAndCloseVideoParent", {
                            flag: 0,
                            noteId: this.noteId
                        })
                    }))
                }, openHandout: function () {
                    var e = "/courseSetting/preview/document?id=".concat(this.noteId);
                    window.open(e)
                }, getVideoAddress: function (e) {
                    var t = this;
                    return Object(s["a"])(regeneratorRuntime.mark((function i() {
                        var n, r, o, s, c;
                        return regeneratorRuntime.wrap((function (i) {
                            while (1) switch (i.prev = i.next) {
                                case 0:
                                    return n = e || t.videoId, i.next = 3, a["a"].getVideoPlayAuthForPC({resourceRelId: n});
                                case 3:
                                    return r = i.sent, i.next = 6, a["a"].APIgetTokenForHls();
                                case 6:
                                    o = i.sent, o = o.msg, r.bizResult.playInfoResponse || null === r.bizResult.playInfoResponse && null === r.bizResult.videoId ? (t.playWay = "source", r.bizResult.playInfoResponse ? ("", s = {}, c = r.bizResult.playInfoResponse.playInfoList, c.forEach((function (e, t) {
                                        0 === t ? s["LD"] = e.playURL + "?MtsHlsUriToken=" + o : 1 === t && (s["HD"] = e.playURL + "?MtsHlsUriToken=" + o)
                                    })), c.length > 0 ? (t.sourceUrl = JSON.stringify(s), t.player && t.player.loadByUrl(s.LD, t.seeked)) : (t.sourceUrl = c[0].playURL, t.player && t.player.loadByUrl(t.sourceUrl, t.seeked)), console.log(t.sourceUrl), t.player && (t.player.loadByUrl(t.sourceUrl, t.seeked), t.player.loadByUrl(s.LD, t.seeked)), t.videoAddressUrl = c[0].playURL) : (t.sourceUrl = r.bizResult.playUrl, t.player && t.player.loadByUrl(t.sourceUrl, t.seeked))) : (t.playWay = "videoId", t.videoId = r.bizResult.videoId, t.playAuth = r.bizResult.playAuth);
                                case 9:
                                case"end":
                                    return i.stop()
                            }
                        }), i)
                    })))()
                }, getPlayAuth: function () {
                    var e = this;
                    return Object(s["a"])(regeneratorRuntime.mark((function t() {
                        var i, n, r;
                        return regeneratorRuntime.wrap((function (t) {
                            while (1) switch (t.prev = t.next) {
                                case 0:
                                    return i = e.videoId, t.next = 3, a["a"].APIgetVideoPlayAuth({resourceRelId: i});
                                case 3:
                                    n = t.sent, r = n.bizResult, e.playAuth = r.playAuth;
                                case 6:
                                case"end":
                                    return t.stop()
                            }
                        }), t)
                    })))()
                }, replayByVidAndPlayAuth: function () {
                    var e = this;
                    this.getPlayAuth().then((function () {
                        e.player.replayByVidAndPlayAuth(e.videoId, e.playAuth)
                    }))
                }, aliPlayer: function (e) {
                    var t = this;
                    this.isPlay = !0, this.getVideoAddress(e).then((function () {
                        var e = t, i = {
                            id: "J_prismPlayer",
                            width: "100%",
                            height: "100%",
                            source: t.sourceUrl,
                            encryptType: 1,
                            autoplay: t.autoPlay,
                            isLive: !1,
                            rePlay: !1,
                            playsinline: !0,
                            preload: t.autoPlay,
                            waitingTimeout: 10,
                            language: "zh-cn",
                            controlBarVisibility: "always",
                            videoHeight: "calc(100% - 44px)",
                            useH5Prism: !0,
                            cover: t.autoPlay ? "@/assets/img/cover.png" : "",
                            components: t.components,
                            PlayConfig: {PlayDomain: "testvod-xinyi.21tb.com"},
                            skinLayout: [{name: "bigPlayButton", align: "blabs", x: 30, y: 80}, {
                                name: "H5Loading",
                                align: "cc"
                            }, {
                                name: "errorDisplay",
                                align: "tlabs",
                                x: 0,
                                y: 0
                            }, {name: "infoDisplay"}, {
                                name: "tooltip",
                                align: "blabs",
                                x: 0,
                                y: 56
                            }, {name: "thumbnail"}, {
                                name: "controlBar",
                                align: "blabs",
                                x: 0,
                                y: 0,
                                children: [{name: "progress", align: "blabs", x: 0, y: 44}, {
                                    name: "playButton",
                                    align: "tl",
                                    x: 15,
                                    y: 12
                                }, {name: "timeDisplay", align: "tl", x: 10, y: 7}, {
                                    name: "fullScreenButton",
                                    align: "tr",
                                    x: 10,
                                    y: 12
                                }, {name: "setting", align: "tr", x: 15, y: 12}, {
                                    name: "volume",
                                    align: "tr",
                                    x: 5,
                                    y: 10
                                }]
                            }]
                        }, n = {
                            id: "J_prismPlayer",
                            width: "100%",
                            height: "100%",
                            vid: t.videoId,
                            playauth: t.playAuth,
                            encryptType: 1,
                            autoplay: t.autoPlay,
                            isLive: !1,
                            rePlay: !1,
                            playsinline: !0,
                            preload: t.autoPlay,
                            waitingTimeout: 10,
                            language: "zh-cn",
                            controlBarVisibility: "always",
                            videoHeight: "calc(100% - 44px)",
                            useH5Prism: !0,
                            cover: t.autoPlay ? "@/assets/img/cover.png" : "",
                            components: t.components,
                            PlayConfig: {PlayDomain: "testvod-xinyi.21tb.com"},
                            skinLayout: [{name: "bigPlayButton", align: "blabs", x: 30, y: 80}, {
                                name: "H5Loading",
                                align: "cc"
                            }, {
                                name: "errorDisplay",
                                align: "tlabs",
                                x: 0,
                                y: 0
                            }, {name: "infoDisplay"}, {
                                name: "tooltip",
                                align: "blabs",
                                x: 0,
                                y: 56
                            }, {name: "thumbnail"}, {
                                name: "controlBar",
                                align: "blabs",
                                x: 0,
                                y: 0,
                                children: [{name: "progress", align: "blabs", x: 0, y: 44}, {
                                    name: "playButton",
                                    align: "tl",
                                    x: 15,
                                    y: 12
                                }, {name: "timeDisplay", align: "tl", x: 10, y: 7}, {
                                    name: "fullScreenButton",
                                    align: "tr",
                                    x: 10,
                                    y: 12
                                }, {name: "setting", align: "tr", x: 15, y: 12}, {
                                    name: "volume",
                                    align: "tr",
                                    x: 5,
                                    y: 10
                                }]
                            }]
                        }, r = t, o = "videoId" === t.playWay ? n : i;
                        if (i = p(p({}, o), t.setting), r.player) {
                            if (r.player.dispose(), console.log(document.querySelector(".waterMarker")), !document.querySelector(".waterMarker")) {
                                var s = document.getElementById("J_prismPlayer"), c = document.createElement("div");
                                s.appendChild(c), c.className = "waterMarker", c.setAttribute("ref", "waterMarker"), c.style.position = "absolute", c.style.left = "0", c.style.top = "0", c.style.width = "100%", c.style.height = "100%", c.style.opacity = "0.3", c.style.pointerEvents = "none", c.style.backgroundImage = "url(".concat(t.base64Url, ")");
                                var d = document.createElement("div");
                                d.style.position = "absolute", d.style.left = "0", d.style.top = "0", d.style.width = "100%", d.style.height = "100%", d.style.pointerEvents = "none", "audio" === r.type && s.appendChild(d);
                                var h = document.createElement("img");
                                h.setAttribute("src", u.a), h.style.position = "absolute", h.style.left = "50%", h.style.top = "50%", h.style.width = "300px", h.style.height = "300px", h.style.pointerEvents = "none", h.style.marginLeft = "-150px", h.style.marginTop = "-150px", "audio" === r.type && d.appendChild(h);
                                var f = document.createElement("div");
                                f.style.position = "absolute", f.style.bottom = "0", f.style.left = "150px", f.style.width = r.allowHighSpeed ? "calc(100% - 320px)" : "calc(100% - 280px)", f.style.height = "38px", f.style.zIndex = "20";
                                var m = document.createElement("span"), v = document.createElement("span");
                                v.setAttribute("id", "handoutOperate"), v.innerText = "查看讲义", m.style.lineHeight = "38px", m.style.color = "#fff", m.style.fontSize = "14px", m.style.float = "left", v.style.cursor = "pointer", v.style.lineHeight = "38px", v.style.color = "#fff", v.style.fontSize = "14px", v.style.float = "right", s.appendChild(f), r.allowMinStudyTime && "preview" !== t.$route.query.from && (t.recordTimeTemp = t.recordTime, t.recordTimeIdTemp && clearInterval(t.recordTimeIdTemp), t.recordTimeIdTemp = setInterval((function () {
                                    t.recordTimeTemp++, "setting" !== t.isTitle && (m.innerText = "(观看时长不少于".concat(Object(l["TimeToString"])(r.curTime.minStudyTime), "，您已学习").concat(Object(l["TimeToString"])(r.recordTime > r.curTime.minStudyTime ? r.curTime.minStudyTime : r.recordTime), ")"), r.recordTime > r.curTime.minStudyTime && (clearInterval(t.recordTimeIdTemp), t.$emit("updateAndClear", "", "clear")))
                                }), 1e3), f.appendChild(m)), r.noteId && (f.appendChild(v), v.onclick = function () {
                                    if (v.innerText === r.$t("v4.js.pc.ocmt.viewHandout")) if (document.pictureInPictureEnabled) r.openAndCloseVideo(1), v.innerText = r.$t("v4.js.pc.ocmt.closeHandout"); else {
                                        var e = "/courseSetting/preview/handout?id=".concat(r.noteId);
                                        window.open(e)
                                    } else r.openAndCloseVideo(0), v.innerText = r.$t("v4.js.pc.ocmt.viewHandout")
                                })
                            }
                        } else {
                            var y = document.getElementById("J_prismPlayer"), g = document.createElement("div");
                            g.style.position = "absolute", g.style.left = "0", g.style.top = "0", g.style.width = "100%", g.style.height = "100%", g.style.pointerEvents = "none", "audio" === r.type && y.appendChild(g);
                            var T = document.createElement("img");
                            T.setAttribute("src", u.a), T.style.position = "absolute", T.style.left = "50%", T.style.top = "50%", T.style.width = "300px", T.style.height = "300px", T.style.marginLeft = "-150px", T.style.pointerEvents = "none", T.style.marginTop = "-150px", "audio" === r.type && g.appendChild(T);
                            var w = document.createElement("div");
                            w.style.position = "absolute", w.style.bottom = "0", w.style.left = "150px", w.style.width = r.allowHighSpeed ? "calc(100% - 320px)" : "calc(100% - 280px)", w.style.height = "38px", w.style.zIndex = "20";
                            var b = document.createElement("span"), C = document.createElement("span");
                            C.setAttribute("id", "handoutOperate"), C.innerText = r.$t("v4.js.pc.ocmt.viewHandout"), b.style.lineHeight = "38px", b.style.color = "#fff", b.style.fontSize = "14px", b.style.float = "left", C.style.cursor = "pointer", C.style.lineHeight = "38px", C.style.color = "#fff", C.style.fontSize = "14px", C.style.float = "right", y.appendChild(w), r.allowMinStudyTime && "preview" !== t.$route.query.from && (t.recordTimeTemp = t.recordTime, t.recordTimeIdTemp && clearInterval(t.recordTimeIdTemp), t.recordTimeIdTemp = setInterval((function () {
                                t.recordTimeTemp++, "setting" !== t.isTitle && (b.innerText = "(观看时长不少于".concat(Object(l["TimeToString"])(r.curTime.minStudyTime), "，您已学习").concat(Object(l["TimeToString"])(r.recordTime > r.curTime.minStudyTime ? r.curTime.minStudyTime : r.recordTime), ")"), r.recordTime > r.curTime.minStudyTime && (clearInterval(t.recordTimeIdTemp), t.$emit("updateAndClear", "", "clear")))
                            }), 1e3), w.appendChild(b)), r.noteId && (w.appendChild(C), C.onclick = function () {
                                if (C.innerText === r.$t("v4.js.pc.ocmt.viewHandout")) if (document.pictureInPictureEnabled) r.openAndCloseVideo(1), C.innerText = r.$t("v4.js.pc.ocmt.closeHandout"); else {
                                    var e = "/courseSetting/preview/handout?id=".concat(r.noteId);
                                    window.open(e)
                                } else r.openAndCloseVideo(0), C.innerText = r.$t("v4.js.pc.ocmt.viewHandout")
                            })
                        }
                        t.player = new Aliplayer(i, (function (t) {
                            var i = this;
                            r.settingBtn || (document.querySelector(".prism-setting-btn").style.display = "none"), t.on("ready", (function () {
                                /** 原有的 */
                                // e.playerBuild = 1, t.seek(e.seek)
                                /** NicolasLemon修改1 */
                                // 调试信息，查看当前对象里面有哪些内容
                                console.log('========= Debug =========='),
                                console.log(e),
                                console.log('========= Debug =========='),
                                e.playerBuild = 1,
                                    // 将对象e的seek时间设置为当前课程需要学习的最少时间
                                    e.seek = e.curTime.minStudyTime + 10,
                                    // 更新当前学习时间
                                    e.curTime.currentStudyTime = e.seek,
                                    // 设置对象t的seek时间
                                    t.seek(e.seek)

                            })), t.on("canplay", (function () {
                                t.play()
                            })), t.on("play", (function () {
                                clearInterval(i.updateToken), i.updateToken = setInterval((function () {
                                    var t = a["a"].APIgetTokenForHls();
                                    t = t.msg, e.sourceUrl = e.videoAddressUrl + "?MtsHlsUriToken=" + t
                                }), 6e4)
                            })), t.on("error", (function () {
                                console.log("出错了，播放器重新播放了"), console.log(document.querySelector(".prism-button-refresh")), document.querySelector(".prism-button-refresh").click()
                            })), setTimeout((function () {
                                e.registerEvent()
                            }), 0), r.$emit("isReady", !0), r.heartBeatFlag && document.getElementsByTagName("video")[0] && r.addVideoClick()
                        }))
                    }))
                }, registerEvent: function () {
                    var e = this;
                    this.eventList.map((function (t) {
                        e.player.on(t, (function (i) {
                            e.$emit(t, i)
                        }))
                    }))
                }, rePlay: function () {
                    var e = this;
                    "" !== this.videoId && (this.isPlay = !1, this.$nextTick((function () {
                        e.isPlay = !0, e.aliPlayer()
                    })))
                }, addVideoClick: function () {
                    if ("preview" !== this.$route.query.from) {
                        var e = this;
                        setTimeout((function () {
                            document.getElementsByTagName("video")[0].addEventListener("play", (function () {
                                clearInterval(e.heartbeatTimer), e.heartbeatTimer = setInterval((function () {
                                    console.log(e.heartbeatTime), e.heartbeatTime % 60 === 0 && document.getElementsByTagName("video")[0] && a["c"].heartBeatSetData(e.courseId), e.heartbeatTime++
                                }), 1e3)
                            })), document.getElementsByTagName("video")[0].addEventListener("pause", (function () {
                                console.log("clear"), clearInterval(e.heartbeatTimer)
                            })), document.getElementsByTagName("video")[0].pause(), document.getElementsByTagName("video")[0].play()
                        }), 1500)
                    }
                }, resetPlayer: function () {
                    this.isPlay = !1
                }, initWater: function () {
                    var e = this;
                    a["a"].APIconfirmWatermark().then((function (t) {
                        var i = t.bizResult, n = "true" === i.enableWatermark,
                            r = i.waterMarkShowObject ? i.waterMarkShowObject.split(",") : [], o = [];
                        r.forEach((function (e) {
                            "EMPLOYEE_CODE" === e ? o.push(i.employeeCode) : "USER_NAME" === e ? o.push(i.userName) : "LOGIN_NAME" === e && o.push(i.loginName)
                        })), o = o.join(" "), console.log(o), n && e.setWater(i, o)
                    }))
                }, setWater: function (e, t) {
                    var i, n, r = t.length, o = "middle", s = 1.1 - e.waterMarkDensity / 100,
                        a = e.waterMarkTransparency / 100,
                        c = 40 * r * s + 200 > document.documentElement.offsetWidth ? document.documentElement.offsetWidth - 150 : 40 * r * s + 200,
                        u = .8 * c;
                    i = (c - 100) / 1.7, n = (c - 100) / 1.5, 40 * r * s + 150 > document.documentElement.offsetWidth && (o = "end");
                    var l = '<svg xmlns="http://www.w3.org/2000/svg"  width="'.concat(c, 'px" height="').concat(u, "px\">\n                            <text \n                              x='").concat(i, "px'\n                              y='").concat(n, "px'\n                              text-anchor=\"").concat(o, '"\n                              stroke="#999"\n                              dominant-baseline="middle"\n                              stroke-opacity="0.25"\n                              fill="#999"\n                              transform="rotate(-45, 120 120)"\n                              style="font-size: 18px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;opacity:').concat(a, '">\n                              ').concat(t, "\n                            </text>\n                          </svg>"),
                        d = "data:image/svg+xml;base64,".concat(window.btoa(unescape(encodeURIComponent(l))));
                    this.base64Url = d, this.$refs.waterMarker.style.backgroundImage = "url(".concat(d, ")")
                }
            }, beforeDestroy: function () {
                clearInterval(this.heartbeatTimer)
            }, mounted: function () {
                this.initWater(), this.aliPlayer()
            }
        }, m = f, v = (i("a7bb"), i("2877")), y = Object(v["a"])(m, n, r, !1, null, "030f9871", null);
        t["a"] = y.exports
    }, "73aa": function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("d8d69");

        function o(e, t, i) {
            r.call(this, e, t, i, {noCredentials: !0})
        }

        n(o, r), o.enabled = r.enabled, e.exports = o
    }, 7514: function (e, t, i) {
        "use strict";
        var n = i("5ca1"), r = i("0a49")(5), o = "find", s = !0;
        o in [] && Array(1)[o]((function () {
            s = !1
        })), n(n.P + n.F * s, "Array", {
            find: function (e) {
                return r(this, e, arguments.length > 1 ? arguments[1] : void 0)
            }
        }), i("9c6c")(o)
    }, 7577: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("621f"), o = i("f7a9"), s = function () {
        };

        function a(e) {
            return function (t, i, n) {
                s("create ajax sender", t, i);
                var o = {};
                "string" === typeof i && (o.headers = {"Content-type": "text/plain"});
                var a = r.addPath(t, "/xhr_send"), c = new e("POST", a, i, o);
                return c.once("finish", (function (e) {
                    if (s("finish", e), c = null, 200 !== e && 204 !== e) return n(new Error("http status " + e));
                    n()
                })), function () {
                    s("abort"), c.close(), c = null;
                    var e = new Error("Aborted");
                    e.code = 1e3, n(e)
                }
            }
        }

        function c(e, t, i, n) {
            o.call(this, e, t, a(n), i, n)
        }

        n(c, o), e.exports = c
    }, 7725: function (e, t, i) {
        "use strict";
        var n, r = Array.prototype, o = Object.prototype, s = Function.prototype, a = String.prototype, c = r.slice,
            u = o.toString, l = function (e) {
                return "[object Function]" === o.toString.call(e)
            }, d = function (e) {
                return "[object Array]" === u.call(e)
            }, h = function (e) {
                return "[object String]" === u.call(e)
            }, p = Object.defineProperty && function () {
                try {
                    return Object.defineProperty({}, "x", {}), !0
                } catch (e) {
                    return !1
                }
            }();
        n = p ? function (e, t, i, n) {
            !n && t in e || Object.defineProperty(e, t, {configurable: !0, enumerable: !1, writable: !0, value: i})
        } : function (e, t, i, n) {
            !n && t in e || (e[t] = i)
        };
        var f = function (e, t, i) {
            for (var r in t) o.hasOwnProperty.call(t, r) && n(e, r, t[r], i)
        }, m = function (e) {
            if (null == e) throw new TypeError("can't convert " + e + " to object");
            return Object(e)
        };

        function v(e) {
            var t = +e;
            return t !== t ? t = 0 : 0 !== t && t !== 1 / 0 && t !== -1 / 0 && (t = (t > 0 || -1) * Math.floor(Math.abs(t))), t
        }

        function y(e) {
            return e >>> 0
        }

        function g() {
        }

        f(s, {
            bind: function (e) {
                var t = this;
                if (!l(t)) throw new TypeError("Function.prototype.bind called on incompatible " + t);
                for (var i = c.call(arguments, 1), n = function () {
                    if (this instanceof a) {
                        var n = t.apply(this, i.concat(c.call(arguments)));
                        return Object(n) === n ? n : this
                    }
                    return t.apply(e, i.concat(c.call(arguments)))
                }, r = Math.max(0, t.length - i.length), o = [], s = 0; s < r; s++) o.push("$" + s);
                var a = Function("binder", "return function (" + o.join(",") + "){ return binder.apply(this, arguments); }")(n);
                return t.prototype && (g.prototype = t.prototype, a.prototype = new g, g.prototype = null), a
            }
        }), f(Array, {isArray: d});
        var T = Object("a"), w = "a" !== T[0] || !(0 in T), b = function (e) {
            var t = !0, i = !0;
            return e && (e.call("foo", (function (e, i, n) {
                "object" !== typeof n && (t = !1)
            })), e.call([1], (function () {
                i = "string" === typeof this
            }), "x")), !!e && t && i
        };
        f(r, {
            forEach: function (e) {
                var t = m(this), i = w && h(this) ? this.split("") : t, n = arguments[1], r = -1, o = i.length >>> 0;
                if (!l(e)) throw new TypeError;
                while (++r < o) r in i && e.call(n, i[r], r, t)
            }
        }, !b(r.forEach));
        var C = Array.prototype.indexOf && -1 !== [0, 1].indexOf(1, 2);
        f(r, {
            indexOf: function (e) {
                var t = w && h(this) ? this.split("") : m(this), i = t.length >>> 0;
                if (!i) return -1;
                var n = 0;
                for (arguments.length > 1 && (n = v(arguments[1])), n = n >= 0 ? n : Math.max(0, i + n); n < i; n++) if (n in t && t[n] === e) return n;
                return -1
            }
        }, C);
        var I = a.split;
        2 !== "ab".split(/(?:ab)*/).length || 4 !== ".".split(/(.?)(.?)/).length || "t" === "tesst".split(/(s)*/)[1] || 4 !== "test".split(/(?:)/, -1).length || "".split(/.?/).length || ".".split(/()()/).length > 1 ? function () {
            var e = void 0 === /()??/.exec("")[1];
            a.split = function (t, i) {
                var n = this;
                if (void 0 === t && 0 === i) return [];
                if ("[object RegExp]" !== u.call(t)) return I.call(this, t, i);
                var o, s, a, c, l = [],
                    d = (t.ignoreCase ? "i" : "") + (t.multiline ? "m" : "") + (t.extended ? "x" : "") + (t.sticky ? "y" : ""),
                    h = 0;
                t = new RegExp(t.source, d + "g"), n += "", e || (o = new RegExp("^" + t.source + "$(?!\\s)", d)), i = void 0 === i ? -1 >>> 0 : y(i);
                while (s = t.exec(n)) {
                    if (a = s.index + s[0].length, a > h && (l.push(n.slice(h, s.index)), !e && s.length > 1 && s[0].replace(o, (function () {
                        for (var e = 1; e < arguments.length - 2; e++) void 0 === arguments[e] && (s[e] = void 0)
                    })), s.length > 1 && s.index < n.length && r.push.apply(l, s.slice(1)), c = s[0].length, h = a, l.length >= i)) break;
                    t.lastIndex === s.index && t.lastIndex++
                }
                return h === n.length ? !c && t.test("") || l.push("") : l.push(n.slice(h)), l.length > i ? l.slice(0, i) : l
            }
        }() : "0".split(void 0, 0).length && (a.split = function (e, t) {
            return void 0 === e && 0 === t ? [] : I.call(this, e, t)
        });
        var x = a.substr, _ = "".substr && "b" !== "0b".substr(-1);
        f(a, {
            substr: function (e, t) {
                return x.call(this, e < 0 && (e = this.length + e) < 0 ? 0 : e, t)
            }
        }, _)
    }, "7b4d": function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("7577"), o = i("f91e"), s = i("df09"), a = i("ca34");

        function c(e) {
            if (!c.enabled()) throw new Error("Transport created when disabled");
            r.call(this, e, "/eventsource", o, s)
        }

        n(c, r), c.enabled = function () {
            return !!a
        }, c.transportName = "eventsource", c.roundTrips = 2, e.exports = c
    }, "7c20": function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("ada0").EventEmitter, r = i("3fb5"), o = i("930c"), s = i("c282"), a = i("9f3a"), c = i("c529"),
                u = function () {
                };

            function l(e, i) {
                var r = this;
                n.call(this);
                var l = function () {
                    var t = r.ifr = new a(c.transportName, i, e);
                    t.once("message", (function (e) {
                        if (e) {
                            var t;
                            try {
                                t = o.parse(e)
                            } catch (s) {
                                return u("bad json", e), r.emit("finish"), void r.close()
                            }
                            var i = t[0], n = t[1];
                            r.emit("finish", i, n)
                        }
                        r.close()
                    })), t.once("close", (function () {
                        r.emit("finish"), r.close()
                    }))
                };
                t.document.body ? l() : s.attachEvent("load", l)
            }

            r(l, n), l.enabled = function () {
                return a.enabled()
            }, l.prototype.close = function () {
                this.ifr && this.ifr.close(), this.removeAllListeners(), this.ifr = null
            }, e.exports = l
        }).call(this, i("c8ba"))
    }, "7eab": function (e, t, i) {
        "use strict";
        var n = i("5bfa"), r = i.n(n);
        r.a
    }, "84fc": function (e, t, i) {
        "use strict";
        var n, r = i("930c"),
            o = /[\x00-\x1f\ud800-\udfff\ufffe\uffff\u0300-\u0333\u033d-\u0346\u034a-\u034c\u0350-\u0352\u0357-\u0358\u035c-\u0362\u0374\u037e\u0387\u0591-\u05af\u05c4\u0610-\u0617\u0653-\u0654\u0657-\u065b\u065d-\u065e\u06df-\u06e2\u06eb-\u06ec\u0730\u0732-\u0733\u0735-\u0736\u073a\u073d\u073f-\u0741\u0743\u0745\u0747\u07eb-\u07f1\u0951\u0958-\u095f\u09dc-\u09dd\u09df\u0a33\u0a36\u0a59-\u0a5b\u0a5e\u0b5c-\u0b5d\u0e38-\u0e39\u0f43\u0f4d\u0f52\u0f57\u0f5c\u0f69\u0f72-\u0f76\u0f78\u0f80-\u0f83\u0f93\u0f9d\u0fa2\u0fa7\u0fac\u0fb9\u1939-\u193a\u1a17\u1b6b\u1cda-\u1cdb\u1dc0-\u1dcf\u1dfc\u1dfe\u1f71\u1f73\u1f75\u1f77\u1f79\u1f7b\u1f7d\u1fbb\u1fbe\u1fc9\u1fcb\u1fd3\u1fdb\u1fe3\u1feb\u1fee-\u1fef\u1ff9\u1ffb\u1ffd\u2000-\u2001\u20d0-\u20d1\u20d4-\u20d7\u20e7-\u20e9\u2126\u212a-\u212b\u2329-\u232a\u2adc\u302b-\u302c\uaab2-\uaab3\uf900-\ufa0d\ufa10\ufa12\ufa15-\ufa1e\ufa20\ufa22\ufa25-\ufa26\ufa2a-\ufa2d\ufa30-\ufa6d\ufa70-\ufad9\ufb1d\ufb1f\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40-\ufb41\ufb43-\ufb44\ufb46-\ufb4e\ufff0-\uffff]/g,
            s = function (e) {
                var t, i = {}, n = [];
                for (t = 0; t < 65536; t++) n.push(String.fromCharCode(t));
                return e.lastIndex = 0, n.join("").replace(e, (function (e) {
                    return i[e] = "\\u" + ("0000" + e.charCodeAt(0).toString(16)).slice(-4), ""
                })), e.lastIndex = 0, i
            };
        e.exports = {
            quote: function (e) {
                var t = r.stringify(e);
                return o.lastIndex = 0, o.test(t) ? (n || (n = s(o)), t.replace(o, (function (e) {
                    return n[e]
                }))) : t
            }
        }
    }, "89bc": function (e, t, i) {
        "use strict";
        var n = i("ada0").EventEmitter, r = i("3fb5"), o = i("930c"), s = i("d5e5"), a = function () {
        };

        function c(e, t) {
            n.call(this);
            var i = this, r = +new Date;
            this.xo = new t("GET", e), this.xo.once("finish", (function (e, t) {
                var n, c;
                if (200 === e) {
                    if (c = +new Date - r, t) try {
                        n = o.parse(t)
                    } catch (u) {
                        a("bad json", t)
                    }
                    s.isObject(n) || (n = {})
                }
                i.emit("finish", n, c), i.removeAllListeners()
            }))
        }

        r(c, n), c.prototype.close = function () {
            this.removeAllListeners(), this.xo.close()
        }, e.exports = c
    }, "8ff7": function (e, t, i) {
    }, "930c": function (e, t, i) {
        (function (e, n) {
            var r;/*! JSON v3.3.2 | https://bestiejs.github.io/json3 | Copyright 2012-2015, Kit Cambridge, Benjamin Tan | http://kit.mit-license.org */
            (function () {
                var o = i("3c35"), s = {function: !0, object: !0}, a = s[typeof t] && t && !t.nodeType && t,
                    c = s[typeof window] && window || this,
                    u = a && s[typeof e] && e && !e.nodeType && "object" == typeof n && n;

                function l(e, t) {
                    e || (e = c.Object()), t || (t = c.Object());
                    var i = e.Number || c.Number, n = e.String || c.String, r = e.Object || c.Object,
                        o = e.Date || c.Date, a = e.SyntaxError || c.SyntaxError, u = e.TypeError || c.TypeError,
                        d = e.Math || c.Math, h = e.JSON || c.JSON;
                    "object" == typeof h && h && (t.stringify = h.stringify, t.parse = h.parse);
                    var p, f = r.prototype, m = f.toString, v = f.hasOwnProperty;

                    function y(e, t) {
                        try {
                            e()
                        } catch (i) {
                            t && t()
                        }
                    }

                    var g = new o(-0xc782b5b800cec);

                    function T(e) {
                        if (null != T[e]) return T[e];
                        var r;
                        if ("bug-string-char-index" == e) r = "a" != "a"[0]; else if ("json" == e) r = T("json-stringify") && T("date-serialization") && T("json-parse"); else if ("date-serialization" == e) {
                            if (r = T("json-stringify") && g, r) {
                                var s = t.stringify;
                                y((function () {
                                    r = '"-271821-04-20T00:00:00.000Z"' == s(new o(-864e13)) && '"+275760-09-13T00:00:00.000Z"' == s(new o(864e13)) && '"-000001-01-01T00:00:00.000Z"' == s(new o(-621987552e5)) && '"1969-12-31T23:59:59.999Z"' == s(new o(-1))
                                }))
                            }
                        } else {
                            var a, c = '{"a":[1,true,false,null,"\\u0000\\b\\n\\f\\r\\t"]}';
                            if ("json-stringify" == e) {
                                s = t.stringify;
                                var u = "function" == typeof s;
                                u && ((a = function () {
                                    return 1
                                }).toJSON = a, y((function () {
                                    u = "0" === s(0) && "0" === s(new i) && '""' == s(new n) && s(m) === p && s(p) === p && s() === p && "1" === s(a) && "[1]" == s([a]) && "[null]" == s([p]) && "null" == s(null) && "[null,null,null]" == s([p, m, null]) && s({a: [a, !0, !1, null, "\0\b\n\f\r\t"]}) == c && "1" === s(null, a) && "[\n 1,\n 2\n]" == s([1, 2], null, 1)
                                }), (function () {
                                    u = !1
                                }))), r = u
                            }
                            if ("json-parse" == e) {
                                var l, d = t.parse;
                                "function" == typeof d && y((function () {
                                    0 !== d("0") || d(!1) || (a = d(c), l = 5 == a["a"].length && 1 === a["a"][0], l && (y((function () {
                                        l = !d('"\t"')
                                    })), l && y((function () {
                                        l = 1 !== d("01")
                                    })), l && y((function () {
                                        l = 1 !== d("1.")
                                    }))))
                                }), (function () {
                                    l = !1
                                })), r = l
                            }
                        }
                        return T[e] = !!r
                    }

                    if (y((function () {
                        g = -109252 == g.getUTCFullYear() && 0 === g.getUTCMonth() && 1 === g.getUTCDate() && 10 == g.getUTCHours() && 37 == g.getUTCMinutes() && 6 == g.getUTCSeconds() && 708 == g.getUTCMilliseconds()
                    })), T["bug-string-char-index"] = T["date-serialization"] = T["json"] = T["json-stringify"] = T["json-parse"] = null, !T("json")) {
                        var w = "[object Function]", b = "[object Date]", C = "[object Number]", I = "[object String]",
                            x = "[object Array]", _ = "[object Boolean]", S = T("bug-string-char-index"),
                            E = function (e, t) {
                                var i, n, r, o = 0;
                                for (r in (i = function () {
                                    this.valueOf = 0
                                }).prototype.valueOf = 0, n = new i, n) v.call(n, r) && o++;
                                return i = n = null, o ? E = function (e, t) {
                                    var i, n, r = m.call(e) == w;
                                    for (i in e) r && "prototype" == i || !v.call(e, i) || (n = "constructor" === i) || t(i);
                                    (n || v.call(e, i = "constructor")) && t(i)
                                } : (n = ["valueOf", "toString", "toLocaleString", "propertyIsEnumerable", "isPrototypeOf", "hasOwnProperty", "constructor"], E = function (e, t) {
                                    var i, r, o = m.call(e) == w,
                                        a = !o && "function" != typeof e.constructor && s[typeof e.hasOwnProperty] && e.hasOwnProperty || v;
                                    for (i in e) o && "prototype" == i || !a.call(e, i) || t(i);
                                    for (r = n.length; i = n[--r];) a.call(e, i) && t(i)
                                }), E(e, t)
                            };
                        if (!T("json-stringify") && !T("date-serialization")) {
                            var A = {92: "\\\\", 34: '\\"', 8: "\\b", 12: "\\f", 10: "\\n", 13: "\\r", 9: "\\t"},
                                P = "000000", D = function (e, t) {
                                    return (P + (t || 0)).slice(-e)
                                }, k = function (e) {
                                    var t, i, n, r, o, s, a, c, u;
                                    if (g) t = function (e) {
                                        i = e.getUTCFullYear(), n = e.getUTCMonth(), r = e.getUTCDate(), s = e.getUTCHours(), a = e.getUTCMinutes(), c = e.getUTCSeconds(), u = e.getUTCMilliseconds()
                                    }; else {
                                        var l = d.floor, h = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334],
                                            p = function (e, t) {
                                                return h[t] + 365 * (e - 1970) + l((e - 1969 + (t = +(t > 1))) / 4) - l((e - 1901 + t) / 100) + l((e - 1601 + t) / 400)
                                            };
                                        t = function (e) {
                                            for (r = l(e / 864e5), i = l(r / 365.2425) + 1970 - 1; p(i + 1, 0) <= r; i++) ;
                                            for (n = l((r - p(i, 0)) / 30.42); p(i, n + 1) <= r; n++) ;
                                            r = 1 + r - p(i, n), o = (e % 864e5 + 864e5) % 864e5, s = l(o / 36e5) % 24, a = l(o / 6e4) % 60, c = l(o / 1e3) % 60, u = o % 1e3
                                        }
                                    }
                                    return k = function (e) {
                                        return e > -1 / 0 && e < 1 / 0 ? (t(e), e = (i <= 0 || i >= 1e4 ? (i < 0 ? "-" : "+") + D(6, i < 0 ? -i : i) : D(4, i)) + "-" + D(2, n + 1) + "-" + D(2, r) + "T" + D(2, s) + ":" + D(2, a) + ":" + D(2, c) + "." + D(3, u) + "Z", i = n = r = s = a = c = u = null) : e = null, e
                                    }, k(e)
                                };
                            if (T("json-stringify") && !T("date-serialization")) {
                                function O(e) {
                                    return k(this)
                                }

                                var R = t.stringify;
                                t.stringify = function (e, t, i) {
                                    var n = o.prototype.toJSON;
                                    o.prototype.toJSON = O;
                                    var r = R(e, t, i);
                                    return o.prototype.toJSON = n, r
                                }
                            } else {
                                var N = "\\u00", L = function (e) {
                                    var t = e.charCodeAt(0), i = A[t];
                                    return i || N + D(2, t.toString(16))
                                }, B = /[\x00-\x1f\x22\x5c]/g, F = function (e) {
                                    return B.lastIndex = 0, '"' + (B.test(e) ? e.replace(B, L) : e) + '"'
                                }, j = function (e, t, i, n, r, s, a) {
                                    var c, l, d, h, f, v, g, T, w;
                                    if (y((function () {
                                        c = t[e]
                                    })), "object" == typeof c && c && (c.getUTCFullYear && m.call(c) == b && c.toJSON === o.prototype.toJSON ? c = k(c) : "function" == typeof c.toJSON && (c = c.toJSON(e))), i && (c = i.call(t, e, c)), c == p) return c === p ? c : "null";
                                    switch (l = typeof c, "object" == l && (d = m.call(c)), d || l) {
                                        case"boolean":
                                        case _:
                                            return "" + c;
                                        case"number":
                                        case C:
                                            return c > -1 / 0 && c < 1 / 0 ? "" + c : "null";
                                        case"string":
                                        case I:
                                            return F("" + c)
                                    }
                                    if ("object" == typeof c) {
                                        for (g = a.length; g--;) if (a[g] === c) throw u();
                                        if (a.push(c), h = [], T = s, s += r, d == x) {
                                            for (v = 0, g = c.length; v < g; v++) f = j(v, c, i, n, r, s, a), h.push(f === p ? "null" : f);
                                            w = h.length ? r ? "[\n" + s + h.join(",\n" + s) + "\n" + T + "]" : "[" + h.join(",") + "]" : "[]"
                                        } else E(n || c, (function (e) {
                                            var t = j(e, c, i, n, r, s, a);
                                            t !== p && h.push(F(e) + ":" + (r ? " " : "") + t)
                                        })), w = h.length ? r ? "{\n" + s + h.join(",\n" + s) + "\n" + T + "}" : "{" + h.join(",") + "}" : "{}";
                                        return a.pop(), w
                                    }
                                };
                                t.stringify = function (e, t, i) {
                                    var n, r, o, a;
                                    if (s[typeof t] && t) if (a = m.call(t), a == w) r = t; else if (a == x) {
                                        o = {};
                                        for (var c, u = 0, l = t.length; u < l;) c = t[u++], a = m.call(c), "[object String]" != a && "[object Number]" != a || (o[c] = 1)
                                    }
                                    if (i) if (a = m.call(i), a == C) {
                                        if ((i -= i % 1) > 0) for (i > 10 && (i = 10), n = ""; n.length < i;) n += " "
                                    } else a == I && (n = i.length <= 10 ? i : i.slice(0, 10));
                                    return j("", (c = {}, c[""] = e, c), r, o, n, "", [])
                                }
                            }
                        }
                        if (!T("json-parse")) {
                            var M, U, H = n.fromCharCode,
                                $ = {92: "\\", 34: '"', 47: "/", 98: "\b", 116: "\t", 110: "\n", 102: "\f", 114: "\r"},
                                V = function () {
                                    throw M = U = null, a()
                                }, q = function () {
                                    var e, t, i, n, r, o = U, s = o.length;
                                    while (M < s) switch (r = o.charCodeAt(M), r) {
                                        case 9:
                                        case 10:
                                        case 13:
                                        case 32:
                                            M++;
                                            break;
                                        case 123:
                                        case 125:
                                        case 91:
                                        case 93:
                                        case 58:
                                        case 44:
                                            return e = S ? o.charAt(M) : o[M], M++, e;
                                        case 34:
                                            for (e = "@", M++; M < s;) if (r = o.charCodeAt(M), r < 32) V(); else if (92 == r) switch (r = o.charCodeAt(++M), r) {
                                                case 92:
                                                case 34:
                                                case 47:
                                                case 98:
                                                case 116:
                                                case 110:
                                                case 102:
                                                case 114:
                                                    e += $[r], M++;
                                                    break;
                                                case 117:
                                                    for (t = ++M, i = M + 4; M < i; M++) r = o.charCodeAt(M), r >= 48 && r <= 57 || r >= 97 && r <= 102 || r >= 65 && r <= 70 || V();
                                                    e += H("0x" + o.slice(t, M));
                                                    break;
                                                default:
                                                    V()
                                            } else {
                                                if (34 == r) break;
                                                r = o.charCodeAt(M), t = M;
                                                while (r >= 32 && 92 != r && 34 != r) r = o.charCodeAt(++M);
                                                e += o.slice(t, M)
                                            }
                                            if (34 == o.charCodeAt(M)) return M++, e;
                                            V();
                                        default:
                                            if (t = M, 45 == r && (n = !0, r = o.charCodeAt(++M)), r >= 48 && r <= 57) {
                                                for (48 == r && (r = o.charCodeAt(M + 1), r >= 48 && r <= 57) && V(), n = !1; M < s && (r = o.charCodeAt(M), r >= 48 && r <= 57); M++) ;
                                                if (46 == o.charCodeAt(M)) {
                                                    for (i = ++M; i < s; i++) if (r = o.charCodeAt(i), r < 48 || r > 57) break;
                                                    i == M && V(), M = i
                                                }
                                                if (r = o.charCodeAt(M), 101 == r || 69 == r) {
                                                    for (r = o.charCodeAt(++M), 43 != r && 45 != r || M++, i = M; i < s; i++) if (r = o.charCodeAt(i), r < 48 || r > 57) break;
                                                    i == M && V(), M = i
                                                }
                                                return +o.slice(t, M)
                                            }
                                            n && V();
                                            var a = o.slice(M, M + 4);
                                            if ("true" == a) return M += 4, !0;
                                            if ("fals" == a && 101 == o.charCodeAt(M + 4)) return M += 5, !1;
                                            if ("null" == a) return M += 4, null;
                                            V()
                                    }
                                    return "$"
                                }, Q = function (e) {
                                    var t, i;
                                    if ("$" == e && V(), "string" == typeof e) {
                                        if ("@" == (S ? e.charAt(0) : e[0])) return e.slice(1);
                                        if ("[" == e) {
                                            for (t = []; ;) {
                                                if (e = q(), "]" == e) break;
                                                i ? "," == e ? (e = q(), "]" == e && V()) : V() : i = !0, "," == e && V(), t.push(Q(e))
                                            }
                                            return t
                                        }
                                        if ("{" == e) {
                                            for (t = {}; ;) {
                                                if (e = q(), "}" == e) break;
                                                i ? "," == e ? (e = q(), "}" == e && V()) : V() : i = !0, "," != e && "string" == typeof e && "@" == (S ? e.charAt(0) : e[0]) && ":" == q() || V(), t[e.slice(1)] = Q(q())
                                            }
                                            return t
                                        }
                                        V()
                                    }
                                    return e
                                }, z = function (e, t, i) {
                                    var n = W(e, t, i);
                                    n === p ? delete e[t] : e[t] = n
                                }, W = function (e, t, i) {
                                    var n, r = e[t];
                                    if ("object" == typeof r && r) if (m.call(r) == x) for (n = r.length; n--;) z(m, E, r, n, i); else E(r, (function (e) {
                                        z(r, e, i)
                                    }));
                                    return i.call(e, t, r)
                                };
                            t.parse = function (e, t) {
                                var i, n;
                                return M = 0, U = "" + e, i = Q(q()), "$" != q() && V(), M = U = null, t && m.call(t) == w ? W((n = {}, n[""] = i, n), "", t) : i
                            }
                        }
                    }
                    return t.runInContext = l, t
                }

                if (!u || u.global !== u && u.window !== u && u.self !== u || (c = u), a && !o) l(c, a); else {
                    var d = c.JSON, h = c.JSON3, p = !1, f = l(c, c.JSON3 = {
                        noConflict: function () {
                            return p || (p = !0, c.JSON = d, c.JSON3 = h, d = h = null), f
                        }
                    });
                    c.JSON = {parse: f.parse, stringify: f.stringify}
                }
                o && (r = function () {
                    return f
                }.call(t, i, t, e), void 0 === r || (e.exports = r))
            }).call(this)
        }).call(this, i("62e4")(e), i("c8ba"))
    }, "948c": function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAANxJREFUOBHdky0OwkAQhTsbDArFCXoEDEGQIEkQBIVA4MpFOEQvQRAkBIUjNT1CT4BCIZfvkQkJblsck7zuT9836XZnLCNijCOGFRpqic5mdmT8BJ4Ni6lv3BkPeOrgcMnG2F+mDPKWYo3H3uEFGZ8pNEwf3wlVgYc+u0mF8WbubcQqwU/Rg751zHDpyP0dpjqY6VRczbXN6eDm8usW1g62SgCzFKcEpkmHeHMqJDVG7uWZlMe9uVj9A3WimumBVJ7qRnXaV6Hg27I/QQrBA1QEjDWTHapQashbiH0BjwFD/NVolbwAAAAASUVORK5CYII="
    }, "97a2": function (e, t, i) {
        "use strict";

        function n() {
            this._listeners = {}
        }

        n.prototype.addEventListener = function (e, t) {
            e in this._listeners || (this._listeners[e] = []);
            var i = this._listeners[e];
            -1 === i.indexOf(t) && (i = i.concat([t])), this._listeners[e] = i
        }, n.prototype.removeEventListener = function (e, t) {
            var i = this._listeners[e];
            if (i) {
                var n = i.indexOf(t);
                -1 === n || (i.length > 1 ? this._listeners[e] = i.slice(0, n).concat(i.slice(n + 1)) : delete this._listeners[e])
            }
        }, n.prototype.dispatchEvent = function () {
            var e = arguments[0], t = e.type, i = 1 === arguments.length ? [e] : Array.apply(null, arguments);
            if (this["on" + t] && this["on" + t].apply(this, i), t in this._listeners) for (var n = this._listeners[t], r = 0; r < n.length; r++) n[r].apply(this, i)
        }, e.exports = n
    }, "9a833": function (e, t, i) {
        "use strict";

        function n(e) {
            this.type = e
        }

        n.prototype.initEvent = function (e, t, i) {
            return this.type = e, this.bubbles = t, this.cancelable = i, this.timeStamp = +new Date, this
        }, n.prototype.stopPropagation = function () {
        }, n.prototype.preventDefault = function () {
        }, n.CAPTURING_PHASE = 1, n.AT_TARGET = 2, n.BUBBLING_PHASE = 3, e.exports = n
    }, "9b21": function (e, t, i) {
        "use strict";
        var n = i("287b"), r = i.n(n);
        r.a
    }, "9c59": function (e, t, i) {
        "use strict";
        var n, r = Object.prototype.hasOwnProperty;

        function o(e) {
            try {
                return decodeURIComponent(e.replace(/\+/g, " "))
            } catch (t) {
                return null
            }
        }

        function s(e) {
            var t, i = /([^=?&]+)=?([^&]*)/g, n = {};
            while (t = i.exec(e)) {
                var r = o(t[1]), s = o(t[2]);
                null === r || null === s || r in n || (n[r] = s)
            }
            return n
        }

        function a(e, t) {
            t = t || "";
            var i, o, s = [];
            for (o in "string" !== typeof t && (t = "?"), e) if (r.call(e, o)) {
                if (i = e[o], i || null !== i && i !== n && !isNaN(i) || (i = ""), o = encodeURIComponent(o), i = encodeURIComponent(i), null === o || null === i) continue;
                s.push(o + "=" + i)
            }
            return s.length ? t + s.join("&") : ""
        }

        t.stringify = a, t.parse = s
    }, "9d7d": function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("ada0").EventEmitter, r = i("3fb5"), o = i("c282"), s = i("26a0"), a = i("621f"),
                c = function () {
                };

            function u(e, t, i) {
                c(e, t);
                var r = this;
                n.call(this), setTimeout((function () {
                    r._start(e, t, i)
                }), 0)
            }

            r(u, n), u.prototype._start = function (e, i, n) {
                c("_start");
                var r = this, s = new t.XDomainRequest;
                i = a.addQuery(i, "t=" + +new Date), s.onerror = function () {
                    c("onerror"), r._error()
                }, s.ontimeout = function () {
                    c("ontimeout"), r._error()
                }, s.onprogress = function () {
                    c("progress", s.responseText), r.emit("chunk", 200, s.responseText)
                }, s.onload = function () {
                    c("load"), r.emit("finish", 200, s.responseText), r._cleanup(!1)
                }, this.xdr = s, this.unloadRef = o.unloadAdd((function () {
                    r._cleanup(!0)
                }));
                try {
                    this.xdr.open(e, i), this.timeout && (this.xdr.timeout = this.timeout), this.xdr.send(n)
                } catch (u) {
                    this._error()
                }
            }, u.prototype._error = function () {
                this.emit("finish", 0, ""), this._cleanup(!1)
            }, u.prototype._cleanup = function (e) {
                if (c("cleanup", e), this.xdr) {
                    if (this.removeAllListeners(), o.unloadDel(this.unloadRef), this.xdr.ontimeout = this.xdr.onerror = this.xdr.onprogress = this.xdr.onload = null, e) try {
                        this.xdr.abort()
                    } catch (t) {
                    }
                    this.unloadRef = this.xdr = null
                }
            }, u.prototype.close = function () {
                c("close"), this._cleanup(!0)
            }, u.enabled = !(!t.XDomainRequest || !s.hasDomain()), e.exports = u
        }).call(this, i("c8ba"))
    }, "9f3a": function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("930c"), o = i("ada0").EventEmitter, s = i("1015"), a = i("621f"), c = i("f1f8"),
            u = i("c282"), l = i("2582"), d = function () {
            };

        function h(e, t, i) {
            if (!h.enabled()) throw new Error("Transport created when disabled");
            o.call(this);
            var n = this;
            this.origin = a.getOrigin(i), this.baseUrl = i, this.transUrl = t, this.transport = e, this.windowId = l.string(8);
            var r = a.addPath(i, "/iframe.html") + "#" + this.windowId;
            d(e, t, r), this.iframeObj = c.createIframe(r, (function (e) {
                d("err callback"), n.emit("close", 1006, "Unable to load an iframe (" + e + ")"), n.close()
            })), this.onmessageCallback = this._message.bind(this), u.attachEvent("message", this.onmessageCallback)
        }

        n(h, o), h.prototype.close = function () {
            if (d("close"), this.removeAllListeners(), this.iframeObj) {
                u.detachEvent("message", this.onmessageCallback);
                try {
                    this.postMessage("c")
                } catch (e) {
                }
                this.iframeObj.cleanup(), this.iframeObj = null, this.onmessageCallback = this.iframeObj = null
            }
        }, h.prototype._message = function (e) {
            if (d("message", e.data), a.isOriginEqual(e.origin, this.origin)) {
                var t;
                try {
                    t = r.parse(e.data)
                } catch (n) {
                    return void d("bad json", e.data)
                }
                if (t.windowId === this.windowId) switch (t.type) {
                    case"s":
                        this.iframeObj.loaded(), this.postMessage("s", r.stringify([s, this.transport, this.transUrl, this.baseUrl]));
                        break;
                    case"t":
                        this.emit("message", t.data);
                        break;
                    case"c":
                        var i;
                        try {
                            i = r.parse(t.data)
                        } catch (n) {
                            return void d("bad json", t.data)
                        }
                        this.emit("close", i[0], i[1]), this.close();
                        break
                } else d("mismatched window id", t.windowId, this.windowId)
            } else d("not same origin", e.origin, this.origin)
        }, h.prototype.postMessage = function (e, t) {
            d("postMessage", e, t), this.iframeObj.post(r.stringify({
                windowId: this.windowId,
                type: e,
                data: t || ""
            }), this.origin)
        }, h.prototype.send = function (e) {
            d("send", e), this.postMessage("m", e)
        }, h.enabled = function () {
            return c.iframeEnabled
        }, h.transportName = "iframe", h.roundTrips = 2, e.exports = h
    }, "9fa7": function (e, t, i) {
        "use strict";
        var n = i("621f"), r = i("c282"), o = i("930c"), s = i("bb31"), a = i("c529"), c = i("f1f8"), u = i("a0e2"),
            l = function () {
            };
        e.exports = function (e, t) {
            var i, d = {};
            t.forEach((function (e) {
                e.facadeTransport && (d[e.facadeTransport.transportName] = e.facadeTransport)
            })), d[a.transportName] = a, e.bootstrap_iframe = function () {
                var t;
                c.currentWindowId = u.hash.slice(1);
                var a = function (r) {
                    if (r.source === parent && ("undefined" === typeof i && (i = r.origin), r.origin === i)) {
                        var a;
                        try {
                            a = o.parse(r.data)
                        } catch (y) {
                            return void l("bad json", r.data)
                        }
                        if (a.windowId === c.currentWindowId) switch (a.type) {
                            case"s":
                                var h;
                                try {
                                    h = o.parse(a.data)
                                } catch (y) {
                                    l("bad json", a.data);
                                    break
                                }
                                var p = h[0], f = h[1], m = h[2], v = h[3];
                                if (l(p, f, m, v), p !== e.version) throw new Error('Incompatible SockJS! Main site uses: "' + p + '", the iframe: "' + e.version + '".');
                                if (!n.isOriginEqual(m, u.href) || !n.isOriginEqual(v, u.href)) throw new Error("Can't connect to different domain from within an iframe. (" + u.href + ", " + m + ", " + v + ")");
                                t = new s(new d[f](m, v));
                                break;
                            case"m":
                                t._send(a.data);
                                break;
                            case"c":
                                t && t._close(), t = null;
                                break
                        }
                    }
                };
                r.attachEvent("message", a), c.postMessage("s")
            }
        }
    }, "9fee": function (e, t, i) {
    }, "9ff8": function (e, t, i) {
        "use strict";
        var n = function () {
                var e = this, t = e.$createElement, n = e._self._c || t;
                return n("div", {
                    ref: "aliyunPreview",
                    staticClass: "aliyunPreview-box"
                }, [e.isShow ? n("iframe", {
                    ref: "aliyunPreviewIframe",
                    attrs: {allowfullscreen: "", id: "aliyunPreview", frameborder: "0", src: e.baseUrl}
                }) : e._e(), e.isControl ? n("div", {staticClass: "control-bar"}, [e._t("default", [n("span", {staticClass: "tips-text"}, [e._v(e._s(e.$t("v4.js.pc.ocmt.completedLearning")))])]), e.fullscreen ? n("img", {
                    staticClass: "fullScreen",
                    attrs: {src: i("dfcd"), alt: ""},
                    on: {click: e.exitFullscreen}
                }) : n("img", {
                    staticClass: "fullScreen", attrs: {src: i("948c"), alt: ""}, on: {
                        click: function (t) {
                            return e.toFullVideo(e.$refs.aliyunPreview)
                        }
                    }
                })], 2) : e._e()])
            }, r = [], o = (i("ac6a"), i("28a5"), i("0fb7"), i("450d"), i("f529")), s = i.n(o),
            a = (i("6b54"), i("c5f6"), i("8e44")), c = {
                data: function () {
                    return {
                        type: "",
                        totalCount: 0,
                        currentCount: this.pageIndex,
                        fullscreen: !1,
                        wmType: 0,
                        wmValue: "",
                        wmDensity: .7,
                        wmOpcity: .6,
                        baseUrl: 0 === this.pageIndex ? "https://preview.imm.aliyun.com/index.html" : "https://preview.imm.aliyun.com/index.html?pageIndex=".concat(this.pageIndex),
                        docUrl: "https://tbcossdocument.oss-cn-shanghai.aliyuncs.com/docs/output/".concat(this.resourceRelId),
                        isShow: !0,
                        tryTimer: null,
                        tryCount: 0,
                        heartTimer: null
                    }
                },
                props: {
                    resourceRelId: {type: String, default: ""},
                    pageIndex: {type: Number, default: 0},
                    isControl: {type: Boolean, default: !0},
                    isFinish: {type: Boolean, default: !1}
                },
                watch: {
                    resourceRelId: function () {
                        var e = this;
                        this.isShow = !1, this.docUrl = "https://tbcossdocument.oss-cn-shanghai.aliyuncs.com/docs/output/".concat(this.resourceRelId), this.baseUrl = 0 === this.pageIndex ? "https://preview.imm.aliyun.com/index.html" : "https://preview.imm.aliyun.com/index.html?pageIndex=".concat(this.pageIndex), this.currentCount = this.pageIndex, this.$nextTick((function () {
                            e.isShow = !0, e.initAliyunPreview()
                        }))
                    }
                },
                methods: {
                    json2str: function (e) {
                        return JSON.stringify(e, (function (e, t) {
                            return "function" === typeof t && (t = t.toString()), t
                        }))
                    }, initAliyunPreview: function () {
                        var e = this, t = this;
                        window.sendMessage = function (e, i) {
                            var n = document.getElementById("aliyunPreview");
                            n.contentWindow.postMessage(t.json2str({action: e, data: i}), "*")
                        }, window.addEventListener("message", (function (e) {
                            var i = Math.floor(800 * (1.1 - t.wmDensity));
                            try {
                                var n = JSON.parse(e.data)
                            } catch (r) {
                                return
                            }
                            switch (n.action) {
                                case"preview.ready":
                                    window.sendMessage("preview.init", {
                                        url: t.docUrl,
                                        wmType: t.wmType,
                                        wmValue: t.wmValue,
                                        wmHeight: i,
                                        wmWidth: i,
                                        wmColor: "rgba(192, 192, 192, ".concat(t.wmOpcity, ")")
                                    }), window.sendMessage("setConfig", {
                                        writerCustomStyle: function (e) {
                                            return e ? {pageBorder: "1px solid #d2d5d8"} : {
                                                containerMarginTop: 30,
                                                containerMarginBottom: 30,
                                                pageSpacing: 20,
                                                pageShadow: "0px 0px 6px 0px rgba(0, 0, 0, 0.3)",
                                                pageBorder: "none",
                                                scale: {},
                                                scaleBtn: {},
                                                scaleShrink: {},
                                                scaleShrinkText: "",
                                                scaleShrinkDisable: {},
                                                scaleMagnify: {},
                                                scaleMagnifyText: "",
                                                scaleMagnifyDisable: {},
                                                scaleText: {},
                                                scaleSort: ["shrink", "text", "magnify"]
                                            }
                                        }, powerpointCustomStyle: function (e) {
                                            return e ? {} : {
                                                paginationDisplay: !0,
                                                fullScreenButtonDisplay: !1,
                                                containerMarginTop: 30,
                                                containerMarginBottom: 30,
                                                containerBackground: "#000000"
                                            }
                                        }, couldRetry: function (e) {
                                            return console.log("重试的次数", e), new Promise((function (t) {
                                                if (e > 35) t(!1); else {
                                                    var i = 0;
                                                    i = e < 2 ? 250 : e <= 11 ? 500 : 1e3, setTimeout((function () {
                                                        t(!0)
                                                    }), i)
                                                }
                                            }))
                                        }
                                    });
                                    break;
                                case"page.readPage":
                                    t.currentCount = n.data.pageIndex;
                                    break;
                                case"preview.meta":
                                    t.type = n.data.ext, "xlsx" === t.type || "xls" === t.type ? t.totalCount = n.data.asc : t.totalCount = n.data.pc;
                                    break;
                                case"message.error":
                                    "aliyunRequestTimeout" === n.result && s()({
                                        message: t.$t("v4.js.pc.ocmt.Resourceloadingtimeout"),
                                        type: "error"
                                    });
                                    break;
                                case"page.renderDone":
                                    clearInterval(t.tryTimer);
                                    break
                            }
                        }), !1), document.addEventListener("gesturestart", (function (e) {
                            e.preventDefault()
                        })), window.addEventListener("resize", (function (t) {
                            e.fullscreen = document.fullscreen || document.msFullscreenElement || document.mozFullScreen || document.webkitIsFullScreen
                        }))
                    }, init: function () {
                        var e = this;
                        "km" !== this.$route.query.from ? a["a"].APIconfirmWatermark().then((function (t) {
                            var i = t.bizResult;
                            e.wmType = "true" === i.enableWatermark ? 1 : 0, e.wmDensity = i.waterMarkDensity / 100, e.wmOpcity = i.waterMarkTransparency / 100, e.wmValue = "";
                            var n = i.waterMarkShowObject ? i.waterMarkShowObject.split(",") : [], r = [];
                            n.forEach((function (e) {
                                "EMPLOYEE_CODE" === e ? r.push(i.employeeCode) : "USER_NAME" === e ? r.push(i.userName) : "LOGIN_NAME" === e && r.push(i.loginName)
                            })), e.wmValue = r.join(" "), e.initAliyunPreview()
                        })) : a["a"].APIconfirmWatermarkKM().then((function (t) {
                            var i = t.bizResult;
                            e.wmType = "true" === i.enableWatermark ? 1 : 0, e.wmDensity = i.waterMarkDensity / 100, e.wmOpcity = i.waterMarkTransparency / 100, e.wmValue = "";
                            var n = i.waterMarkShowObject ? i.waterMarkShowObject.split(",") : [], r = [];
                            n.forEach((function (e) {
                                "EMPLOYEE_CODE" === e ? r.push(i.employeeCode) : "USER_NAME" === e ? r.push(i.userName) : "LOGIN_NAME" === e && r.push(i.loginName)
                            })), e.wmValue = r.join(" "), e.initAliyunPreview()
                        }))
                    }, toFullVideo: function (e) {
                        e.requestFullscreen ? e.requestFullscreen() : e.webkitRequestFullScreen ? e.webkitRequestFullScreen() : e.mozRequestFullScreen ? e.mozRequestFullScreen() : e.msRequestFullscreen()
                    }, exitFullscreen: function () {
                        document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen()
                    }, initHeart: function () {
                        var e = this, t = decodeURIComponent(this.$route.params.courseInfo).split("&")[0],
                            i = {courseId: t};
                        a["c"].loadCourseSystemSeting(i).then((function (i) {
                            "1001" == i.code && (!i.bizResult.heartBeat || e.isFinish && !i.bizResult.continueHeartBeat || (e.heartTimer = setInterval((function () {
                                a["c"].heartBeatSetData(t)
                            }), 6e4)))
                        }))
                    }
                },
                beforeDestroy: function () {
                    clearInterval(this.heartTimer)
                },
                mounted: function () {
                    var e = this;
                    this.initHeart(), this.init(), this.tryTimer = setInterval((function () {
                        e.isShow = !1, e.$nextTick((function () {
                            e.isShow = !0, e.initAliyunPreview()
                        })), e.tryCount++, e.tryCount >= 10 && clearInterval(e.tryTimer)
                    }), 3e3), this.$emit("isReady")
                }
            }, u = c, l = (i("7eab"), i("2877")), d = Object(l["a"])(u, n, r, !1, null, "4243ccf4", null);
        t["a"] = d.exports
    }, a0e2: function (e, t, i) {
        "use strict";
        (function (t) {
            e.exports = t.location || {
                origin: "http://localhost:80",
                protocol: "http:",
                host: "localhost",
                port: 80,
                href: "http://localhost/",
                hash: ""
            }
        }).call(this, i("c8ba"))
    }, a7bb: function (e, t, i) {
        "use strict";
        var n = i("bc9f"), r = i.n(n);
        r.a
    }, ada0: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("97a2");

        function o() {
            r.call(this)
        }

        n(o, r), o.prototype.removeAllListeners = function (e) {
            e ? delete this._listeners[e] : this._listeners = {}
        }, o.prototype.once = function (e, t) {
            var i = this, n = !1;

            function r() {
                i.removeListener(e, r), n || (n = !0, t.apply(this, arguments))
            }

            this.on(e, r)
        }, o.prototype.emit = function () {
            var e = arguments[0], t = this._listeners[e];
            if (t) {
                for (var i = arguments.length, n = new Array(i - 1), r = 1; r < i; r++) n[r - 1] = arguments[r];
                for (var o = 0; o < t.length; o++) t[o].apply(this, n)
            }
        }, o.prototype.on = o.prototype.addListener = r.prototype.addEventListener, o.prototype.removeListener = r.prototype.removeEventListener, e.exports.EventEmitter = o
    }, b185: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("7577"), o = i("1548"), s = i("9d7d");

        function a(e) {
            if (!s.enabled) throw new Error("Transport created when disabled");
            r.call(this, e, "/xhr_streaming", o, s)
        }

        n(a, r), a.enabled = function (e) {
            return !e.cookie_needed && !e.nullOrigin && (s.enabled && e.sameScheme)
        }, a.transportName = "xdr-streaming", a.roundTrips = 2, e.exports = a
    }, b9a8: function (e, t, i) {
        "use strict";
        var n = i("ada0").EventEmitter, r = i("3fb5"), o = i("621f"), s = i("9d7d"), a = i("df09"), c = i("73aa"),
            u = i("f701"), l = i("7c20"), d = i("89bc"), h = function () {
            };

        function p(e, t) {
            h(e);
            var i = this;
            n.call(this), setTimeout((function () {
                i.doXhr(e, t)
            }), 0)
        }

        r(p, n), p._getReceiver = function (e, t, i) {
            return i.sameOrigin ? new d(t, c) : a.enabled ? new d(t, a) : s.enabled && i.sameScheme ? new d(t, s) : l.enabled() ? new l(e, t) : new d(t, u)
        }, p.prototype.doXhr = function (e, t) {
            var i = this, n = o.addPath(e, "/info");
            h("doXhr", n), this.xo = p._getReceiver(e, n, t), this.timeoutRef = setTimeout((function () {
                h("timeout"), i._cleanup(!1), i.emit("finish")
            }), p.timeout), this.xo.once("finish", (function (e, t) {
                h("finish", e, t), i._cleanup(!0), i.emit("finish", e, t)
            }))
        }, p.prototype._cleanup = function (e) {
            h("_cleanup"), clearTimeout(this.timeoutRef), this.timeoutRef = null, !e && this.xo && this.xo.close(), this.xo = null
        }, p.prototype.close = function () {
            h("close"), this.removeAllListeners(), this._cleanup(!1)
        }, p.timeout = 8e3, e.exports = p
    }, bb31: function (e, t, i) {
        "use strict";
        var n = i("930c"), r = i("f1f8");

        function o(e) {
            this._transport = e, e.on("message", this._transportMessage.bind(this)), e.on("close", this._transportClose.bind(this))
        }

        o.prototype._transportClose = function (e, t) {
            r.postMessage("c", n.stringify([e, t]))
        }, o.prototype._transportMessage = function (e) {
            r.postMessage("t", e)
        }, o.prototype._send = function (e) {
            this._transport.send(e)
        }, o.prototype._close = function () {
            this._transport.close(), this._transport.removeAllListeners()
        }, e.exports = o
    }, bc9f: function (e, t, i) {
    }, bf4a: function (e, t, i) {
        "use strict";
        (function (t) {
            var n, r, o = i("2582"), s = i("621f"), a = function () {
            };

            function c(e) {
                a("createIframe", e);
                try {
                    return t.document.createElement('<iframe name="' + e + '">')
                } catch (n) {
                    var i = t.document.createElement("iframe");
                    return i.name = e, i
                }
            }

            function u() {
                a("createForm"), n = t.document.createElement("form"), n.style.display = "none", n.style.position = "absolute", n.method = "POST", n.enctype = "application/x-www-form-urlencoded", n.acceptCharset = "UTF-8", r = t.document.createElement("textarea"), r.name = "d", n.appendChild(r), t.document.body.appendChild(n)
            }

            e.exports = function (e, t, i) {
                a(e, t), n || u();
                var l = "a" + o.string(8);
                n.target = l, n.action = s.addQuery(s.addPath(e, "/jsonp_send"), "i=" + l);
                var d = c(l);
                d.id = l, d.style.display = "none", n.appendChild(d);
                try {
                    r.value = t
                } catch (p) {
                }
                n.submit();
                var h = function (e) {
                    a("completed", l, e), d.onerror && (d.onreadystatechange = d.onerror = d.onload = null, setTimeout((function () {
                        a("cleaning up", l), d.parentNode.removeChild(d), d = null
                    }), 500), r.value = "", i(e))
                };
                return d.onerror = function () {
                    a("onerror", l), h()
                }, d.onload = function () {
                    a("onload", l), h()
                }, d.onreadystatechange = function (e) {
                    a("onreadystatechange", l, d.readyState, e), "complete" === d.readyState && h()
                }, function () {
                    a("aborted", l), h(new Error("Aborted"))
                }
            }
        }).call(this, i("c8ba"))
    }, c282: function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("2582"), r = {}, o = !1, s = t.chrome && t.chrome.app && t.chrome.app.runtime;
            e.exports = {
                attachEvent: function (e, i) {
                    "undefined" !== typeof t.addEventListener ? t.addEventListener(e, i, !1) : t.document && t.attachEvent && (t.document.attachEvent("on" + e, i), t.attachEvent("on" + e, i))
                }, detachEvent: function (e, i) {
                    "undefined" !== typeof t.addEventListener ? t.removeEventListener(e, i, !1) : t.document && t.detachEvent && (t.document.detachEvent("on" + e, i), t.detachEvent("on" + e, i))
                }, unloadAdd: function (e) {
                    if (s) return null;
                    var t = n.string(8);
                    return r[t] = e, o && setTimeout(this.triggerUnloadCallbacks, 0), t
                }, unloadDel: function (e) {
                    e in r && delete r[e]
                }, triggerUnloadCallbacks: function () {
                    for (var e in r) r[e](), delete r[e]
                }
            };
            var a = function () {
                o || (o = !0, e.exports.triggerUnloadCallbacks())
            };
            s || e.exports.attachEvent("unload", a)
        }).call(this, i("c8ba"))
    }, c529: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("ada0").EventEmitter, o = i("930c"), s = i("73aa"), a = i("89bc");

        function c(e) {
            var t = this;
            r.call(this), this.ir = new a(e, s), this.ir.once("finish", (function (e, i) {
                t.ir = null, t.emit("message", o.stringify([e, i]))
            }))
        }

        n(c, r), c.transportName = "iframe-info-receiver", c.prototype.close = function () {
            this.ir && (this.ir.close(), this.ir = null), this.removeAllListeners()
        }, e.exports = c
    }, ca34: function (e, t, i) {
        (function (t) {
            e.exports = t.EventSource
        }).call(this, i("c8ba"))
    }, cc7d: function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("6945");
            e.exports = i("486c")(n), "_sockjs_onload" in t && setTimeout(t._sockjs_onload, 1)
        }).call(this, i("c8ba"))
    }, cfe6: function (e, t, i) {
        "use strict";
        (function (t) {
            t.crypto && t.crypto.getRandomValues ? e.exports.randomBytes = function (e) {
                var i = new Uint8Array(e);
                return t.crypto.getRandomValues(i), i
            } : e.exports.randomBytes = function (e) {
                for (var t = new Array(e), i = 0; i < e; i++) t[i] = Math.floor(256 * Math.random());
                return t
            }
        }).call(this, i("c8ba"))
    }, d044: function (e, t, i) {
        var n;
        (function (t, i) {
            e.exports = i()
        })(0, (function () {
            function e(e) {
                this.mode = i.MODE_8BIT_BYTE, this.data = e, this.parsedData = [];
                for (var t = 0, n = this.data.length; t < n; t++) {
                    var r = [], o = this.data.charCodeAt(t);
                    o > 65536 ? (r[0] = 240 | (1835008 & o) >>> 18, r[1] = 128 | (258048 & o) >>> 12, r[2] = 128 | (4032 & o) >>> 6, r[3] = 128 | 63 & o) : o > 2048 ? (r[0] = 224 | (61440 & o) >>> 12, r[1] = 128 | (4032 & o) >>> 6, r[2] = 128 | 63 & o) : o > 128 ? (r[0] = 192 | (1984 & o) >>> 6, r[1] = 128 | 63 & o) : r[0] = o, this.parsedData.push(r)
                }
                this.parsedData = Array.prototype.concat.apply([], this.parsedData), this.parsedData.length != this.data.length && (this.parsedData.unshift(191), this.parsedData.unshift(187), this.parsedData.unshift(239))
            }

            function t(e, t) {
                this.typeNumber = e, this.errorCorrectLevel = t, this.modules = null, this.moduleCount = 0, this.dataCache = null, this.dataList = []
            }

            e.prototype = {
                getLength: function (e) {
                    return this.parsedData.length
                }, write: function (e) {
                    for (var t = 0, i = this.parsedData.length; t < i; t++) e.put(this.parsedData[t], 8)
                }
            }, t.prototype = {
                addData: function (t) {
                    var i = new e(t);
                    this.dataList.push(i), this.dataCache = null
                }, isDark: function (e, t) {
                    if (e < 0 || this.moduleCount <= e || t < 0 || this.moduleCount <= t) throw new Error(e + "," + t);
                    return this.modules[e][t]
                }, getModuleCount: function () {
                    return this.moduleCount
                }, make: function () {
                    this.makeImpl(!1, this.getBestMaskPattern())
                }, makeImpl: function (e, i) {
                    this.moduleCount = 4 * this.typeNumber + 17, this.modules = new Array(this.moduleCount);
                    for (var n = 0; n < this.moduleCount; n++) {
                        this.modules[n] = new Array(this.moduleCount);
                        for (var r = 0; r < this.moduleCount; r++) this.modules[n][r] = null
                    }
                    this.setupPositionProbePattern(0, 0), this.setupPositionProbePattern(this.moduleCount - 7, 0), this.setupPositionProbePattern(0, this.moduleCount - 7), this.setupPositionAdjustPattern(), this.setupTimingPattern(), this.setupTypeInfo(e, i), this.typeNumber >= 7 && this.setupTypeNumber(e), null == this.dataCache && (this.dataCache = t.createData(this.typeNumber, this.errorCorrectLevel, this.dataList)), this.mapData(this.dataCache, i)
                }, setupPositionProbePattern: function (e, t) {
                    for (var i = -1; i <= 7; i++) if (!(e + i <= -1 || this.moduleCount <= e + i)) for (var n = -1; n <= 7; n++) t + n <= -1 || this.moduleCount <= t + n || (this.modules[e + i][t + n] = 0 <= i && i <= 6 && (0 == n || 6 == n) || 0 <= n && n <= 6 && (0 == i || 6 == i) || 2 <= i && i <= 4 && 2 <= n && n <= 4)
                }, getBestMaskPattern: function () {
                    for (var e = 0, t = 0, i = 0; i < 8; i++) {
                        this.makeImpl(!0, i);
                        var n = s.getLostPoint(this);
                        (0 == i || e > n) && (e = n, t = i)
                    }
                    return t
                }, createMovieClip: function (e, t, i) {
                    var n = e.createEmptyMovieClip(t, i), r = 1;
                    this.make();
                    for (var o = 0; o < this.modules.length; o++) for (var s = o * r, a = 0; a < this.modules[o].length; a++) {
                        var c = a * r, u = this.modules[o][a];
                        u && (n.beginFill(0, 100), n.moveTo(c, s), n.lineTo(c + r, s), n.lineTo(c + r, s + r), n.lineTo(c, s + r), n.endFill())
                    }
                    return n
                }, setupTimingPattern: function () {
                    for (var e = 8; e < this.moduleCount - 8; e++) null == this.modules[e][6] && (this.modules[e][6] = e % 2 == 0);
                    for (var t = 8; t < this.moduleCount - 8; t++) null == this.modules[6][t] && (this.modules[6][t] = t % 2 == 0)
                }, setupPositionAdjustPattern: function () {
                    for (var e = s.getPatternPosition(this.typeNumber), t = 0; t < e.length; t++) for (var i = 0; i < e.length; i++) {
                        var n = e[t], r = e[i];
                        if (null == this.modules[n][r]) for (var o = -2; o <= 2; o++) for (var a = -2; a <= 2; a++) this.modules[n + o][r + a] = -2 == o || 2 == o || -2 == a || 2 == a || 0 == o && 0 == a
                    }
                }, setupTypeNumber: function (e) {
                    for (var t = s.getBCHTypeNumber(this.typeNumber), i = 0; i < 18; i++) {
                        var n = !e && 1 == (t >> i & 1);
                        this.modules[Math.floor(i / 3)][i % 3 + this.moduleCount - 8 - 3] = n
                    }
                    for (i = 0; i < 18; i++) {
                        n = !e && 1 == (t >> i & 1);
                        this.modules[i % 3 + this.moduleCount - 8 - 3][Math.floor(i / 3)] = n
                    }
                }, setupTypeInfo: function (e, t) {
                    for (var i = this.errorCorrectLevel << 3 | t, n = s.getBCHTypeInfo(i), r = 0; r < 15; r++) {
                        var o = !e && 1 == (n >> r & 1);
                        r < 6 ? this.modules[r][8] = o : r < 8 ? this.modules[r + 1][8] = o : this.modules[this.moduleCount - 15 + r][8] = o
                    }
                    for (r = 0; r < 15; r++) {
                        o = !e && 1 == (n >> r & 1);
                        r < 8 ? this.modules[8][this.moduleCount - r - 1] = o : r < 9 ? this.modules[8][15 - r - 1 + 1] = o : this.modules[8][15 - r - 1] = o
                    }
                    this.modules[this.moduleCount - 8][8] = !e
                }, mapData: function (e, t) {
                    for (var i = -1, n = this.moduleCount - 1, r = 7, o = 0, a = this.moduleCount - 1; a > 0; a -= 2) {
                        6 == a && a--;
                        while (1) {
                            for (var c = 0; c < 2; c++) if (null == this.modules[n][a - c]) {
                                var u = !1;
                                o < e.length && (u = 1 == (e[o] >>> r & 1));
                                var l = s.getMask(t, n, a - c);
                                l && (u = !u), this.modules[n][a - c] = u, r--, -1 == r && (o++, r = 7)
                            }
                            if (n += i, n < 0 || this.moduleCount <= n) {
                                n -= i, i = -i;
                                break
                            }
                        }
                    }
                }
            }, t.PAD0 = 236, t.PAD1 = 17, t.createData = function (e, i, n) {
                for (var r = l.getRSBlocks(e, i), o = new d, a = 0; a < n.length; a++) {
                    var c = n[a];
                    o.put(c.mode, 4), o.put(c.getLength(), s.getLengthInBits(c.mode, e)), c.write(o)
                }
                var u = 0;
                for (a = 0; a < r.length; a++) u += r[a].dataCount;
                if (o.getLengthInBits() > 8 * u) throw new Error("code length overflow. (" + o.getLengthInBits() + ">" + 8 * u + ")");
                o.getLengthInBits() + 4 <= 8 * u && o.put(0, 4);
                while (o.getLengthInBits() % 8 != 0) o.putBit(!1);
                while (1) {
                    if (o.getLengthInBits() >= 8 * u) break;
                    if (o.put(t.PAD0, 8), o.getLengthInBits() >= 8 * u) break;
                    o.put(t.PAD1, 8)
                }
                return t.createBytes(o, r)
            }, t.createBytes = function (e, t) {
                for (var i = 0, n = 0, r = 0, o = new Array(t.length), a = new Array(t.length), c = 0; c < t.length; c++) {
                    var l = t[c].dataCount, d = t[c].totalCount - l;
                    n = Math.max(n, l), r = Math.max(r, d), o[c] = new Array(l);
                    for (var h = 0; h < o[c].length; h++) o[c][h] = 255 & e.buffer[h + i];
                    i += l;
                    var p = s.getErrorCorrectPolynomial(d), f = new u(o[c], p.getLength() - 1), m = f.mod(p);
                    a[c] = new Array(p.getLength() - 1);
                    for (h = 0; h < a[c].length; h++) {
                        var v = h + m.getLength() - a[c].length;
                        a[c][h] = v >= 0 ? m.get(v) : 0
                    }
                }
                var y = 0;
                for (h = 0; h < t.length; h++) y += t[h].totalCount;
                var g = new Array(y), T = 0;
                for (h = 0; h < n; h++) for (c = 0; c < t.length; c++) h < o[c].length && (g[T++] = o[c][h]);
                for (h = 0; h < r; h++) for (c = 0; c < t.length; c++) h < a[c].length && (g[T++] = a[c][h]);
                return g
            };
            for (var i = {MODE_NUMBER: 1, MODE_ALPHA_NUM: 2, MODE_8BIT_BYTE: 4, MODE_KANJI: 8}, r = {
                L: 1,
                M: 0,
                Q: 3,
                H: 2
            }, o = {
                PATTERN000: 0,
                PATTERN001: 1,
                PATTERN010: 2,
                PATTERN011: 3,
                PATTERN100: 4,
                PATTERN101: 5,
                PATTERN110: 6,
                PATTERN111: 7
            }, s = {
                PATTERN_POSITION_TABLE: [[], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50], [6, 30, 54], [6, 32, 58], [6, 34, 62], [6, 26, 46, 66], [6, 26, 48, 70], [6, 26, 50, 74], [6, 30, 54, 78], [6, 30, 56, 82], [6, 30, 58, 86], [6, 34, 62, 90], [6, 28, 50, 72, 94], [6, 26, 50, 74, 98], [6, 30, 54, 78, 102], [6, 28, 54, 80, 106], [6, 32, 58, 84, 110], [6, 30, 58, 86, 114], [6, 34, 62, 90, 118], [6, 26, 50, 74, 98, 122], [6, 30, 54, 78, 102, 126], [6, 26, 52, 78, 104, 130], [6, 30, 56, 82, 108, 134], [6, 34, 60, 86, 112, 138], [6, 30, 58, 86, 114, 142], [6, 34, 62, 90, 118, 146], [6, 30, 54, 78, 102, 126, 150], [6, 24, 50, 76, 102, 128, 154], [6, 28, 54, 80, 106, 132, 158], [6, 32, 58, 84, 110, 136, 162], [6, 26, 54, 82, 110, 138, 166], [6, 30, 58, 86, 114, 142, 170]],
                G15: 1335,
                G18: 7973,
                G15_MASK: 21522,
                getBCHTypeInfo: function (e) {
                    var t = e << 10;
                    while (s.getBCHDigit(t) - s.getBCHDigit(s.G15) >= 0) t ^= s.G15 << s.getBCHDigit(t) - s.getBCHDigit(s.G15);
                    return (e << 10 | t) ^ s.G15_MASK
                },
                getBCHTypeNumber: function (e) {
                    var t = e << 12;
                    while (s.getBCHDigit(t) - s.getBCHDigit(s.G18) >= 0) t ^= s.G18 << s.getBCHDigit(t) - s.getBCHDigit(s.G18);
                    return e << 12 | t
                },
                getBCHDigit: function (e) {
                    var t = 0;
                    while (0 != e) t++, e >>>= 1;
                    return t
                },
                getPatternPosition: function (e) {
                    return s.PATTERN_POSITION_TABLE[e - 1]
                },
                getMask: function (e, t, i) {
                    switch (e) {
                        case o.PATTERN000:
                            return (t + i) % 2 == 0;
                        case o.PATTERN001:
                            return t % 2 == 0;
                        case o.PATTERN010:
                            return i % 3 == 0;
                        case o.PATTERN011:
                            return (t + i) % 3 == 0;
                        case o.PATTERN100:
                            return (Math.floor(t / 2) + Math.floor(i / 3)) % 2 == 0;
                        case o.PATTERN101:
                            return t * i % 2 + t * i % 3 == 0;
                        case o.PATTERN110:
                            return (t * i % 2 + t * i % 3) % 2 == 0;
                        case o.PATTERN111:
                            return (t * i % 3 + (t + i) % 2) % 2 == 0;
                        default:
                            throw new Error("bad maskPattern:" + e)
                    }
                },
                getErrorCorrectPolynomial: function (e) {
                    for (var t = new u([1], 0), i = 0; i < e; i++) t = t.multiply(new u([1, a.gexp(i)], 0));
                    return t
                },
                getLengthInBits: function (e, t) {
                    if (1 <= t && t < 10) switch (e) {
                        case i.MODE_NUMBER:
                            return 10;
                        case i.MODE_ALPHA_NUM:
                            return 9;
                        case i.MODE_8BIT_BYTE:
                            return 8;
                        case i.MODE_KANJI:
                            return 8;
                        default:
                            throw new Error("mode:" + e)
                    } else if (t < 27) switch (e) {
                        case i.MODE_NUMBER:
                            return 12;
                        case i.MODE_ALPHA_NUM:
                            return 11;
                        case i.MODE_8BIT_BYTE:
                            return 16;
                        case i.MODE_KANJI:
                            return 10;
                        default:
                            throw new Error("mode:" + e)
                    } else {
                        if (!(t < 41)) throw new Error("type:" + t);
                        switch (e) {
                            case i.MODE_NUMBER:
                                return 14;
                            case i.MODE_ALPHA_NUM:
                                return 13;
                            case i.MODE_8BIT_BYTE:
                                return 16;
                            case i.MODE_KANJI:
                                return 12;
                            default:
                                throw new Error("mode:" + e)
                        }
                    }
                },
                getLostPoint: function (e) {
                    for (var t = e.getModuleCount(), i = 0, n = 0; n < t; n++) for (var r = 0; r < t; r++) {
                        for (var o = 0, s = e.isDark(n, r), a = -1; a <= 1; a++) if (!(n + a < 0 || t <= n + a)) for (var c = -1; c <= 1; c++) r + c < 0 || t <= r + c || 0 == a && 0 == c || s == e.isDark(n + a, r + c) && o++;
                        o > 5 && (i += 3 + o - 5)
                    }
                    for (n = 0; n < t - 1; n++) for (r = 0; r < t - 1; r++) {
                        var u = 0;
                        e.isDark(n, r) && u++, e.isDark(n + 1, r) && u++, e.isDark(n, r + 1) && u++, e.isDark(n + 1, r + 1) && u++, 0 != u && 4 != u || (i += 3)
                    }
                    for (n = 0; n < t; n++) for (r = 0; r < t - 6; r++) e.isDark(n, r) && !e.isDark(n, r + 1) && e.isDark(n, r + 2) && e.isDark(n, r + 3) && e.isDark(n, r + 4) && !e.isDark(n, r + 5) && e.isDark(n, r + 6) && (i += 40);
                    for (r = 0; r < t; r++) for (n = 0; n < t - 6; n++) e.isDark(n, r) && !e.isDark(n + 1, r) && e.isDark(n + 2, r) && e.isDark(n + 3, r) && e.isDark(n + 4, r) && !e.isDark(n + 5, r) && e.isDark(n + 6, r) && (i += 40);
                    var l = 0;
                    for (r = 0; r < t; r++) for (n = 0; n < t; n++) e.isDark(n, r) && l++;
                    var d = Math.abs(100 * l / t / t - 50) / 5;
                    return i += 10 * d, i
                }
            }, a = {
                glog: function (e) {
                    if (e < 1) throw new Error("glog(" + e + ")");
                    return a.LOG_TABLE[e]
                }, gexp: function (e) {
                    while (e < 0) e += 255;
                    while (e >= 256) e -= 255;
                    return a.EXP_TABLE[e]
                }, EXP_TABLE: new Array(256), LOG_TABLE: new Array(256)
            }, c = 0; c < 8; c++) a.EXP_TABLE[c] = 1 << c;
            for (c = 8; c < 256; c++) a.EXP_TABLE[c] = a.EXP_TABLE[c - 4] ^ a.EXP_TABLE[c - 5] ^ a.EXP_TABLE[c - 6] ^ a.EXP_TABLE[c - 8];
            for (c = 0; c < 255; c++) a.LOG_TABLE[a.EXP_TABLE[c]] = c;

            function u(e, t) {
                if (void 0 == e.length) throw new Error(e.length + "/" + t);
                var i = 0;
                while (i < e.length && 0 == e[i]) i++;
                this.num = new Array(e.length - i + t);
                for (var n = 0; n < e.length - i; n++) this.num[n] = e[n + i]
            }

            function l(e, t) {
                this.totalCount = e, this.dataCount = t
            }

            function d() {
                this.buffer = [], this.length = 0
            }

            u.prototype = {
                get: function (e) {
                    return this.num[e]
                }, getLength: function () {
                    return this.num.length
                }, multiply: function (e) {
                    for (var t = new Array(this.getLength() + e.getLength() - 1), i = 0; i < this.getLength(); i++) for (var n = 0; n < e.getLength(); n++) t[i + n] ^= a.gexp(a.glog(this.get(i)) + a.glog(e.get(n)));
                    return new u(t, 0)
                }, mod: function (e) {
                    if (this.getLength() - e.getLength() < 0) return this;
                    for (var t = a.glog(this.get(0)) - a.glog(e.get(0)), i = new Array(this.getLength()), n = 0; n < this.getLength(); n++) i[n] = this.get(n);
                    for (n = 0; n < e.getLength(); n++) i[n] ^= a.gexp(a.glog(e.get(n)) + t);
                    return new u(i, 0).mod(e)
                }
            }, l.RS_BLOCK_TABLE = [[1, 26, 19], [1, 26, 16], [1, 26, 13], [1, 26, 9], [1, 44, 34], [1, 44, 28], [1, 44, 22], [1, 44, 16], [1, 70, 55], [1, 70, 44], [2, 35, 17], [2, 35, 13], [1, 100, 80], [2, 50, 32], [2, 50, 24], [4, 25, 9], [1, 134, 108], [2, 67, 43], [2, 33, 15, 2, 34, 16], [2, 33, 11, 2, 34, 12], [2, 86, 68], [4, 43, 27], [4, 43, 19], [4, 43, 15], [2, 98, 78], [4, 49, 31], [2, 32, 14, 4, 33, 15], [4, 39, 13, 1, 40, 14], [2, 121, 97], [2, 60, 38, 2, 61, 39], [4, 40, 18, 2, 41, 19], [4, 40, 14, 2, 41, 15], [2, 146, 116], [3, 58, 36, 2, 59, 37], [4, 36, 16, 4, 37, 17], [4, 36, 12, 4, 37, 13], [2, 86, 68, 2, 87, 69], [4, 69, 43, 1, 70, 44], [6, 43, 19, 2, 44, 20], [6, 43, 15, 2, 44, 16], [4, 101, 81], [1, 80, 50, 4, 81, 51], [4, 50, 22, 4, 51, 23], [3, 36, 12, 8, 37, 13], [2, 116, 92, 2, 117, 93], [6, 58, 36, 2, 59, 37], [4, 46, 20, 6, 47, 21], [7, 42, 14, 4, 43, 15], [4, 133, 107], [8, 59, 37, 1, 60, 38], [8, 44, 20, 4, 45, 21], [12, 33, 11, 4, 34, 12], [3, 145, 115, 1, 146, 116], [4, 64, 40, 5, 65, 41], [11, 36, 16, 5, 37, 17], [11, 36, 12, 5, 37, 13], [5, 109, 87, 1, 110, 88], [5, 65, 41, 5, 66, 42], [5, 54, 24, 7, 55, 25], [11, 36, 12], [5, 122, 98, 1, 123, 99], [7, 73, 45, 3, 74, 46], [15, 43, 19, 2, 44, 20], [3, 45, 15, 13, 46, 16], [1, 135, 107, 5, 136, 108], [10, 74, 46, 1, 75, 47], [1, 50, 22, 15, 51, 23], [2, 42, 14, 17, 43, 15], [5, 150, 120, 1, 151, 121], [9, 69, 43, 4, 70, 44], [17, 50, 22, 1, 51, 23], [2, 42, 14, 19, 43, 15], [3, 141, 113, 4, 142, 114], [3, 70, 44, 11, 71, 45], [17, 47, 21, 4, 48, 22], [9, 39, 13, 16, 40, 14], [3, 135, 107, 5, 136, 108], [3, 67, 41, 13, 68, 42], [15, 54, 24, 5, 55, 25], [15, 43, 15, 10, 44, 16], [4, 144, 116, 4, 145, 117], [17, 68, 42], [17, 50, 22, 6, 51, 23], [19, 46, 16, 6, 47, 17], [2, 139, 111, 7, 140, 112], [17, 74, 46], [7, 54, 24, 16, 55, 25], [34, 37, 13], [4, 151, 121, 5, 152, 122], [4, 75, 47, 14, 76, 48], [11, 54, 24, 14, 55, 25], [16, 45, 15, 14, 46, 16], [6, 147, 117, 4, 148, 118], [6, 73, 45, 14, 74, 46], [11, 54, 24, 16, 55, 25], [30, 46, 16, 2, 47, 17], [8, 132, 106, 4, 133, 107], [8, 75, 47, 13, 76, 48], [7, 54, 24, 22, 55, 25], [22, 45, 15, 13, 46, 16], [10, 142, 114, 2, 143, 115], [19, 74, 46, 4, 75, 47], [28, 50, 22, 6, 51, 23], [33, 46, 16, 4, 47, 17], [8, 152, 122, 4, 153, 123], [22, 73, 45, 3, 74, 46], [8, 53, 23, 26, 54, 24], [12, 45, 15, 28, 46, 16], [3, 147, 117, 10, 148, 118], [3, 73, 45, 23, 74, 46], [4, 54, 24, 31, 55, 25], [11, 45, 15, 31, 46, 16], [7, 146, 116, 7, 147, 117], [21, 73, 45, 7, 74, 46], [1, 53, 23, 37, 54, 24], [19, 45, 15, 26, 46, 16], [5, 145, 115, 10, 146, 116], [19, 75, 47, 10, 76, 48], [15, 54, 24, 25, 55, 25], [23, 45, 15, 25, 46, 16], [13, 145, 115, 3, 146, 116], [2, 74, 46, 29, 75, 47], [42, 54, 24, 1, 55, 25], [23, 45, 15, 28, 46, 16], [17, 145, 115], [10, 74, 46, 23, 75, 47], [10, 54, 24, 35, 55, 25], [19, 45, 15, 35, 46, 16], [17, 145, 115, 1, 146, 116], [14, 74, 46, 21, 75, 47], [29, 54, 24, 19, 55, 25], [11, 45, 15, 46, 46, 16], [13, 145, 115, 6, 146, 116], [14, 74, 46, 23, 75, 47], [44, 54, 24, 7, 55, 25], [59, 46, 16, 1, 47, 17], [12, 151, 121, 7, 152, 122], [12, 75, 47, 26, 76, 48], [39, 54, 24, 14, 55, 25], [22, 45, 15, 41, 46, 16], [6, 151, 121, 14, 152, 122], [6, 75, 47, 34, 76, 48], [46, 54, 24, 10, 55, 25], [2, 45, 15, 64, 46, 16], [17, 152, 122, 4, 153, 123], [29, 74, 46, 14, 75, 47], [49, 54, 24, 10, 55, 25], [24, 45, 15, 46, 46, 16], [4, 152, 122, 18, 153, 123], [13, 74, 46, 32, 75, 47], [48, 54, 24, 14, 55, 25], [42, 45, 15, 32, 46, 16], [20, 147, 117, 4, 148, 118], [40, 75, 47, 7, 76, 48], [43, 54, 24, 22, 55, 25], [10, 45, 15, 67, 46, 16], [19, 148, 118, 6, 149, 119], [18, 75, 47, 31, 76, 48], [34, 54, 24, 34, 55, 25], [20, 45, 15, 61, 46, 16]], l.getRSBlocks = function (e, t) {
                var i = l.getRsBlockTable(e, t);
                if (void 0 == i) throw new Error("bad rs block @ typeNumber:" + e + "/errorCorrectLevel:" + t);
                for (var n = i.length / 3, r = [], o = 0; o < n; o++) for (var s = i[3 * o + 0], a = i[3 * o + 1], c = i[3 * o + 2], u = 0; u < s; u++) r.push(new l(a, c));
                return r
            }, l.getRsBlockTable = function (e, t) {
                switch (t) {
                    case r.L:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 0];
                    case r.M:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 1];
                    case r.Q:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 2];
                    case r.H:
                        return l.RS_BLOCK_TABLE[4 * (e - 1) + 3];
                    default:
                        return
                }
            }, d.prototype = {
                get: function (e) {
                    var t = Math.floor(e / 8);
                    return 1 == (this.buffer[t] >>> 7 - e % 8 & 1)
                }, put: function (e, t) {
                    for (var i = 0; i < t; i++) this.putBit(1 == (e >>> t - i - 1 & 1))
                }, getLengthInBits: function () {
                    return this.length
                }, putBit: function (e) {
                    var t = Math.floor(this.length / 8);
                    this.buffer.length <= t && this.buffer.push(0), e && (this.buffer[t] |= 128 >>> this.length % 8), this.length++
                }
            };
            var h = [[17, 14, 11, 7], [32, 26, 20, 14], [53, 42, 32, 24], [78, 62, 46, 34], [106, 84, 60, 44], [134, 106, 74, 58], [154, 122, 86, 64], [192, 152, 108, 84], [230, 180, 130, 98], [271, 213, 151, 119], [321, 251, 177, 137], [367, 287, 203, 155], [425, 331, 241, 177], [458, 362, 258, 194], [520, 412, 292, 220], [586, 450, 322, 250], [644, 504, 364, 280], [718, 560, 394, 310], [792, 624, 442, 338], [858, 666, 482, 382], [929, 711, 509, 403], [1003, 779, 565, 439], [1091, 857, 611, 461], [1171, 911, 661, 511], [1273, 997, 715, 535], [1367, 1059, 751, 593], [1465, 1125, 805, 625], [1528, 1190, 868, 658], [1628, 1264, 908, 698], [1732, 1370, 982, 742], [1840, 1452, 1030, 790], [1952, 1538, 1112, 842], [2068, 1628, 1168, 898], [2188, 1722, 1228, 958], [2303, 1809, 1283, 983], [2431, 1911, 1351, 1051], [2563, 1989, 1423, 1093], [2699, 2099, 1499, 1139], [2809, 2213, 1579, 1219], [2953, 2331, 1663, 1273]];

            function p() {
                return "undefined" != typeof CanvasRenderingContext2D
            }

            function f() {
                var e = !1, t = navigator.userAgent;
                if (/android/i.test(t)) {
                    e = !0;
                    var i = t.toString().match(/android ([0-9]\.[0-9])/i);
                    i && i[1] && (e = parseFloat(i[1]))
                }
                return e
            }

            var m = function () {
                var e = function (e, t) {
                    this._el = e, this._htOption = t
                };
                return e.prototype.draw = function (e) {
                    var t = this._htOption, i = this._el, n = e.getModuleCount();
                    Math.floor(t.width / n), Math.floor(t.height / n);

                    function r(e, t) {
                        var i = document.createElementNS("http://www.w3.org/2000/svg", e);
                        for (var n in t) t.hasOwnProperty(n) && i.setAttribute(n, t[n]);
                        return i
                    }

                    this.clear();
                    var o = r("svg", {
                        viewBox: "0 0 " + String(n) + " " + String(n),
                        width: "100%",
                        height: "100%",
                        fill: t.colorLight
                    });
                    o.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:xlink", "http://www.w3.org/1999/xlink"), i.appendChild(o), o.appendChild(r("rect", {
                        fill: t.colorLight,
                        width: "100%",
                        height: "100%"
                    })), o.appendChild(r("rect", {fill: t.colorDark, width: "1", height: "1", id: "template"}));
                    for (var s = 0; s < n; s++) for (var a = 0; a < n; a++) if (e.isDark(s, a)) {
                        var c = r("use", {x: String(a), y: String(s)});
                        c.setAttributeNS("http://www.w3.org/1999/xlink", "href", "#template"), o.appendChild(c)
                    }
                }, e.prototype.clear = function () {
                    while (this._el.hasChildNodes()) this._el.removeChild(this._el.lastChild)
                }, e
            }(), v = "svg" === document.documentElement.tagName.toLowerCase(), y = v ? m : p() ? function () {
                function e() {
                    this._elImage.src = this._elCanvas.toDataURL("image/png"), this._elImage.style.display = "block", this._elCanvas.style.display = "none"
                }

                if (this._android && this._android <= 2.1) {
                    var t = 1 / window.devicePixelRatio, i = CanvasRenderingContext2D.prototype.drawImage;
                    CanvasRenderingContext2D.prototype.drawImage = function (e, n, r, o, s, a, c, u, l) {
                        if ("nodeName" in e && /img/i.test(e.nodeName)) for (var d = arguments.length - 1; d >= 1; d--) arguments[d] = arguments[d] * t; else "undefined" == typeof u && (arguments[1] *= t, arguments[2] *= t, arguments[3] *= t, arguments[4] *= t);
                        i.apply(this, arguments)
                    }
                }

                function n(e, t) {
                    var i = this;
                    if (i._fFail = t, i._fSuccess = e, null === i._bSupportDataURI) {
                        var n = document.createElement("img"), r = function () {
                            i._bSupportDataURI = !1, i._fFail && i._fFail.call(i)
                        }, o = function () {
                            i._bSupportDataURI = !0, i._fSuccess && i._fSuccess.call(i)
                        };
                        return n.onabort = r, n.onerror = r, n.onload = o, void (n.src = "data:image/gif;base64,iVBORw0KGgoAAAANSUhEUgAAAAUAAAAFCAYAAACNbyblAAAAHElEQVQI12P4//8/w38GIAXDIBKE0DHxgljNBAAO9TXL0Y4OHwAAAABJRU5ErkJggg==")
                    }
                    !0 === i._bSupportDataURI && i._fSuccess ? i._fSuccess.call(i) : !1 === i._bSupportDataURI && i._fFail && i._fFail.call(i)
                }

                var r = function (e, t) {
                    this._bIsPainted = !1, this._android = f(), this._htOption = t, this._elCanvas = document.createElement("canvas"), this._elCanvas.width = t.width, this._elCanvas.height = t.height, e.appendChild(this._elCanvas), this._el = e, this._oContext = this._elCanvas.getContext("2d"), this._bIsPainted = !1, this._elImage = document.createElement("img"), this._elImage.alt = "Scan me!", this._elImage.style.display = "none", this._el.appendChild(this._elImage), this._bSupportDataURI = null
                };
                return r.prototype.draw = function (e) {
                    var t = this._elImage, i = this._oContext, n = this._htOption, r = e.getModuleCount(),
                        o = n.width / r, s = n.height / r, a = Math.round(o), c = Math.round(s);
                    t.style.display = "none", this.clear();
                    for (var u = 0; u < r; u++) for (var l = 0; l < r; l++) {
                        var d = e.isDark(u, l), h = l * o, p = u * s;
                        i.strokeStyle = d ? n.colorDark : n.colorLight, i.lineWidth = 1, i.fillStyle = d ? n.colorDark : n.colorLight, i.fillRect(h, p, o, s), i.strokeRect(Math.floor(h) + .5, Math.floor(p) + .5, a, c), i.strokeRect(Math.ceil(h) - .5, Math.ceil(p) - .5, a, c)
                    }
                    this._bIsPainted = !0
                }, r.prototype.makeImage = function () {
                    this._bIsPainted && n.call(this, e)
                }, r.prototype.isPainted = function () {
                    return this._bIsPainted
                }, r.prototype.clear = function () {
                    this._oContext.clearRect(0, 0, this._elCanvas.width, this._elCanvas.height), this._bIsPainted = !1
                }, r.prototype.round = function (e) {
                    return e ? Math.floor(1e3 * e) / 1e3 : e
                }, r
            }() : function () {
                var e = function (e, t) {
                    this._el = e, this._htOption = t
                };
                return e.prototype.draw = function (e) {
                    for (var t = this._htOption, i = this._el, n = e.getModuleCount(), r = Math.floor(t.width / n), o = Math.floor(t.height / n), s = ['<table style="border:0;border-collapse:collapse;">'], a = 0; a < n; a++) {
                        s.push("<tr>");
                        for (var c = 0; c < n; c++) s.push('<td style="border:0;border-collapse:collapse;padding:0;margin:0;width:' + r + "px;height:" + o + "px;background-color:" + (e.isDark(a, c) ? t.colorDark : t.colorLight) + ';"></td>');
                        s.push("</tr>")
                    }
                    s.push("</table>"), i.innerHTML = s.join("");
                    var u = i.childNodes[0], l = (t.width - u.offsetWidth) / 2, d = (t.height - u.offsetHeight) / 2;
                    l > 0 && d > 0 && (u.style.margin = d + "px " + l + "px")
                }, e.prototype.clear = function () {
                    this._el.innerHTML = ""
                }, e
            }();

            function g(e, t) {
                for (var i = 1, n = T(e), o = 0, s = h.length; o <= s; o++) {
                    var a = 0;
                    switch (t) {
                        case r.L:
                            a = h[o][0];
                            break;
                        case r.M:
                            a = h[o][1];
                            break;
                        case r.Q:
                            a = h[o][2];
                            break;
                        case r.H:
                            a = h[o][3];
                            break
                    }
                    if (n <= a) break;
                    i++
                }
                if (i > h.length) throw new Error("Too long data");
                return i
            }

            function T(e) {
                var t = encodeURI(e).toString().replace(/\%[0-9a-fA-F]{2}/g, "a");
                return t.length + (t.length != e ? 3 : 0)
            }

            return n = function (e, t) {
                if (this._htOption = {
                    width: 256,
                    height: 256,
                    typeNumber: 4,
                    colorDark: "#000000",
                    colorLight: "#ffffff",
                    correctLevel: r.H
                }, "string" === typeof t && (t = {text: t}), t) for (var i in t) this._htOption[i] = t[i];
                "string" == typeof e && (e = document.getElementById(e)), this._htOption.useSVG && (y = m), this._android = f(), this._el = e, this._oQRCode = null, this._oDrawing = new y(this._el, this._htOption), this._htOption.text && this.makeCode(this._htOption.text)
            }, n.prototype.makeCode = function (e) {
                this._oQRCode = new t(g(e, this._htOption.correctLevel), this._htOption.correctLevel), this._oQRCode.addData(e), this._oQRCode.make(), this._el.title = e, this._oDrawing.draw(this._oQRCode), this.makeImage()
            }, n.prototype.makeImage = function () {
                "function" == typeof this._oDrawing.makeImage && (!this._android || this._android >= 3) && this._oDrawing.makeImage()
            }, n.prototype.clear = function () {
                this._oDrawing.clear()
            }, n.CorrectLevel = r, n
        }))
    }, d26f: function (e, t, i) {
        "use strict";
        var n = i("9fee"), r = i.n(n);
        r.a
    }, d5e5: function (e, t, i) {
        "use strict";
        e.exports = {
            isObject: function (e) {
                var t = typeof e;
                return "function" === t || "object" === t && !!e
            }, extend: function (e) {
                if (!this.isObject(e)) return e;
                for (var t, i, n = 1, r = arguments.length; n < r; n++) for (i in t = arguments[n], t) Object.prototype.hasOwnProperty.call(t, i) && (e[i] = t[i]);
                return e
            }
        }
    }, d8d69: function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("ada0").EventEmitter, r = i("3fb5"), o = i("c282"), s = i("621f"), a = t.XMLHttpRequest,
                c = function () {
                };

            function u(e, t, i, r) {
                c(e, t);
                var o = this;
                n.call(this), setTimeout((function () {
                    o._start(e, t, i, r)
                }), 0)
            }

            r(u, n), u.prototype._start = function (e, t, i, n) {
                var r = this;
                try {
                    this.xhr = new a
                } catch (d) {
                }
                if (!this.xhr) return c("no xhr"), this.emit("finish", 0, "no xhr support"), void this._cleanup();
                t = s.addQuery(t, "t=" + +new Date), this.unloadRef = o.unloadAdd((function () {
                    c("unload cleanup"), r._cleanup(!0)
                }));
                try {
                    this.xhr.open(e, t, !0), this.timeout && "timeout" in this.xhr && (this.xhr.timeout = this.timeout, this.xhr.ontimeout = function () {
                        c("xhr timeout"), r.emit("finish", 0, ""), r._cleanup(!1)
                    })
                } catch (h) {
                    return c("exception", h), this.emit("finish", 0, ""), void this._cleanup(!1)
                }
                if (n && n.noCredentials || !u.supportsCORS || (c("withCredentials"), this.xhr.withCredentials = !0), n && n.headers) for (var l in n.headers) this.xhr.setRequestHeader(l, n.headers[l]);
                this.xhr.onreadystatechange = function () {
                    if (r.xhr) {
                        var e, t, i = r.xhr;
                        switch (c("readyState", i.readyState), i.readyState) {
                            case 3:
                                try {
                                    t = i.status, e = i.responseText
                                } catch (h) {
                                }
                                c("status", t), 1223 === t && (t = 204), 200 === t && e && e.length > 0 && (c("chunk"), r.emit("chunk", t, e));
                                break;
                            case 4:
                                t = i.status, c("status", t), 1223 === t && (t = 204), 12005 !== t && 12029 !== t || (t = 0), c("finish", t, i.responseText), r.emit("finish", t, i.responseText), r._cleanup(!1);
                                break
                        }
                    }
                };
                try {
                    r.xhr.send(i)
                } catch (h) {
                    r.emit("finish", 0, ""), r._cleanup(!1)
                }
            }, u.prototype._cleanup = function (e) {
                if (c("cleanup"), this.xhr) {
                    if (this.removeAllListeners(), o.unloadDel(this.unloadRef), this.xhr.onreadystatechange = function () {
                    }, this.xhr.ontimeout && (this.xhr.ontimeout = null), e) try {
                        this.xhr.abort()
                    } catch (t) {
                    }
                    this.unloadRef = this.xhr = null
                }
            }, u.prototype.close = function () {
                c("close"), this._cleanup(!0)
            }, u.enabled = !!a;
            var l = ["Active"].concat("Object").join("X");
            !u.enabled && l in t && (c("overriding xmlhttprequest"), a = function () {
                try {
                    return new t[l]("Microsoft.XMLHTTP")
                } catch (e) {
                    return null
                }
            }, u.enabled = !!new a);
            var d = !1;
            try {
                d = "withCredentials" in new a
            } catch (h) {
            }
            u.supportsCORS = d, e.exports = u
        }).call(this, i("c8ba"))
    }, df09: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("d8d69");

        function o(e, t, i, n) {
            r.call(this, e, t, i, n)
        }

        n(o, r), o.enabled = r.enabled && r.supportsCORS, e.exports = o
    }, dfcd: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0IArs4c6QAAARZJREFUOBHlkkFLAkEUgHdyDx3VDoKQ4E0Jb56DTCgKoYN4qR8R/Y7wFP0LIdglwpOHDt77A0t1SAxPHrqt3yxvhp1xQe8NfL5533sz485uEHgjTdMh3Hg6wN3Bpe8PfEGum7YacdfQB2cUbeA07EqcDfiLIQsasCpY+ItrSY8th4hzsp6YE2IVXiXPhwnJI8SsSaTwpk88hraIH+KTUupdchtwMxbeIwZwJIWSbfjHE8XFnPH85i0smL9wYd9Fd0JvF38FFalP9VtoQkfEBXFE4y2bfInLAu6UyRjWYA4oZ0XzQ1MD5vBgnIm4Z4jg0DgdnS+RUz9xCdTBHzXEBz1/+YKzQb6w71zfgT9ixNKX5BGYZ7flDQm0WV3DIlGvAAAAAElFTkSuQmCC"
    }, e2b3: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("7577"), o = i("1548"), s = i("df09"), a = i("73aa");

        function c(e) {
            if (!a.enabled && !s.enabled) throw new Error("Transport created when disabled");
            r.call(this, e, "/xhr", o, s)
        }

        n(c, r), c.enabled = function (e) {
            return !e.nullOrigin && (!(!a.enabled || !e.sameOrigin) || s.enabled)
        }, c.transportName = "xhr-polling", c.roundTrips = 2, e.exports = c
    }, e362: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("9a833");

        function o() {
            r.call(this), this.initEvent("close", !1, !1), this.wasClean = !1, this.code = 0, this.reason = ""
        }

        n(o, r), e.exports = o
    }, e556: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("7577"), o = i("b185"), s = i("1548"), a = i("9d7d");

        function c(e) {
            if (!a.enabled) throw new Error("Transport created when disabled");
            r.call(this, e, "/xhr", s, a)
        }

        n(c, r), c.enabled = o.enabled, c.transportName = "xdr-polling", c.roundTrips = 2, e.exports = c
    }, e998: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("ada0").EventEmitter, o = function () {
        };

        function s(e, t) {
            o(e), r.call(this), this.sendBuffer = [], this.sender = t, this.url = e
        }

        n(s, r), s.prototype.send = function (e) {
            o("send", e), this.sendBuffer.push(e), this.sendStop || this.sendSchedule()
        }, s.prototype.sendScheduleWait = function () {
            o("sendScheduleWait");
            var e, t = this;
            this.sendStop = function () {
                o("sendStop"), t.sendStop = null, clearTimeout(e)
            }, e = setTimeout((function () {
                o("timeout"), t.sendStop = null, t.sendSchedule()
            }), 25)
        }, s.prototype.sendSchedule = function () {
            o("sendSchedule", this.sendBuffer.length);
            var e = this;
            if (this.sendBuffer.length > 0) {
                var t = "[" + this.sendBuffer.join(",") + "]";
                this.sendStop = this.sender(this.url, t, (function (t) {
                    e.sendStop = null, t ? (o("error", t), e.emit("close", t.code || 1006, "Sending error: " + t), e.close()) : e.sendScheduleWait()
                })), this.sendBuffer = []
            }
        }, s.prototype._cleanup = function () {
            o("_cleanup"), this.removeAllListeners()
        }, s.prototype.close = function () {
            o("close"), this._cleanup(), this.sendStop && (this.sendStop(), this.sendStop = null)
        }, e.exports = s
    }, eeb5: function (e, t) {
        e.exports = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABIAAAAkCAYAAACE7WrnAAAAAXNSR0IArs4c6QAAAeNJREFUSA2tlj9PwkAYxq/asDBQVxM/gBMhbBg3OhgccMBvYRxM+BAmJhq/hQwyaBw6oiyEECZ3THC0RFlITX0ewpHCXWmveMnl7t6+97v3zzXvWdVq9VsIMV70kWVZXi6Xe0b7gix1swAKNdoBZB1A7z3Pe9R8V0RxoKUiYF0smgC+LYWayY5GtiIKw7CC/uq67m2j0dhd+RhZJIKkLmCXvu+/1Ot1R8qiY2oQNwHmTqfTrg5mBFrADgF7WHfTGCQtg5s3nMuWCcTNjBkScLQ1aAG4/hcQrKrAqjPCFNcGg4Ho9XpiNpvJwzaOgF1oQUEQiMlkIvr9flrYca1W21MsKhaLIp/PC6Q4LcyG9acKCH++KJfLpjBXAdFfUxjidKAFZYDtx4J0sOFwSLGubQbpdsTIwo0W8S7xGjCDzCQzGtM+Y0HrEGaSSYhpYy3IEEL2SAFlgAhWHgXEzMiYJLgjvQxYvmy5kqNt26JQKMwDuyEmUp1jhzVQAZVKpahS4py1j0qKa4k7IwqsebKAbgUCsym5mUGw5i5afTOBmG7Hca6kNRyNQYC843c5b7Vav5lBtASQSrvd9qMQI4sYE7hzooMQpNyj9ZMASPWsiQMZP7QI+kGfP/1w+gfmfPo9mT79/gCn2eyLErrc3gAAAABJRU5ErkJggg=="
    }, f1f8: function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("c282"), r = i("930c"), o = i("26a0"), s = function () {
            };
            e.exports = {
                WPrefix: "_jp", currentWindowId: null, polluteGlobalNamespace: function () {
                    e.exports.WPrefix in t || (t[e.exports.WPrefix] = {})
                }, postMessage: function (i, n) {
                    t.parent !== t ? t.parent.postMessage(r.stringify({
                        windowId: e.exports.currentWindowId,
                        type: i,
                        data: n || ""
                    }), "*") : s("Cannot postMessage, no parent window.", i, n)
                }, createIframe: function (e, i) {
                    var r, o, a = t.document.createElement("iframe"), c = function () {
                        s("unattach"), clearTimeout(r);
                        try {
                            a.onload = null
                        } catch (e) {
                        }
                        a.onerror = null
                    }, u = function () {
                        s("cleanup"), a && (c(), setTimeout((function () {
                            a && a.parentNode.removeChild(a), a = null
                        }), 0), n.unloadDel(o))
                    }, l = function (e) {
                        s("onerror", e), a && (u(), i(e))
                    }, d = function (e, t) {
                        s("post", e, t), setTimeout((function () {
                            try {
                                a && a.contentWindow && a.contentWindow.postMessage(e, t)
                            } catch (i) {
                            }
                        }), 0)
                    };
                    return a.src = e, a.style.display = "none", a.style.position = "absolute", a.onerror = function () {
                        l("onerror")
                    }, a.onload = function () {
                        s("onload"), clearTimeout(r), r = setTimeout((function () {
                            l("onload timeout")
                        }), 2e3)
                    }, t.document.body.appendChild(a), r = setTimeout((function () {
                        l("timeout")
                    }), 15e3), o = n.unloadAdd(u), {post: d, cleanup: u, loaded: c}
                }, createHtmlfile: function (i, r) {
                    var o, a, c, u = ["Active"].concat("Object").join("X"), l = new t[u]("htmlfile"), d = function () {
                        clearTimeout(o), c.onerror = null
                    }, h = function () {
                        l && (d(), n.unloadDel(a), c.parentNode.removeChild(c), c = l = null, CollectGarbage())
                    }, p = function (e) {
                        s("onerror", e), l && (h(), r(e))
                    }, f = function (e, t) {
                        try {
                            setTimeout((function () {
                                c && c.contentWindow && c.contentWindow.postMessage(e, t)
                            }), 0)
                        } catch (i) {
                        }
                    };
                    l.open(), l.write('<html><script>document.domain="' + t.document.domain + '";<\/script></html>'), l.close(), l.parentWindow[e.exports.WPrefix] = t[e.exports.WPrefix];
                    var m = l.createElement("div");
                    return l.body.appendChild(m), c = l.createElement("iframe"), m.appendChild(c), c.src = i, c.onerror = function () {
                        p("onerror")
                    }, o = setTimeout((function () {
                        p("timeout")
                    }), 15e3), a = n.unloadAdd(h), {post: f, cleanup: h, loaded: d}
                }
            }, e.exports.iframeEnabled = !1, t.document && (e.exports.iframeEnabled = ("function" === typeof t.postMessage || "object" === typeof t.postMessage) && !o.isKonqueror())
        }).call(this, i("c8ba"))
    }, f701: function (e, t, i) {
        "use strict";
        var n = i("ada0").EventEmitter, r = i("3fb5");

        function o() {
            var e = this;
            n.call(this), this.to = setTimeout((function () {
                e.emit("finish", 200, "{}")
            }), o.timeout)
        }

        r(o, n), o.prototype.close = function () {
            clearTimeout(this.to)
        }, o.timeout = 2e3, e.exports = o
    }, f7a9: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("621f"), o = i("e998"), s = i("0e88"), a = function () {
        };

        function c(e, t, i, n, c) {
            var u = r.addPath(e, t);
            a(u);
            var l = this;
            o.call(this, e, i), this.poll = new s(n, u, c), this.poll.on("message", (function (e) {
                a("poll message", e), l.emit("message", e)
            })), this.poll.once("close", (function (e, t) {
                a("poll close", e, t), l.poll = null, l.emit("close", e, t), l.close()
            }))
        }

        n(c, o), c.prototype.close = function () {
            o.prototype.close.call(this), a("close"), this.removeAllListeners(), this.poll && (this.poll.abort(), this.poll = null)
        }, e.exports = c
    }, f84c: function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("3fb5"), r = i("f7a9"), o = i("f9f5"), s = i("bf4a");

            function a(e) {
                if (!a.enabled()) throw new Error("Transport created when disabled");
                r.call(this, e, "/jsonp", s, o)
            }

            n(a, r), a.enabled = function () {
                return !!t.document
            }, a.transportName = "jsonp-polling", a.roundTrips = 1, a.needBody = !0, e.exports = a
        }).call(this, i("c8ba"))
    }, f91e: function (e, t, i) {
        "use strict";
        var n = i("3fb5"), r = i("ada0").EventEmitter, o = i("ca34"), s = function () {
        };

        function a(e) {
            s(e), r.call(this);
            var t = this, i = this.es = new o(e);
            i.onmessage = function (e) {
                s("message", e.data), t.emit("message", decodeURI(e.data))
            }, i.onerror = function (e) {
                s("error", i.readyState, e);
                var n = 2 !== i.readyState ? "network" : "permanent";
                t._cleanup(), t._close(n)
            }
        }

        n(a, r), a.prototype.abort = function () {
            s("abort"), this._cleanup(), this._close("user")
        }, a.prototype._cleanup = function () {
            s("cleanup");
            var e = this.es;
            e && (e.onmessage = e.onerror = null, e.close(), this.es = null)
        }, a.prototype._close = function (e) {
            s("close", e);
            var t = this;
            setTimeout((function () {
                t.emit("close", null, e), t.removeAllListeners()
            }), 200)
        }, e.exports = a
    }, f9f5: function (e, t, i) {
        "use strict";
        (function (t) {
            var n = i("f1f8"), r = i("2582"), o = i("26a0"), s = i("621f"), a = i("3fb5"), c = i("ada0").EventEmitter,
                u = function () {
                };

            function l(e) {
                u(e);
                var i = this;
                c.call(this), n.polluteGlobalNamespace(), this.id = "a" + r.string(6);
                var o = s.addQuery(e, "c=" + encodeURIComponent(n.WPrefix + "." + this.id));
                t[n.WPrefix][this.id] = this._callback.bind(this), this._createScript(o), this.timeoutId = setTimeout((function () {
                    u("timeout"), i._abort(new Error("JSONP script loaded abnormally (timeout)"))
                }), l.timeout)
            }

            a(l, c), l.prototype.abort = function () {
                if (u("abort"), t[n.WPrefix][this.id]) {
                    var e = new Error("JSONP user aborted read");
                    e.code = 1e3, this._abort(e)
                }
            }, l.timeout = 35e3, l.scriptErrorTimeout = 1e3, l.prototype._callback = function (e) {
                u("_callback", e), this._cleanup(), this.aborting || (e && (u("message", e), this.emit("message", e)), this.emit("close", null, "network"), this.removeAllListeners())
            }, l.prototype._abort = function (e) {
                u("_abort", e), this._cleanup(), this.aborting = !0, this.emit("close", e.code, e.message), this.removeAllListeners()
            }, l.prototype._cleanup = function () {
                if (u("_cleanup"), clearTimeout(this.timeoutId), this.script2 && (this.script2.parentNode.removeChild(this.script2), this.script2 = null), this.script) {
                    var e = this.script;
                    e.parentNode.removeChild(e), e.onreadystatechange = e.onerror = e.onload = e.onclick = null, this.script = null
                }
                delete t[n.WPrefix][this.id]
            }, l.prototype._scriptError = function () {
                u("_scriptError");
                var e = this;
                this.errorTimer || (this.errorTimer = setTimeout((function () {
                    e.loadedOkay || e._abort(new Error("JSONP script loaded abnormally (onerror)"))
                }), l.scriptErrorTimeout))
            }, l.prototype._createScript = function (e) {
                u("_createScript", e);
                var i, n = this, s = this.script = t.document.createElement("script");
                if (s.id = "a" + r.string(8), s.src = e, s.type = "text/javascript", s.charset = "UTF-8", s.onerror = this._scriptError.bind(this), s.onload = function () {
                    u("onload"), n._abort(new Error("JSONP script loaded abnormally (onload)"))
                }, s.onreadystatechange = function () {
                    if (u("onreadystatechange", s.readyState), /loaded|closed/.test(s.readyState)) {
                        if (s && s.htmlFor && s.onclick) {
                            n.loadedOkay = !0;
                            try {
                                s.onclick()
                            } catch (e) {
                            }
                        }
                        s && n._abort(new Error("JSONP script loaded abnormally (onreadystatechange)"))
                    }
                }, "undefined" === typeof s.async && t.document.attachEvent) if (o.isOpera()) i = this.script2 = t.document.createElement("script"), i.text = "try{var a = document.getElementById('" + s.id + "'); if(a)a.onerror();}catch(x){};", s.async = i.async = !1; else {
                    try {
                        s.htmlFor = s.id, s.event = "onclick"
                    } catch (c) {
                    }
                    s.async = !0
                }
                "undefined" !== typeof s.async && (s.async = !0);
                var a = t.document.getElementsByTagName("head")[0];
                a.insertBefore(s, a.firstChild), i && a.insertBefore(i, a.firstChild)
            }, e.exports = l
        }).call(this, i("c8ba"))
    }
}]);
//# sourceMappingURL=coursePlay.db8c48fa.js.map